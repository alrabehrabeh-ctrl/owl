# تحليل شامل لنظام المستخدمين والأدوار والصلاحيات

## الملفات المهمة المراد فحصها:

### 1. نظام المستخدمين والأدوار والصلاحيات
- [ ] `server/db.ts` - دالة upsertUser وإنشاء المستخدمين
- [ ] `server/users-router.ts` - إجراءات إدارة المستخدمين
- [ ] `server/roles-router.ts` - إجراءات إدارة الأدوار
- [ ] `server/permissions-manager-router.ts` - إجراءات إدارة الصلاحيات
- [ ] `drizzle/schema.ts` - هيكل قاعدة البيانات

### 2. تسجيل الدخول والخروج وتبديل المستخدمين
- [ ] `server/routers.ts` - دوال logout و directLogin
- [ ] `client/src/_core/hooks/useAuth.ts` - دالة logout
- [ ] `client/src/components/UserCard.tsx` - تبديل المستخدم
- [ ] `server/_core/sdk.ts` - authenticateRequest و createSessionToken

### 3. تهيئة النظام والربط
- [ ] `server/_core/context.ts` - بناء context
- [ ] `client/src/App.tsx` - التطبيق الرئيسي
- [ ] `client/src/components/HorizontalNav.tsx` - الملاحة حسب الصلاحيات
- [ ] `client/src/pages/InitializationPage.tsx` - تهيئة النظام

## المشاكل المحتملة:
1. تضارب في إدارة الجلسات والبيانات
2. مشاكل في مسح البيانات عند تسجيل الخروج
3. أخطاء TypeScript في الروترز
4. مشاكل في ربط الصلاحيات مع الواجهة
