# خطة النشر والإطلاق
## مخبر النجاح للتعويضات السنية - نظام الإدارة والمحاسبة

**الإصدار:** 1.0  
**التاريخ:** 24 فبراير 2026  
**الحالة:** جاهز للنشر

---

## 📋 جدول المحتويات

1. [نظرة عامة على النشر](#نظرة-عامة-على-النشر)
2. [متطلبات النشر](#متطلبات-النشر)
3. [خطوات النشر](#خطوات-النشر)
4. [التحقق من النشر](#التحقق-من-النشر)
5. [خطة الإطلاق](#خطة-الإطلاق)
6. [خطة الطوارئ](#خطة-الطوارئ)

---

## نظرة عامة على النشر

### الهدف:
نشر نظام مخبر النجاح للتعويضات السنية على خادم الإنتاج بشكل آمن وموثوق.

### المراحل:
1. **التحضير:** إعداد البيئة والخوادم
2. **النشر:** نقل التطبيق إلى الخادم
3. **الاختبار:** التحقق من عمل جميع الميزات
4. **الإطلاق:** تفعيل النظام للمستخدمين
5. **المراقبة:** مراقبة الأداء والأخطاء

---

## متطلبات النشر

### المتطلبات الفنية:
- ✅ خادم Linux (Ubuntu 20.04+)
- ✅ Node.js 18.0+
- ✅ MySQL 8.0+ أو TiDB
- ✅ Nginx أو Apache
- ✅ شهادة SSL صالحة
- ✅ نطاق مسجل (Domain)
- ✅ بريد إلكتروني SMTP

### المتطلبات الإدارية:
- ✅ موافقة الإدارة العليا
- ✅ خطة الطوارئ معدة
- ✅ فريق الدعم جاهز
- ✅ نسخة احتياطية كاملة

### المتطلبات الأمنية:
- ✅ شهادة SSL
- ✅ جدار ناري (Firewall)
- ✅ نسخ احتياطية منتظمة
- ✅ نظام المراقبة

---

## خطوات النشر

### المرحلة 1: التحضير (قبل النشر بـ 48 ساعة)

#### 1.1 إعداد الخادم:
```bash
# تحديث النظام
sudo apt update && sudo apt upgrade -y

# تثبيت المتطلبات الأساسية
sudo apt install -y curl git wget build-essential

# تثبيت Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# تثبيت Nginx
sudo apt install -y nginx

# تثبيت MySQL
sudo apt install -y mysql-server
```

#### 1.2 إعداد قاعدة البيانات:
```bash
# إنشاء قاعدة البيانات
sudo mysql -e "CREATE DATABASE alnajah_dental;"
sudo mysql -e "CREATE USER 'alnajah'@'localhost' IDENTIFIED BY 'strong_password';"
sudo mysql -e "GRANT ALL PRIVILEGES ON alnajah_dental.* TO 'alnajah'@'localhost';"
sudo mysql -e "FLUSH PRIVILEGES;"
```

#### 1.3 إعداد النطاق والـ SSL:
```bash
# تثبيت Certbot
sudo apt install -y certbot python3-certbot-nginx

# الحصول على شهادة SSL
sudo certbot certonly --nginx -d yourdomain.com
```

#### 1.4 إعداد متغيرات البيئة:
```bash
# نسخ ملف البيئة
cp .env.example .env.production

# تعديل البيانات الحساسة
nano .env.production
```

**المتغيرات المهمة:**
```env
NODE_ENV=production
DATABASE_URL=mysql://alnajah:strong_password@localhost/alnajah_dental
JWT_SECRET=your_strong_secret_key
VITE_APP_TITLE=مخبر النجاح للتعويضات السنية
VITE_APP_LOGO=https://yourdomain.com/logo.png
```

### المرحلة 2: النشر (يوم النشر)

#### 2.1 استنساخ المستودع:
```bash
# إنشاء مجلد التطبيق
sudo mkdir -p /var/www/alnajah-dental
cd /var/www/alnajah-dental

# استنساخ المستودع
sudo git clone https://github.com/alnajah-dental/system.git .

# تغيير الملكية
sudo chown -R $USER:$USER /var/www/alnajah-dental
```

#### 2.2 تثبيت المتطلبات:
```bash
# تثبيت npm packages
npm install --production

# بناء التطبيق
npm run build
```

#### 2.3 تشغيل الهجرات:
```bash
# تطبيق الهجرات
npm run db:push

# إدراج البيانات الأساسية
npm run db:seed
```

#### 2.4 إعداد PM2 (لإدارة العملية):
```bash
# تثبيت PM2
sudo npm install -g pm2

# بدء التطبيق
pm2 start npm --name "alnajah-dental" -- start

# حفظ الإعدادات
pm2 save

# تفعيل البدء التلقائي
pm2 startup
```

#### 2.5 إعداد Nginx:
```bash
# إنشاء ملف الإعدادات
sudo nano /etc/nginx/sites-available/alnajah-dental
```

**محتوى الملف:**
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

#### 2.6 تفعيل الموقع:
```bash
# تفعيل الموقع
sudo ln -s /etc/nginx/sites-available/alnajah-dental /etc/nginx/sites-enabled/

# اختبار الإعدادات
sudo nginx -t

# إعادة تشغيل Nginx
sudo systemctl restart nginx
```

---

## التحقق من النشر

### 1. اختبار الاتصال:
```bash
# اختبار الخادم
curl -I https://yourdomain.com

# يجب أن تحصل على: HTTP/2 200
```

### 2. اختبار قاعدة البيانات:
```bash
# الاتصال بقاعدة البيانات
mysql -u alnajah -p alnajah_dental

# عرض الجداول
SHOW TABLES;
```

### 3. اختبار الميزات الأساسية:
- [ ] تسجيل الدخول
- [ ] عرض لوحة التحكم
- [ ] إضافة عمل جديد
- [ ] إضافة فاتورة
- [ ] عرض التقارير
- [ ] التنبيهات الصوتية

### 4. اختبار الأداء:
```bash
# اختبار السرعة
curl -w "@curl-format.txt" -o /dev/null -s https://yourdomain.com

# يجب أن تكون أقل من 3 ثوانٍ
```

---

## خطة الإطلاق

### المرحلة 1: الإطلاق المحدود (24 ساعة)
- **المستخدمون:** 5-10 مستخدمين تجريبيين
- **الهدف:** اختبار النظام في بيئة الإنتاج
- **المراقبة:** مراقبة مكثفة للأخطاء والأداء

### المرحلة 2: الإطلاق التدريجي (أسبوع واحد)
- **المستخدمون:** 50% من المستخدمين
- **الهدف:** التأكد من استقرار النظام
- **المراقبة:** مراقبة منتظمة

### المرحلة 3: الإطلاق الكامل (بعد أسبوع)
- **المستخدمون:** جميع المستخدمين
- **الهدف:** تفعيل النظام بشكل كامل
- **المراقبة:** مراقبة مستمرة

---

## خطة الطوارئ

### السيناريو 1: فشل النشر
**الإجراء:**
1. التراجع إلى الإصدار السابق
2. التحقق من الأخطاء
3. إصلاح المشاكل
4. إعادة النشر

### السيناريو 2: توقف الخادم
**الإجراء:**
1. إعادة تشغيل الخادم
2. التحقق من الخدمات
3. استعادة النسخة الاحتياطية إذا لزم الأمر

### السيناريو 3: فقدان البيانات
**الإجراء:**
1. استعادة من النسخة الاحتياطية
2. التحقق من سلامة البيانات
3. إخطار المستخدمين

### السيناريو 4: هجوم أمني
**الإجراء:**
1. عزل الخادم
2. تحليل الهجوم
3. تطبيق الإصلاحات الأمنية
4. استعادة النظام

---

## قائمة التحقق النهائية

- [ ] تم إعداد الخادم بالكامل
- [ ] تم تثبيت جميع المتطلبات
- [ ] تم إعداد قاعدة البيانات
- [ ] تم تثبيت شهادة SSL
- [ ] تم إعداد متغيرات البيئة
- [ ] تم بناء التطبيق بنجاح
- [ ] تم تطبيق الهجرات
- [ ] تم اختبار جميع الميزات
- [ ] تم إعداد النسخ الاحتياطية
- [ ] تم إعداد المراقبة
- [ ] تم إخطار المستخدمين
- [ ] تم تدريب فريق الدعم

---

## معلومات الاتصال في حالة الطوارئ

- **مسؤول النظام:** admin@alnajah-dental.com
- **فريق الدعم:** support@alnajah-dental.com
- **الهاتف الطارئ:** +966 XX XXX XXXX

---

**آخر تحديث:** 24 فبراير 2026  
**الإصدار:** 1.0  
**الحالة:** ✅ جاهز للنشر
