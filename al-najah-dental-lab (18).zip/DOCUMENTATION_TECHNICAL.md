# دليل تقني ومعمارية النظام

## نظرة عامة على المعمارية

نظام إدارة مخبر النجاح مبني على معمارية حديثة تفصل بين الواجهة الأمامية والخادم:

```
┌─────────────────────────────────────────────────────────────┐
│                     المتصفح (Frontend)                      │
│  React 19 + Tailwind CSS 4 + TypeScript + tRPC Client      │
└────────────────────┬────────────────────────────────────────┘
                     │ HTTP/WebSocket
                     │ tRPC API
┌────────────────────▼────────────────────────────────────────┐
│                  الخادم (Backend)                           │
│  Express 4 + tRPC 11 + Node.js + TypeScript                │
│  ├─ OAuth Authentication (Manus OAuth)                      │
│  ├─ Database Layer (Drizzle ORM)                            │
│  └─ Business Logic                                          │
└────────────────────┬────────────────────────────────────────┘
                     │ SQL
┌────────────────────▼────────────────────────────────────────┐
│              قاعدة البيانات (Database)                      │
│  MySQL / TiDB                                               │
└─────────────────────────────────────────────────────────────┘
```

---

## التكنولوجيا المستخدمة

### الواجهة الأمامية (Frontend)

| التكنولوجيا | الإصدار | الوصف |
|-----------|--------|-------|
| React | 19 | مكتبة بناء الواجهات |
| TypeScript | - | لغة برمجة محسّنة |
| Tailwind CSS | 4 | إطار عمل للتصميم |
| tRPC | 11 | نقل البيانات الآمن |
| Wouter | - | توجيه الصفحات |
| Shadcn/UI | - | مكونات واجهة جاهزة |

### الخادم (Backend)

| التكنولوجيا | الإصدار | الوصف |
|-----------|--------|-------|
| Node.js | 22 | بيئة تشغيل JavaScript |
| Express | 4 | إطار عمل الخادم |
| tRPC | 11 | نقل البيانات الآمن |
| Drizzle ORM | - | مكتبة الوصول للبيانات |
| TypeScript | - | لغة برمجة محسّنة |

### قاعدة البيانات

| التكنولوجيا | الوصف |
|-----------|-------|
| MySQL / TiDB | قاعدة بيانات علائقية |
| Drizzle Kit | أدوات إدارة الهجرات |

---

## هيكل المشروع

```
al-najah-dental-lab/
├── client/                          # الواجهة الأمامية
│   ├── src/
│   │   ├── pages/                   # صفحات التطبيق
│   │   │   ├── Home.tsx
│   │   │   ├── DoctorsPage.tsx
│   │   │   ├── WorksPage.tsx
│   │   │   ├── InvoicesPage.tsx
│   │   │   ├── PaymentsPage.tsx
│   │   │   ├── ExpensesPage.tsx
│   │   │   ├── EmployeesPage.tsx
│   │   │   ├── ReportsPage.tsx
│   │   │   └── ProfitDistributionPage.tsx
│   │   ├── components/              # مكونات قابلة لإعادة الاستخدام
│   │   │   ├── DashboardLayout.tsx
│   │   │   ├── TopBar.tsx
│   │   │   ├── HorizontalNav.tsx
│   │   │   └── ...
│   │   ├── lib/
│   │   │   └── trpc.ts              # إعدادات tRPC
│   │   ├── App.tsx                  # التطبيق الرئيسي
│   │   ├── main.tsx                 # نقطة الدخول
│   │   └── index.css                # الأنماط العامة
│   ├── public/                      # الملفات الثابتة
│   └── index.html
├── server/                          # الخادم
│   ├── routers.ts                   # إجراءات tRPC
│   ├── db.ts                        # دوال قاعدة البيانات
│   ├── _core/
│   │   ├── index.ts                 # نقطة دخول الخادم
│   │   ├── context.ts               # سياق tRPC
│   │   ├── oauth.ts                 # المصادقة
│   │   ├── env.ts                   # متغيرات البيئة
│   │   └── ...
│   └── *.test.ts                    # اختبارات الوحدة
├── drizzle/                         # قاعدة البيانات
│   ├── schema.ts                    # تعريف الجداول
│   └── migrations/                  # هجرات قاعدة البيانات
├── shared/                          # الكود المشترك
│   └── constants.ts
├── storage/                         # إدارة التخزين
│   └── index.ts
├── package.json                     # المتطلبات والنصوص
├── tsconfig.json                    # إعدادات TypeScript
└── vite.config.ts                   # إعدادات Vite
```

---

## جداول قاعدة البيانات

### جدول الأطباء (doctors)

```sql
CREATE TABLE doctors (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  licenseNumber VARCHAR(50),
  specialty VARCHAR(255),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### جدول الأعمال (works)

```sql
CREATE TABLE works (
  id INT PRIMARY KEY AUTO_INCREMENT,
  doctorId INT NOT NULL,
  description VARCHAR(255),
  patientName VARCHAR(255),
  dueDate DATE,
  completedDate DATE,
  quantity INT DEFAULT 1,
  unitPrice DECIMAL(10,2),
  totalPrice DECIMAL(10,2),
  status ENUM('pending', 'delivered') DEFAULT 'pending',
  notes TEXT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (doctorId) REFERENCES doctors(id)
);
```

### جدول الفواتير (invoices)

```sql
CREATE TABLE invoices (
  id INT PRIMARY KEY AUTO_INCREMENT,
  doctorId INT NOT NULL,
  invoiceDate DATE,
  dueDate DATE,
  totalAmount DECIMAL(10,2),
  paidAmount DECIMAL(10,2) DEFAULT 0,
  remainingAmount DECIMAL(10,2),
  status ENUM('pending', 'partial', 'paid') DEFAULT 'pending',
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (doctorId) REFERENCES doctors(id)
);
```

### جدول الدفعات (payments)

```sql
CREATE TABLE payments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  invoiceId INT NOT NULL,
  amount DECIMAL(10,2),
  paymentDate DATE,
  paymentMethod VARCHAR(50),
  notes TEXT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (invoiceId) REFERENCES invoices(id)
);
```

### جدول المصروفات (expenses)

```sql
CREATE TABLE expenses (
  id INT PRIMARY KEY AUTO_INCREMENT,
  category VARCHAR(50),
  description VARCHAR(255),
  amount DECIMAL(10,2),
  expenseDate DATE,
  notes TEXT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### جدول الموظفين (employees)

```sql
CREATE TABLE employees (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  position VARCHAR(255),
  monthlySalary DECIMAL(10,2),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### جدول الرواتب (salaries)

```sql
CREATE TABLE salaries (
  id INT PRIMARY KEY AUTO_INCREMENT,
  employeeId INT NOT NULL,
  amount DECIMAL(10,2),
  salaryDate DATE,
  notes TEXT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employeeId) REFERENCES employees(id)
);
```

---

## إجراءات tRPC الرئيسية

### إجراءات الأطباء

```typescript
doctors.list()              // جلب قائمة الأطباء
doctors.create(data)        // إضافة طبيب جديد
doctors.update(id, data)    // تعديل بيانات الطبيب
doctors.delete(id)          // حذف الطبيب
```

### إجراءات الأعمال

```typescript
works.list()                // جلب قائمة الأعمال
works.create(data)          // إضافة عمل جديد
works.update(id, data)      // تعديل العمل
works.delete(id)            // حذف العمل
```

### إجراءات الفواتير

```typescript
invoices.list()             // جلب قائمة الفواتير
invoices.getByDoctorAndDate(doctorId, year, month)  // جلب فواتير الطبيب للشهر
invoices.create(data)       // إنشاء فاتورة جديدة
invoices.update(id, data)   // تعديل الفاتورة
```

### إجراءات الدفعات

```typescript
payments.list()             // جلب قائمة الدفعات
payments.create(data)       // تسجيل دفعة جديدة
payments.delete(id)         // حذف الدفعة
```

---

## تدفق البيانات

### إضافة عمل جديد

```
1. المستخدم يملأ النموذج في الواجهة الأمامية
2. يتم إرسال البيانات عبر tRPC إلى الخادم
3. الخادم يتحقق من صحة البيانات
4. يتم إدراج العمل في قاعدة البيانات
5. يتم إرجاع العمل الجديد إلى الواجهة الأمامية
6. يتم تحديث قائمة الأعمال في الواجهة الأمامية
```

### إنشاء فاتورة

```
1. المستخدم يختار طبيب وشهر
2. يتم جلب جميع أعمال الطبيب للشهر من قاعدة البيانات
3. يتم حساب الإجمالي والمبالغ المدفوعة والمتبقية
4. يتم عرض الفاتورة في الواجهة الأمامية
5. يمكن تصدير الفاتورة كـ PDF أو Excel
```

### تسجيل دفعة

```
1. المستخدم يختار فاتورة ويدخل مبلغ الدفعة
2. يتم إرسال البيانات إلى الخادم
3. يتم إدراج الدفعة في قاعدة البيانات
4. يتم تحديث الفاتورة (المبلغ المدفوع والمتبقي والحالة)
5. يتم تحديث المديونيات الإجمالية
6. يتم تحديث الواجهة الأمامية
```

---

## المصادقة والأمان

### نظام المصادقة

يستخدم النظام Manus OAuth للمصادقة:

```
1. المستخدم يضغط على "تسجيل الدخول"
2. يتم إعادة التوجيه إلى صفحة Manus OAuth
3. المستخدم يدخل بيانات حسابه
4. يتم إرجاع التوكن إلى التطبيق
5. يتم حفظ التوكن في ملف تعريف الجلسة
6. يتم السماح للمستخدم بالوصول للتطبيق
```

### الأمان

- جميع الاتصالات مشفرة (HTTPS)
- كلمات المرور مشفرة في قاعدة البيانات
- الوصول محمي بنظام المصادقة
- تحقق من الصلاحيات على الخادم

---

## الاختبارات

### أنواع الاختبارات

يتم إجراء اختبارات الوحدة باستخدام Vitest:

```bash
pnpm test
```

### ملفات الاختبار

```
server/
├── auth.logout.test.ts
├── payments.test.ts
├── profit-distribution.test.ts
├── notifications-filter.test.ts
└── routers.test.ts
```

### تشغيل الاختبارات

```bash
# تشغيل جميع الاختبارات
pnpm test

# تشغيل اختبار محدد
pnpm test server/auth.logout.test.ts

# مراقبة الاختبارات
pnpm test --watch
```

---

## الأداء والتحسينات

### تحسينات الأداء

1. **التخزين المؤقت**: استخدام React Query للتخزين المؤقت للبيانات
2. **التحميل البطيء**: تحميل الصفحات عند الحاجة
3. **ضغط البيانات**: استخدام gzip لضغط البيانات
4. **قاعدة البيانات**: استخدام الفهارس لتسريع الاستعلامات

### مراقبة الأداء

يمكن مراقبة الأداء باستخدام:

- Chrome DevTools
- React DevTools
- Network Tab

---

## النشر والإنتاج

### متطلبات النشر

- Node.js 22 أو أحدث
- MySQL / TiDB
- متغيرات البيئة المطلوبة

### متغيرات البيئة

```
DATABASE_URL=mysql://user:password@host/database
JWT_SECRET=your-secret-key
VITE_APP_ID=your-app-id
OAUTH_SERVER_URL=https://api.manus.im
```

### خطوات النشر

```bash
# تثبيت المتطلبات
pnpm install

# بناء الواجهة الأمامية
pnpm build

# تشغيل الخادم
pnpm start
```

---

## استكشاف الأخطاء

### الأخطاء الشائعة

| الخطأ | السبب | الحل |
|------|------|------|
| خطأ في الاتصال بقاعدة البيانات | DATABASE_URL غير صحيح | تحقق من متغيرات البيئة |
| خطأ في المصادقة | التوكن منتهي الصلاحية | أعد تسجيل الدخول |
| خطأ في الحساب | بيانات غير صحيحة | تحقق من صحة البيانات |

### سجلات الأخطاء

يتم تسجيل الأخطاء في:

- `devserver.log` - سجلات الخادم
- `browserConsole.log` - سجلات المتصفح
- `networkRequests.log` - طلبات الشبكة

---

## الموارد والمراجع

- [React Documentation](https://react.dev)
- [TypeScript Documentation](https://www.typescriptlang.org/docs)
- [tRPC Documentation](https://trpc.io/docs)
- [Drizzle ORM Documentation](https://orm.drizzle.team)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)

---

