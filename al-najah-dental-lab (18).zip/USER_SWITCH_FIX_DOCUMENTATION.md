# توثيق إصلاح مشكلة تبديل المستخدم (User Switch Issues)

## المشكلة المكتشفة

عند إضافة ميزة "تبديل المستخدم" (Switch User) للمسؤولين، ظهرت مشاكل في تطبيق RBAC (Role-Based Access Control) على جميع المستخدمين.

### الأعراض:
1. ❌ عند تبديل المستخدم، قد تبقى بيانات المستخدم السابق مخزنة في localStorage
2. ❌ تضارب في عرض معلومات المستخدم الحالي في الواجهة
3. ❌ تأخر في تحديث الصلاحيات والأدوار بعد تبديل المستخدم
4. ❌ قد تظهر بيانات المستخدم القديم مؤقتاً قبل إعادة تحميل الصفحة

## تحليل المشكلة

### 1. في الواجهة الأمامية (Frontend)

**الملف**: client/src/components/UserCard.tsx

**المشكلة الأصلية** (سطور 20-27):
- عند نجاح تبديل المستخدم، يتم استدعاء window.location.reload() مباشرة
- لكن قبل إعادة التحميل، لا يتم مسح بيانات المستخدم السابق من localStorage
- هذا يسبب ظهور بيانات قديمة مؤقتاً عند إعادة تحميل الصفحة

### 2. في خادم المصادقة (Backend)

**الملف**: server/users-router.ts (سطور 233-300)

**الملاحظة**: الكود الخاص بالخادم صحيح - يقوم بحذف الجلسة القديمة وإنشاء جلسة جديدة.

### 3. في useAuth Hook

**الملف**: client/src/_core/hooks/useAuth.ts

**الملاحظة**: دالة logout تقوم بمسح البيانات بشكل صحيح، لكن دالة switchUser لا تفعل الشيء نفسه!

## الحل المطبق

### 1. تحديث UserCard.tsx

تم تحديث دالة switchUserMutation لمسح البيانات قبل إعادة تحميل الصفحة:

```typescript
const switchUserMutation = trpc.switchUser.switchUser.useMutation({
  onSuccess: () => {
    setShowUserList(false);
    setIsOpen(false);
    
    // مسح بيانات المستخدم السابق من localStorage
    localStorage.removeItem('manus-runtime-user-info');
    localStorage.removeItem('loginUsername');
    localStorage.removeItem('loginRememberMe');
    
    // مسح tRPC cache للمستخدم الحالي
    utils.auth.me.setData(undefined, null);
    
    // إعادة تحميل الصفحة لتحديث البيانات
    window.location.reload();
  },
  onError: (error) => {
    console.error("Failed to switch user:", error);
  },
});
```

### 2. الفوائد

✅ مسح كامل للبيانات القديمة
✅ تحديث tRPC Cache
✅ إعادة تحميل آمنة
✅ معالجة الأخطاء

## الملفات المعدلة

- client/src/components/UserCard.tsx: إضافة مسح بيانات localStorage و tRPC cache
- server/user-switch-data-cleanup.test.ts: اختبارات جديدة

## الخلاصة

تم حل المشكلة بإضافة مسح شامل لبيانات المستخدم السابق من localStorage و tRPC cache قبل إعادة تحميل الصفحة.
