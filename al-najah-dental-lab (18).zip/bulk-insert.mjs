import { getDb } from './server/db.ts';
import { works, doctors } from './drizzle/schema.ts';
import { eq } from 'drizzle-orm';
import XLSX from 'xlsx';

const db = await getDb();

const file = '/home/ubuntu/upload/جميعالاعمال.xlsx';
const workbook = XLSX.readFile(file);
const worksheet = workbook.Sheets[workbook.SheetNames[0]];
const data = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

let count = 0;
const errors = [];

for (let i = 1; i < data.length; i++) {
  const row = data[i];
  if (!row[0]) continue;
  
  try {
    const doctorName = row[1];
    const description = row[3];
    const status = row[4] && row[4] !== '-' ? row[4] : 'pending';
    const receptionDate = new Date(row[5]);
    const dueDate = new Date(row[6]);
    const totalPrice = parseFloat(row[7]) || 0;
    const patientName = row[2];
    
    // البحث عن الطبيب
    const doctor = await db.select().from(doctors).where(eq(doctors.name, doctorName)).limit(1);
    
    if (doctor.length > 0) {
      await db.insert(works).values({
        doctorId: doctor[0].id,
        workTypeId: 1,
        description,
        quantity: 1,
        unitPrice: 0,
        totalPrice,
        status,
        dueDate,
        receptionDate,
        patientName,
        toothNumbers: '-',
        notes: ''
      });
      count++;
      
      if (count % 50 === 0) {
        console.log(`✓ تم إدراج ${count} عمل`);
      }
    }
  } catch (err) {
    errors.push(`خطأ في الصف ${i}: ${err.message}`);
  }
}

console.log(`\n✓ تم إدراج ${count} عمل بنجاح`);
if (errors.length > 0) {
  console.log(`\n⚠️ أخطاء: ${errors.length}`);
  errors.slice(0, 5).forEach(e => console.log(`  - ${e}`));
}

process.exit(0);

