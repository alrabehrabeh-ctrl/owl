import mysql from "mysql2/promise";

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error("❌ DATABASE_URL غير محدد");
  process.exit(1);
}

async function main() {
  const connection = await mysql.createConnection(DATABASE_URL);
  
  // فحص عينة من البيانات
  const [rows] = await connection.execute(
    "SELECT id, doctorId, description, receptionDate, dueDate, createdAt FROM works LIMIT 10"
  ) as any;
  
  console.log("📊 عينة من البيانات:");
  rows.forEach((row: any) => {
    console.log(`  ID: ${row.id}, receptionDate: ${row.receptionDate}, dueDate: ${row.dueDate}`);
  });
  
  // فحص الإحصائيات
  const [stats] = await connection.execute(
    "SELECT COUNT(*) as total, SUM(CASE WHEN receptionDate IS NOT NULL AND receptionDate != '' THEN 1 ELSE 0 END) as withDates FROM works"
  ) as any;
  
  console.log("\n📊 الإحصائيات:");
  console.log(`  إجمالي الأعمال: ${stats[0].total}`);
  console.log(`  الأعمال بتواريخ: ${stats[0].withDates}`);
  
  await connection.end();
}

main().catch((error) => {
  console.error("❌ خطأ:", error);
  process.exit(1);
});

