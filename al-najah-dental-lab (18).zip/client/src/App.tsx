import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, Redirect } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import TopBar from "./components/TopBar";
import HorizontalNav from "./components/HorizontalNav";
import Home from "./pages/Home";
import DoctorsPage from "./pages/DoctorsPage";
import WorksPage from "./pages/WorksPage";
import InvoicesPage from "./pages/InvoicesPage";
import InvoicesListPage from "./pages/InvoicesListPage";
import PaymentsPage from "./pages/PaymentsPage";
import ExpensesPage from "./pages/ExpensesPage";
import EmployeesPage from "./pages/EmployeesPage";
import SalariesPage from "./pages/SalariesPage";
import ReportsPage from "./pages/ReportsPage";
import DashboardPage from "./pages/DashboardPage";
import ReceivablesPage from "./pages/ReceivablesPage";
import NotificationsPage from "./pages/NotificationsPage";
import ProfitDistributionPage from "./pages/ProfitDistributionPage";
import AboutPage from "./pages/AboutPage";
import Analytics from "./pages/Analytics";
import ForecastsPage from "./pages/ForecastsPage";
import CurrenciesPage from "./pages/CurrenciesPage";
import { ImportWorksPage } from "./pages/ImportWorksPage";
import MonthlyReportsPage from "./pages/MonthlyReportsPage";
import UsersPage from "./pages/UsersPage";
import RolesPage from "./pages/RolesPage";
import PermissionsManagerPage from "./pages/PermissionsManagerPage";
import PasswordManagementPage from "./pages/PasswordManagementPage";
import InitializationPage from "./pages/InitializationPage";
import BackupManagementPage from "./pages/BackupManagementPage";
import LoginPage from "./pages/LoginPage";
import { useAuth } from "@/_core/hooks/useAuth";
import { OverdueWorksAlert } from "./components/OverdueWorksAlert";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import ProtectedRoute from "./components/ProtectedRoute";

function Router() {
  const { isAuthenticated, user } = useAuth();
  const [location] = useLocation();
  
  const { data: doctors = [] } = trpc.doctors.list.useQuery(undefined, { enabled: isAuthenticated });
  const { data: worksData } = trpc.works.list.useQuery(undefined, { enabled: isAuthenticated });
  const { data: invoicesData } = trpc.invoices.list.useQuery(undefined, { enabled: isAuthenticated });
  
  const works = (Array.isArray(worksData) ? worksData : (worksData as any)?.data) || [];
  const invoices = (Array.isArray(invoicesData) ? invoicesData : (invoicesData as any)?.data) || [];
  const { data: receivablesData = 0 } = trpc.reports.getTotalReceivables.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  // حساب الأعمال حسب الحالة
  const pendingWorks = works.filter((w: any) => w.status === 'pending').length;
  const inProgressWorks = works.filter((w: any) => w.status === 'in_progress').length;
  const completedWorks = works.filter((w: any) => w.status === 'completed').length;

  // صفحات لا تحتاج إلى شرائط (Login, Home, 404)
  // تجاهل معاملات الاستعلام عند التحقق من الصفحة العامة
  const locationWithoutQuery = location.split('?')[0];
  const isPublicPage = locationWithoutQuery === '/login' || locationWithoutQuery === '/' || locationWithoutQuery === '/404';

  // إذا كان المستخدم غير مصرح، عرض صفحات عامة فقط
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/login" component={LoginPage} />
          <Route path="/undefined" component={() => <Redirect to="/" />} />
          <Route path="/404" component={NotFound} />
          <Route component={NotFound} />
        </Switch>
      </div>
    );
  }

  const receivables = typeof receivablesData === 'number' ? receivablesData : 0;

  // إذا كان المستخدم مصرح وعلى صفحة تسجيل الدخول، أعد التوجيه إلى لوحة التحكم
  if (locationWithoutQuery === '/login') {
    return (
      <div className="min-h-screen bg-gray-50">
        <Switch>
          <Route component={() => <Redirect to="/dashboard" />} />
        </Switch>
      </div>
    );
  }

  // إذا كان المستخدم مصرح وليس على صفحة عامة، عرض Dashboard مع الشرائط
  // ملاحظة: تم إيقاف نظام الصلاحيات مؤقتاً - جميع الصفحات متاحة لجميع المستخدمين
  return (
    <div className="min-h-screen bg-gray-50">
      <OverdueWorksAlert />
      <TopBar 
        doctorsCount={doctors.length} 
        worksCount={works.length} 
        invoicesCount={invoices.length} 
        receivables={receivables}
        pendingWorks={pendingWorks}
        inProgressWorks={inProgressWorks}
        completedWorks={completedWorks}
      />
      <HorizontalNav />
      <div className="max-w-7xl mx-auto px-6 py-8">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/undefined" component={() => <Redirect to="/" />} />
          <Route path="/doctors" component={DoctorsPage} />
          <Route path="/works" component={WorksPage} />
          <Route path="/invoices" component={InvoicesListPage} />
          <Route path="/invoices/monthly" component={InvoicesPage} />
          <Route path="/invoices/generate" component={InvoicesPage} />
          <Route path="/payments" component={PaymentsPage} />
          <Route path="/expenses" component={ExpensesPage} />
          <Route path="/employees" component={EmployeesPage} />
          <Route path="/salaries" component={SalariesPage} />
          <Route path="/reports" component={ReportsPage} />
          <Route path="/dashboard" component={DashboardPage} />
          <Route path="/receivables" component={ReceivablesPage} />
          <Route path="/notifications" component={NotificationsPage} />
          <Route path="/profit-distribution" component={ProfitDistributionPage} />
          <Route path="/about" component={AboutPage} />
          <Route path="/analytics" component={Analytics} />
          <Route path="/forecasts" component={ForecastsPage} />
          <Route path="/currencies" component={CurrenciesPage} />
          <Route path="/monthly-reports" component={MonthlyReportsPage} />
          <Route path="/users" component={(props) => <ProtectedRoute component={UsersPage} requiredRoles={['admin']} {...props} />} />
          <Route path="/roles" component={(props) => <ProtectedRoute component={RolesPage} requiredRoles={['admin']} {...props} />} />
          <Route path="/permissions-manager" component={(props) => <ProtectedRoute component={PermissionsManagerPage} requiredRoles={['admin']} {...props} />} />
          <Route path="/password-management" component={(props) => <ProtectedRoute component={PasswordManagementPage} requiredRoles={['admin']} {...props} />} />
          <Route path="/initialization" component={(props) => <ProtectedRoute component={InitializationPage} requiredRoles={['admin']} {...props} />} />
          <Route path="/backup-management" component={(props) => <ProtectedRoute component={BackupManagementPage} requiredRoles={['admin']} {...props} />} />
          <Route path="/import-works" component={ImportWorksPage} />
          <Route path="/404" component={NotFound} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
