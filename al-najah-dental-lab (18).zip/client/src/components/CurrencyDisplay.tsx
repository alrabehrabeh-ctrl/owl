import { trpc } from "@/lib/trpc";

interface CurrencyDisplayProps {
  amount: number;
  currencyId?: number;
  showBothCurrencies?: boolean;
  className?: string;
}

export function CurrencyDisplay({
  amount,
  currencyId = 1, // USD
  showBothCurrencies = true,
  className = "",
}: CurrencyDisplayProps) {
  const { data: currencies = [] } = trpc.currencies.getAll.useQuery();
  const { data: conversion } = trpc.currencies.convertAmount.useQuery(
    {
      amount,
      fromCurrencyId: currencyId,
      toCurrencyId: 2, // SYP
    },
    { enabled: showBothCurrencies && currencyId !== 2 }
  );

  const primaryCurrency = currencies.find((c) => c.id === currencyId);
  const secondaryCurrency = currencies.find((c) => c.id === 2);

  if (!primaryCurrency) {
    return <span className={className}>{amount}</span>;
  }

  return (
    <div className={className}>
      <div className="font-semibold">
        {primaryCurrency.symbol}
        {amount.toFixed(2)}
      </div>
      {showBothCurrencies && conversion?.convertedAmount && secondaryCurrency && (
        <div className="text-sm text-muted-foreground">
          {secondaryCurrency.symbol}
          {conversion.convertedAmount.toFixed(0)}
        </div>
      )}
    </div>
  );
}

interface CurrencyInputProps {
  value: number;
  onChange: (value: number) => void;
  currencyId?: number;
  onCurrencyChange?: (currencyId: number) => void;
  showConversion?: boolean;
  className?: string;
}

export function CurrencyInput({
  value,
  onChange,
  currencyId = 1,
  onCurrencyChange,
  showConversion = true,
  className = "",
}: CurrencyInputProps) {
  const { data: currencies = [] } = trpc.currencies.getAll.useQuery();
  const { data: conversion } = trpc.currencies.convertAmount.useQuery(
    {
      amount: value,
      fromCurrencyId: currencyId,
      toCurrencyId: 2,
    },
    { enabled: showConversion && currencyId !== 2 }
  );

  const primaryCurrency = currencies.find((c) => c.id === currencyId);
  const secondaryCurrency = currencies.find((c) => c.id === 2);

  return (
    <div className={className}>
      <div className="flex gap-2 mb-2">
        <div className="flex-1">
          <label className="block text-sm font-medium mb-1">
            {primaryCurrency?.name || "العملة الأساسية"}
          </label>
          <div className="flex gap-2">
            <input
              type="number"
              value={value}
              onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
              className="flex-1 px-3 py-2 border border-border rounded-md bg-background"
              placeholder="0.00"
              step="0.01"
            />
            <select
              value={currencyId}
              onChange={(e) => onCurrencyChange?.(parseInt(e.target.value))}
              className="px-3 py-2 border border-border rounded-md bg-background"
            >
              {currencies.map((currency) => (
                <option key={currency.id} value={currency.id}>
                  {currency.code}
                </option>
              ))}
            </select>
          </div>
        </div>

        {showConversion && conversion?.convertedAmount && secondaryCurrency && (
          <div className="flex-1">
            <label className="block text-sm font-medium mb-1">
              {secondaryCurrency.name}
            </label>
            <div className="px-3 py-2 border border-border rounded-md bg-muted text-muted-foreground">
              {conversion.convertedAmount.toFixed(0)} {secondaryCurrency.code}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
