import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, CheckCircle, Loader } from "lucide-react";

export function ExchangeRateSyncPanel() {
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<"idle" | "success" | "error">("idle");

  // جلب آخر تحديث عند التحميل
  const { data: updateInfo, refetch: refetchUpdateInfo } =
    trpc.currencies.getLastUpdateTime.useQuery();

  // إجراء التحديث اليدوي
  const syncMutation = trpc.currencies.syncExchangeRates.useMutation({
    onMutate: () => {
      setIsSyncing(true);
      setSyncStatus("idle");
    },
    onSuccess: (data) => {
      setIsSyncing(false);
      if (data.success) {
        setSyncStatus("success");
        refetchUpdateInfo();
        // إعادة تعيين الحالة بعد 3 ثوان
        setTimeout(() => setSyncStatus("idle"), 3000);
      } else {
        setSyncStatus("error");
        setTimeout(() => setSyncStatus("idle"), 3000);
      }
    },
    onError: () => {
      setIsSyncing(false);
      setSyncStatus("error");
      setTimeout(() => setSyncStatus("idle"), 3000);
    },
  });

  useEffect(() => {
    if (updateInfo?.lastUpdate) {
      setLastUpdate(new Date(updateInfo.lastUpdate));
    }
  }, [updateInfo]);

  const formatDate = (date: Date | null) => {
    if (!date) return "لم يتم التحديث بعد";
    return new Intl.DateTimeFormat("ar-SA", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>تحديث أسعار الصرف</CardTitle>
        <CardDescription>
          إدارة تحديث أسعار الصرف من مصادر خارجية
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* حالة آخر تحديث */}
        <div className="space-y-2">
          <label className="text-sm font-medium">آخر تحديث</label>
          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
            <span className="text-sm">{formatDate(lastUpdate)}</span>
            {updateInfo?.status === "synced" && (
              <CheckCircle className="w-4 h-4 text-green-500" />
            )}
            {updateInfo?.status === "not_synced" && (
              <AlertCircle className="w-4 h-4 text-yellow-500" />
            )}
          </div>
        </div>

        {/* زر التحديث اليدوي */}
        <div className="space-y-2">
          <label className="text-sm font-medium">التحديث اليدوي</label>
          <Button
            onClick={() => syncMutation.mutate()}
            disabled={isSyncing || syncMutation.isPending}
            className="w-full"
            variant={
              syncStatus === "success"
                ? "default"
                : syncStatus === "error"
                  ? "destructive"
                  : "default"
            }
          >
            {isSyncing || syncMutation.isPending ? (
              <>
                <Loader className="w-4 h-4 mr-2 animate-spin" />
                جاري التحديث...
              </>
            ) : syncStatus === "success" ? (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                تم التحديث بنجاح
              </>
            ) : syncStatus === "error" ? (
              <>
                <AlertCircle className="w-4 h-4 mr-2" />
                فشل التحديث
              </>
            ) : (
              "تحديث الآن"
            )}
          </Button>
        </div>

        {/* معلومات إضافية */}
        <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
          <p className="text-xs text-blue-800">
            💡 <strong>ملاحظة:</strong> يتم تحديث أسعار الصرف تلقائياً يومياً في الساعة 12:00
            صباحاً (UTC). يمكنك أيضاً تحديثها يدوياً باستخدام الزر أعلاه.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
