import { useLocation } from "wouter";
import { Users, Building2, FileText, BarChart3, DollarSign, Bell, TrendingUp, Briefcase, CreditCard, AlertCircle, Info, LineChart, Zap, Coins, Upload, Shield, Lock, Settings, PieChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";

export default function HorizontalNav() {
  const [location, setLocation] = useLocation() as [string, (path: string) => void];
  const { user, isAuthenticated } = useAuth();
  
  // إخفاء شريط الأدوات إذا لم يكن المستخدم مسجل دخول
  if (!isAuthenticated) {
    return null;
  }
  
  // التحقق من أن location معرّف وليس undefined
  const safeLocation = location || "/";

  // تعريف الألوان لكل عنصر
  const colorMap: { [key: string]: { bg: string; text: string; hover: string; icon: string } } = {
    "/doctors": { bg: "bg-blue-500", text: "text-white", hover: "hover:bg-blue-600", icon: "text-white" },
    "/salaries": { bg: "bg-amber-500", text: "text-white", hover: "hover:bg-amber-600", icon: "text-white" },
    "/works": { bg: "bg-red-500", text: "text-white", hover: "hover:bg-red-600", icon: "text-white" },
    "/dashboard": { bg: "bg-emerald-500", text: "text-white", hover: "hover:bg-emerald-600", icon: "text-white" },
    "/invoices": { bg: "bg-cyan-500", text: "text-white", hover: "hover:bg-cyan-600", icon: "text-white" },
    "/invoices/monthly": { bg: "bg-blue-600", text: "text-white", hover: "hover:bg-blue-700", icon: "text-white" },
    "/monthly-reports": { bg: "bg-indigo-500", text: "text-white", hover: "hover:bg-indigo-600", icon: "text-white" },
    "/payments": { bg: "bg-purple-500", text: "text-white", hover: "hover:bg-purple-600", icon: "text-white" },
    "/reports": { bg: "bg-green-500", text: "text-white", hover: "hover:bg-green-600", icon: "text-white" },
    "/expenses": { bg: "bg-orange-500", text: "text-white", hover: "hover:bg-orange-600", icon: "text-white" },
    "/receivables": { bg: "bg-pink-500", text: "text-white", hover: "hover:bg-pink-600", icon: "text-white" },
    "/notifications": { bg: "bg-indigo-500", text: "text-white", hover: "hover:bg-indigo-600", icon: "text-white" },
    "/analytics": { bg: "bg-teal-500", text: "text-white", hover: "hover:bg-teal-600", icon: "text-white" },
    "/forecasts": { bg: "bg-violet-500", text: "text-white", hover: "hover:bg-violet-600", icon: "text-white" },
    "/currencies": { bg: "bg-fuchsia-500", text: "text-white", hover: "hover:bg-fuchsia-600", icon: "text-white" },
    "/users": { bg: "bg-sky-500", text: "text-white", hover: "hover:bg-sky-600", icon: "text-white" },
    "/roles": { bg: "bg-indigo-600", text: "text-white", hover: "hover:bg-indigo-700", icon: "text-white" },
    "/permissions-manager": { bg: "bg-rose-600", text: "text-white", hover: "hover:bg-rose-700", icon: "text-white" },
    "/password-management": { bg: "bg-orange-600", text: "text-white", hover: "hover:bg-orange-700", icon: "text-white" },
    "/initialization": { bg: "bg-cyan-600", text: "text-white", hover: "hover:bg-cyan-700", icon: "text-white" },
    "/backup-management": { bg: "bg-emerald-600", text: "text-white", hover: "hover:bg-emerald-700", icon: "text-white" },
    "/import-works": { bg: "bg-lime-500", text: "text-white", hover: "hover:bg-lime-600", icon: "text-white" },
    "/about": { bg: "bg-slate-600", text: "text-white", hover: "hover:bg-slate-700", icon: "text-white" },
    "/profit-distribution": { bg: "bg-green-600", text: "text-white", hover: "hover:bg-green-700", icon: "text-white" },
  };

  // خريطة الصلاحيات للقوائم حسب الأدوار
  // user: مستخدم عادي
  // manager: مدير
  // staff: موظف
  // admin: مسؤول
  const rolePermissions: { [key: string]: string[] } = {
    user: ["/doctors", "/works", "/dashboard", "/invoices", "/payments", "/reports", "/about"],
    manager: ["/doctors", "/works", "/dashboard", "/invoices", "/invoices/monthly", "/payments", "/reports", "/expenses", "/receivables", "/analytics", "/forecasts", "/monthly-reports", "/profit-distribution", "/about"],
    staff: ["/doctors", "/salaries", "/works", "/dashboard", "/invoices", "/payments", "/reports", "/expenses", "/receivables", "/notifications", "/about"],
    admin: [
      "/doctors", "/salaries", "/works", "/dashboard", "/invoices", "/invoices/monthly", 
      "/payments", "/reports", "/expenses", "/receivables", "/notifications", "/analytics", 
      "/forecasts", "/monthly-reports", "/currencies", "/users", "/roles", "/permissions-manager", 
      "/password-management", "/initialization", "/backup-management", "/import-works", "/profit-distribution", "/about"
    ],
  };

  // الحصول على الأدوار المسموحة للمستخدم الحالي
  const userRole = (user?.role as keyof typeof rolePermissions) || "user";
  const allowedPaths = rolePermissions[userRole] || rolePermissions.user;

  // تحديد العناصر - مع تطبيق الصلاحيات
  const allNavItems = [
    { label: "الأطباء", icon: Users, path: "/doctors" },
    { label: "الرواتب", icon: Briefcase, path: "/salaries" },
    { label: "الأعمال", icon: Building2, path: "/works" },
    { label: "الملخص", icon: BarChart3, path: "/dashboard" },
    { label: "الفواتير", icon: FileText, path: "/invoices" },
    { label: "الفواتير الشهرية", icon: FileText, path: "/invoices/monthly" },
    { label: "الدفعات", icon: CreditCard, path: "/payments" },
    { label: "التقارير", icon: BarChart3, path: "/reports" },
    { label: "المصروفات", icon: DollarSign, path: "/expenses" },
    { label: "المديونية", icon: AlertCircle, path: "/receivables" },
    { label: "التنبيهات", icon: Bell, path: "/notifications" },
    { label: "التحليلات", icon: LineChart, path: "/analytics" },
    { label: "التوقعات", icon: Zap, path: "/forecasts" },
    { label: "التقارير الشهرية", icon: FileText, path: "/monthly-reports" },
    { label: "توزيع الأرباح", icon: PieChart, path: "/profit-distribution" },
    { label: "إدارة العملات", icon: Coins, path: "/currencies" },
    { label: "إدارة المستخدمين", icon: Users, path: "/users" },
    { label: "الأدوار والصلاحيات", icon: Shield, path: "/roles" },
    { label: "إدارة الصلاحيات", icon: Lock, path: "/permissions-manager" },
    { label: "إدارة كلمات المرور", icon: Lock, path: "/password-management" },
    { label: "تهيئة النظام", icon: Settings, path: "/initialization" },
    { label: "النسخ الاحتياطية", icon: Settings, path: "/backup-management" },
    { label: "استيراد الأعمال", icon: Upload, path: "/import-works" },
    { label: "عن النظام", icon: Info, path: "/about" },
  ];

  // تصفية العناصر حسب الصلاحيات
  const navItems = allNavItems.filter(item => allowedPaths.includes(item.path));

  return (
    <div className="bg-gradient-to-b from-white to-gray-50 border-b border-slate-200 shadow-md">
      <div className="px-6 py-4 flex justify-between items-center">
        <div className="flex gap-2 flex-wrap overflow-x-auto flex-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = safeLocation === item.path;
            const colors = colorMap[item.path] || colorMap["/doctors"];
            
            return (
              <Button
                key={item.path}
                variant="ghost"
                onClick={() => setLocation(item.path)}
                className={`flex flex-col items-center gap-1 h-auto py-2 px-3 whitespace-nowrap rounded-lg transition-all duration-300 transform hover:scale-105 shadow-sm hover:shadow-md ${
                  isActive 
                    ? `${colors.bg} ${colors.text} shadow-lg scale-105` 
                    : `${colors.bg} ${colors.text} opacity-90 ${colors.hover}`
                }`}
              >
                <Icon className={`h-5 w-5 ${colors.icon}`} />
                <span className="text-xs font-medium">{item.label}</span>
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
