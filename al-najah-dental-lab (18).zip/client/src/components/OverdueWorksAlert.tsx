import { useEffect, useState } from "react";
import { AlertCircle, Volume2, X } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";

interface OverdueWork {
  id: number;
  patientName: string;
  doctorId: number;
  dueDate: Date;
  daysOverdue: number;
  description?: string;
}

export function OverdueWorksAlert() {
  const [, setLocation] = useLocation();
  const [overdueWorks, setOverdueWorks] = useState<OverdueWork[]>([]);
  const [isVisible, setIsVisible] = useState(true);
  const [hasPlayedSound, setHasPlayedSound] = useState(false);

  // جلب الأعمال المتأخرة - تحديث كل 5 دقائق (300000 ميلي ثانية)
  const { data: works } = trpc.reports.getOverdueWorks.useQuery(undefined, {
    refetchInterval: 300000, // 5 دقائق
  });

  // تشغيل الصوت عند اكتشاف أعمال متأخرة
  useEffect(() => {
    if (works && works.length > 0 && !hasPlayedSound) {
      playAlertSound();
      setHasPlayedSound(true);
      setOverdueWorks(works as any);
    }
  }, [works, hasPlayedSound]);

  // دالة تشغيل الصوت - إنشاء oscillator جديد لكل نبضة
  const playAlertSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const gainNode = audioContext.createGain();
      gainNode.connect(audioContext.destination);

      const now = audioContext.currentTime;
      const frequency = 800; // تردد 800 Hz
      const duration = 0.2; // مدة النبضة
      const interval = 0.3; // الفاصل بين النبضات

      // تشغيل 3 نبضات صوتية
      for (let i = 0; i < 3; i++) {
        const oscillator = audioContext.createOscillator();
        oscillator.frequency.value = frequency;
        oscillator.connect(gainNode);

        const startTime = now + i * interval;
        const stopTime = startTime + duration;

        gainNode.gain.setValueAtTime(0.3, startTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, stopTime);

        oscillator.start(startTime);
        oscillator.stop(stopTime);
      }
    } catch (error) {
      console.error("خطأ في تشغيل الصوت:", error);
    }
  };

  if (!isVisible || overdueWorks.length === 0) {
    return null;
  }

  return (
    <div className="fixed top-4 right-4 max-w-md z-50 animate-in slide-in-from-top">
      <div className="bg-red-50 border-2 border-red-500 rounded-lg p-4 shadow-lg">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0">
              <AlertCircle className="h-6 w-6 text-red-600 animate-pulse" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-red-900 text-lg">
                ⚠️ تنبيه: أعمال متأخرة!
              </h3>
              <p className="text-red-800 text-sm mt-1">
                يوجد {overdueWorks.length} أعمال متأخرة عن موعد التسليم
              </p>
              <div className="mt-3 space-y-2 max-h-48 overflow-y-auto">
                {overdueWorks.slice(0, 5).map((work) => (
                  <div
                    key={work.id}
                    className="bg-white rounded p-2 text-sm border-l-4 border-red-500"
                  >
                    <p className="font-medium text-gray-900">
                      {work.patientName || "- غير معروف"}
                    </p>
                    <p className="text-red-600 text-xs">
                      متأخر بـ {work.daysOverdue} يوم
                    </p>
                  </div>
                ))}
                {overdueWorks.length > 5 && (
                  <p className="text-red-700 text-xs font-medium">
                    و {overdueWorks.length - 5} أعمال أخرى...
                  </p>
                )}
              </div>
            </div>
          </div>
          <button
            onClick={() => setIsVisible(false)}
            className="flex-shrink-0 text-red-600 hover:text-red-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-4 flex gap-2">
          <Button
            size="sm"
            variant="outline"
            className="flex-1 border-red-300 text-red-700 hover:bg-red-100"
            onClick={playAlertSound}
          >
            <Volume2 className="h-4 w-4 mr-2" />
            إعادة الصوت
          </Button>
          <Button
            size="sm"
            className="flex-1 bg-red-600 hover:bg-red-700 text-white"
            onClick={() => {
              setIsVisible(false);
              setLocation("/works");
            }}
          >
            عرض الأعمال
          </Button>
        </div>
      </div>
    </div>
  );
}
