import { useAuth } from "@/_core/hooks/useAuth";
import { Redirect } from "wouter";
import NotFound from "@/pages/NotFound";

interface ProtectedRouteProps {
  component: React.ComponentType<any>;
  requiredRoles?: string[];
}

export default function ProtectedRoute({ component: Component, requiredRoles = [] }: ProtectedRouteProps) {
  const { user, isAuthenticated } = useAuth();

  // إذا لم يكن المستخدم مسجل دخول، أعد التوجيه إلى الصفحة الرئيسية
  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  // إذا كان هناك أدوار مطلوبة وليس لدى المستخدم الصلاحيات، عرض صفحة 404
  if (requiredRoles.length > 0 && user) {
    const userRole = user.role as string;
    if (!requiredRoles.includes(userRole)) {
      return <NotFound />;
    }
  }

  // إذا كان كل شيء بخير، عرض المكون
  return <Component />;
}
