"use client";

/**
 * مكون لرسم أشكال أسنان واقعية مفصلة
 * يتضمن أنواع مختلفة من الأسنان: قواطع، أنياب، ضواحك، أرحاء
 */

interface RealisticToothProps {
  toothId: string;
  isSelected: boolean;
  isUpperJaw: boolean;
  onClick: () => void;
}

export function RealisticTooth({
  toothId,
  isSelected,
  isUpperJaw,
  onClick,
}: RealisticToothProps) {
  // تحديد نوع السن بناءً على الرقم
  const toothNumber = parseInt(toothId.match(/\d/)![0]);
  let toothType: "incisor" | "canine" | "premolar" | "molar";

  if (toothNumber <= 2) {
    toothType = "incisor"; // قاطع
  } else if (toothNumber === 3) {
    toothType = "canine"; // ناب
  } else if (toothNumber <= 5) {
    toothType = "premolar"; // ضاحك
  } else {
    toothType = "molar"; // رحى
  }

  // تحديد الجانب (يسار/يمين) للتأثير على الظل
  const side = toothId.endsWith("L") ? "left" : "right";

  return (
    <svg
      width="50"
      height="65"
      viewBox="0 0 50 65"
      className={`cursor-pointer transition-all duration-200 ${
        isSelected ? "drop-shadow-lg scale-105" : "drop-shadow"
      }`}
      onClick={onClick}
    >
      <defs>
        {/* تدرج للتظليل الواقعي */}
        <linearGradient id={`toothGradient-${toothId}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={isSelected ? "#3b82f6" : "#f5f5f5"} />
          <stop offset="50%" stopColor={isSelected ? "#1e40af" : "#e8e8e8"} />
          <stop offset="100%" stopColor={isSelected ? "#1e3a8a" : "#d0d0d0"} />
        </linearGradient>

        {/* تدرج للجذر */}
        <linearGradient id={`rootGradient-${toothId}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={isSelected ? "#1e40af" : "#c0c0c0"} />
          <stop offset="100%" stopColor={isSelected ? "#1e3a8a" : "#a0a0a0"} />
        </linearGradient>

        {/* ظل */}
        <filter id={`shadow-${toothId}`}>
          <feDropShadow dx="0" dy="2" stdDeviation="2" floodOpacity="0.3" />
        </filter>
      </defs>

      {isUpperJaw ? (
        <>
          {/* الأسنان العلوية */}
          {toothType === "incisor" && (
            <>
              {/* قاطع - شكل مستطيل مع حافة حادة */}
              <path
                d="M 12 5 L 38 5 Q 40 8 40 15 L 40 45 Q 38 50 35 52 L 15 52 Q 12 50 10 45 L 10 15 Q 10 8 12 5"
                fill={`url(#toothGradient-${toothId})`}
                stroke={isSelected ? "#1e40af" : "#999"}
                strokeWidth="0.5"
                filter={`url(#shadow-${toothId})`}
              />
              {/* خط وسطي */}
              <line
                x1="25"
                y1="5"
                x2="25"
                y2="52"
                stroke={isSelected ? "#0f172a" : "#ccc"}
                strokeWidth="0.5"
                opacity="0.5"
              />
            </>
          )}

          {toothType === "canine" && (
            <>
              {/* ناب - شكل مدبب */}
              <path
                d="M 15 5 L 35 5 Q 38 8 40 12 L 42 30 Q 40 50 35 53 L 15 53 Q 10 50 8 30 L 10 12 Q 12 8 15 5"
                fill={`url(#toothGradient-${toothId})`}
                stroke={isSelected ? "#1e40af" : "#999"}
                strokeWidth="0.5"
                filter={`url(#shadow-${toothId})`}
              />
              {/* خط وسطي */}
              <line
                x1="25"
                y1="5"
                x2="25"
                y2="53"
                stroke={isSelected ? "#0f172a" : "#ccc"}
                strokeWidth="0.5"
                opacity="0.5"
              />
            </>
          )}

          {toothType === "premolar" && (
            <>
              {/* ضاحك - شكل مع قمتين صغيرتين */}
              <path
                d="M 10 5 L 40 5 Q 42 8 42 12 L 42 45 Q 40 50 37 52 L 13 52 Q 10 50 8 45 L 8 12 Q 8 8 10 5"
                fill={`url(#toothGradient-${toothId})`}
                stroke={isSelected ? "#1e40af" : "#999"}
                strokeWidth="0.5"
                filter={`url(#shadow-${toothId})`}
              />
              {/* قمتان */}
              <circle cx="18" cy="8" r="2" fill={isSelected ? "#0f172a" : "#bbb"} opacity="0.6" />
              <circle cx="32" cy="8" r="2" fill={isSelected ? "#0f172a" : "#bbb"} opacity="0.6" />
            </>
          )}

          {toothType === "molar" && (
            <>
              {/* رحى - شكل أعرض مع قمم متعددة */}
              <path
                d="M 8 5 L 42 5 Q 44 8 44 12 L 44 45 Q 42 50 39 52 L 11 52 Q 8 50 6 45 L 6 12 Q 6 8 8 5"
                fill={`url(#toothGradient-${toothId})`}
                stroke={isSelected ? "#1e40af" : "#999"}
                strokeWidth="0.5"
                filter={`url(#shadow-${toothId})`}
              />
              {/* قمم متعددة */}
              <circle cx="15" cy="7" r="1.5" fill={isSelected ? "#0f172a" : "#bbb"} opacity="0.6" />
              <circle cx="25" cy="6" r="1.5" fill={isSelected ? "#0f172a" : "#bbb"} opacity="0.6" />
              <circle cx="35" cy="7" r="1.5" fill={isSelected ? "#0f172a" : "#bbb"} opacity="0.6" />
            </>
          )}

          {/* الجذر */}
          <path
            d="M 15 52 Q 18 55 20 60 L 30 60 Q 32 55 35 52"
            fill={`url(#rootGradient-${toothId})`}
            stroke={isSelected ? "#1e3a8a" : "#888"}
            strokeWidth="0.5"
          />
        </>
      ) : (
        <>
          {/* الأسنان السفلية - معكوسة */}
          {toothType === "incisor" && (
            <>
              {/* قاطع - شكل مستطيل مع حافة حادة */}
              <path
                d="M 12 60 L 38 60 Q 40 57 40 50 L 40 15 Q 38 10 35 8 L 15 8 Q 12 10 10 15 L 10 50 Q 10 57 12 60"
                fill={`url(#toothGradient-${toothId})`}
                stroke={isSelected ? "#16a34a" : "#999"}
                strokeWidth="0.5"
                filter={`url(#shadow-${toothId})`}
              />
              {/* خط وسطي */}
              <line
                x1="25"
                y1="60"
                x2="25"
                y2="8"
                stroke={isSelected ? "#0f172a" : "#ccc"}
                strokeWidth="0.5"
                opacity="0.5"
              />
            </>
          )}

          {toothType === "canine" && (
            <>
              {/* ناب - شكل مدبب */}
              <path
                d="M 15 60 L 35 60 Q 38 57 40 53 L 42 35 Q 40 15 35 12 L 15 12 Q 10 15 8 35 L 10 53 Q 12 57 15 60"
                fill={`url(#toothGradient-${toothId})`}
                stroke={isSelected ? "#16a34a" : "#999"}
                strokeWidth="0.5"
                filter={`url(#shadow-${toothId})`}
              />
              {/* خط وسطي */}
              <line
                x1="25"
                y1="60"
                x2="25"
                y2="12"
                stroke={isSelected ? "#0f172a" : "#ccc"}
                strokeWidth="0.5"
                opacity="0.5"
              />
            </>
          )}

          {toothType === "premolar" && (
            <>
              {/* ضاحك - شكل مع قمتين صغيرتين */}
              <path
                d="M 10 60 L 40 60 Q 42 57 42 53 L 42 15 Q 40 10 37 8 L 13 8 Q 10 10 8 15 L 8 53 Q 8 57 10 60"
                fill={`url(#toothGradient-${toothId})`}
                stroke={isSelected ? "#16a34a" : "#999"}
                strokeWidth="0.5"
                filter={`url(#shadow-${toothId})`}
              />
              {/* قمتان */}
              <circle cx="18" cy="57" r="2" fill={isSelected ? "#0f172a" : "#bbb"} opacity="0.6" />
              <circle cx="32" cy="57" r="2" fill={isSelected ? "#0f172a" : "#bbb"} opacity="0.6" />
            </>
          )}

          {toothType === "molar" && (
            <>
              {/* رحى - شكل أعرض مع قمم متعددة */}
              <path
                d="M 8 60 L 42 60 Q 44 57 44 53 L 44 15 Q 42 10 39 8 L 11 8 Q 8 10 6 15 L 6 53 Q 6 57 8 60"
                fill={`url(#toothGradient-${toothId})`}
                stroke={isSelected ? "#16a34a" : "#999"}
                strokeWidth="0.5"
                filter={`url(#shadow-${toothId})`}
              />
              {/* قمم متعددة */}
              <circle cx="15" cy="58" r="1.5" fill={isSelected ? "#0f172a" : "#bbb"} opacity="0.6" />
              <circle cx="25" cy="59" r="1.5" fill={isSelected ? "#0f172a" : "#bbb"} opacity="0.6" />
              <circle cx="35" cy="58" r="1.5" fill={isSelected ? "#0f172a" : "#bbb"} opacity="0.6" />
            </>
          )}

          {/* الجذر */}
          <path
            d="M 15 8 Q 18 5 20 0 L 30 0 Q 32 5 35 8"
            fill={`url(#rootGradient-${toothId})`}
            stroke={isSelected ? "#15803d" : "#888"}
            strokeWidth="0.5"
          />
        </>
      )}

      {/* رقم السن */}
      <text
        x="25"
        y={isUpperJaw ? "35" : "30"}
        textAnchor="middle"
        fontSize="10"
        fontWeight="bold"
        fill={isSelected ? "white" : "#666"}
        opacity={isSelected ? 1 : 0.7}
      >
        {toothNumber}
      </text>
    </svg>
  );
}
