"use client";

/**
 * مكون لعرض صور أسنان حقيقية
 */

interface RealisticToothImageProps {
  toothId: string;
  isSelected: boolean;
  onClick: () => void;
}

// روابط CDN لصور الأسنان
const TOOTH_IMAGES = {
  incisor: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338947951/DwibXUFGgrTEqJaA.png",
  canine: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338947951/VmImCbNFOTkHTApA.png",
  premolar: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338947951/jnPyKULppibWbXeV.png",
  molar: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338947951/djfUtsoPHvBrGAKs.png",
};

export function RealisticToothImage({
  toothId,
  isSelected,
  onClick,
}: RealisticToothImageProps) {
  // تحديد نوع السن بناءً على الرقم
  const toothNumber = parseInt(toothId.match(/\d/)![0]);
  let toothType: "incisor" | "canine" | "premolar" | "molar";
  let toothImage: string;

  if (toothNumber <= 2) {
    toothType = "incisor";
    toothImage = TOOTH_IMAGES.incisor;
  } else if (toothNumber === 3) {
    toothType = "canine";
    toothImage = TOOTH_IMAGES.canine;
  } else if (toothNumber <= 5) {
    toothType = "premolar";
    toothImage = TOOTH_IMAGES.premolar;
  } else {
    toothType = "molar";
    toothImage = TOOTH_IMAGES.molar;
  }

  return (
    <div
      onClick={onClick}
      className={`relative cursor-pointer transition-all duration-200 rounded-lg overflow-hidden ${
        isSelected ? "ring-2 ring-blue-500 scale-105 shadow-lg" : "hover:shadow-md"
      }`}
      title={toothId}
    >
      {/* صورة السن */}
      <div className="relative w-10 h-14 bg-white border border-gray-200 rounded-lg overflow-hidden">
        <img
          src={toothImage}
          alt={`Tooth ${toothNumber}`}
          className="w-full h-full object-cover"
        />

        {/* طبقة تراكب عند الاختيار */}
        {isSelected && (
          <div className="absolute inset-0 bg-blue-500 opacity-20"></div>
        )}
      </div>

      {/* رقم السن */}
      <div
        className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full flex items-center justify-center text-[0.5rem] font-bold leading-none ${
          isSelected
            ? "bg-blue-500 text-white"
            : "bg-gray-300 text-gray-700"
        }`}
      >
        {toothNumber}
      </div>
    </div>
  );
}
