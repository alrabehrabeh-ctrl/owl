"use client";

import { X } from "lucide-react";

// روابط CDN لصور الأسنان
const TOOTH_IMAGES = {
  incisor: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338947951/DwibXUFGgrTEqJaA.png",
  canine: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338947951/VmImCbNFOTkHTApA.png",
  premolar: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338947951/jnPyKULppibWbXeV.png",
  molar: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338947951/djfUtsoPHvBrGAKs.png",
};

interface SelectedTeethPreviewProps {
  selectedTeeth: string[];
  onRemove?: (toothId: string) => void;
}

function getToothType(toothId: string): keyof typeof TOOTH_IMAGES {
  const toothNumber = parseInt(toothId.match(/\d/)![0]);
  if (toothNumber <= 2) return "incisor";
  if (toothNumber === 3) return "canine";
  if (toothNumber <= 5) return "premolar";
  return "molar";
}

export function SelectedTeethPreview({
  selectedTeeth,
  onRemove,
}: SelectedTeethPreviewProps) {
  if (selectedTeeth.length === 0) {
    return (
      <div className="text-center py-8 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
        <p className="text-gray-500 text-sm">لم تختر أي أسنان بعد</p>
      </div>
    );
  }

  // تجميع الأسنان حسب النوع
  const teethByType = {
    incisor: selectedTeeth.filter((t) => {
      const num = parseInt(t.match(/\d/)![0]);
      return num <= 2;
    }),
    canine: selectedTeeth.filter((t) => {
      const num = parseInt(t.match(/\d/)![0]);
      return num === 3;
    }),
    premolar: selectedTeeth.filter((t) => {
      const num = parseInt(t.match(/\d/)![0]);
      return num > 3 && num <= 5;
    }),
    molar: selectedTeeth.filter((t) => {
      const num = parseInt(t.match(/\d/)![0]);
      return num > 5;
    }),
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-700">
          الأسنان المختارة ({selectedTeeth.length})
        </h3>
        <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
          معاينة حية
        </span>
      </div>

      {/* عرض الأسنان المختارة */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {Object.entries(teethByType).map(([type, teeth]) => {
          if (teeth.length === 0) return null;

          const toothType = type as keyof typeof TOOTH_IMAGES;
          const toothImage = TOOTH_IMAGES[toothType];

          return (
            <div key={type} className="space-y-2">
              <div className="text-xs font-semibold text-gray-600 text-center">
                {type === "incisor" && "القواطع"}
                {type === "canine" && "الأنياب"}
                {type === "premolar" && "الضواحك"}
                {type === "molar" && "الأرحاء"}
              </div>
              <div className="flex flex-wrap gap-2 justify-center">
                {teeth.map((toothId) => (
                  <div
                    key={toothId}
                    className="relative group"
                  >
                    <div className="relative w-16 h-24 rounded-lg overflow-hidden border-2 border-blue-300 bg-white shadow-sm hover:shadow-md transition-shadow">
                      <img
                        src={toothImage}
                        alt={toothId}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-blue-500 opacity-10 group-hover:opacity-20 transition-opacity"></div>
                    </div>
                    <div className="absolute -top-2 -right-2 bg-blue-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                      {toothId.match(/\d/)![0]}
                    </div>
                    {onRemove && (
                      <button
                        onClick={() => onRemove(toothId)}
                        className="absolute -top-2 -left-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"
                        title="إزالة السن"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* ملخص الأسنان المختارة */}
      <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
        <p className="text-xs text-gray-700">
          <span className="font-semibold">الأسنان المختارة:</span>{" "}
          <span className="text-blue-600 font-mono">
            {selectedTeeth.sort().join(", ")}
          </span>
        </p>
      </div>
    </div>
  );
}
