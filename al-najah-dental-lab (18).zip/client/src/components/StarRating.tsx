import React, { useState } from "react";
import { Star } from "lucide-react";

interface StarRatingProps {
  rating: number;
  maxRating?: number;
  onRatingChange?: (rating: number) => void;
  readOnly?: boolean;
  size?: "sm" | "md" | "lg";
  showLabel?: boolean;
  className?: string;
}

export function StarRating({
  rating,
  maxRating = 5,
  onRatingChange,
  readOnly = false,
  size = "md",
  showLabel = true,
  className = "",
}: StarRatingProps) {
  const [hoverRating, setHoverRating] = useState(0);

  const sizeClasses = {
    sm: "h-4 w-4",
    md: "h-5 w-5",
    lg: "h-6 w-6",
  };

  const normalizedRating = Math.round(Number(rating) * 2) / 2;
  const displayRating = hoverRating || normalizedRating;

  const handleStarClick = (value: number) => {
    if (!readOnly && onRatingChange) {
      onRatingChange(value);
    }
  };

  const handleStarHover = (value: number) => {
    if (!readOnly) {
      setHoverRating(value);
    }
  };

  const handleMouseLeave = () => {
    setHoverRating(0);
  };

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="flex items-center gap-1">
        {Array.from({ length: maxRating }).map((_, index) => {
          const starValue = index + 1;
          const isFilled = starValue <= Math.floor(displayRating);
          const isHalf =
            starValue === Math.ceil(displayRating) &&
            displayRating % 1 !== 0;

          return (
            <button
              key={index}
              onClick={() => handleStarClick(starValue)}
              onMouseEnter={() => handleStarHover(starValue)}
              onMouseLeave={handleMouseLeave}
              disabled={readOnly}
              className={`relative transition-all ${
                readOnly ? "cursor-default" : "cursor-pointer hover:scale-110"
              } ${sizeClasses[size]}`}
              title={`${starValue} من ${maxRating}`}
            >
              {/* النجم الخلفي (الرمادي) */}
              <Star
                className={`absolute inset-0 ${sizeClasses[size]} text-gray-300`}
              />

              {/* النجم الأمامي (الأصفر) */}
              <div
                className="absolute inset-0 overflow-hidden transition-all"
                style={{
                  width: isHalf ? "50%" : isFilled ? "100%" : "0%",
                }}
              >
                <Star
                  className={`${sizeClasses[size]} fill-yellow-400 text-yellow-400`}
                />
              </div>
            </button>
          );
        })}
      </div>

      {showLabel && (
        <span className="text-sm font-medium text-gray-700">
          {normalizedRating.toFixed(1)}
        </span>
      )}
    </div>
  );
}

/**
 * مكون عرض التقييم الثابت (بدون تفاعل)
 * يستخدم لعرض التقييمات في الجداول والقوائم
 */
export function StarRatingDisplay({
  rating,
  maxRating = 5,
  size = "sm",
  showLabel = true,
  className = "",
}: Omit<StarRatingProps, "onRatingChange" | "readOnly">) {
  return (
    <StarRating
      rating={rating}
      maxRating={maxRating}
      readOnly={true}
      size={size}
      showLabel={showLabel}
      className={className}
    />
  );
}

/**
 * مكون تعديل التقييم (تفاعلي)
 * يستخدم لتعديل التقييمات في نماذج التعديل
 */
export function StarRatingEditor({
  rating,
  onRatingChange,
  maxRating = 5,
  size = "lg",
  showLabel = true,
  className = "",
}: Omit<StarRatingProps, "readOnly">) {
  return (
    <StarRating
      rating={rating}
      maxRating={maxRating}
      onRatingChange={onRatingChange}
      readOnly={false}
      size={size}
      showLabel={showLabel}
      className={className}
    />
  );
}
