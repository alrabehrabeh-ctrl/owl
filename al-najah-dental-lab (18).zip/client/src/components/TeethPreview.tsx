/**
 * مكون معاينة مصغرة لرسم الأسنان المحددة
 * يعرض الأسنان المختارة برسم مصغر جداً مناسب للجداول
 */

interface TeethPreviewProps {
  selectedTeeth?: number[];
  size?: "sm" | "md" | "lg";
}

export function TeethPreview({ selectedTeeth = [], size = "sm" }: TeethPreviewProps) {
  if (selectedTeeth.length === 0) {
    return <span className="text-gray-400 text-xs">لا توجد أسنان</span>;
  }

  // حساب حجم الأسنان بناءً على الحجم المطلوب
  const sizeClasses = {
    sm: "w-5 h-5",
    md: "w-6 h-6",
    lg: "w-7 h-7",
  };

  const textSizeClasses = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
  };

  const toothSize = sizeClasses[size];
  const textSize = textSizeClasses[size];

  // تجميع الأسنان حسب الفك والجانب
  const upperRight = selectedTeeth.filter((t) => t >= 11 && t <= 18);
  const upperLeft = selectedTeeth.filter((t) => t >= 21 && t <= 28);
  const lowerLeft = selectedTeeth.filter((t) => t >= 31 && t <= 38);
  const lowerRight = selectedTeeth.filter((t) => t >= 41 && t <= 48);

  return (
    <div className="flex items-center gap-1">
      {/* الفك العلوي اليمين */}
      {upperRight.length > 0 && (
        <div className="flex gap-0.5">
          {upperRight.map((tooth) => (
            <div
              key={tooth}
              className={`${toothSize} rounded-full bg-red-100 border border-red-300 flex items-center justify-center`}
              title={`السن ${tooth}`}
            >
              <span className={`${textSize} font-semibold text-red-700`}>{tooth}</span>
            </div>
          ))}
        </div>
      )}

      {/* الفاصل */}
      {(upperRight.length > 0 || upperLeft.length > 0) && (lowerLeft.length > 0 || lowerRight.length > 0) && (
        <div className="w-px h-4 bg-gray-300 mx-0.5"></div>
      )}

      {/* الفك العلوي اليسار */}
      {upperLeft.length > 0 && (
        <div className="flex gap-0.5">
          {upperLeft.map((tooth) => (
            <div
              key={tooth}
              className={`${toothSize} rounded-full bg-red-100 border border-red-300 flex items-center justify-center`}
              title={`السن ${tooth}`}
            >
              <span className={`${textSize} font-semibold text-red-700`}>{tooth}</span>
            </div>
          ))}
        </div>
      )}

      {/* الفاصل الأفقي */}
      {(upperRight.length > 0 || upperLeft.length > 0) && (lowerLeft.length > 0 || lowerRight.length > 0) && (
        <div className="w-4 h-px bg-gray-300 mx-0.5"></div>
      )}

      {/* الفك السفلي اليسار */}
      {lowerLeft.length > 0 && (
        <div className="flex gap-0.5">
          {lowerLeft.map((tooth) => (
            <div
              key={tooth}
              className={`${toothSize} rounded-full bg-blue-100 border border-blue-300 flex items-center justify-center`}
              title={`السن ${tooth}`}
            >
              <span className={`${textSize} font-semibold text-blue-700`}>{tooth}</span>
            </div>
          ))}
        </div>
      )}

      {/* الفاصل */}
      {(lowerLeft.length > 0 || lowerRight.length > 0) && (upperRight.length > 0 || upperLeft.length > 0) && (
        <div className="w-px h-4 bg-gray-300 mx-0.5"></div>
      )}

      {/* الفك السفلي اليمين */}
      {lowerRight.length > 0 && (
        <div className="flex gap-0.5">
          {lowerRight.map((tooth) => (
            <div
              key={tooth}
              className={`${toothSize} rounded-full bg-blue-100 border border-blue-300 flex items-center justify-center`}
              title={`السن ${tooth}`}
            >
              <span className={`${textSize} font-semibold text-blue-700`}>{tooth}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
