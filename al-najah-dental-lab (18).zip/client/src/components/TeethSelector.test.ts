import { describe, it, expect, vi } from "vitest";

/**
 * اختبارات مكون TeethSelector
 * يختبر وظائف اختيار الأسنان والتفاعل مع المستخدم
 */

describe("TeethSelector Component", () => {
  it("should initialize with empty selection", () => {
    const selectedTeeth: number[] = [];
    expect(selectedTeeth).toEqual([]);
  });

  it("should initialize with provided selected teeth", () => {
    const selectedTeeth = [11, 12, 13];
    expect(selectedTeeth).toContain(11);
    expect(selectedTeeth).toContain(12);
    expect(selectedTeeth).toContain(13);
    expect(selectedTeeth.length).toBe(3);
  });

  it("should add tooth to selection", () => {
    const selected = new Set<number>();
    const toothNumber = 11;
    
    selected.add(toothNumber);
    
    expect(selected.has(toothNumber)).toBe(true);
    expect(selected.size).toBe(1);
  });

  it("should remove tooth from selection", () => {
    const selected = new Set<number>([11, 12, 13]);
    
    selected.delete(12);
    
    expect(selected.has(12)).toBe(false);
    expect(selected.size).toBe(2);
    expect(selected.has(11)).toBe(true);
    expect(selected.has(13)).toBe(true);
  });

  it("should toggle tooth selection", () => {
    const selected = new Set<number>();
    const toothNumber = 11;
    
    // أضف السن
    if (selected.has(toothNumber)) {
      selected.delete(toothNumber);
    } else {
      selected.add(toothNumber);
    }
    expect(selected.has(toothNumber)).toBe(true);
    
    // أزل السن
    if (selected.has(toothNumber)) {
      selected.delete(toothNumber);
    } else {
      selected.add(toothNumber);
    }
    expect(selected.has(toothNumber)).toBe(false);
  });

  it("should select all teeth (1-32)", () => {
    const allTeeth = Array.from({ length: 32 }, (_, i) => i + 1);
    const selected = new Set(allTeeth);
    
    expect(selected.size).toBe(32);
    for (let i = 1; i <= 32; i++) {
      expect(selected.has(i)).toBe(true);
    }
  });

  it("should clear all selections", () => {
    const selected = new Set<number>([11, 12, 13, 21, 22, 23]);
    
    selected.clear();
    
    expect(selected.size).toBe(0);
    expect(selected.has(11)).toBe(false);
  });

  it("should return sorted array of selected teeth", () => {
    const selected = new Set<number>([23, 11, 32, 15, 21]);
    const sorted = Array.from(selected).sort((a, b) => a - b);
    
    expect(sorted).toEqual([11, 15, 21, 23, 32]);
  });

  it("should handle quadrant 1 (upper right: 11-18)", () => {
    const quadrant1 = [18, 17, 16, 15, 14, 13, 12, 11];
    expect(quadrant1.length).toBe(8);
    expect(quadrant1[0]).toBe(18);
    expect(quadrant1[7]).toBe(11);
  });

  it("should handle quadrant 2 (upper left: 21-28)", () => {
    const quadrant2 = [21, 22, 23, 24, 25, 26, 27, 28];
    expect(quadrant2.length).toBe(8);
    expect(quadrant2[0]).toBe(21);
    expect(quadrant2[7]).toBe(28);
  });

  it("should handle quadrant 3 (lower left: 31-38)", () => {
    const quadrant3 = [38, 37, 36, 35, 34, 33, 32, 31];
    expect(quadrant3.length).toBe(8);
    expect(quadrant3[0]).toBe(38);
    expect(quadrant3[7]).toBe(31);
  });

  it("should handle quadrant 4 (lower right: 41-48)", () => {
    const quadrant4 = [41, 42, 43, 44, 45, 46, 47, 48];
    expect(quadrant4.length).toBe(8);
    expect(quadrant4[0]).toBe(41);
    expect(quadrant4[7]).toBe(48);
  });

  it("should serialize teeth to JSON", () => {
    const teeth = [11, 12, 13, 21, 22];
    const serialized = JSON.stringify(teeth);
    const deserialized = JSON.parse(serialized);
    
    expect(deserialized).toEqual(teeth);
  });

  it("should handle empty JSON serialization", () => {
    const teeth: number[] = [];
    const serialized = JSON.stringify(teeth);
    const deserialized = JSON.parse(serialized);
    
    expect(deserialized).toEqual([]);
    expect(deserialized.length).toBe(0);
  });

  it("should validate tooth numbers are in range 1-32", () => {
    const validTeeth = [1, 11, 18, 21, 32];
    const isValid = validTeeth.every(t => t >= 1 && t <= 32);
    
    expect(isValid).toBe(true);
  });

  it("should handle mixed selection from multiple quadrants", () => {
    const selected = new Set<number>([11, 12, 21, 22, 31, 32, 41, 42]);
    const sorted = Array.from(selected).sort((a, b) => a - b);
    
    expect(sorted).toEqual([11, 12, 21, 22, 31, 32, 41, 42]);
    expect(sorted.length).toBe(8);
  });

  it("should handle onChange callback", () => {
    const mockOnChange = vi.fn();
    const teeth = [11, 12, 13];
    
    mockOnChange(teeth);
    
    expect(mockOnChange).toHaveBeenCalledWith(teeth);
    expect(mockOnChange).toHaveBeenCalledTimes(1);
  });

  it("should update selected teeth when prop changes", () => {
    const initialTeeth = [11, 12];
    const updatedTeeth = [21, 22, 23];
    
    let selectedTeeth = initialTeeth;
    expect(selectedTeeth).toEqual([11, 12]);
    
    selectedTeeth = updatedTeeth;
    expect(selectedTeeth).toEqual([21, 22, 23]);
  });
});
