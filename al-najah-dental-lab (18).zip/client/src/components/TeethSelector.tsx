"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { RealisticToothImage } from "./RealisticToothImage";

interface TeethSelectorProps {
  selectedTeeth?: string[];
  onChange: (teeth: string[]) => void;
}

/**
 * مكون اختيار الأسنان بتصميم احترافي وتفاعلي
 * عرض الأسنان كما نراها من الأمام (كما لو كنا ننظر مباشرة إلى وجه المريض)
 * الفك العلوي في الأعلى والفك السفلي في الأسفل
 */
export function TeethSelector({ selectedTeeth = [], onChange }: TeethSelectorProps) {
  const [selected, setSelected] = useState<Set<string>>(new Set(selectedTeeth));

  useEffect(() => {
    setSelected(new Set(selectedTeeth));
  }, [selectedTeeth]);

  const toggleTooth = (toothId: string) => {
    const newSelected = new Set(selected);
    if (newSelected.has(toothId)) {
      newSelected.delete(toothId);
    } else {
      newSelected.add(toothId);
    }
    setSelected(newSelected);
    onChange(Array.from(newSelected));
  };

  const clearAll = () => {
    setSelected(new Set());
    onChange([]);
  };

  const selectAll = () => {
    const allTeeth = [
      // الفك العلوي يسار (معكوس في العرض - من وجهة نظر المريض)
      "T1L", "T2L", "T3L", "T4L", "T5L", "T6L", "T7L", "T8L",
      // الفك العلوي يمين
      "T1R", "T2R", "T3R", "T4R", "T5R", "T6R", "T7R", "T8R",
      // الفك السفلي يسار
      "B1L", "B2L", "B3L", "B4L", "B5L", "B6L", "B7L", "B8L",
      // الفك السفلي يمين
      "B1R", "B2R", "B3R", "B4R", "B5R", "B6R", "B7R", "B8R",
    ];
    setSelected(new Set(allTeeth));
    onChange(allTeeth);
  };

  const getToothDisplay = (toothId: string) => {
    const [jaw, number, side] = toothId.match(/([TB])(\d)([LR])/)?.slice(1) || [];
    return number;
  };

  // ترتيب الأسنان كما نراها من الأمام
  // الفك العلوي: من اليسار إلى اليمين (من وجهة نظر المريض)
  const topLeftTeeth = ["T8L", "T7L", "T6L", "T5L", "T4L", "T3L", "T2L", "T1L"];
  const topRightTeeth = ["T1R", "T2R", "T3R", "T4R", "T5R", "T6R", "T7R", "T8R"];
  
  // الفك السفلي: من اليسار إلى اليمين (من وجهة نظر المريض)
  const bottomLeftTeeth = ["B8L", "B7L", "B6L", "B5L", "B4L", "B3L", "B2L", "B1L"];
  const bottomRightTeeth = ["B1R", "B2R", "B3R", "B4R", "B5R", "B6R", "B7R", "B8R"];

  return (
    <div className="space-y-6">
      {/* رأس القسم مع أزرار التحكم */}
      <div className="flex justify-between items-center bg-gradient-to-r from-blue-50 to-green-50 p-4 rounded-lg border-2 border-blue-200">
        <div>
          <h3 className="text-lg font-bold text-gray-800">اختر أرقام الأسنان</h3>
          <p className="text-sm text-gray-600 mt-1">انقر على السن لاختياره أو إلغاء اختياره</p>
        </div>
        <div className="space-x-2 flex">
          <Button
            onClick={selectAll}
            variant="outline"
            size="sm"
            className="text-xs bg-blue-500 text-white hover:bg-blue-600 border-blue-600"
          >
            اختر الكل
          </Button>
          <Button
            onClick={clearAll}
            variant="outline"
            size="sm"
            className="text-xs bg-red-500 text-white hover:bg-red-600 border-red-600"
          >
            مسح الكل
          </Button>
        </div>
      </div>

      {/* مفتاح الألوان والإحصائيات */}
      <div className="grid grid-cols-3 gap-4 bg-gradient-to-r from-gray-50 to-gray-100 p-4 rounded-lg border border-gray-200">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-b from-blue-50 to-blue-100 border-3 border-blue-400 rounded-lg shadow-md"></div>
          <div>
            <span className="text-xs font-bold text-gray-600">الفك العلوي</span>
            <p className="text-xs text-gray-500">16 سن</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-b from-green-50 to-green-100 border-3 border-green-400 rounded-lg shadow-md"></div>
          <div>
            <span className="text-xs font-bold text-gray-600">الفك السفلي</span>
            <p className="text-xs text-gray-500">16 سن</p>
          </div>
        </div>
        <div className="flex items-center gap-3 bg-white rounded-lg p-2 border border-gray-300">
          <div className="w-8 h-8 bg-gradient-to-b from-purple-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-sm shadow-md">
            {selected.size}
          </div>
          <div>
            <span className="text-xs font-bold text-gray-600">مختار</span>
            <p className="text-xs text-gray-500">من 32 سن</p>
          </div>
        </div>
      </div>

      {/* عرض الأسنان من الأمام */}
      <div className="bg-white rounded-xl border-3 border-gray-300 p-8 shadow-lg overflow-x-auto">
        {/* الفك العلوي */}
        <div className="mb-16">
          <div className="text-center mb-6">
            <div className="inline-block bg-gradient-to-r from-blue-100 to-blue-50 px-4 py-2 rounded-full border-2 border-blue-400">
              <span className="text-xs font-bold text-blue-700 uppercase tracking-wider">👆 الفك العلوي</span>
            </div>
          </div>
          <div className="flex justify-center gap-2 mb-6 overflow-x-auto pb-2">
            {/* الجانب الأيسر من الفك العلوي */}
            <div className="flex gap-2">
              {topLeftTeeth.map((toothId) => (
                <RealisticToothImage
                  key={toothId}
                  toothId={toothId}
                  isSelected={selected.has(toothId)}
                  onClick={() => toggleTooth(toothId)}
                />
              ))}
            </div>

            {/* خط فاصل في المنتصف */}
            <div className="w-2 bg-gradient-to-b from-blue-300 to-blue-500 mx-4 rounded-full shadow-md"></div>

            {/* الجانب الأيمن من الفك العلوي */}
            <div className="flex gap-2">
              {topRightTeeth.map((toothId) => (
                <RealisticToothImage
                  key={toothId}
                  toothId={toothId}
                  isSelected={selected.has(toothId)}
                  onClick={() => toggleTooth(toothId)}
                />
              ))}
            </div>
          </div>
        </div>

        {/* الفك السفلي */}
        <div>
          <div className="text-center mb-6">
            <div className="inline-block bg-gradient-to-r from-green-100 to-green-50 px-4 py-2 rounded-full border-2 border-green-400">
              <span className="text-xs font-bold text-green-700 uppercase tracking-wider">👇 الفك السفلي</span>
            </div>
          </div>
          <div className="flex justify-center gap-2 overflow-x-auto pb-2">
            {/* الجانب الأيسر من الفك السفلي */}
            <div className="flex gap-2">
              {bottomLeftTeeth.map((toothId) => (
                <RealisticToothImage
                  key={toothId}
                  toothId={toothId}
                  isSelected={selected.has(toothId)}
                  onClick={() => toggleTooth(toothId)}
                />
              ))}
            </div>

            {/* خط فاصل في المنتصف */}
            <div className="w-2 bg-gradient-to-b from-green-300 to-green-500 mx-4 rounded-full shadow-md"></div>

            {/* الجانب الأيمن من الفك السفلي */}
            <div className="flex gap-2">
              {bottomRightTeeth.map((toothId) => (
                <RealisticToothImage
                  key={toothId}
                  toothId={toothId}
                  isSelected={selected.has(toothId)}
                  onClick={() => toggleTooth(toothId)}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* عرض الأسنان المختارة */}
      {selected.size > 0 && (
        <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-lg border-2 border-purple-300 shadow-md">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm font-bold text-gray-800">
              ✅ الأسنان المختارة: <span className="text-purple-600 text-lg">{selected.size}</span>
            </p>
            <span className="text-xs bg-purple-500 text-white px-3 py-1 rounded-full font-bold">
              {Math.round((selected.size / 32) * 100)}% من الأسنان
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {Array.from(selected).sort().map((toothId) => (
              <span
                key={toothId}
                className={`px-3 py-2 rounded-full text-xs font-bold transition-all hover:scale-110 cursor-pointer ${
                  toothId.startsWith("T")
                    ? "bg-blue-500 text-white shadow-md"
                    : "bg-green-500 text-white shadow-md"
                }`}
                onClick={() => toggleTooth(toothId)}
                title="انقر لإلغاء الاختيار"
              >
                {toothId}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* رسالة عندما لا يكون هناك أسنان مختارة */}
      {selected.size === 0 && (
        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 p-6 rounded-lg border-2 border-yellow-300 text-center">
          <p className="text-sm text-gray-700 font-semibold">
            ℹ️ لم تختر أي أسنان حتى الآن. انقر على الأسنان أعلاه لاختيارها.
          </p>
        </div>
      )}
    </div>
  );
}
