import { Users, Building2, FileText, AlertCircle, Clock, CheckCircle } from "lucide-react";
import UserCard from "./UserCard";

// ألوان احترافية لمخبر طب الأسنان
const COLORS = {
  primary: '#1e5a96',
  secondary: '#2ecc71',
  accent: '#3498db',
  danger: '#e74c3c',
};

interface TopBarProps {
  doctorsCount?: number;
  worksCount?: number;
  invoicesCount?: number;
  receivables?: number;
  pendingWorks?: number;
  inProgressWorks?: number;
  completedWorks?: number;
}

export default function TopBar({
  doctorsCount = 18,
  worksCount = 207,
  invoicesCount = 2,
  receivables = 0,
  pendingWorks = 0,
  inProgressWorks = 0,
  completedWorks = 0,
}: TopBarProps) {
  return (
    <div className="bg-gradient-to-r from-white to-slate-50 border-b border-slate-200 px-6 py-3 shadow-sm">
      <div className="flex justify-between items-center gap-6">
        {/* الشعار */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <img src="/logo.png" alt="مخبر النجاح" className="h-12 object-contain" />
        </div>
        {/* الإحصائيات - وسط الشريط */}
        <div className="flex items-center gap-6 flex-1">
          {/* الأطباء */}
          <div className="flex items-center gap-3 p-3 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg border border-blue-200 hover:shadow-md transition-shadow">
            <div className="bg-white p-2 rounded-lg">
              <Users className="h-6 w-6 text-[#1e5a96]" />
            </div>
            <div>
              <p className="text-xs text-slate-600 font-medium">الأطباء</p>
              <p className="text-2xl font-bold text-[#1e5a96]">{doctorsCount}</p>
            </div>
          </div>

          {/* الأعمال */}
          <div className="flex items-center gap-3 p-3 bg-gradient-to-br from-green-50 to-green-100 rounded-lg border border-green-200 hover:shadow-md transition-shadow">
            <div className="bg-white p-2 rounded-lg">
              <Building2 className="h-6 w-6 text-[#2ecc71]" />
            </div>
            <div>
              <p className="text-xs text-slate-600 font-medium">الأعمال</p>
              <p className="text-2xl font-bold text-[#2ecc71]">{worksCount}</p>
            </div>
          </div>

          {/* الفواتير */}
          <div className="flex items-center gap-3 p-3 bg-gradient-to-br from-cyan-50 to-cyan-100 rounded-lg border border-cyan-200 hover:shadow-md transition-shadow">
            <div className="bg-white p-2 rounded-lg">
              <FileText className="h-6 w-6 text-[#3498db]" />
            </div>
            <div>
              <p className="text-xs text-slate-600 font-medium">الفواتير</p>
              <p className="text-2xl font-bold text-[#3498db]">{invoicesCount}</p>
            </div>
          </div>

          {/* الأعمال المعلقة */}
          <div className="flex items-center gap-3 p-3 bg-gradient-to-br from-red-50 to-red-100 rounded-lg border border-red-200 hover:shadow-md transition-shadow">
            <div className="bg-white p-2 rounded-lg">
              <AlertCircle className="h-6 w-6 text-[#e74c3c]" />
            </div>
            <div>
              <p className="text-xs text-slate-600 font-medium">الأعمال المعلقة</p>
              <p className="text-2xl font-bold text-[#e74c3c]">{pendingWorks}</p>
            </div>
          </div>

          {/* الأعمال قيد التنفيذ */}
          <div className="flex items-center gap-3 p-3 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg border border-yellow-200 hover:shadow-md transition-shadow">
            <div className="bg-white p-2 rounded-lg">
              <Clock className="h-6 w-6 text-[#f39c12]" />
            </div>
            <div>
              <p className="text-xs text-slate-600 font-medium">قيد التنفيذ</p>
              <p className="text-2xl font-bold text-[#f39c12]">{inProgressWorks}</p>
            </div>
          </div>

          {/* الأعمال المكتملة */}
          <div className="flex items-center gap-3 p-3 bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-lg border border-emerald-200 hover:shadow-md transition-shadow">
            <div className="bg-white p-2 rounded-lg">
              <CheckCircle className="h-6 w-6 text-[#27ae60]" />
            </div>
            <div>
              <p className="text-xs text-slate-600 font-medium">الأعمال المكتملة</p>
              <p className="text-2xl font-bold text-[#27ae60]">{completedWorks}</p>
            </div>
          </div>
        </div>
        {/* بطاقة المستخدم الحالي - على اليمين */}
        <div className="flex-shrink-0">
          <UserCard />
        </div>
      </div>
    </div>
  );
}

