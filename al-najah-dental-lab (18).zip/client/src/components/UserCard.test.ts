import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import UserCard from "./UserCard";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

// Mock the hooks
vi.mock("@/_core/hooks/useAuth");
vi.mock("@/lib/trpc");

describe("UserCard Component", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should render user card with user information", () => {
    const mockUser = {
      id: 1,
      name: "أحمد محمد",
      role: "admin",
      email: "ahmed@example.com",
    };

    vi.mocked(useAuth).mockReturnValue({
      user: mockUser,
      logout: vi.fn(),
      loading: false,
      error: null,
      isAuthenticated: true,
      refresh: vi.fn(),
    });

    vi.mocked(trpc.users.getAll.useQuery).mockReturnValue({
      data: [],
      isLoading: false,
      error: null,
    } as any);

    vi.mocked(trpc.switchUser.switchUser.useMutation).mockReturnValue({
      mutate: vi.fn(),
      mutateAsync: vi.fn(),
      isPending: false,
    } as any);

    render(<UserCard />);

    // التحقق من ظهور اسم المستخدم
    expect(screen.getByText("أحمد محمد")).toBeInTheDocument();

    // التحقق من ظهور الدور
    expect(screen.getByText("مسؤول")).toBeInTheDocument();

    // التحقق من ظهور الأيقونة (الحروف الأولى)
    expect(screen.getByText("أم")).toBeInTheDocument();
  });

  it("should show dropdown menu when user card is clicked", async () => {
    const mockUser = {
      id: 1,
      name: "أحمد محمد",
      role: "admin",
      email: "ahmed@example.com",
    };

    vi.mocked(useAuth).mockReturnValue({
      user: mockUser,
      logout: vi.fn(),
      loading: false,
      error: null,
      isAuthenticated: true,
      refresh: vi.fn(),
    });

    vi.mocked(trpc.users.getAll.useQuery).mockReturnValue({
      data: [],
      isLoading: false,
      error: null,
    } as any);

    vi.mocked(trpc.switchUser.switchUser.useMutation).mockReturnValue({
      mutate: vi.fn(),
      mutateAsync: vi.fn(),
      isPending: false,
    } as any);

    render(<UserCard />);

    // النقر على بطاقة المستخدم
    const userButton = screen.getByRole("button", { name: /أحمد محمد/ });
    fireEvent.click(userButton);

    // التحقق من ظهور القائمة المنسدلة
    await waitFor(() => {
      expect(screen.getByText("المستخدم الحالي")).toBeInTheDocument();
    });
  });

  it("should show switch user option only for admin", async () => {
    const mockUser = {
      id: 1,
      name: "أحمد محمد",
      role: "admin",
      email: "ahmed@example.com",
    };

    vi.mocked(useAuth).mockReturnValue({
      user: mockUser,
      logout: vi.fn(),
      loading: false,
      error: null,
      isAuthenticated: true,
      refresh: vi.fn(),
    });

    vi.mocked(trpc.users.getAll.useQuery).mockReturnValue({
      data: [],
      isLoading: false,
      error: null,
    } as any);

    vi.mocked(trpc.switchUser.switchUser.useMutation).mockReturnValue({
      mutate: vi.fn(),
      mutateAsync: vi.fn(),
      isPending: false,
    } as any);

    render(<UserCard />);

    // النقر على بطاقة المستخدم
    const userButton = screen.getByRole("button", { name: /أحمد محمد/ });
    fireEvent.click(userButton);

    // التحقق من ظهور خيار تبديل المستخدم
    await waitFor(() => {
      expect(screen.getByText("تبديل المستخدم")).toBeInTheDocument();
    });
  });

  it("should not show switch user option for non-admin users", async () => {
    const mockUser = {
      id: 2,
      name: "علي أحمد",
      role: "user",
      email: "ali@example.com",
    };

    vi.mocked(useAuth).mockReturnValue({
      user: mockUser,
      logout: vi.fn(),
      loading: false,
      error: null,
      isAuthenticated: true,
      refresh: vi.fn(),
    });

    vi.mocked(trpc.users.getAll.useQuery).mockReturnValue({
      data: [],
      isLoading: false,
      error: null,
    } as any);

    vi.mocked(trpc.switchUser.switchUser.useMutation).mockReturnValue({
      mutate: vi.fn(),
      mutateAsync: vi.fn(),
      isPending: false,
    } as any);

    render(<UserCard />);

    // النقر على بطاقة المستخدم
    const userButton = screen.getByRole("button", { name: /علي أحمد/ });
    fireEvent.click(userButton);

    // التحقق من عدم ظهور خيار تبديل المستخدم
    await waitFor(() => {
      expect(screen.queryByText("تبديل المستخدم")).not.toBeInTheDocument();
    });
  });

  it("should display user list when switch user option is clicked", async () => {
    const mockUser = {
      id: 1,
      name: "أحمد محمد",
      role: "admin",
      email: "ahmed@example.com",
    };

    const mockUsers = [
      { id: 2, name: "علي أحمد", role: "user", email: "ali@example.com" },
      { id: 3, name: "فاطمة علي", role: "manager", email: "fatima@example.com" },
    ];

    vi.mocked(useAuth).mockReturnValue({
      user: mockUser,
      logout: vi.fn(),
      loading: false,
      error: null,
      isAuthenticated: true,
      refresh: vi.fn(),
    });

    vi.mocked(trpc.users.getAll.useQuery).mockReturnValue({
      data: mockUsers,
      isLoading: false,
      error: null,
    } as any);

    vi.mocked(trpc.switchUser.switchUser.useMutation).mockReturnValue({
      mutate: vi.fn(),
      mutateAsync: vi.fn(),
      isPending: false,
    } as any);

    render(<UserCard />);

    // النقر على بطاقة المستخدم
    const userButton = screen.getByRole("button", { name: /أحمد محمد/ });
    fireEvent.click(userButton);

    // النقر على خيار تبديل المستخدم
    await waitFor(() => {
      const switchButton = screen.getByText("تبديل المستخدم");
      fireEvent.click(switchButton);
    });

    // التحقق من ظهور قائمة المستخدمين
    await waitFor(() => {
      expect(screen.getByText("علي أحمد")).toBeInTheDocument();
      expect(screen.getByText("فاطمة علي")).toBeInTheDocument();
    });
  });

  it("should call logout when logout button is clicked", async () => {
    const mockLogout = vi.fn();
    const mockUser = {
      id: 1,
      name: "أحمد محمد",
      role: "admin",
      email: "ahmed@example.com",
    };

    vi.mocked(useAuth).mockReturnValue({
      user: mockUser,
      logout: mockLogout,
      loading: false,
      error: null,
      isAuthenticated: true,
      refresh: vi.fn(),
    });

    vi.mocked(trpc.users.getAll.useQuery).mockReturnValue({
      data: [],
      isLoading: false,
      error: null,
    } as any);

    vi.mocked(trpc.switchUser.switchUser.useMutation).mockReturnValue({
      mutate: vi.fn(),
      mutateAsync: vi.fn(),
      isPending: false,
    } as any);

    render(<UserCard />);

    // النقر على بطاقة المستخدم
    const userButton = screen.getByRole("button", { name: /أحمد محمد/ });
    fireEvent.click(userButton);

    // النقر على زر تسجيل الخروج
    await waitFor(() => {
      const logoutButton = screen.getByText("تسجيل الخروج");
      fireEvent.click(logoutButton);
    });

    // التحقق من استدعاء دالة logout
    expect(mockLogout).toHaveBeenCalled();
  });

  it("should display correct role colors", () => {
    const mockUser = {
      id: 1,
      name: "أحمد محمد",
      role: "admin",
      email: "ahmed@example.com",
    };

    vi.mocked(useAuth).mockReturnValue({
      user: mockUser,
      logout: vi.fn(),
      loading: false,
      error: null,
      isAuthenticated: true,
      refresh: vi.fn(),
    });

    vi.mocked(trpc.users.getAll.useQuery).mockReturnValue({
      data: [],
      isLoading: false,
      error: null,
    } as any);

    vi.mocked(trpc.switchUser.switchUser.useMutation).mockReturnValue({
      mutate: vi.fn(),
      mutateAsync: vi.fn(),
      isPending: false,
    } as any);

    const { container } = render(<UserCard />);

    // التحقق من وجود الدور بالألوان الصحيحة
    const roleElement = screen.getByText("مسؤول");
    expect(roleElement).toHaveClass("text-red-700");
  });
});
