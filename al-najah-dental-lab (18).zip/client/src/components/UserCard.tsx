import { ChevronDown, LogOut, Users } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

interface UserCardProps {
  onSwitchUser?: (userId: string) => void;
}

export default function UserCard({ onSwitchUser }: UserCardProps) {
  const { user, logout } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [showUserList, setShowUserList] = useState(false);
  const utils = trpc.useUtils();

  // جلب قائمة المستخدمين (للمسؤول فقط)
  const { data: users = [] } = trpc.users.getAll.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  const switchUserMutation = trpc.users.switchUser.useMutation({
    onSuccess: () => {
      setShowUserList(false);
      setIsOpen(false);
      
      // مسح بيانات المستخدم السابق من localStorage
      localStorage.removeItem('manus-runtime-user-info');
      localStorage.removeItem('loginUsername');
      localStorage.removeItem('loginRememberMe');
      
      // مسح tRPC cache للمستخدم الحالي
      utils.auth.me.setData(undefined, null);
      
      // إعادة تحميل الصفحة مع تأخير صغير للتأكد من أن الخادم حدّث الجلسة
      // هذا يضمن أن جميع المكونات تحصل على بيانات المستخدم الجديد من الخادم
      setTimeout(() => {
        window.location.reload();
      }, 500);
    },
    onError: (error) => {
      console.error("Failed to switch user:", error);
    },
  });

  if (!user) {
    return null;
  }

  // ترجمة الأدوار إلى العربية
  const roleTranslation: Record<string, string> = {
    admin: "مسؤول",
    manager: "مدير",
    staff: "موظف",
    user: "مستخدم",
  };

  const roleLabel = roleTranslation[user.role] || user.role;

  // الحصول على الحرف الأول من الاسم لعرضه في الأيقونة
  const initials = user.name
    ?.split(" ")
    .map((n: string) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2) || "U";

  // ألوان مختلفة لكل دور
  const roleColors: Record<string, { bg: string; text: string }> = {
    admin: { bg: "bg-red-100", text: "text-red-700" },
    manager: { bg: "bg-blue-100", text: "text-blue-700" },
    staff: { bg: "bg-green-100", text: "text-green-700" },
    user: { bg: "bg-gray-100", text: "text-gray-700" },
  };

  const roleColor = roleColors[user.role] || roleColors.user;

  return (
    <div className="relative">
      {/* زر بطاقة المستخدم */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-3 px-4 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors"
      >
        {/* أيقونة المستخدم */}
        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 text-white text-sm font-bold">
          {initials}
        </div>

        {/* معلومات المستخدم */}
        <div className="text-right">
          <p className="text-sm font-semibold text-slate-900">{user.name}</p>
          <p className={`text-xs font-medium ${roleColor.text}`}>{roleLabel}</p>
        </div>

        {/* أيقونة السهم */}
        <ChevronDown
          className={`h-4 w-4 text-slate-600 transition-transform ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>

      {/* القائمة المنسدلة */}
      {isOpen && (
        <div className="absolute top-full right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-slate-200 z-50">
          {/* معلومات المستخدم الحالي */}
          <div className="px-4 py-3 border-b border-slate-200">
            <p className="text-xs text-slate-600 mb-2">المستخدم الحالي</p>
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 text-white font-bold">
                {initials}
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-900">
                  {user.name}
                </p>
                <span
                  className={`inline-block px-2 py-1 rounded text-xs font-medium ${roleColor.bg} ${roleColor.text}`}
                >
                  {roleLabel}
                </span>
              </div>
            </div>
          </div>

          {/* خيار تبديل المستخدم (للمسؤول فقط) */}
          {user.role === "admin" && (
            <>
              <button
                onClick={() => setShowUserList(!showUserList)}
                className="w-full px-4 py-3 text-right hover:bg-slate-50 transition-colors flex items-center gap-2 text-slate-700 text-sm font-medium border-b border-slate-200"
              >
                <Users className="h-4 w-4" />
                تبديل المستخدم
              </button>

              {/* قائمة المستخدمين */}
              {showUserList && (
                <div className="max-h-48 overflow-y-auto">
                  {users
                    .filter((u) => u.id !== user.id)
                    .map((u) => (
                      <button
                        key={u.id}
                        onClick={() => {
                          switchUserMutation.mutate({ userId: u.id });
                        }}
                        disabled={switchUserMutation.isPending}
                        className="w-full px-4 py-2 text-right hover:bg-blue-50 transition-colors text-sm text-slate-700 border-b border-slate-100 last:border-b-0 disabled:opacity-50"
                      >
                        <p className="font-medium">{u.name}</p>
                        <p className="text-xs text-slate-500">
                          {roleTranslation[u.role] || u.role}
                        </p>
                      </button>
                    ))}
                </div>
              )}
            </>
          )}

          {/* خيار تسجيل الخروج */}
          <button
            onClick={() => {
              logout();
              setIsOpen(false);
            }}
            className="w-full px-4 py-3 text-right hover:bg-red-50 transition-colors flex items-center gap-2 text-red-700 text-sm font-medium"
          >
            <LogOut className="h-4 w-4" />
            تسجيل الخروج
          </button>
        </div>
      )}
    </div>
  );
}
