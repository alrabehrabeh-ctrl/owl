import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { ChevronDown, Users } from "lucide-react";
import { Input } from "@/components/ui/input";

export function UserSwitcher() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const { data: availableUsers, isLoading } =
    trpc.users.getAvailableForSwitch.useQuery(undefined, {
      enabled: isOpen,
    });

  const utils = trpc.useUtils();

  // إجراء تسجيل خروج
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: async () => {
      // بعد التسجيل الخروج الناجح، قم بتسجيل دخول المستخدم الجديد
      if (selectedUserId) {
        directLoginMutation.mutate({ userId: selectedUserId });
      }
    },
    onError: (error: any) => {
      console.error("Logout error:", error);
      setPasswordError("فشل تسجيل الخروج");
    },
  });

  // إجراء تسجيل دخول مباشر
  const directLoginMutation = trpc.auth.directLogin.useMutation({
    onSuccess: async () => {
      setPassword("");
      setPasswordError("");
      setSelectedUserId(null);
      await utils.auth.me.invalidate();
      setIsOpen(false);
      setTimeout(() => {
        window.location.reload();
      }, 500);
    },
    onError: (error: any) => {
      console.error("Direct login error:", error);
      setPasswordError(error.message || "فشل تسجيل الدخول");
    },
  });

  const switchUserMutation = trpc.users.switchUser.useMutation({
    onSuccess: async () => {
      // بعد التبديل الناجح، قم بإعادة تحميل الصفحة
      setPassword("");
      setPasswordError("");
      setSelectedUserId(null);
      await utils.auth.me.invalidate();
      setIsOpen(false);
      setTimeout(() => {
        window.location.reload();
      }, 500);
    },
    onError: (error: any) => {
      console.error("Switch user error:", error);
      setPasswordError(error.message || "فشل التبديل");
    },
  });

  const filteredUsers = (availableUsers || []).filter(
    (u: any) =>
      u.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!user) {
    return null;
  }

  const verifyPasswordMutation = trpc.auth.directLogin.useMutation({
    onSuccess: () => {
      if (selectedUserId) {
        switchUserMutation.mutate({ userId: selectedUserId });
        setShowPasswordDialog(false);
      }
    },
    onError: (error: any) => {
      setPasswordError(error.message || "كلمة السر غير صحيحة");
      setPassword("");
    },
  });

  const handlePasswordSubmit = () => {
    if (password && selectedUserId) {
      verifyPasswordMutation.mutate({ userId: selectedUserId });
    } else {
      setPasswordError("يرجى إدخال كلمة السر");
    }
  };

  return (
    <>
      <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            className="gap-2"
            title="التبديل السريع بين المستخدمين"
          >
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">تبديل</span>
            <ChevronDown className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel>التبديل إلى مستخدم آخر</DropdownMenuLabel>
          <DropdownMenuSeparator />

          <div className="px-2 py-2">
            <Input
              placeholder="البحث عن مستخدم..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-8"
            />
          </div>

          <DropdownMenuSeparator />

          {isLoading ? (
            <div className="px-2 py-2 text-sm text-muted-foreground">
              جاري التحميل...
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="px-2 py-2 text-sm text-muted-foreground">
              لا توجد مستخدمين متاحين
            </div>
          ) : (
            <div className="max-h-64 overflow-y-auto">
              {filteredUsers.map((u: any) => (
                <DropdownMenuItem
                  key={u.id}
                  onClick={() => {
                    // احفظ معرفة المستخدم المختار
                    setSelectedUserId(u.id);
                    
                    // إذا كان مسؤولاً، طلب كلمة المرور
                    if (u.role === "admin") {
                      setShowPasswordDialog(true);
                      setPassword("");
                      setPasswordError("");
                    } else {
                      // بالنسبة للمستخدمين العاديين، قم بالتسجيل الخروج أولاً
                      logoutMutation.mutate();
                    }
                  }}
                  disabled={switchUserMutation.isPending}
                  className="cursor-pointer"
                >
                  <div className="flex flex-col gap-1">
                    <span className="font-medium">{u.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {u.email}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      ({u.role === "admin" ? "مسؤول" : "مستخدم"})
                    </span>
                  </div>
                </DropdownMenuItem>
              ))}
            </div>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      {showPasswordDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 max-w-sm w-full mx-4">
            <h2 className="text-lg font-semibold mb-4">تأكيد الهوية</h2>
            <p className="text-sm text-gray-600 mb-4">
              يرجى إدخال كلمة السر للعودة إلى حساب المسؤول
            </p>
            <input
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setPasswordError("");
              }}
              placeholder="أدخل كلمة السر"
              className="w-full px-3 py-2 border border-gray-300 rounded-md mb-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handlePasswordSubmit();
                }
              }}
              autoFocus
            />
            {passwordError && (
              <p className="text-sm text-red-600 mb-4">{passwordError}</p>
            )}
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setShowPasswordDialog(false);
                  setPassword("");
                  setPasswordError("");
                }}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
              >
                إلغاء
              </button>
              <button
                onClick={handlePasswordSubmit}
                disabled={switchUserMutation.isPending || logoutMutation.isPending || directLoginMutation.isPending}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
              >
                تأكيد
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
