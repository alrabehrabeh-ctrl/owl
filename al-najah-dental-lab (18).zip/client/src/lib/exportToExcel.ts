import * as XLSX from 'xlsx';

/**
 * تصدير البيانات إلى ملف Excel
 */
export function exportToExcel<T extends Record<string, any>>(
  data: T[],
  filename: string,
  sheetName: string = "Sheet1"
) {
  if (!data || data.length === 0) {
    console.warn("لا توجد بيانات للتصدير");
    return;
  }

  // إنشاء Workbook جديد
  const workbook = XLSX.utils.book_new();

  // تحويل البيانات إلى ورقة عمل
  const worksheet = XLSX.utils.json_to_sheet(data);

  // تعيين عرض الأعمدة
  const colWidths = Object.keys(data[0]).map(() => 20);
  worksheet['!cols'] = colWidths.map(width => ({ wch: width }));

  // إضافة الورقة إلى الكتاب
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);

  // حفظ الملف
  XLSX.writeFile(workbook, `${filename}.xlsx`);
}

/**
 * تصدير الأعمال إلى Excel
 */
export function exportWorksToExcel(works: any[]) {
  const formattedData = works.map((work) => {
    let toothNumbers: any[] = [];
    try {
      toothNumbers = work.toothNumbers ? JSON.parse(work.toothNumbers) : [];
    } catch (error) {
      console.error('Error parsing toothNumbers:', error);
      toothNumbers = [];
    }
    return {
      "رقم العمل": work.id,
      "اسم الطبيب": work.doctorName || work.doctor?.name || work.doctorId || "-",
      "اسم المريض": work.patientName || "-",
      "الوصف": work.description || "-",
      "أرقام الأسنان": toothNumbers.length > 0 ? toothNumbers.join(", ") : "-",
      "الكمية": work.quantity || 0,
      "السعر": work.price || 0,
      "السعر الإجمالي": work.totalPrice || 0,
      "الحالة": work.status || "قيد الانتظار",
      "تاريخ الاستقبال": work.receptionDate ? new Date(work.receptionDate).toLocaleDateString('ar-SA') : "-",
      "تاريخ التسليم": work.deliveryDate ? new Date(work.deliveryDate).toLocaleDateString('ar-SA') : "-",
      "الملاحظات": work.notes || "-",
    };
  });

  exportToExcel(formattedData, "الأعمال", "الأعمال");
}

/**
 * تصدير الفواتير إلى Excel
 */
export function exportInvoicesToExcel(invoices: any[]) {
  const formattedData = invoices.map((invoice) => ({
    "رقم الفاتورة": invoice.id,
    "الطبيب": invoice.doctorId,
    "المبلغ": invoice.amount || 0,
    "الحالة": invoice.status || "معلقة",
    "الشهر": invoice.month || "-",
    "السنة": invoice.year || "-",
    "الملاحظات": invoice.notes || "-",
    "تاريخ الإنشاء": invoice.createdAt ? new Date(invoice.createdAt).toLocaleDateString('ar-SA') : "-",
  }));

  exportToExcel(formattedData, "الفواتير", "الفواتير");
}

/**
 * تصدير الدفعات إلى Excel
 */
export function exportPaymentsToExcel(payments: any[]) {
  const formattedData = payments.map((payment) => ({
    "رقم الدفعة": payment.id,
    "الطبيب": payment.doctorId,
    "المبلغ": payment.amount || 0,
    "طريقة الدفع": payment.paymentMethod || "-",
    "الحالة": payment.status || "مكتملة",
    "الملاحظات": payment.notes || "-",
    "تاريخ الدفع": payment.paymentDate ? new Date(payment.paymentDate).toLocaleDateString('ar-SA') : "-",
  }));

  exportToExcel(formattedData, "الدفعات", "الدفعات");
}

/**
 * تصدير الأطباء إلى Excel
 */
export function exportDoctorsToExcel(doctors: any[]) {
  const formattedData = doctors.map((doctor) => ({
    "رقم الرخصة": doctor.licenseNumber || "-",
    "الاسم": doctor.name || "-",
    "التخصص": doctor.specialty || "-",
    "البريد الإلكتروني": doctor.email || "-",
    "الهاتف": doctor.phone || "-",
    "العنوان": doctor.address || "-",
    "تاريخ الإنشاء": doctor.createdAt ? new Date(doctor.createdAt).toLocaleDateString('ar-SA') : "-",
  }));

  exportToExcel(formattedData, "الأطباء", "الأطباء");
}

/**
 * تصدير المصروفات إلى Excel
 */
export function exportExpensesToExcel(expenses: any[]) {
  const formattedData = expenses.map((expense) => ({
    "رقم المصروف": expense.id,
    "الوصف": expense.description || "-",
    "المبلغ": expense.amount || 0,
    "الفئة": expense.category || "-",
    "الملاحظات": expense.notes || "-",
    "تاريخ المصروف": expense.expenseDate ? new Date(expense.expenseDate).toLocaleDateString('ar-SA') : "-",
  }));

  exportToExcel(formattedData, "المصروفات", "المصروفات");
}
