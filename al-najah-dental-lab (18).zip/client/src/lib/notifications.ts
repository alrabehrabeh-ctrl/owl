import { toast } from "sonner";

export type NotificationType = "success" | "error" | "warning" | "info";

/**
 * إظهار إشعار نجاح
 */
export const showSuccessNotification = (message: string, description?: string) => {
  toast.success(message, {
    description,
    duration: 4000,
    position: "top-right",
  });
};

/**
 * إظهار إشعار خطأ
 */
export const showErrorNotification = (message: string, description?: string) => {
  toast.error(message, {
    description,
    duration: 5000,
    position: "top-right",
  });
};

/**
 * إظهار إشعار تحذير
 */
export const showWarningNotification = (message: string, description?: string) => {
  toast.warning(message, {
    description,
    duration: 4000,
    position: "top-right",
  });
};

/**
 * إظهار إشعار معلومات
 */
export const showInfoNotification = (message: string, description?: string) => {
  toast.info(message, {
    description,
    duration: 4000,
    position: "top-right",
  });
};

/**
 * إظهار إشعار مديونية مستحقة
 */
export const showReceivableNotification = (doctorName: string, amount: number) => {
  toast.warning(`⚠️ مديونية مستحقة`, {
    description: `الدكتور ${doctorName} عليه ${amount} دولار`,
    duration: 6000,
    position: "top-right",
  });
};

/**
 * إظهار إشعار عمل متأخر
 */
export const showOverdueWorkNotification = (workName: string, daysOverdue: number) => {
  toast.error(`⏰ عمل متأخر`, {
    description: `${workName} متأخر منذ ${daysOverdue} أيام`,
    duration: 6000,
    position: "top-right",
  });
};

/**
 * إظهار إشعار فاتورة جديدة
 */
export const showNewInvoiceNotification = (invoiceNumber: string, amount: number) => {
  toast.success(`✅ فاتورة جديدة`, {
    description: `الفاتورة #${invoiceNumber} بقيمة $${amount}`,
    duration: 4000,
    position: "top-right",
  });
};

/**
 * إظهار إشعار دفعة جديدة
 */
export const showNewPaymentNotification = (doctorName: string, amount: number) => {
  toast.success(`💰 دفعة جديدة`, {
    description: `دفعة من ${doctorName} بقيمة $${amount}`,
    duration: 4000,
    position: "top-right",
  });
};

/**
 * إظهار إشعار حذف
 */
export const showDeleteNotification = (itemName: string) => {
  toast.info(`🗑️ تم الحذف`, {
    description: `تم حذف ${itemName} بنجاح`,
    duration: 3000,
    position: "top-right",
  });
};

/**
 * إظهار إشعار تحديث
 */
export const showUpdateNotification = (itemName: string) => {
  toast.success(`✏️ تم التحديث`, {
    description: `تم تحديث ${itemName} بنجاح`,
    duration: 3000,
    position: "top-right",
  });
};

/**
 * إظهار إشعار تحميل
 */
export const showLoadingNotification = (message: string) => {
  return toast.loading(message, {
    position: "top-right",
  });
};

/**
 * تحديث إشعار التحميل
 */
export const updateNotification = (toastId: string | number, message: string, type: NotificationType = "success") => {
  if (type === "success") {
    toast.success(message, { id: toastId as string });
  } else if (type === "error") {
    toast.error(message, { id: toastId as string });
  } else if (type === "warning") {
    toast.warning(message, { id: toastId as string });
  } else {
    toast.info(message, { id: toastId as string });
  }
};

/**
 * تشغيل صوت إشعار
 */
export const playNotificationSound = () => {
  try {
    // استخدام Web Audio API لتشغيل صوت بسيط
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.value = 800; // التردد بالهرتز
    oscillator.type = "sine";

    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
  } catch (error) {
    console.log("لم يتمكن من تشغيل الصوت");
  }
};

/**
 * إظهار إشعار مع صوت
 */
export const showNotificationWithSound = (
  message: string,
  type: NotificationType = "info",
  description?: string
) => {
  playNotificationSound();

  if (type === "success") {
    showSuccessNotification(message, description);
  } else if (type === "error") {
    showErrorNotification(message, description);
  } else if (type === "warning") {
    showWarningNotification(message, description);
  } else {
    showInfoNotification(message, description);
  }
};
