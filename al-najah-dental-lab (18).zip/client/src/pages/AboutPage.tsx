import { Users, Code, Heart } from "lucide-react";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* العنوان الرئيسي */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">عن النظام</h1>
          <p className="text-xl text-gray-600">نظام إدارة وحسابات متكامل لمخبر النجاح للتعويضات السنية</p>
        </div>

        {/* معلومات النظام */}
        <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">عن المشروع</h2>
          <p className="text-gray-700 mb-4">
            نظام إدارة مخبر النجاح للتعويضات السنية هو تطبيق ويب متكامل مصمم لإدارة جميع جوانب العمليات المالية والإدارية للمختبر. يوفر النظام واجهة سهلة الاستخدام لتتبع الأطباء والأعمال والفواتير والدفعات والمصروفات والرواتب.
          </p>
          <p className="text-gray-700">
            تم تطوير هذا النظام بعناية لتوفير حل شامل يلبي احتياجات مخبر النجاح ويساعد في تحسين الكفاءة الإدارية والمالية.
          </p>
        </div>

        {/* الفريق */}
        <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            <Users className="h-6 w-6 text-blue-600" />
            فريق التطوير
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* المطور الأول */}
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-6 border border-blue-200">
              <div className="flex items-center gap-3 mb-3">
                <Code className="h-6 w-6 text-blue-600" />
                <h3 className="text-xl font-bold text-gray-800">ربيع الربيع</h3>
              </div>
              <p className="text-gray-700 mb-2">
                <span className="font-semibold">المسمى الوظيفي:</span> مطور ويب
              </p>
              <p className="text-gray-700 mb-2">
                <span className="font-semibold">المسؤوليات:</span>
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-1">
                <li>تطوير الواجهة الأمامية (Frontend)</li>
                <li>تطوير الخادم (Backend)</li>
                <li>تصميم قاعدة البيانات</li>
                <li>إدارة المشروع التقني</li>
              </ul>
            </div>

            {/* معلومات إضافية */}
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-6 border border-purple-200">
              <div className="flex items-center gap-3 mb-3">
                <Heart className="h-6 w-6 text-purple-600" />
                <h3 className="text-xl font-bold text-gray-800">الإدارة</h3>
              </div>
              <p className="text-gray-700 mb-2">
                <span className="font-semibold">المسؤولون:</span> ربيع الربيع - إيناس الربيع
              </p>
              <p className="text-gray-700 mb-2">
                <span className="font-semibold">المسؤوليات:</span>
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-1">
                <li>إدارة المشروع</li>
                <li>تحديد المتطلبات</li>
                <li>ضمان جودة النظام</li>
                <li>دعم المستخدمين</li>
              </ul>
            </div>
          </div>
        </div>

        {/* الميزات الرئيسية */}
        <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">الميزات الرئيسية</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-2 mt-1">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">إدارة الأطباء</h3>
                <p className="text-gray-600 text-sm">إضافة وتعديل وحذف بيانات الأطباء</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-2 mt-1">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">إدارة الأعمال</h3>
                <p className="text-gray-600 text-sm">تسجيل وتتبع الأعمال المنفذة</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-2 mt-1">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">نظام الفواتير</h3>
                <p className="text-gray-600 text-sm">إنشاء وتصدير فواتير احترافية</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-2 mt-1">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">إدارة الدفعات</h3>
                <p className="text-gray-600 text-sm">تسجيل ومتابعة الدفعات</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-2 mt-1">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">التقارير المالية</h3>
                <p className="text-gray-600 text-sm">عرض تقارير شاملة للإيرادات والمصروفات</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-2 mt-1">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">توزيع الأرباح</h3>
                <p className="text-gray-600 text-sm">حساب وتوزيع الأرباح تلقائياً</p>
              </div>
            </div>
          </div>
        </div>

        {/* موقع الملخص والملفات */}
        <div className="bg-gradient-to-br from-green-50 to-emerald-100 rounded-lg shadow-lg p-8 mb-8 border border-green-200">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            <span className="text-2xl">📚</span>
            الملفات والتوثيق
          </h2>
          <div className="bg-white rounded-lg p-6 mb-4">
            <p className="text-gray-700 mb-4">
              تم إنشاء موقع ويب شامل يعرض ملخص المشروع والملفات المهمة. يمكنك الوصول إليه من الرابط أدناه:
            </p>
            <div className="bg-green-50 border border-green-300 rounded-lg p-4 mb-4">
              <p className="text-sm text-gray-600 mb-2">🌐 <span className="font-semibold">موقع الملخص والملفات:</span></p>
              <a 
                href="https://8000-itb2na23308g3u9ydea9k-24cb5a15.sg1.manus.computer" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-800 font-semibold break-all text-sm"
              >
                https://8000-itb2na23308g3u9ydea9k-24cb5a15.sg1.manus.computer
              </a>
            </div>
            <div className="bg-blue-50 border border-blue-300 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-2">📥 <span className="font-semibold">صفحة تحميل الملفات:</span></p>
              <a 
                href="https://8000-itb2na23308g3u9ydea9k-24cb5a15.sg1.manus.computer/download.html" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-800 font-semibold break-all text-sm"
              >
                https://8000-itb2na23308g3u9ydea9k-24cb5a15.sg1.manus.computer/download.html
              </a>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-blue-50 rounded-lg p-4">
              <h3 className="font-semibold text-gray-800 mb-2">📖 الملفات المتاحة:</h3>
              <ul className="text-gray-700 text-sm space-y-1">
                <li>✓ دليل المستخدم (USER_GUIDE.md)</li>
                <li>✓ دليل المسؤول (ADMIN_GUIDE.md)</li>
                <li>✓ خطة النشر (DEPLOYMENT_PLAN.md)</li>
                <li>✓ خطة الصيانة (MAINTENANCE_PLAN.md)</li>
                <li>✓ خطة التحليل (ANALYTICS_PLAN.md)</li>
                <li>✓ خارطة التحسينات (OPTIMIZATION_ROADMAP.md)</li>
              </ul>
            </div>
            <div className="bg-purple-50 rounded-lg p-4">
              <h3 className="font-semibold text-gray-800 mb-2">🎯 محتوى الموقع:</h3>
              <ul className="text-gray-700 text-sm space-y-1">
                <li>✓ ملخص المشروع والإحصائيات</li>
                <li>✓ المراحل الخمس المكتملة</li>
                <li>✓ الميزات الرئيسية</li>
                <li>✓ الجدول الزمني</li>
                <li>✓ تحميل جميع الملفات</li>
                <li>✓ معلومات الفريق</li>
              </ul>
            </div>
          </div>
        </div>

        {/* التكنولوجيا المستخدمة */}
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">التكنولوجيا المستخدمة</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold text-gray-800 mb-3">الواجهة الأمامية</h3>
              <ul className="text-gray-700 space-y-2">
                <li>• React 19</li>
                <li>• TypeScript</li>
                <li>• Tailwind CSS 4</li>
                <li>• tRPC</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-800 mb-3">الخادم</h3>
              <ul className="text-gray-700 space-y-2">
                <li>• Node.js</li>
                <li>• Express 4</li>
                <li>• tRPC 11</li>
                <li>• Drizzle ORM</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-800 mb-3">قاعدة البيانات</h3>
              <ul className="text-gray-700 space-y-2">
                <li>• MySQL / TiDB</li>
                <li>• Drizzle Kit</li>
                <li>• المهاجر التلقائي</li>
                <li>• النسخ الاحتياطية</li>
              </ul>
            </div>
          </div>
        </div>

        {/* التذييل */}
        <div className="text-center mt-12 pt-8 border-t border-gray-300">
          <p className="text-gray-600 mb-2">
            © 2026 مخبر النجاح للتعويضات السنية
          </p>
          <p className="text-gray-600 text-sm">
            تم تطويره بعناية بواسطة <span className="font-semibold">ربيع الربيع</span>
          </p>
          <p className="text-gray-500 text-xs mt-2">
            جميع الحقوق محفوظة
          </p>
        </div>
      </div>
    </div>
  );
}
