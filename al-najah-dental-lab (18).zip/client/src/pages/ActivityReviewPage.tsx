import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle, XCircle, RefreshCw } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";

export default function ActivityReviewPage() {
  const [selectedActivity, setSelectedActivity] = useState<any>(null);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [notes, setNotes] = useState("");
  const [reason, setReason] = useState("");

  const { data: stats } = trpc.activityLog.getActivityStats.useQuery();
  const { data: pendingData, refetch: refetchPending } = trpc.activityLog.getPendingActivities.useQuery({
    limit: 50,
    offset: 0,
  });
  const { data: allData } = trpc.activityLog.getAllActivities.useQuery({
    limit: 50,
    offset: 0,
  });

  const approveMutation = trpc.activityLog.approveActivity.useMutation({
    onSuccess: () => {
      setShowApproveDialog(false);
      setNotes("");
      setSelectedActivity(null);
      refetchPending();
    },
  });

  const rejectMutation = trpc.activityLog.rejectActivity.useMutation({
    onSuccess: () => {
      setShowRejectDialog(false);
      setReason("");
      setSelectedActivity(null);
      refetchPending();
    },
  });

  const handleApprove = () => {
    if (selectedActivity) {
      approveMutation.mutate({
        activityId: selectedActivity.id,
        notes,
      });
    }
  };

  const handleReject = () => {
    if (selectedActivity && reason) {
      rejectMutation.mutate({
        activityId: selectedActivity.id,
        reason,
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-800">قيد الانتظار</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-50 text-green-800">موافق عليه</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-50 text-red-800">مرفوض</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getActionBadge = (action: string) => {
    switch (action) {
      case "create":
        return <Badge className="bg-blue-100 text-blue-800">إضافة</Badge>;
      case "update":
        return <Badge className="bg-purple-100 text-purple-800">تعديل</Badge>;
      case "delete":
        return <Badge className="bg-red-100 text-red-800">حذف</Badge>;
      default:
        return <Badge>{action}</Badge>;
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-bold">مراجعة الأنشطة</h1>
        <p className="text-muted-foreground mt-2">مراجعة وإدارة جميع الأنشطة والإضافات الجديدة</p>
      </div>

      {/* الإحصائيات */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">قيد الانتظار</CardTitle>
              <AlertCircle className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pending}</div>
              <p className="text-xs text-muted-foreground">أنشطة تحتاج مراجعة</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">موافق عليها</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.approved}</div>
              <p className="text-xs text-muted-foreground">أنشطة معتمدة</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">مرفوضة</CardTitle>
              <XCircle className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.rejected}</div>
              <p className="text-xs text-muted-foreground">أنشطة مرفوضة</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">الإجمالي</CardTitle>
              <RefreshCw className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-xs text-muted-foreground">جميع الأنشطة</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* الأنشطة المعلقة */}
      <Card>
        <CardHeader>
          <CardTitle>الأنشطة المعلقة للمراجعة</CardTitle>
          <CardDescription>الأنشطة التي تحتاج إلى موافقة أو رفض</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {pendingData?.activities && pendingData.activities.length > 0 ? (
              pendingData.activities.map((activity: any) => (
                <div key={activity.id} className="border rounded-lg p-4 hover:bg-accent/50 transition-colors">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">{activity.entityName || activity.entityType}</span>
                        {getActionBadge(activity.action)}
                        {getStatusBadge(activity.status)}
                      </div>
                      <p className="text-sm text-muted-foreground">{activity.description}</p>
                      <div className="text-xs text-muted-foreground space-y-1">
                        <p>المستخدم: {activity.userId}</p>
                        <p>التاريخ: {new Date(activity.createdAt).toLocaleString("ar-SA")}</p>
                        {activity.ipAddress && <p>IP: {activity.ipAddress}</p>}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-green-600 hover:text-green-700"
                        onClick={() => {
                          setSelectedActivity(activity);
                          setShowApproveDialog(true);
                        }}
                      >
                        موافقة
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-red-600 hover:text-red-700"
                        onClick={() => {
                          setSelectedActivity(activity);
                          setShowRejectDialog(true);
                        }}
                      >
                        رفض
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-8">لا توجد أنشطة معلقة للمراجعة</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* جميع الأنشطة */}
      <Card>
        <CardHeader>
          <CardTitle>جميع الأنشطة</CardTitle>
          <CardDescription>سجل كامل لجميع الأنشطة والإضافات</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {allData?.activities && allData.activities.length > 0 ? (
              allData.activities.map((activity: any) => (
                <div key={activity.id} className="border rounded-lg p-4 hover:bg-accent/50 transition-colors">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">{activity.entityName || activity.entityType}</span>
                        {getActionBadge(activity.action)}
                        {getStatusBadge(activity.status)}
                      </div>
                      <p className="text-sm text-muted-foreground">{activity.description}</p>
                      <div className="text-xs text-muted-foreground space-y-1">
                        <p>المستخدم: {activity.userId}</p>
                        <p>التاريخ: {new Date(activity.createdAt).toLocaleString("ar-SA")}</p>
                        {activity.reviewedAt && (
                          <p>تم المراجعة: {new Date(activity.reviewedAt).toLocaleString("ar-SA")}</p>
                        )}
                        {activity.reviewNotes && <p>الملاحظات: {activity.reviewNotes}</p>}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-8">لا توجد أنشطة</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Dialog الموافقة */}
      <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>الموافقة على النشاط</DialogTitle>
            <DialogDescription>
              هل تريد الموافقة على هذا النشاط؟ يمكنك إضافة ملاحظات اختيارية.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="أضف ملاحظاتك هنا (اختياري)"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApproveDialog(false)}>
              إلغاء
            </Button>
            <Button
              onClick={handleApprove}
              disabled={approveMutation.isPending}
              className="bg-green-600 hover:bg-green-700"
            >
              {approveMutation.isPending ? "جاري..." : "موافقة"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog الرفض */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>رفض النشاط</DialogTitle>
            <DialogDescription>
              هل تريد رفض هذا النشاط؟ يرجى إضافة سبب الرفض.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="أضف سبب الرفض"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
              إلغاء
            </Button>
            <Button
              onClick={handleReject}
              disabled={rejectMutation.isPending || !reason}
              className="bg-red-600 hover:bg-red-700"
            >
              {rejectMutation.isPending ? "جاري..." : "رفض"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
