import { useState, useMemo } from "react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";

export default function Analytics() {
  const [timeRange, setTimeRange] = useState<"month" | "quarter" | "year">("month");
  
  // جلب البيانات من الخادم
  const { data: works = [] } = trpc.works.listWithTypes.useQuery();
  const { data: invoices = [] } = trpc.invoices.list.useQuery();
  const { data: payments = [] } = trpc.payments.list.useQuery();
  const { data: expenses = [] } = trpc.expenses.list.useQuery();

  // معالجة البيانات
  const analyticsData = useMemo(() => {
    // حساب الإيرادات من الأعمال المسلمة أو المكتملة فقط
    const deliveredWorks = works.filter((work: any) => 
      work.status === "delivered" || work.status === "completed"
    );
    
    const totalRevenue = deliveredWorks.reduce((sum, work) => sum + (Number(work.totalPrice) || 0), 0);
    
    // حساب المصروفات
    const totalExpenses = expenses.reduce((sum, exp) => sum + (Number(exp.amount) || 0), 0);
    
    // حساب الأرباح
    const totalProfit = totalRevenue - totalExpenses;
    
    // حساب الدفعات
    const totalPayments = payments.reduce((sum, payment) => sum + (Number(payment.amount) || 0), 0);
    
    // توزيع الخدمات (من الأعمال المسلمة فقط)
    const workTypes = new Map<string, number>();
    deliveredWorks.forEach((work: any) => {
      const type = work.workTypeName || "أخرى";
      workTypes.set(type, (workTypes.get(type) || 0) + 1);
    });
    
    const categoryData = Array.from(workTypes.entries()).map(([name, count]) => ({
      name: name,
      value: count,
      color: ["#3b82f6", "#2ecc71", "#f39c12", "#e74c3c", "#95a5a6"][
        Array.from(workTypes.keys()).indexOf(name) % 5
      ],
    }));

    // بيانات شهرية
    const monthlyMap = new Map<string, { revenue: number; expenses: number; profit: number }>();
    const months = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
    
    // تجميع البيانات حسب الشهر (من الأعمال المسلمة فقط)
    deliveredWorks.forEach((work: any) => {
      if (work.createdAt) {
        const date = new Date(work.createdAt);
        const monthIndex = date.getMonth();
        const monthName = months[monthIndex];
        
        if (!monthlyMap.has(monthName)) {
          monthlyMap.set(monthName, { revenue: 0, expenses: 0, profit: 0 });
        }
        
        const data = monthlyMap.get(monthName)!;
        data.revenue += Number(work.totalPrice) || 0;
        data.profit = data.revenue - data.expenses;
      }
    });

    expenses.forEach((exp: any) => {
      if (exp.expenseDate) {
        const date = new Date(exp.expenseDate);
        const monthIndex = date.getMonth();
        const monthName = months[monthIndex];
        
        if (!monthlyMap.has(monthName)) {
          monthlyMap.set(monthName, { revenue: 0, expenses: 0, profit: 0 });
        }
        
        const data = monthlyMap.get(monthName)!;
        data.expenses += Number(exp.amount) || 0;
        data.profit = data.revenue - data.expenses;
      }
    });

    const monthlyData = months
      .map(month => ({
        month,
        revenue: monthlyMap.get(month)?.revenue || 0,
        expenses: monthlyMap.get(month)?.expenses || 0,
        profit: monthlyMap.get(month)?.profit || 0,
      }))
      .filter(item => item.revenue > 0 || item.expenses > 0);

    return {
      totalRevenue,
      totalExpenses,
      totalProfit,
      totalPayments,
      deliveredWorksCount: deliveredWorks.length,
      monthlyData: monthlyData.length > 0 ? monthlyData : generateDefaultMonthlyData(),
      categoryData: categoryData.length > 0 ? categoryData : generateDefaultCategoryData(),
    };
  }, [works, invoices, payments, expenses]);

  // بيانات افتراضية للعرض إذا لم تكن هناك بيانات
  function generateDefaultMonthlyData() {
    const months = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو"];
    return months.map((month) => ({
      month,
      revenue: Math.floor(Math.random() * 10000) + 5000,
      expenses: Math.floor(Math.random() * 5000) + 2000,
      profit: Math.floor(Math.random() * 8000) + 3000,
    }));
  }

  function generateDefaultCategoryData() {
    return [
      { name: "تعويضات", value: 35, color: "#3b82f6" },
      { name: "تنظيف", value: 25, color: "#2ecc71" },
      { name: "حشو", value: 20, color: "#f39c12" },
      { name: "خلع", value: 15, color: "#e74c3c" },
      { name: "أخرى", value: 5, color: "#95a5a6" },
    ];
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* رأس الصفحة */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">📊 لوحة التحليلات</h1>
        <p className="text-gray-600">تحليل شامل للإيرادات والمصروفات والأرباح (من الأعمال المسلمة فقط)</p>
      </div>

      {/* خيارات الفترة الزمنية */}
      <div className="mb-6 flex gap-2">
        <Button
          onClick={() => setTimeRange("month")}
          className={`${
            timeRange === "month"
              ? "bg-[#1e5a96] text-white"
              : "bg-white text-gray-700 border border-gray-300"
          }`}
        >
          شهري
        </Button>
        <Button
          onClick={() => setTimeRange("quarter")}
          className={`${
            timeRange === "quarter"
              ? "bg-[#1e5a96] text-white"
              : "bg-white text-gray-700 border border-gray-300"
          }`}
        >
          ربع سنوي
        </Button>
        <Button
          onClick={() => setTimeRange("year")}
          className={`${
            timeRange === "year"
              ? "bg-[#1e5a96] text-white"
              : "bg-white text-gray-700 border border-gray-300"
          }`}
        >
          سنوي
        </Button>
      </div>

      {/* البطاقات الإحصائية */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">إجمالي الإيرادات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">${analyticsData.totalRevenue.toFixed(2)}</div>
            <p className="text-xs text-gray-500 mt-1">من {analyticsData.deliveredWorksCount} عمل مسلم</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">إجمالي المصروفات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">${analyticsData.totalExpenses.toFixed(2)}</div>
            <p className="text-xs text-gray-500 mt-1">من {expenses.length} مصروف</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">الأرباح الصافية</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${analyticsData.totalProfit >= 0 ? "text-blue-600" : "text-red-600"}`}>
              ${analyticsData.totalProfit.toFixed(2)}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {analyticsData.totalRevenue > 0 
                ? `نسبة الأرباح: ${((analyticsData.totalProfit / analyticsData.totalRevenue) * 100).toFixed(2)}%`
                : "لا توجد إيرادات"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">إجمالي الدفعات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">${analyticsData.totalPayments.toFixed(2)}</div>
            <p className="text-xs text-gray-500 mt-1">من {payments.length} دفعة</p>
          </CardContent>
        </Card>
      </div>

      {/* الرسوم البيانية */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* مخطط الإيرادات والمصروفات الشهرية */}
        <Card>
          <CardHeader>
            <CardTitle>الإيرادات والمصروفات الشهرية</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={analyticsData.monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value: any) => `$${value.toFixed(2)}`} />
                <Legend />
                <Bar dataKey="revenue" fill="#10b981" name="الإيرادات" />
                <Bar dataKey="expenses" fill="#ef4444" name="المصروفات" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* مخطط الأرباح الشهرية */}
        <Card>
          <CardHeader>
            <CardTitle>الأرباح الشهرية</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={analyticsData.monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value: any) => `$${value.toFixed(2)}`} />
                <Legend />
                <Line type="monotone" dataKey="profit" stroke="#3b82f6" strokeWidth={2} name="الأرباح" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* توزيع الخدمات */}
        <Card>
          <CardHeader>
            <CardTitle>توزيع الخدمات</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={analyticsData.categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {analyticsData.categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* ملخص الخدمات */}
        <Card>
          <CardHeader>
            <CardTitle>ملخص الخدمات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {analyticsData.categoryData.map((category, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: category.color }}></div>
                    <span className="text-sm text-gray-700">{category.name}</span>
                  </div>
                  <span className="text-sm font-medium text-gray-900">{category.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ملاحظات مهمة */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-900">ملاحظات مهمة</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-blue-800 space-y-1">
          <p>• يتم حساب الإيرادات من الأعمال المسلمة أو المكتملة فقط</p>
          <p>• يتم استخدام تاريخ إدخال العمل في النظام (createdAt) كتاريخ العمل</p>
          <p>• الأرباح = الإيرادات - المصروفات</p>
          <p>• هذه الحسابات متطابقة مع صفحة توزيع الأرباح</p>
        </CardContent>
      </Card>
    </div>
  );
}
