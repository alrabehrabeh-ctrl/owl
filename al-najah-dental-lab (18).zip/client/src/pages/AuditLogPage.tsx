import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function AuditLogPage() {
  const [userSwitchOffset, setUserSwitchOffset] = useState(0);
  const [passwordChangeOffset, setPasswordChangeOffset] = useState(0);
  const [permissionChangeOffset, setPermissionChangeOffset] = useState(0);

  // جلب سجلات تبديل المستخدمين
  const { data: userSwitchLogs = [], isLoading: isLoadingUserSwitch } =
    trpc.auditLog.getUserSwitchLog.useQuery({
      limit: 20,
      offset: userSwitchOffset,
    });

  // جلب سجلات تغيير كلمات المرور
  const { data: passwordChangeLogs = [], isLoading: isLoadingPasswordChange } =
    trpc.auditLog.getPasswordAuditLog.useQuery({
      limit: 20,
      offset: passwordChangeOffset,
    });

  // جلب سجلات تغيير الصلاحيات
  const { data: permissionChangeLogs = [], isLoading: isLoadingPermissionChange } =
    trpc.auditLog.getPermissionAuditLog.useQuery({
      limit: 20,
      offset: permissionChangeOffset,
    });

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleString("ar-SA");
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">سجل التدقيق</h1>
        <p className="text-slate-600 mt-2">عرض جميع أنشطة النظام والتغييرات</p>
      </div>

      {/* سجل تبديل المستخدمين */}
      <Card>
        <CardHeader>
          <CardTitle>سجل تبديل المستخدمين</CardTitle>
          <CardDescription>تتبع جميع محاولات تبديل المستخدمين من قبل المسؤولين</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingUserSwitch ? (
            <p className="text-slate-600">جاري التحميل...</p>
          ) : userSwitchLogs.length === 0 ? (
            <p className="text-slate-600">لا توجد سجلات</p>
          ) : (
            <>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>تم التبديل بواسطة</TableHead>
                    <TableHead>تم التبديل إلى</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>التاريخ والوقت</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {userSwitchLogs.map((log: any) => (
                    <TableRow key={log.id}>
                      <TableCell>{log.switchedBy}</TableCell>
                      <TableCell>{log.switchedTo}</TableCell>
                      <TableCell>
                        <span
                          className={`px-2 py-1 rounded text-xs font-medium ${
                            log.status === "success"
                              ? "bg-green-100 text-green-700"
                              : "bg-red-100 text-red-700"
                          }`}
                        >
                          {log.status === "success" ? "نجح" : "فشل"}
                        </span>
                      </TableCell>
                      <TableCell>{formatDate(log.createdAt)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <div className="flex justify-between items-center mt-4">
                <Button
                  onClick={() => setUserSwitchOffset(Math.max(0, userSwitchOffset - 20))}
                  disabled={userSwitchOffset === 0}
                  variant="outline"
                >
                  <ChevronLeft className="h-4 w-4" />
                  السابق
                </Button>
                <Button
                  onClick={() => setUserSwitchOffset(userSwitchOffset + 20)}
                  disabled={userSwitchLogs.length < 20}
                  variant="outline"
                >
                  التالي
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* سجل تغيير كلمات المرور */}
      <Card>
        <CardHeader>
          <CardTitle>سجل تغيير كلمات المرور</CardTitle>
          <CardDescription>تتبع جميع تغييرات كلمات المرور</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingPasswordChange ? (
            <p className="text-slate-600">جاري التحميل...</p>
          ) : passwordChangeLogs.length === 0 ? (
            <p className="text-slate-600">لا توجد سجلات</p>
          ) : (
            <>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المستخدم</TableHead>
                    <TableHead>نوع التغيير</TableHead>
                    <TableHead>التاريخ والوقت</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {passwordChangeLogs.map((log: any) => (
                    <TableRow key={log.id}>
                      <TableCell>{log.userId}</TableCell>
                      <TableCell>تغيير كلمة المرور</TableCell>
                      <TableCell>{formatDate(log.createdAt)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <div className="flex justify-between items-center mt-4">
                <Button
                  onClick={() => setPasswordChangeOffset(Math.max(0, passwordChangeOffset - 20))}
                  disabled={passwordChangeOffset === 0}
                  variant="outline"
                >
                  <ChevronLeft className="h-4 w-4" />
                  السابق
                </Button>
                <Button
                  onClick={() => setPasswordChangeOffset(passwordChangeOffset + 20)}
                  disabled={passwordChangeLogs.length < 20}
                  variant="outline"
                >
                  التالي
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* سجل تغيير الصلاحيات */}
      <Card>
        <CardHeader>
          <CardTitle>سجل تغيير الصلاحيات</CardTitle>
          <CardDescription>تتبع جميع تغييرات الصلاحيات والأدوار</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingPermissionChange ? (
            <p className="text-slate-600">جاري التحميل...</p>
          ) : permissionChangeLogs.length === 0 ? (
            <p className="text-slate-600">لا توجد سجلات</p>
          ) : (
            <>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المستخدم</TableHead>
                    <TableHead>الإجراء</TableHead>
                    <TableHead>التاريخ والوقت</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {permissionChangeLogs.map((log: any) => (
                    <TableRow key={log.id}>
                      <TableCell>{log.userId}</TableCell>
                      <TableCell>تغيير الصلاحيات</TableCell>
                      <TableCell>{formatDate(log.createdAt)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <div className="flex justify-between items-center mt-4">
                <Button
                  onClick={() => setPermissionChangeOffset(Math.max(0, permissionChangeOffset - 20))}
                  disabled={permissionChangeOffset === 0}
                  variant="outline"
                >
                  <ChevronLeft className="h-4 w-4" />
                  السابق
                </Button>
                <Button
                  onClick={() => setPermissionChangeOffset(permissionChangeOffset + 20)}
                  disabled={permissionChangeLogs.length < 20}
                  variant="outline"
                >
                  التالي
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
