import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Loader2, Download, RotateCcw, Trash2, Settings, Clock } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

export default function BackupManagementPage() {
  const [backupDescription, setBackupDescription] = useState("");

  // Queries
  const { data: backups = [], isLoading: backupsLoading, refetch: refetchBackups } = trpc.backup.listBackups.useQuery({
    limit: 20,
    offset: 0,
  }, {
    staleTime: 1000 * 60 * 5,
    gcTime: 1000 * 60 * 10,
  });

  const { data: backupSettings, isLoading: settingsLoading, error: settingsError } = trpc.backup.getBackupSettings.useQuery(undefined, {
    staleTime: 1000 * 60 * 5, // 5 minutes
    gcTime: 1000 * 60 * 10, // 10 minutes
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });

  // Mutations
  const createBackupMutation = trpc.backup.createManualBackup.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء النسخة الاحتياطية بنجاح");
      setBackupDescription("");
      refetchBackups();
    },
    onError: (error) => {
      toast.error(error.message || "فشل في إنشاء النسخة الاحتياطية");
    },
  });

  const restoreBackupMutation = trpc.backup.restoreBackup.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      refetchBackups();
    },
    onError: (error) => {
      toast.error(error.message || "فشل في استعادة النسخة الاحتياطية");
    },
  });

  const deleteBackupMutation = trpc.backup.deleteBackup.useMutation({
    onSuccess: () => {
      toast.success("تم حذف النسخة الاحتياطية بنجاح");
      refetchBackups();
    },
    onError: (error) => {
      toast.error(error.message || "فشل في حذف النسخة الاحتياطية");
    },
  });

  const cleanupExpiredMutation = trpc.backup.cleanupExpiredBackups.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      refetchBackups();
    },
    onError: (error) => {
      toast.error(error.message || "فشل في تنظيف النسخ المنتهية الصلاحية");
    },
  });

  const handleCreateBackup = () => {
    createBackupMutation.mutate({
      description: backupDescription || undefined,
    });
  };

  const handleRestoreBackup = (backupId: number) => {
    if (confirm("هل أنت متأكد من استعادة هذه النسخة الاحتياطية؟ سيتم استبدال جميع الإعدادات الحالية.")) {
      restoreBackupMutation.mutate({ backupId });
    }
  };

  const handleDeleteBackup = (backupId: number) => {
    if (confirm("هل أنت متأكد من حذف هذه النسخة الاحتياطية؟")) {
      deleteBackupMutation.mutate({ backupId });
    }
  };

  const getBackupTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      manual: "يدوية",
      automatic: "تلقائية",
      scheduled: "مجدولة",
    };
    return labels[type] || type;
  };

  const getBackupTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      manual: "bg-blue-100 text-blue-800",
      automatic: "bg-green-100 text-green-800",
      scheduled: "bg-purple-100 text-purple-800",
    };
    return colors[type] || "bg-gray-100 text-gray-800";
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">إدارة النسخ الاحتياطية</h1>
        <p className="text-muted-foreground mt-2">
          إنشاء واستعادة النسخ الاحتياطية لإعدادات النظام والأدوار
        </p>
      </div>

      <Tabs defaultValue="backups" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="backups">النسخ الاحتياطية</TabsTrigger>
          <TabsTrigger value="create">إنشاء نسخة</TabsTrigger>
          <TabsTrigger value="settings">الإعدادات</TabsTrigger>
        </TabsList>

        {/* قائمة النسخ الاحتياطية */}
        <TabsContent value="backups" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>النسخ الاحتياطية المتاحة</CardTitle>
              <CardDescription>
                عدد النسخ: {backups.length}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {backupsLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin" />
                </div>
              ) : backups.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  لا توجد نسخ احتياطية حتى الآن
                </div>
              ) : (
                <div className="space-y-4">
                  {backups.map((backup: any) => (
                    <div
                      key={backup.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold">{backup.backupName}</h3>
                          <Badge className={getBackupTypeColor(backup.backupType)}>
                            {getBackupTypeLabel(backup.backupType)}
                          </Badge>
                          {backup.isRestored === "true" && (
                            <Badge variant="secondary">تم استعادتها</Badge>
                          )}
                        </div>
                        {backup.description && (
                          <p className="text-sm text-muted-foreground mb-2">
                            {backup.description}
                          </p>
                        )}
                        <div className="text-xs text-muted-foreground space-y-1">
                          <div>
                            التاريخ: {new Date(backup.createdAt).toLocaleString("ar-SA")}
                          </div>
                          <div>
                            الحجم: {((backup.size || 0) / 1024).toFixed(2)} KB
                          </div>
                          {backup.restoredAt && (
                            <div>
                              آخر استعادة: {new Date(backup.restoredAt).toLocaleString("ar-SA")}
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleRestoreBackup(backup.id)}
                          disabled={restoreBackupMutation.isPending}
                        >
                          {restoreBackupMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <RotateCcw className="h-4 w-4" />
                          )}
                          <span className="ml-2">استعادة</span>
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteBackup(backup.id)}
                          disabled={deleteBackupMutation.isPending}
                        >
                          {deleteBackupMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-4 pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => cleanupExpiredMutation.mutate()}
                  disabled={cleanupExpiredMutation.isPending}
                >
                  {cleanupExpiredMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Trash2 className="h-4 w-4 mr-2" />
                  )}
                  تنظيف النسخ المنتهية الصلاحية
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* إنشاء نسخة احتياطية */}
        <TabsContent value="create" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>إنشاء نسخة احتياطية يدوية</CardTitle>
              <CardDescription>
                إنشاء نسخة احتياطية من إعدادات النظام الحالية
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  وصف النسخة الاحتياطية (اختياري)
                </label>
                <Input
                  placeholder="مثال: نسخة احتياطية قبل التحديث"
                  value={backupDescription}
                  onChange={(e) => setBackupDescription(e.target.value)}
                />
              </div>
              <Button
                onClick={handleCreateBackup}
                disabled={createBackupMutation.isPending}
                className="w-full"
              >
                {createBackupMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Download className="h-4 w-4 mr-2" />
                )}
                إنشاء النسخة الاحتياطية
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* إعدادات النسخ الاحتياطية */}
        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>إعدادات النسخ الاحتياطية</CardTitle>
              <CardDescription>
                التحكم في سياسة النسخ الاحتياطي التلقائي
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {settingsLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin" />
                </div>
              ) : settingsError ? (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-sm text-red-800">
                    خطأ في تحميل الإعدادات: {settingsError.message}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2"
                    onClick={() => window.location.reload()}
                  >
                    إعادة محاولة
                  </Button>
                </div>
              ) : backupSettings ? (
                <div className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="h-4 w-4" />
                      <span className="font-medium">حالة النسخ الاحتياطي التلقائي</span>
                    </div>
                    <p className="text-sm">
                      {backupSettings.autoBackupEnabled === "true" ? (
                        <span className="text-green-600">✓ مفعّلة</span>
                      ) : (
                        <span className="text-red-600">✗ معطّلة</span>
                      )}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-muted rounded-lg">
                      <p className="text-sm text-muted-foreground mb-1">تكرار النسخ</p>
                      <p className="font-semibold">
                        {backupSettings.backupFrequency === "daily"
                          ? "يومياً"
                          : backupSettings.backupFrequency === "weekly"
                            ? "أسبوعياً"
                            : backupSettings.backupFrequency === "monthly"
                              ? "شهرياً"
                              : "كل ساعة"}
                      </p>
                    </div>

                    <div className="p-4 bg-muted rounded-lg">
                      <p className="text-sm text-muted-foreground mb-1">فترة الاحتفاظ</p>
                      <p className="font-semibold">
                        {backupSettings.backupRetentionDays} يوم
                      </p>
                    </div>

                    <div className="p-4 bg-muted rounded-lg">
                      <p className="text-sm text-muted-foreground mb-1">الحد الأقصى للنسخ</p>
                      <p className="font-semibold">
                        {backupSettings.maxBackups} نسخة
                      </p>
                    </div>

                    <div className="p-4 bg-muted rounded-lg">
                      <p className="text-sm text-muted-foreground mb-1">آخر نسخة احتياطية</p>
                      <p className="font-semibold">
                        {backupSettings && "lastBackupAt" in backupSettings && backupSettings.lastBackupAt
                          ? formatDistanceToNow(
                              new Date(backupSettings.lastBackupAt),
                              { locale: ar, addSuffix: true }
                            )
                          : "لم تتم أي نسخة بعد"}
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm text-blue-900">
                      ℹ️ يتم حذف النسخ الاحتياطية تلقائياً بعد انقضاء فترة الاحتفاظ المحددة
                    </p>
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-sm text-yellow-800">
                    لم يتم تحميل الإعدادات
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
