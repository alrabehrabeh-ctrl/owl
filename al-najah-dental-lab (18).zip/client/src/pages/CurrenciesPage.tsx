import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Plus, Edit2, Trash2, DollarSign } from "lucide-react";
import { toast } from "sonner";
import { ExchangeRateSyncPanel } from "@/components/ExchangeRateSyncPanel";

const getCurrencyFlag = (code: string): string => {
  switch (code.toUpperCase()) {
    case 'USD':
      return '🇺🇸';
    case 'SYP':
      return '🇸🇾';
    default:
      return '💱';
  }
};

export default function CurrenciesPage() {
  const [showAddForm, setShowAddForm] = useState(false);
  const [showExchangeRateForm, setShowExchangeRateForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [editingCurrency, setEditingCurrency] = useState<any>(null);
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    symbol: "",
    isDefault: false,
  });
  const [editFormData, setEditFormData] = useState({
    name: "",
    symbol: "",
    isDefault: false,
  });
  const [exchangeRateData, setExchangeRateData] = useState({
    fromCurrencyId: "",
    toCurrencyId: "",
    rate: "",
  });

  // جلب البيانات
  const { data: currencies = [], refetch: refetchCurrencies } = trpc.currencies.getAll.useQuery();
  const { data: defaultCurrency } = trpc.currencies.getDefault.useQuery();

  // Mutations
  const addCurrencyMutation = trpc.currencies.add.useMutation({
    onSuccess: () => {
      toast.success("تم إضافة العملة بنجاح");
      setFormData({ code: "", name: "", symbol: "", isDefault: false });
      setShowAddForm(false);
      refetchCurrencies();
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء إضافة العملة");
    },
  });

  const updateCurrencyMutation = trpc.currencies.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث العملة بنجاح");
      setEditFormData({ name: "", symbol: "", isDefault: false });
      setEditingCurrency(null);
      setShowEditForm(false);
      refetchCurrencies();
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء تحديث العملة");
    },
  });

  const utils = trpc.useUtils();
  
  const setExchangeRateMutation = trpc.currencies.setExchangeRate.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث سعر الصرف بنجاح");
      setExchangeRateData({ fromCurrencyId: "", toCurrencyId: "", rate: "" });
      setShowExchangeRateForm(false);
      // إعادة تحميل بيانات العملات
      utils.currencies.getAll.invalidate();
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء تحديث سعر الصرف");
    },
  });

  const handleAddCurrency = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.code || !formData.name || !formData.symbol) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }
    addCurrencyMutation.mutate(formData);
  };

  const handleEditCurrency = (currency: any) => {
    setEditingCurrency(currency);
    setEditFormData({
      name: currency.name,
      symbol: currency.symbol,
      isDefault: currency.isDefault,
    });
    setShowEditForm(true);
  };

  const handleUpdateCurrency = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editFormData.name || !editFormData.symbol) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }
    updateCurrencyMutation.mutate({
      currencyId: editingCurrency.id,
      ...editFormData,
    });
  };

  const handleSetExchangeRate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!exchangeRateData.fromCurrencyId || !exchangeRateData.toCurrencyId || !exchangeRateData.rate) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }
    setExchangeRateMutation.mutate({
      fromCurrencyId: parseInt(exchangeRateData.fromCurrencyId),
      toCurrencyId: parseInt(exchangeRateData.toCurrencyId),
      rate: exchangeRateData.rate,
    });
  };

  return (
    <div className="space-y-6 p-6">
      {/* رأس الصفحة */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">إدارة العملات</h1>
          <p className="text-muted-foreground mt-2">إدارة العملات المدعومة وأسعار الصرف</p>
        </div>
        <Button onClick={() => setShowAddForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          إضافة عملة جديدة
        </Button>
      </div>

      {/* نموذج تعديل عملة */}
      {showEditForm && editingCurrency && (
        <Card>
          <CardHeader>
            <CardTitle>تعديل العملة: {editingCurrency.code}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdateCurrency} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">اسم العملة</label>
                  <Input
                    placeholder="مثال: الدولار الأمريكي"
                    value={editFormData.name}
                    onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">الرمز</label>
                  <Input
                    placeholder="مثال: $"
                    value={editFormData.symbol}
                    onChange={(e) => setEditFormData({ ...editFormData, symbol: e.target.value })}
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="editIsDefault"
                  checked={editFormData.isDefault}
                  onChange={(e) => setEditFormData({ ...editFormData, isDefault: e.target.checked })}
                  className="rounded"
                />
                <label htmlFor="editIsDefault" className="text-sm">
                  جعل هذه العملة الافتراضية
                </label>
              </div>
              <div className="flex gap-2">
                <Button type="submit" disabled={updateCurrencyMutation.isPending}>
                  {updateCurrencyMutation.isPending ? "جاري التحديث..." : "تحديث"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowEditForm(false)}>
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* نموذج إضافة عملة */}
      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>إضافة عملة جديدة</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddCurrency} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">رمز العملة</label>
                  <Input
                    placeholder="مثال: USD"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">اسم العملة</label>
                  <Input
                    placeholder="مثال: الدولار الأمريكي"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">الرمز</label>
                  <Input
                    placeholder="مثال: $"
                    value={formData.symbol}
                    onChange={(e) => setFormData({ ...formData, symbol: e.target.value })}
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="isDefault"
                  checked={formData.isDefault}
                  onChange={(e) => setFormData({ ...formData, isDefault: e.target.checked })}
                  className="rounded"
                />
                <label htmlFor="isDefault" className="text-sm">
                  جعل هذه العملة الافتراضية
                </label>
              </div>
              <div className="flex gap-2">
                <Button type="submit" disabled={addCurrencyMutation.isPending}>
                  {addCurrencyMutation.isPending ? "جاري الإضافة..." : "إضافة"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowAddForm(false)}>
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* قائمة العملات */}
      <Card>
        <CardHeader>
          <CardTitle>العملات المتاحة</CardTitle>
          <CardDescription>إدارة العملات المدعومة في النظام</CardDescription>
        </CardHeader>
        <CardContent>
          {currencies.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-right py-3 px-4 font-semibold">الرمز</th>
                    <th className="text-right py-3 px-4 font-semibold">الاسم</th>
                    <th className="text-right py-3 px-4 font-semibold">الرمز</th>
                    <th className="text-right py-3 px-4 font-semibold">الافتراضية</th>
                    <th className="text-center py-3 px-4 font-semibold">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {currencies.map((currency) => (
                    <tr key={currency.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-mono">{getCurrencyFlag(currency.code)} {currency.code}</td>
                      <td className="py-3 px-4">{currency.name}</td>
                      <td className="py-3 px-4 text-lg">{currency.symbol}</td>
                      <td className="py-3 px-4">
                        {currency.isDefault ? (
                          <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-sm">نعم</span>
                        ) : (
                          <span className="bg-gray-100 text-gray-800 px-2 py-1 rounded text-sm">لا</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => handleEditCurrency(currency)}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">لا توجد عملات مضافة</p>
          )}
        </CardContent>
      </Card>

      {/* نموذج أسعار الصرف */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            أسعار الصرف
          </CardTitle>
          <CardDescription>تحديث أسعار الصرف بين العملات</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSetExchangeRate} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">من العملة</label>
                <select
                  value={exchangeRateData.fromCurrencyId}
                  onChange={(e) => setExchangeRateData({ ...exchangeRateData, fromCurrencyId: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-md bg-background"
                >
                  <option value="">-- اختر العملة --</option>
                  {currencies.map((currency) => (
                    <option key={currency.id} value={currency.id}>
                      {getCurrencyFlag(currency.code)} {currency.name} ({currency.code})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">إلى العملة</label>
                <select
                  value={exchangeRateData.toCurrencyId}
                  onChange={(e) => setExchangeRateData({ ...exchangeRateData, toCurrencyId: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-md bg-background"
                >
                  <option value="">-- اختر العملة --</option>
                  {currencies.map((currency) => (
                    <option key={currency.id} value={currency.id}>
                      {getCurrencyFlag(currency.code)} {currency.name} ({currency.code})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">سعر الصرف</label>
                <Input
                  type="number"
                  step="0.000001"
                  placeholder="مثال: 1.5"
                  value={exchangeRateData.rate}
                  onChange={(e) => setExchangeRateData({ ...exchangeRateData, rate: e.target.value })}
                />
              </div>
            </div>
            <Button type="submit" disabled={setExchangeRateMutation.isPending}>
              {setExchangeRateMutation.isPending ? "جاري التحديث..." : "تحديث سعر الصرف"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* معلومات العملة الافتراضية */}
      {defaultCurrency && (
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader>
            <CardTitle className="text-primary">العملة الافتراضية</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <div className="text-4xl">{defaultCurrency.symbol}</div>
              <div>
                <p className="font-semibold text-lg">{defaultCurrency.name}</p>
                <p className="text-sm text-muted-foreground">{defaultCurrency.code}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* لوحة التحديث التلقائي */}
      <div className="mt-8">
        <ExchangeRateSyncPanel />
      </div>
    </div>
  );
}
