import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Loader2, TrendingUp, DollarSign, TrendingDown, Percent, AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function DashboardPage() {
  const [, setLocation] = useLocation();
  
  const { data: revenueData, isLoading: revenueLoading } = trpc.reports.getTotalRevenue.useQuery({
    startDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
    endDate: new Date(),
  }, {
    refetchInterval: 300000, // 5 دقائق
  });

  const { data: expensesData, isLoading: expensesLoading } = trpc.reports.getTotalExpenses.useQuery({
    startDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
    endDate: new Date(),
  }, {
    refetchInterval: 300000, // 5 دقائق
  });

  const { data: overdueInvoices } = trpc.reports.getOverdueInvoices.useQuery(undefined, {
    refetchInterval: 300000, // 5 دقائق
  });
  
  const { data: pendingWorks } = trpc.reports.getPendingWorks.useQuery(undefined, {
    refetchInterval: 300000, // 5 دقائق
  });
  
  const { data: doctors = [] } = trpc.doctors.list.useQuery(undefined, {
    refetchInterval: 300000, // 5 دقائق
  });
  
  const { data: worksData } = trpc.works.list.useQuery(undefined, {
    refetchInterval: 300000, // 5 دقائق
  });
  
  const works = (Array.isArray(worksData) ? worksData : (worksData as any)?.data) || [];  // حساب عدد الأعمال حسب الحالة
  const pendingWorksCount = works.filter((w: any) => w.status === 'pending').length;
  const inProgressWorksCount = works.filter((w: any) => w.status === 'in_progress').length;
  const completedWorksCount = works.filter((w: any) => w.status === 'completed').length;
  
  const { data: invoices = [] } = trpc.invoices.list.useQuery(undefined, {
    refetchInterval: 300000, // 5 دقائق
  });
  const invoicesCount = invoices.length || 0;

  // جلب البيانات الشهرية
  const currentYear = new Date().getFullYear();
  const { data: monthlyRevenue = [] } = trpc.reports.getMonthlyRevenue.useQuery({ year: currentYear }, {
    refetchInterval: 300000, // 5 دقائق
  });

  const { data: monthlyExpenses = [] } = trpc.reports.getMonthlyExpenses.useQuery({ year: currentYear }, {
    refetchInterval: 300000, // 5 دقائق
  });
  
  // جلب إحصائيات الديون
  const { data: debtsStats } = trpc.debts.getDebtsStatistics.useQuery(undefined, {
    refetchInterval: 300000, // 5 دقائق
  });

  const revenue = parseFloat(revenueData as string) || 0;
  const expenses = parseFloat(expensesData as string) || 0;
  const profit = revenue - expenses;
  const profitMargin = revenue > 0 ? ((profit / revenue) * 100).toFixed(2) : 0;

  // تحويل البيانات الشهرية للرسم البياني
  const monthNames = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
  
  const chartData = monthNames.map((name, index) => {
    const revenueMonth = monthlyRevenue.find((r: any) => r.month === index + 1);
    const expensesMonth = monthlyExpenses.find((e: any) => e.month === index + 1);
    
    return {
      month: name,
      revenue: parseFloat((revenueMonth?.total as string) || "0"),
      expenses: parseFloat((expensesMonth?.total as string) || "0"),
    };
  });

  const statCards = [
    {
      title: "الأطباء",
      value: doctors?.length || 0,
      icon: TrendingUp,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      onClick: () => setLocation("/doctors"),
    },
    {
      title: "الأعمال",
      value: works?.length || 0,
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-50",
      onClick: () => setLocation("/works"),
    },
    {
      title: "الفواتير",
      value: invoicesCount,
      icon: TrendingDown,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      onClick: () => setLocation("/invoices"),
    },
    {
      title: "الأعمال المعلقة",
      value: pendingWorksCount,
      icon: AlertCircle,
      color: "text-red-600",
      bgColor: "bg-red-50",
      onClick: () => setLocation("/works"),
    },
    {
      title: "قيد التنفيذ",
      value: inProgressWorksCount,
      icon: TrendingUp,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
      onClick: () => setLocation("/works"),
    },
    {
      title: "الأعمال المكتملة",
      value: completedWorksCount,
      icon: TrendingUp,
      color: "text-green-600",
      bgColor: "bg-green-50",
      onClick: () => setLocation("/works"),
    },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">لوحة التحكم</h1>
      {/* الإحصائيات السريعة */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">      {statCards.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <Card
              key={idx}
              className={`cursor-pointer hover:shadow-lg transition-all ${stat.bgColor}`}
              onClick={stat.onClick}
            >
              <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
                <CardTitle className="text-sm font-medium text-gray-600">{stat.title}</CardTitle>
                <Icon className={`h-5 w-5 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${stat.color}`}>{stat.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* الرسوم البيانية الشهرية */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>الإيرادات والمصاريف الشهرية</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="revenue" stroke="#10b981" name="الإيرادات" strokeWidth={2} />
                <Line type="monotone" dataKey="expenses" stroke="#ef4444" name="المصاريف" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>مقارنة الإيرادات والمصاريف</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="revenue" fill="#10b981" name="الإيرادات" />
                <Bar dataKey="expenses" fill="#ef4444" name="المصاريف" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* معلومات إضافية */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>الفواتير المستحقة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">{overdueInvoices?.length || 0}</div>
            <p className="text-sm text-gray-500 mt-2">فاتورة متأخرة عن موعد الاستحقاق</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>الأعمال المعلقة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-600">{pendingWorks?.length || 0}</div>
            <p className="text-sm text-gray-500 mt-2">عمل قيد التنفيذ</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
