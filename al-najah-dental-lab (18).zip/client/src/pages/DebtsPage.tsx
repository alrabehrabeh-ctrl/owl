import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Loader2, Search, Download, Eye } from "lucide-react";

export default function DebtsPage() {
  const [selectedDoctor, setSelectedDoctor] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // الحصول على إحصائيات المديونيات العامة
  const { data: statistics, isLoading: statsLoading } = trpc.debts.getDebtsStatistics.useQuery();

  // الحصول على قائمة جميع الأطباء مع المديونيات
  const { data: doctorsDebts, isLoading: doctorsLoading } = trpc.debts.getAllDoctorsDebts.useQuery();

  // الحصول على تفاصيل المديونيات لطبيب معين
  const { data: debtDetails, isLoading: detailsLoading } = trpc.debts.getDoctorDebtDetails.useQuery(
    { doctorId: selectedDoctor! },
    { enabled: !!selectedDoctor }
  );

  // البحث عن الأطباء
  const { data: searchResults } = trpc.debts.searchDoctors.useQuery(
    { query: searchQuery },
    { enabled: searchQuery.length > 0 }
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "clear":
        return <Badge className="bg-green-500">مسدد</Badge>;
      case "pending":
        return <Badge className="bg-yellow-500">مستحق</Badge>;
      case "overdue":
        return <Badge className="bg-red-500">متأخر</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* رأس الصفحة */}
      <div>
        <h1 className="text-3xl font-bold">المديونيات</h1>
        <p className="text-gray-600">عرض وإدارة مديونيات الأطباء</p>
      </div>

      {/* الإحصائيات العامة */}
      {statsLoading ? (
        <div className="flex justify-center">
          <Loader2 className="animate-spin" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">إجمالي المديونيات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${statistics?.totalDebt.toFixed(2)}</div>
              <p className="text-xs text-gray-500">من {statistics?.totalInvoiced.toFixed(2)}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">المديونيات المتأخرة</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">${statistics?.overdueDebt.toFixed(2)}</div>
              <p className="text-xs text-gray-500">{statistics?.overdueInvoices} فاتورة متأخرة</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">نسبة الدفع</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{statistics?.paymentPercentage.toFixed(1)}%</div>
              <p className="text-xs text-gray-500">من الإجمالي</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">الأطباء المدينون</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{doctorsDebts?.doctorsWithDebt}</div>
              <p className="text-xs text-gray-500">من {doctorsDebts?.totalDoctors}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* البحث والفلترة */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 text-gray-400" size={18} />
          <Input
            placeholder="ابحث عن طبيب..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* جدول الأطباء */}
      <Card>
        <CardHeader>
          <CardTitle>قائمة الأطباء والمديونيات</CardTitle>
          <CardDescription>اضغط على أي طبيب لعرض التفاصيل</CardDescription>
        </CardHeader>
        <CardContent>
          {doctorsLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="animate-spin" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>اسم الطبيب</TableHead>
                  <TableHead>العيادة</TableHead>
                  <TableHead>إجمالي المديونية</TableHead>
                  <TableHead>عدد الفواتير</TableHead>
                  <TableHead>المتأخرة</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(searchResults || doctorsDebts?.doctors)?.map((doctor: any) => (
                  <TableRow key={doctor.id}>
                    <TableCell className="font-medium">{doctor.name}</TableCell>
                    <TableCell>{doctor.clinic || "-"}</TableCell>
                    <TableCell className="font-bold">${doctor.totalDebt.toFixed(2)}</TableCell>
                    <TableCell>{doctor.totalInvoices}</TableCell>
                    <TableCell className="text-red-600">{doctor.overdueInvoices}</TableCell>
                    <TableCell>{getStatusBadge(doctor.status)}</TableCell>
                    <TableCell>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedDoctor(doctor.id)}
                      >
                        <Eye size={16} />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* تفاصيل الطبيب */}
      {selectedDoctor && (
        <Card>
          <CardHeader>
            <CardTitle>{debtDetails?.doctor.name}</CardTitle>
            <CardDescription>{debtDetails?.doctor.clinic}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* الإحصائيات */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">إجمالي الفواتير</p>
                <p className="text-2xl font-bold">${debtDetails?.statistics.totalInvoiced.toFixed(2)}</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">المدفوع</p>
                <p className="text-2xl font-bold text-green-600">${debtDetails?.statistics.totalPaid.toFixed(2)}</p>
              </div>
              <div className="bg-red-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">المتبقي</p>
                <p className="text-2xl font-bold text-red-600">${debtDetails?.statistics.totalDebt.toFixed(2)}</p>
              </div>
            </div>

            {/* جدول الفواتير */}
            <div>
              <h3 className="font-bold mb-4">الفواتير</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>رقم الفاتورة</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الإجمالي</TableHead>
                    <TableHead>المدفوع</TableHead>
                    <TableHead>المتبقي</TableHead>
                    <TableHead>الحالة</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {detailsLoading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <Loader2 className="animate-spin mx-auto" />
                      </TableCell>
                    </TableRow>
                  ) : (
                    debtDetails?.invoices.map((invoice: any) => (
                      <TableRow key={invoice.id}>
                        <TableCell>{invoice.invoiceNumber}</TableCell>
                        <TableCell>{new Date(invoice.invoiceDate).toLocaleDateString("ar-SA")}</TableCell>
                        <TableCell>${invoice.total.toFixed(2)}</TableCell>
                        <TableCell className="text-green-600">${invoice.paidAmount.toFixed(2)}</TableCell>
                        <TableCell className="text-red-600">${invoice.remainingAmount.toFixed(2)}</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              invoice.status === "paid"
                                ? "bg-green-500"
                                : invoice.status === "partial"
                                ? "bg-yellow-500"
                                : "bg-red-500"
                            }
                          >
                            {invoice.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            <Button onClick={() => setSelectedDoctor(null)} variant="outline">
              إغلاق
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
