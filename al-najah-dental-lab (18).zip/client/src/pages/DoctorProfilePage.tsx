import React, { useState } from "react";
import { useParams, useLocation } from "wouter";
import { ArrowLeft, Star, Upload, Edit2, Save, X, Mail, Phone, MapPin, Briefcase, Calendar, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { StarRatingDisplay, StarRatingEditor } from "@/components/StarRating";

export function DoctorProfilePage() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const [isEditingRating, setIsEditingRating] = useState(false);
  const [newRating, setNewRating] = useState(0);
  const [notes, setNotes] = useState("");
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  // جلب بيانات الطبيب
  const { data: doctor, isLoading: doctorLoading } = trpc.doctors.getById.useQuery(
    { id: parseInt(id || "0") },
    { enabled: !!id }
  );

  // جلب أعمال الطبيب
  const { data: worksData } = trpc.works.getByDoctorWithDetails.useQuery(
    { doctorId: parseInt(id || "0") },
    { enabled: !!id }
  );

  // جلب فواتير الطبيب
  const { data: invoicesData } = trpc.invoices.getByDoctor.useQuery(
    { doctorId: parseInt(id || "0") },
    { enabled: !!id }
  );



  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingImage(true);
    try {
      // هنا يمكن إضافة منطق رفع الصورة إلى S3
      // للآن سنستخدم FileReader لعرض الصورة محلياً
      const reader = new FileReader();
      reader.onload = async (event) => {
        const imageData = event.target?.result as string;
        // يمكن حفظ الصورة في قاعدة البيانات أو S3
        toast.success("تم رفع الصورة بنجاح");
      };
      reader.readAsDataURL(file);
    } finally {
      setIsUploadingImage(false);
    }
  };

  if (doctorLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري تحميل البيانات...</p>
        </div>
      </div>
    );
  }

  if (!doctor) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <p className="text-gray-600 mb-4">لم يتم العثور على الطبيب</p>
          <Button onClick={() => setLocation("/doctors")}>العودة للأطباء</Button>
        </div>
      </div>
    );
  }

  const works = (worksData || []) as any[];
  const invoices = (invoicesData || []) as any[];
  const totalRevenue = invoices.reduce((sum, inv) => sum + (typeof inv.total === 'string' ? parseFloat(inv.total) : inv.total || 0), 0);
  const averageRating = 0;

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      {/* زر العودة */}
      <button
        onClick={() => setLocation("/doctors")}
        className="flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-6"
      >
        <ArrowLeft className="h-5 w-5" />
        <span>العودة للأطباء</span>
      </button>

      {/* رأس الملف الشخصي */}
      <Card className="mb-6 overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-blue-500 to-blue-600"></div>
        <div className="px-6 pb-6">
          <div className="flex flex-col md:flex-row gap-6 -mt-16 mb-6">
            {/* الصورة الشخصية */}
            <div className="relative">
              <div className="w-32 h-32 rounded-full bg-gray-200 border-4 border-white flex items-center justify-center overflow-hidden">
                <div className="text-4xl font-bold text-gray-400">
                  {doctor.name.charAt(0)}
                </div>
              </div>
              <label className="absolute bottom-0 right-0 bg-blue-600 text-white p-2 rounded-full cursor-pointer hover:bg-blue-700">
                <Upload className="h-4 w-4" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  disabled={isUploadingImage}
                  className="hidden"
                />
              </label>
            </div>

            {/* معلومات الطبيب الأساسية */}
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{doctor.name}</h1>
              <p className="text-gray-600 mb-4">{doctor.specialization || "تخصص غير محدد"}</p>

              {/* التقييم */}
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-3">
                  <StarRatingDisplay
                    rating={averageRating}
                    size="md"
                    showLabel={true}
                  />
                  <span className="text-xs text-gray-500">(0 تقييم)</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setNewRating(averageRating);
                    setIsEditingRating(true);
                  }}
                >
                  <Edit2 className="h-4 w-4 mr-2" />
                  تعديل التقييم
                </Button>
              </div>

              {/* معلومات الاتصال */}
              <div className="grid grid-cols-2 gap-4 text-sm">
                {doctor.email && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <Mail className="h-4 w-4" />
                    <span>{doctor.email}</span>
                  </div>
                )}
                {doctor.phone && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <Phone className="h-4 w-4" />
                    <span>{doctor.phone}</span>
                  </div>
                )}
                {doctor.clinic && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <Briefcase className="h-4 w-4" />
                    <span>{doctor.clinic}</span>
                  </div>
                )}
                {doctor.address && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <MapPin className="h-4 w-4" />
                    <span>{doctor.address}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* الإحصائيات */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">عدد الأعمال</p>
              <p className="text-2xl font-bold text-gray-900">{works.length}</p>
            </div>
            <Briefcase className="h-8 w-8 text-blue-600" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">إجمالي الإيرادات</p>
              <p className="text-2xl font-bold text-green-600">{totalRevenue.toFixed(2)} ر.س</p>
            </div>
            <TrendingUp className="h-8 w-8 text-green-600" />
          </div>
        </Card>



        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">عدد الفواتير</p>
              <p className="text-2xl font-bold text-gray-900">{invoices.length}</p>
            </div>
            <TrendingUp className="h-8 w-8 text-orange-600" />
          </div>
        </Card>
      </div>

      {/* الملاحظات الداخلية */}
      <Card className="mb-6 p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">الملاحظات الداخلية</h2>
        <textarea
          value={notes || ""}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="أضف ملاحظات خاصة عن الطبيب..."
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          rows={4}
        />
        <Button
          className="mt-4"
          disabled={true}
        >
          <Save className="h-4 w-4 mr-2" />
          حفظ الملاحظات
        </Button>
      </Card>

      {/* الأعمال */}
      <Card className="mb-6 p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">الأعمال المنجزة ({works.length})</h2>
        {works.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-right py-2 px-4">الوصف</th>
                  <th className="text-right py-2 px-4">الكمية</th>
                  <th className="text-right py-2 px-4">السعر</th>
                  <th className="text-right py-2 px-4">الإجمالي</th>
                  <th className="text-right py-2 px-4">التاريخ</th>
                </tr>
              </thead>
              <tbody>
                {works.map((work: any) => (
                  <tr key={work.id} className="border-b hover:bg-gray-50">
                    <td className="py-2 px-4">{work.description}</td>
                    <td className="py-2 px-4">{work.quantity}</td>
                    <td className="py-2 px-4">{work.unitPrice}</td>
                    <td className="py-2 px-4 font-semibold">{(work.quantity * work.unitPrice).toFixed(2)}</td>
                    <td className="py-2 px-4">{new Date(work.createdAt).toLocaleDateString("ar-SA")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-600">لا توجد أعمال مسجلة</p>
        )}
      </Card>

      {/* الفواتير */}
      <Card className="p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">الفواتير ({invoices.length})</h2>
        {invoices.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-right py-2 px-4">رقم الفاتورة</th>
                  <th className="text-right py-2 px-4">الإجمالي</th>
                  <th className="text-right py-2 px-4">المدفوع</th>
                  <th className="text-right py-2 px-4">المتبقي</th>
                  <th className="text-right py-2 px-4">الحالة</th>
                  <th className="text-right py-2 px-4">التاريخ</th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((invoice: any) => (
                  <tr key={invoice.id} className="border-b hover:bg-gray-50">
                    <td className="py-2 px-4">{invoice.invoiceNumber}</td>
                    <td className="py-2 px-4">{parseFloat(invoice.total).toFixed(2)}</td>
                    <td className="py-2 px-4">{parseFloat(invoice.paid).toFixed(2)}</td>
                    <td className="py-2 px-4">{(parseFloat(invoice.total) - parseFloat(invoice.paid)).toFixed(2)}</td>
                    <td className="py-2 px-4">
                      <span className={`px-2 py-1 rounded text-xs font-semibold ${
                        invoice.status === "paid" ? "bg-green-100 text-green-800" :
                        invoice.status === "pending" ? "bg-yellow-100 text-yellow-800" :
                        "bg-red-100 text-red-800"
                      }`}>
                        {invoice.status === "paid" ? "مدفوعة" : invoice.status === "pending" ? "قيد الانتظار" : "متأخرة"}
                      </span>
                    </td>
                    <td className="py-2 px-4">{new Date(invoice.createdAt).toLocaleDateString("ar-SA")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-600">لا توجد فواتير مسجلة</p>
        )}
      </Card>

      {/* نافذة تعديل التقييم */}
      <Dialog open={isEditingRating} onOpenChange={setIsEditingRating}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تعديل تقييم الطبيب</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="flex justify-center">
              <StarRatingEditor
                rating={newRating}
                onRatingChange={setNewRating}
                size="lg"
                showLabel={true}
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button
                variant="outline"
                onClick={() => setIsEditingRating(false)}
              >
                إلغاء
              </Button>
              <Button
                disabled={true}
                className="bg-blue-600 hover:bg-blue-700"
              >
                حفظ التقييم
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
