import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Edit2, Trash2, Loader2, User, Mail, Phone, Building2, Award, Briefcase } from "lucide-react";
import { toast } from "sonner";

export default function DoctorsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    specialization: "",
    clinic: "",
  });

  const { data: doctors = [], isLoading, refetch } = trpc.doctors.list.useQuery();
  const { data: works = [] } = trpc.works.list.useQuery();
  const createMutation = trpc.doctors.create.useMutation();
  const updateMutation = trpc.doctors.update.useMutation();
  const deleteMutation = trpc.doctors.delete.useMutation();

  // حساب عدد الأعمال لكل طبيب
  const doctorWorkCounts = useMemo(() => {
    const counts: Record<number, number> = {};
    const worksList = (works as any)?.data || works || [];
    (worksList as any[]).forEach((work: any) => {
      if (work.doctorId) {
        counts[work.doctorId] = (counts[work.doctorId] || 0) + 1;
      }
    });
    return counts;
  }, [works]);

  // ترتيب الأطباء تنازلياً حسب عدد الأعمال
  const sortedDoctors = useMemo(() => {
    return [...(doctors || [])].sort((a, b) => {
      const countA = doctorWorkCounts[a.id] || 0;
      const countB = doctorWorkCounts[b.id] || 0;
      return countB - countA;
    });
  }, [doctors, doctorWorkCounts]);

  const filteredDoctors = (sortedDoctors || []).filter(
    (doctor) =>
      doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doctor.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const dataToSubmit = {
        name: formData.name,
        email: formData.email.trim() === "" ? undefined : formData.email.trim(),
        phone: formData.phone.trim() === "" ? undefined : formData.phone.trim(),
        specialization: formData.specialization.trim() === "" ? undefined : formData.specialization.trim(),
        clinic: formData.clinic.trim() === "" ? undefined : formData.clinic.trim(),
      };

      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...dataToSubmit });
        toast.success("تم تحديث بيانات الطبيب بنجاح");
      } else {
        await createMutation.mutateAsync(dataToSubmit);
        toast.success("تم إضافة الطبيب بنجاح");
      }
      setFormData({ name: "", email: "", phone: "", specialization: "", clinic: "" });
      setEditingId(null);
      setIsDialogOpen(false);
      refetch();
    } catch (error: any) {
      console.error("Error:", error);
      const errorMessage = error?.message || "حدث خطأ أثناء حفظ البيانات";
      toast.error(errorMessage);
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("هل تريد حذف هذا الطبيب؟")) {
      try {
        await deleteMutation.mutateAsync({ id });
        toast.success("تم حذف الطبيب بنجاح");
        refetch();
      } catch (error) {
        toast.error("حدث خطأ أثناء الحذف");
      }
    }
  };

  const handleEdit = (doctor: any) => {
    setFormData({
      name: doctor.name,
      email: doctor.email || "",
      phone: doctor.phone || "",
      specialization: doctor.specialization || "",
      clinic: doctor.clinic || "",
    });
    setEditingId(doctor.id);
    setIsDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">إدارة الأطباء</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingId(null)} className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-lg">
              <Plus className="h-4 w-4 ml-2" />
              إضافة طبيب جديد
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingId ? "تعديل الطبيب" : "إضافة طبيب جديد"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                placeholder="اسم الطبيب"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
              <Input
                type="email"
                placeholder="البريد الإلكتروني (اختياري)"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
              <Input
                placeholder="رقم الهاتف (اختياري)"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
              <Input
                placeholder="التخصص (اختياري)"
                value={formData.specialization}
                onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
              />
              <Input
                placeholder="العيادة (اختياري)"
                value={formData.clinic}
                onChange={(e) => setFormData({ ...formData, clinic: e.target.value })}
              />
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                {editingId ? "تحديث" : "إضافة"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex gap-4">
        <Input
          placeholder="بحث عن طبيب..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-sm border-gray-300 focus:border-blue-500 focus:ring-blue-500"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {(filteredDoctors || []).map((doctor) => {
          const workCount = doctorWorkCounts[doctor.id] || 0;
          return (
            <Card key={doctor.id} className="hover:shadow-xl transition-all duration-300 border-0 bg-gradient-to-br from-white to-slate-50 overflow-hidden relative">
              <div className="h-1 bg-gradient-to-r from-blue-500 to-blue-600"></div>
              
              {/* عدد الأعمال على يمين البطاقة */}
              <div className="absolute top-4 right-4 flex items-center gap-2">
                {/* النجوم على يسار العمل */}
                {workCount >= 50 && (
                  <div className="flex gap-0.5">
                    {Array.from({ length: Math.floor(workCount / 50) }).map((_, i) => (
                      <span key={i} className="text-yellow-400 text-xl">⭐</span>
                    ))}
                  </div>
                )}
                {/* صندوق الأعمال */}
                <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-lg p-3 shadow-lg">
                  <div className="flex items-center gap-2 flex-row-reverse">
                    <Briefcase className="h-5 w-5" />
                    <div className="text-left">
                      <p className="text-2xl font-bold">{workCount}</p>
                      <p className="text-xs opacity-90">عمل</p>
                    </div>
                  </div>
                </div>
              </div>

              <CardHeader className="pb-4 pl-24">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <User className="h-4 w-4 text-blue-600" />
                      </div>
                      <CardTitle className="text-lg font-bold text-gray-900">{doctor.name}</CardTitle>
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <Award className="h-3 w-3 text-gray-400" />
                      <p className="text-xs text-gray-500 font-medium">الرخصة: DR{String(doctor.id).padStart(3, "0")}</p>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {doctor.specialization && (
                    <div className="flex items-center gap-3 p-2 bg-blue-50 rounded-lg">
                      <Award className="h-4 w-4 text-blue-600 flex-shrink-0" />
                      <div>
                        <p className="text-xs text-gray-600 font-medium">التخصص</p>
                        <p className="text-sm text-gray-900 font-semibold">{doctor.specialization}</p>
                      </div>
                    </div>
                  )}
                  {doctor.email && (
                    <div className="flex items-center gap-3 p-2 bg-green-50 rounded-lg">
                      <Mail className="h-4 w-4 text-green-600 flex-shrink-0" />
                      <div>
                        <p className="text-xs text-gray-600 font-medium">البريد الإلكتروني</p>
                        <p className="text-xs text-gray-900 font-semibold break-all">{doctor.email}</p>
                      </div>
                    </div>
                  )}
                  {doctor.phone && (
                    <div className="flex items-center gap-3 p-2 bg-purple-50 rounded-lg">
                      <Phone className="h-4 w-4 text-purple-600 flex-shrink-0" />
                      <div>
                        <p className="text-xs text-gray-600 font-medium">الهاتف</p>
                        <p className="text-sm text-gray-900 font-semibold">{doctor.phone}</p>
                      </div>
                    </div>
                  )}
                  {doctor.clinic && (
                    <div className="flex items-center gap-3 p-2 bg-orange-50 rounded-lg">
                      <Building2 className="h-4 w-4 text-orange-600 flex-shrink-0" />
                      <div>
                        <p className="text-xs text-gray-600 font-medium">العيادة</p>
                        <p className="text-sm text-gray-900 font-semibold">{doctor.clinic}</p>
                      </div>
                    </div>
                  )}
                </div>
                <div className="flex gap-2 mt-6 pt-4 border-t border-gray-200">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(doctor)}
                    className="flex-1 text-xs bg-blue-50 text-blue-600 border-blue-200 hover:bg-blue-100 hover:text-blue-700"
                  >
                    <Edit2 className="h-3 w-3 ml-1" />
                    تعديل
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDelete(doctor.id)}
                    className="flex-1 text-xs bg-red-50 text-red-600 border-red-200 hover:bg-red-100 hover:text-red-700"
                  >
                    <Trash2 className="h-3 w-3 ml-1" />
                    حذف
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {(filteredDoctors || []).length === 0 && (
        <div className="text-center py-12 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
          <User className="h-12 w-12 text-blue-300 mx-auto mb-3" />
          <p className="text-gray-600 font-medium">لا توجد أطباء</p>
        </div>
      )}
    </div>
  );
}
