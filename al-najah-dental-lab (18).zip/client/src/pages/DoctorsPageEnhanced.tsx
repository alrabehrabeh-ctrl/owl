import React, { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Edit2, Trash2, Loader2, User, Briefcase, DollarSign, Calendar, Search, Filter, Download, Mail, Copy, Star } from "lucide-react";
import { StarRatingDisplay } from "@/components/StarRating";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function DoctorsPageEnhanced() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSpecialization, setFilterSpecialization] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [selectedDoctor, setSelectedDoctor] = useState<any | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    specialization: "",
    clinic: "",
    rating: 0,
  });

  const { data: doctors = [], isLoading, refetch } = trpc.doctors.list.useQuery();
  const { data: worksData } = trpc.works.list.useQuery();
  const works = (Array.isArray(worksData) ? worksData : (worksData as any)?.data) || [];

  const createMutation = trpc.doctors.create.useMutation();
  const updateMutation = trpc.doctors.update.useMutation();
  const deleteMutation = trpc.doctors.delete.useMutation();

  // حساب الإحصائيات لكل طبيب
  const doctorStats = useMemo(() => {
    const stats: Record<number, any> = {};
    works.forEach((work: any) => {
      if (!stats[work.doctorId]) {
        stats[work.doctorId] = {
          totalWorks: 0,
          completedWorks: 0,
          totalRevenue: 0,
          lastWorkDate: null,
        };
      }
      stats[work.doctorId].totalWorks++;
      if (work.status === "delivered") {
        stats[work.doctorId].completedWorks++;
        stats[work.doctorId].totalRevenue += parseFloat(work.totalPrice || "0");
      }
      const workDate = new Date(work.receivedDate || work.createdAt);
      if (!stats[work.doctorId].lastWorkDate || workDate > new Date(stats[work.doctorId].lastWorkDate)) {
        stats[work.doctorId].lastWorkDate = workDate;
      }
    });
    return stats;
  }, [works]);

  // التصفية والفرز
  const filteredAndSortedDoctors = useMemo(() => {
    let filtered = doctors.filter((doctor) => {
      const matchesSearch =
        doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doctor.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doctor.phone?.includes(searchTerm);

      const matchesSpecialization =
        filterSpecialization === "all" || doctor.specialization === filterSpecialization;

      return matchesSearch && matchesSpecialization;
    });

    // الفرز
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "name":
          return a.name.localeCompare(b.name);
        case "revenue":
          const revenueA = doctorStats[a.id]?.totalRevenue || 0;
          const revenueB = doctorStats[b.id]?.totalRevenue || 0;
          return revenueB - revenueA;
        case "works":
          const worksA = doctorStats[a.id]?.completedWorks || 0;
          const worksB = doctorStats[b.id]?.completedWorks || 0;
          return worksB - worksA;
        case "recent":
          const dateA = doctorStats[a.id]?.lastWorkDate || new Date(0);
          const dateB = doctorStats[b.id]?.lastWorkDate || new Date(0);
          return new Date(dateB).getTime() - new Date(dateA).getTime();
        default:
          return 0;
      }
    });

    return filtered;
  }, [doctors, searchTerm, filterSpecialization, sortBy, doctorStats]);

  // الحصول على قائمة التخصصات الفريدة
  const specializations = useMemo(() => {
    const specs = new Set(doctors.map((d) => d.specialization).filter(Boolean));
    return Array.from(specs);
  }, [doctors]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const dataToSubmit = {
        name: formData.name,
        email: formData.email.trim() === "" ? undefined : formData.email.trim(),
        phone: formData.phone.trim() === "" ? undefined : formData.phone.trim(),
        specialization: formData.specialization.trim() === "" ? undefined : formData.specialization.trim(),
        clinic: formData.clinic.trim() === "" ? undefined : formData.clinic.trim(),
      };

      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...dataToSubmit });
        toast.success("✓ تم تحديث بيانات الطبيب بنجاح");
      } else {
        await createMutation.mutateAsync(dataToSubmit);
        toast.success("✓ تم إضافة الطبيب بنجاح");
      }
      setFormData({ name: "", email: "", phone: "", specialization: "", clinic: "", rating: 0 });
      setEditingId(null);
      setIsDialogOpen(false);
      refetch();
    } catch (error: any) {
      console.error("Error:", error);
      toast.error("✗ حدث خطأ: " + (error?.message || "حاول مرة أخرى"));
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("✓ تم حذف الطبيب بنجاح");
      setDeleteConfirm(null);
      refetch();
    } catch (error) {
      toast.error("✗ حدث خطأ أثناء الحذف");
    }
  };

  const handleEdit = (doctor: any) => {
    setFormData({
      name: doctor.name,
      email: doctor.email || "",
      phone: doctor.phone || "",
      specialization: doctor.specialization || "",
      clinic: doctor.clinic || "",
      rating: 0,
    });
    setEditingId(doctor.id);
    setIsDialogOpen(true);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("✓ تم النسخ");
  };

  const getStatusColor = (doctorId: number) => {
    const stats = doctorStats[doctorId];
    if (!stats || stats.totalWorks === 0) return "bg-gray-100";
    const completionRate = (stats.completedWorks / stats.totalWorks) * 100;
    if (completionRate >= 80) return "bg-green-100";
    if (completionRate >= 50) return "bg-blue-100";
    return "bg-yellow-100";
  };

  const getStatusText = (doctorId: number) => {
    const stats = doctorStats[doctorId];
    if (!stats || stats.totalWorks === 0) return "جديد";
    const completionRate = (stats.completedWorks / stats.totalWorks) * 100;
    if (completionRate >= 80) return "نشط جداً";
    if (completionRate >= 50) return "نشط";
    return "خامل";
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* رأس الصفحة */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">إدارة الأطباء</h1>
          <p className="text-gray-600 mt-1">إدارة بيانات الأطباء والعاملين بالمخبر</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingId(null)} className="bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="h-4 w-4 ml-2" />
              إضافة طبيب جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingId ? "تعديل بيانات الطبيب" : "إضافة طبيب جديد"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">اسم الطبيب *</label>
                <Input
                  placeholder="أدخل اسم الطبيب"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="border-gray-300"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                <Input
                  type="email"
                  placeholder="example@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="border-gray-300"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف</label>
                <Input
                  placeholder="+966 50 1234567"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="border-gray-300"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">التخصص</label>
                <Input
                  placeholder="مثال: تقويم أسنان"
                  value={formData.specialization}
                  onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                  className="border-gray-300"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">العيادة</label>
                <Input
                  placeholder="اسم العيادة"
                  value={formData.clinic}
                  onChange={(e) => setFormData({ ...formData, clinic: e.target.value })}
                  className="border-gray-300"
                />
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                {editingId ? "تحديث البيانات" : "إضافة الطبيب"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* أدوات البحث والتصفية */}
      <div className="bg-white rounded-lg shadow p-4 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="بحث عن طبيب..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-10 border-gray-300"
            />
          </div>
          <div>
            <select
              value={filterSpecialization || "all"}
              onChange={(e) => setFilterSpecialization(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">جميع التخصصات</option>
              {specializations.map((spec) => (
                <option key={spec} value={spec || ""}>
                  {spec}
                </option>
              ))}
            </select>
          </div>
          <div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="name">ترتيب حسب الاسم</option>
              <option value="revenue">ترتيب حسب الإيرادات</option>
              <option value="works">ترتيب حسب الأعمال المنجزة</option>
              <option value="recent">الأحدث أولاً</option>
            </select>
          </div>
          <div className="text-sm text-gray-600 flex items-center">
            <span className="font-medium">{filteredAndSortedDoctors.length}</span>
            <span className="mr-2">طبيب</span>
          </div>
        </div>
      </div>

      {/* شبكة بطاقات الأطباء */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAndSortedDoctors.map((doctor) => {
          const stats = doctorStats[doctor.id] || {};
          const initials = doctor.name
            .split(" ")
            .map((n) => n[0])
            .join("")
            .toUpperCase();

          return (
            <Card key={doctor.id} className="hover:shadow-xl transition-all duration-300 overflow-hidden">
              {/* شريط ملون في الأعلى */}
              <div className={`h-1 ${getStatusColor(doctor.id)}`}></div>

              <CardHeader className="pb-3">
                {/* صورة الملف الشخصي */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white font-bold text-lg">
                      {initials}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{doctor.name}</CardTitle>
                      <p className="text-xs text-gray-500">الرخصة: DR{String(doctor.id).padStart(3, "0")}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(doctor.id)}`}>
                      {getStatusText(doctor.id)}
                    </span>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* معلومات الاتصال */}
                <div className="space-y-2">
                  {doctor.specialization && (
                    <div className="flex items-center gap-2 text-sm">
                      <Briefcase className="h-4 w-4 text-blue-600" />
                      <span className="font-medium">{doctor.specialization}</span>
                    </div>
                  )}
                  {doctor.clinic && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Building className="h-4 w-4" />
                      <span>{doctor.clinic}</span>
                    </div>
                  )}
                </div>

                {/* التقييم */}


                {/* الإحصائيات */}
                <div className="grid grid-cols-3 gap-2 bg-gray-50 p-3 rounded-lg">
                  <div className="text-center">
                    <p className="text-xs text-gray-600">الأعمال</p>
                    <p className="text-lg font-bold text-blue-600">{stats.completedWorks || 0}</p>
                  </div>
                  <div className="text-center border-r border-l border-gray-200">
                    <p className="text-xs text-gray-600">الإيرادات</p>
                    <p className="text-lg font-bold text-green-600">${(stats.totalRevenue || 0).toFixed(0)}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-gray-600">آخر عملية</p>
                    <p className="text-xs font-medium text-gray-700">
                      {stats.lastWorkDate
                        ? new Date(stats.lastWorkDate).toLocaleDateString("ar-SA", {
                            month: "short",
                            day: "numeric",
                          })
                        : "-"}
                    </p>
                  </div>
                </div>

                {/* معلومات الاتصال السريعة */}
                <div className="space-y-2 border-t pt-3">
                  {doctor.email && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600 truncate">{doctor.email}</span>
                      <button
                        onClick={() => copyToClipboard(doctor.email || "")}
                        className="text-blue-600 hover:text-blue-700"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                  {doctor.phone && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">{doctor.phone}</span>
                      <button
                        onClick={() => copyToClipboard(doctor.phone || "")}
                        className="text-blue-600 hover:text-blue-700"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                </div>

                {/* الأزرار */}
                <div className="flex gap-2 pt-3 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(doctor)}
                    className="flex-1 text-xs"
                  >
                    <Edit2 className="h-3 w-3 ml-1" />
                    تعديل
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDeleteConfirm(doctor.id)}
                    className="flex-1 text-xs text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="h-3 w-3 ml-1" />
                    حذف
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* حالة عدم وجود أطباء */}
      {filteredAndSortedDoctors.length === 0 && (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <User className="h-12 w-12 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-600 font-medium">لا توجد أطباء مطابقة</p>
          <p className="text-gray-500 text-sm">حاول تغيير معايير البحث أو التصفية</p>
        </div>
      )}

      {/* نافذة تأكيد الحذف */}
      <AlertDialog open={deleteConfirm !== null} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من رغبتك في حذف هذا الطبيب؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex gap-3 justify-end">
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteConfirm && handleDelete(deleteConfirm)}
              className="bg-red-600 hover:bg-red-700"
            >
              حذف
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// مكون أيقونة المبنى
function Building({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
      <polyline points="9 22 9 12 15 12 15 22"></polyline>
    </svg>
  );
}
