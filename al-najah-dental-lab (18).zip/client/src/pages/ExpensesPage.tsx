import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Loader2, Edit, Trash2 } from "lucide-react";
import { toast } from "sonner";

export default function ExpensesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    category: "other",
    description: "",
    amount: "",
    vendor: "",
    paymentMethod: "cash",
    referenceNumber: "",
  });

  const { data: expenses, isLoading, refetch } = trpc.expenses.list.useQuery();
  const createMutation = trpc.expenses.create.useMutation();
  const updateMutation = trpc.expenses.update.useMutation();
  const deleteMutation = trpc.expenses.delete.useMutation();

  const filteredExpenses = expenses?.filter(
    (expense) =>
      expense.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      expense.vendor?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await updateMutation.mutateAsync({
          id: editingId,
          category: formData.category as any,
          description: formData.description,
          amount: formData.amount,
          vendor: formData.vendor,
          expenseDate: new Date(),
          paymentMethod: formData.paymentMethod as any,
          referenceNumber: formData.referenceNumber,
        });
        toast.success("تم تحديث المصروف بنجاح");
      } else {
        await createMutation.mutateAsync({
          category: formData.category as any,
          description: formData.description,
          amount: formData.amount,
          vendor: formData.vendor,
          expenseDate: new Date(),
          paymentMethod: formData.paymentMethod as any,
          referenceNumber: formData.referenceNumber,
        });
        toast.success("تم تسجيل المصروف بنجاح");
      }
      setFormData({
        category: "other",
        description: "",
        amount: "",
        vendor: "",
        paymentMethod: "cash",
        referenceNumber: "",
      });
      setEditingId(null);
      setIsDialogOpen(false);
      refetch();
    } catch (error) {
      toast.error("حدث خطأ أثناء معالجة المصروف");
    }
  };

  const handleEdit = (expense: any) => {
    setEditingId(expense.id);
    setFormData({
      category: expense.category,
      description: expense.description,
      amount: expense.amount,
      vendor: expense.vendor || "",
      paymentMethod: expense.paymentMethod,
      referenceNumber: expense.referenceNumber || "",
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("تم حذف المصروف بنجاح");
      setDeleteConfirm(null);
      refetch();
    } catch (error) {
      toast.error("حدث خطأ أثناء حذف المصروف");
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "salary":
        return "رواتب";
      case "rent":
        return "إيجار";
      case "materials":
        return "مواد";
      case "utilities":
        return "فواتير";
      case "maintenance":
        return "صيانة";
      case "other":
        return "أخرى";
      default:
        return category;
    }
  };

  const getTotalByCategory = (category: string) => {
    return expenses
      ?.filter((e) => e.category === category)
      .reduce((sum, e) => sum + parseFloat(e.amount), 0) || 0;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const totalExpenses = expenses?.reduce((sum, e) => sum + parseFloat(e.amount), 0) || 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">إدارة المصروفات</h1>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) {
            setEditingId(null);
            setFormData({
              category: "other",
              description: "",
              amount: "",
              vendor: "",
              paymentMethod: "cash",
              referenceNumber: "",
            });
          }
        }}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 ml-2" />
              إضافة مصروف جديد
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingId ? "تعديل المصروف" : "إضافة مصروف جديد"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full border rounded px-3 py-2"
              >
                <option value="salary">رواتب</option>
                <option value="rent">إيجار</option>
                <option value="materials">مواد</option>
                <option value="utilities">فواتير</option>
                <option value="maintenance">صيانة</option>
                <option value="other">أخرى</option>
              </select>
              <Input
                placeholder="وصف المصروف"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                required
              />
              <Input
                type="number"
                placeholder="المبلغ"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
              />
              <Input
                placeholder="المورد/الشركة"
                value={formData.vendor}
                onChange={(e) => setFormData({ ...formData, vendor: e.target.value })}
              />
              <select
                value={formData.paymentMethod}
                onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                className="w-full border rounded px-3 py-2"
              >
                <option value="cash">نقداً</option>
                <option value="check">شيك</option>
                <option value="bank_transfer">تحويل بنكي</option>
                <option value="credit_card">بطاقة ائتمان</option>
                <option value="other">أخرى</option>
              </select>
              <Input
                placeholder="رقم المرجع"
                value={formData.referenceNumber}
                onChange={(e) => setFormData({ ...formData, referenceNumber: e.target.value })}
              />
              <Button type="submit" className="w-full">
                {editingId ? "تحديث المصروف" : "إضافة المصروف"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المصروفات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">${totalExpenses.toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">الرواتب</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${getTotalByCategory("salary").toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">الإيجار</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${getTotalByCategory("rent").toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-4">
        <Input
          placeholder="بحث عن مصروف..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-sm"
        />
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100">
              <th className="border p-3 text-right">الوصف</th>
              <th className="border p-3 text-right">التصنيف</th>
              <th className="border p-3 text-right">المبلغ</th>
              <th className="border p-3 text-right">المورد</th>
              <th className="border p-3 text-right">التاريخ</th>
              <th className="border p-3 text-right">الإجراءات</th>
            </tr>
          </thead>
          <tbody>
            {filteredExpenses?.map((expense) => (
              <tr key={expense.id} className="border-b hover:bg-gray-50">
                <td className="border p-3">{expense.description}</td>
                <td className="border p-3">{getCategoryLabel(expense.category)}</td>
                <td className="border p-3 font-bold text-red-600">${expense.amount}</td>
                <td className="border p-3">{expense.vendor || "-"}</td>
                <td className="border p-3">{new Date(expense.expenseDate).toLocaleDateString("ar-SA")}</td>
                <td className="border p-3 flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(expense)}
                    className="flex items-center gap-1"
                  >
                    <Edit className="h-4 w-4" />
                    تعديل
                  </Button>
                  {deleteConfirm === expense.id ? (
                    <div className="flex gap-2">
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDelete(expense.id)}
                      >
                        تأكيد
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setDeleteConfirm(null)}
                      >
                        إلغاء
                      </Button>
                    </div>
                  ) : (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => setDeleteConfirm(expense.id)}
                      className="flex items-center gap-1"
                    >
                      <Trash2 className="h-4 w-4" />
                      حذف
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
