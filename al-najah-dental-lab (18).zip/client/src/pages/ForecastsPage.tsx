import { useState, useMemo } from "react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { TrendingUp, Calendar, Target, AlertCircle, Download, FileText } from "lucide-react";

export default function ForecastsPage() {
  const [monthsAhead, setMonthsAhead] = useState(3);
  const [monthsBack, setMonthsBack] = useState(12);
  const [activeTab, setActiveTab] = useState<"overall" | "byType" | "byDoctor">("overall");
  const [isExporting, setIsExporting] = useState(false);

  // جلب البيانات
  const { data: overallForecast = [] } = trpc.forecasts.getOverallForecast.useQuery({ monthsAhead });
  const { data: forecastByType = [] } = trpc.forecasts.getByType.useQuery({ monthsAhead });
  const { data: forecastByDoctor = [] } = trpc.forecasts.getByDoctor.useQuery({ monthsAhead });
  const { data: historicalData = [] } = trpc.forecasts.getHistoricalData.useQuery({ monthsBack });

  // معالجة البيانات
  const monthNames = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];

  const combinedData = useMemo(() => {
    // دمج البيانات التاريخية مع التوقعات
    const historical = historicalData.map(h => ({
      month: monthNames[h.month - 1] || `شهر ${h.month}`,
      revenue: h.revenue,
      type: "فعلي",
      monthNum: h.month,
      year: h.year,
    }));

    const forecasted = overallForecast.map(f => ({
      month: monthNames[f.month - 1] || `شهر ${f.month}`,
      forecastedRevenue: f.forecastedRevenue,
      confidence: f.confidence,
      type: "توقع",
      monthNum: f.month,
      year: f.year,
    }));

    // دمج البيانات
    const combined: any[] = [];
    const monthMap = new Map<string, any>();

    historical.forEach(h => {
      const key = `${h.year}-${h.monthNum}`;
      monthMap.set(key, { ...h });
    });

    forecasted.forEach(f => {
      const key = `${f.year}-${f.monthNum}`;
      const existing = monthMap.get(key) || {};
      monthMap.set(key, { ...existing, ...f });
    });

    // تحويل إلى مصفوفة وترتيبها
    monthMap.forEach((value, key) => {
      combined.push(value);
    });

    return combined.sort((a, b) => {
      if (a.year !== b.year) return a.year - b.year;
      return a.monthNum - b.monthNum;
    });
  }, [historicalData, overallForecast, monthNames]);

  // حساب الإحصائيات
  // دالة حساب الموسمية
  const calculateSeasonality = useMemo(() => {
    if (historicalData.length === 0) return {};
    const monthlyAvg: Record<number, number[]> = {};
    
    historicalData.forEach(h => {
      if (!monthlyAvg[h.month]) monthlyAvg[h.month] = [];
      monthlyAvg[h.month].push(h.revenue);
    });
    
    const seasonality: Record<number, number> = {};
    const overallAvg = historicalData.reduce((sum, h) => sum + h.revenue, 0) / historicalData.length;
    
    Object.entries(monthlyAvg).forEach(([month, values]) => {
      const monthAvg = values.reduce((a, b) => a + b, 0) / values.length;
      seasonality[parseInt(month)] = Math.round((monthAvg / overallAvg - 1) * 100);
    });
    
    return seasonality;
  }, [historicalData]);

  const stats = useMemo(() => {
    const totalForecast = overallForecast.reduce((sum, f) => sum + f.forecastedRevenue, 0);
    const avgForecast = overallForecast.length > 0 ? totalForecast / overallForecast.length : 0;
    const avgHistorical = historicalData.length > 0 
      ? historicalData.reduce((sum, h) => sum + h.revenue, 0) / historicalData.length 
      : 0;
    const growthRate = avgHistorical > 0 ? ((avgForecast - avgHistorical) / avgHistorical) * 100 : 0;

    return {
      totalForecast: isNaN(totalForecast) ? 0 : Math.round(totalForecast * 100) / 100,
      avgForecast: isNaN(avgForecast) ? 0 : Math.round(avgForecast * 100) / 100,
      avgHistorical: isNaN(avgHistorical) ? 0 : Math.round(avgHistorical * 100) / 100,
      growthRate: isNaN(growthRate) ? 0 : Math.round(growthRate * 10) / 10,
    };
  }, [overallForecast, historicalData]);

  // دالة تصدير PDF
  const handleExportPDF = async () => {
    setIsExporting(true);
    try {
      const content = `
تقرير التوقعات - مخبر النجاح للتعويضات السنية
================================================

إجمالي التوقعات: $${stats.totalForecast}
المتوسط الشهري: $${stats.avgForecast}
معدل النمو: ${stats.growthRate}%

البيانات التاريخية:
${historicalData.map(h => `${monthNames[h.month - 1]}: $${h.revenue}`).join('\n')}

التوقعات:
${overallForecast.map(f => `${monthNames[f.month - 1]}: $${f.forecastedRevenue} (ثقة: ${Math.round(f.confidence * 100)}%)`).join('\n')}
      `;
      
      const element = document.createElement('a');
      element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
      element.setAttribute('download', 'forecast-report.txt');
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    } finally {
      setIsExporting(false);
    }
  };

  // دالة تصدير Excel
  const handleExportExcel = async () => {
    setIsExporting(true);
    try {
      const csvContent = [
        ['الشهر', 'الإيرادات الفعلية', 'الإيرادات المتوقعة', 'الثقة'],
        ...combinedData.map(d => [
          d.month,
          d.revenue || '',
          d.forecastedRevenue || '',
          d.confidence ? Math.round(d.confidence * 100) + '%' : ''
        ])
      ].map(row => row.join(',')).join('\n');
      
      const element = document.createElement('a');
      element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvContent));
      element.setAttribute('download', 'forecast-report.csv');
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    } finally {
      setIsExporting(false);
    }
  };

  // بيانات التوقعات حسب نوع الخدمة
  const typeChartData = useMemo(() => {
    const typeMap = new Map<string, any>();
    
    forecastByType.forEach(f => {
      const key = f.workTypeName;
      if (!typeMap.has(key)) {
        typeMap.set(key, {
          name: f.workTypeName,
          total: 0,
          months: [],
        });
      }
      const item = typeMap.get(key)!;
      item.total += f.forecastedRevenue;
      item.months.push({
        month: monthNames[f.month - 1],
        revenue: f.forecastedRevenue,
      });
    });

    return Array.from(typeMap.values());
  }, [forecastByType, monthNames]);

  // بيانات التوقعات حسب الطبيب
  const doctorChartData = useMemo(() => {
    const doctorMap = new Map<string, any>();
    
    forecastByDoctor.forEach(f => {
      const key = f.doctorName;
      if (!doctorMap.has(key)) {
        doctorMap.set(key, {
          name: f.doctorName,
          total: 0,
          months: [],
        });
      }
      const item = doctorMap.get(key)!;
      item.total += f.forecastedRevenue;
      item.months.push({
        month: monthNames[f.month - 1],
        revenue: f.forecastedRevenue,
      });
    });

    return Array.from(doctorMap.values()).sort((a, b) => b.total - a.total).slice(0, 5);
  }, [forecastByDoctor, monthNames]);

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* رأس الصفحة */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-2">
          <TrendingUp className="text-blue-600" size={32} />
          التوقعات والتنبؤات
        </h1>
        <p className="text-gray-600">توقعات الإيرادات للأشهر القادمة بناءً على البيانات التاريخية</p>
      </div>

      {/* خيارات الفترة الزمنية */}
      <div className="mb-6 flex gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <label className="text-sm font-medium text-gray-700">عدد الأشهر المتوقعة:</label>
          <select
            value={monthsAhead}
            onChange={(e) => setMonthsAhead(Number(e.target.value))}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value={1}>شهر واحد</option>
            <option value={3}>3 أشهر</option>
            <option value={6}>6 أشهر</option>
            <option value={12}>12 شهر</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-sm font-medium text-gray-700">البيانات التاريخية:</label>
          <select
            value={monthsBack}
            onChange={(e) => setMonthsBack(Number(e.target.value))}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value={6}>6 أشهر</option>
            <option value={12}>12 شهر</option>
            <option value={24}>24 شهر</option>
          </select>
        </div>

        <div className="flex items-center gap-2 ml-auto">
          <Button
            onClick={handleExportPDF}
            disabled={isExporting}
            variant="outline"
            className="flex items-center gap-2"
          >
            <FileText size={18} />
            تصدير PDF
          </Button>
          <Button
            onClick={handleExportExcel}
            disabled={isExporting}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Download size={18} />
            تصدير Excel
          </Button>
        </div>
      </div>

      {/* بطاقات الإحصائيات */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">
              إجمالي التوقعات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">
              ${isNaN(stats.totalForecast) ? '0' : stats.totalForecast.toLocaleString()}
            </div>
            <p className="text-xs text-gray-500 mt-2">للأشهر {monthsAhead} القادمة</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">
              المتوسط الشهري المتوقع
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              ${isNaN(stats.avgForecast) ? '0' : stats.avgForecast.toLocaleString()}
            </div>
            <p className="text-xs text-gray-500 mt-2">متوسط الإيرادات</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">
              المتوسط التاريخي
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">
              ${isNaN(stats.avgHistorical) ? '0' : stats.avgHistorical.toLocaleString()}
            </div>
            <p className="text-xs text-gray-500 mt-2">متوسط السابق</p>
          </CardContent>
        </Card>

        <Card className={`border-l-4 ${stats.growthRate >= 0 ? "border-l-emerald-500" : "border-l-red-500"}`}>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">
              معدل النمو المتوقع
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-3xl font-bold ${stats.growthRate >= 0 ? "text-emerald-600" : "text-red-600"}`}>
              {isNaN(stats.growthRate) ? '0' : stats.growthRate > 0 ? "+" : ""}{isNaN(stats.growthRate) ? '0' : stats.growthRate}%
            </div>
            <p className="text-xs text-gray-500 mt-2">مقارنة بالمتوسط</p>
          </CardContent>
        </Card>
      </div>

      {/* الرسوم البيانية */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* الرسم البياني الشامل */}
        <Card>
          <CardHeader>
            <CardTitle>الإيرادات الفعلية والمتوقعة</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <ComposedChart data={combinedData.map(d => ({
                ...d,
                revenue: isNaN(d.revenue) ? 0 : d.revenue,
                forecastedRevenue: isNaN(d.forecastedRevenue) ? 0 : d.forecastedRevenue,
              }))}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="revenue" fill="#3b82f6" name="الإيرادات الفعلية" />
                <Line
                  type="monotone"
                  dataKey="forecastedRevenue"
                  stroke="#f39c12"
                  name="التوقعات"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                />
              </ComposedChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* معدل النمو */}
        <Card>
          <CardHeader>
            <CardTitle>توجه التوقعات</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={overallForecast.map((f, i) => ({
                month: monthNames[f.month - 1],
                revenue: isNaN(f.forecastedRevenue) ? 0 : f.forecastedRevenue,
                confidence: isNaN(f.confidence) ? 0 : Math.round(f.confidence * 100),
              }))}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Legend />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="revenue"
                  stroke="#2ecc71"
                  name="الإيرادات المتوقعة"
                  strokeWidth={2}
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="confidence"
                  stroke="#e74c3c"
                  name="مستوى الثقة (%)"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* رسم بياني الموسمية */}
        <Card>
          <CardHeader>
            <CardTitle>تحليل الموسمية (تأثير الشهر على الإيرادات)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={Object.entries(calculateSeasonality).map(([month, value]) => ({
                month: monthNames[parseInt(month) - 1],
                seasonality: value,
              }))}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="seasonality" fill="#9b59b6" name="تأثير الموسمية (%)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* التوقعات حسب نوع الخدمة */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target size={20} />
            التوقعات حسب نوع الخدمة
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {typeChartData.map((type, idx) => (
              <div key={idx} className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
                <h3 className="font-semibold text-gray-900 mb-2">{type.name}</h3>
                <div className="text-2xl font-bold text-blue-600 mb-2">
                  ${isNaN(type.total) ? '0' : type.total.toLocaleString()}
                </div>
                <div className="text-xs text-gray-600">
                  متوسط شهري: ${isNaN(type.total / monthsAhead) ? '0' : (type.total / monthsAhead).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* التوقعات حسب الطبيب (أفضل 5) */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar size={20} />
            أفضل 5 أطباء من حيث التوقعات
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={doctorChartData.map(d => ({
              name: d.name,
              revenue: isNaN(d.total) ? 0 : d.total,
            })).filter(d => d.revenue > 0)}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="revenue" fill="#3b82f6" name="الإيرادات المتوقعة" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* ملاحظات مهمة */}
      <Card className="bg-blue-50 border-l-4 border-l-blue-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-900">
            <AlertCircle size={20} />
            ملاحظات مهمة حول التوقعات
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-blue-800 space-y-2">
          <p>• التوقعات تستند إلى المتوسط المتحرك وتحليل الاتجاهات من البيانات التاريخية</p>
          <p>• مستوى الثقة ينخفض كلما زاد الفترة الزمنية للتوقعات</p>
          <p>• التوقعات قد لا تأخذ في الاعتبار العوامل الخارجية غير المتوقعة</p>
          <p>• يُنصح بمراجعة التوقعات شهرياً وتحديثها بناءً على البيانات الجديدة</p>
        </CardContent>
      </Card>
    </div>
  );
}
