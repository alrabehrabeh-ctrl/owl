import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { isAuthenticated, loading, user } = useAuth();
  const [location, setLocation] = useLocation() as [string, (path: string) => void];

  useEffect(() => {
    // إذا كان المستخدم مصرح له، قم بإعادة التوجيه إلى صفحة الأطباء
    if (isAuthenticated && !loading) {
      setLocation("/dashboard");
    }
  }, [isAuthenticated, loading, setLocation]);

  // إذا كان المستخدم مصرح له, عرض رسالة ترحيب شخصية
  if (isAuthenticated && !loading) {
    const userName = user?.name || "المستخدم";
    // مسح بيانات المستخدم من localStorage عند الدخول
    localStorage.removeItem("manus-runtime-user-info");
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="max-w-2xl w-full">
          <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-8 py-16 text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-white bg-opacity-20 rounded-full mb-6">
                <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                </svg>
              </div>
              <h1 className="text-4xl font-bold text-white mb-2">أهلا بك {userName}</h1>
              <p className="text-blue-100 text-lg">رحبا بعودتك إلى مخبر النجاح</p>
            </div>
            <div className="px-8 py-8 text-center">
              <p className="text-gray-600 mb-8 text-lg">جاري تحميل لوحة التحكم الخاصة بك...</p>
              <div className="flex justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-green-50 flex items-center justify-center p-4">
        {/* خلفية ديكورية */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-100 rounded-full mix-blend-multiply filter blur-3xl opacity-20"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-green-100 rounded-full mix-blend-multiply filter blur-3xl opacity-20"></div>
        </div>

        {/* المحتوى الرئيسي */}
        <div className="relative z-10 max-w-2xl w-full">
          {/* البطاقة الرئيسية */}
          <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
            {/* رأس البطاقة بتدرج */}
            <div className="bg-gradient-to-r from-[#1e5a96] to-[#2ecc71] px-8 py-12 text-center">
              <img src="/logo.png" alt="مخبر النجاح" className="h-32 mx-auto mb-4 object-contain" />
              <h1 className="text-4xl font-bold text-white mb-2">مخبر النجاح</h1>
              <p className="text-blue-100 text-lg font-medium">نظام إدارة وحسابات متكامل</p>
            </div>

            {/* محتوى البطاقة */}
            <div className="px-8 py-10">
              <p className="text-center text-gray-700 text-lg mb-2 font-medium">للتعويضات السنية</p>
              <p className="text-center text-gray-500 mb-8">نظام احترافي مصمم خصيصاً لإدارة عيادات وملابس طب الأسنان</p>

              {/* المميزات */}
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-blue-50 rounded-lg p-4 text-center border border-blue-100 hover:shadow-md transition-shadow">
                  <div className="text-3xl mb-2">👨‍⚕️</div>
                  <p className="text-sm text-gray-700 font-medium">إدارة الأطباء</p>
                </div>
                <div className="bg-green-50 rounded-lg p-4 text-center border border-green-100 hover:shadow-md transition-shadow">
                  <div className="text-3xl mb-2">📋</div>
                  <p className="text-sm text-gray-700 font-medium">إدارة الأعمال</p>
                </div>
                <div className="bg-blue-50 rounded-lg p-4 text-center border border-blue-100 hover:shadow-md transition-shadow">
                  <div className="text-3xl mb-2">💰</div>
                  <p className="text-sm text-gray-700 font-medium">الفواتير والدفعات</p>
                </div>
                <div className="bg-green-50 rounded-lg p-4 text-center border border-green-100 hover:shadow-md transition-shadow">
                  <div className="text-3xl mb-2">📊</div>
                  <p className="text-sm text-gray-700 font-medium">التقارير والإحصائيات</p>
                </div>
              </div>

              {/* رسالة الترحيب */}
              <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-lg p-4 mb-8 border border-blue-100">
                <p className="text-center text-gray-700">
                  <span className="font-semibold">مرحباً بك!</span> يرجى تسجيل الدخول للوصول إلى جميع الميزات
                </p>
              </div>

              {/* زر تسجيل الدخول */}
              <Button 
                onClick={() => window.location.href = getLoginUrl()}
                className="w-full bg-gradient-to-r from-[#1e5a96] to-[#2ecc71] hover:from-[#1a4a7a] hover:to-[#27ae60] text-white font-bold py-3 rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105"
              >
                <span className="text-lg">🔐 تسجيل الدخول</span>
              </Button>
            </div>

            {/* تذييل البطاقة */}
            <div className="bg-gray-50 px-8 py-4 text-center border-t border-gray-200">
              <p className="text-sm text-gray-600">
                <span className="font-semibold">الإصدار 3.5</span> - فبراير 2026
              </p>
            </div>
          </div>

          {/* معلومات إضافية */}
          <div className="mt-8 text-center text-gray-600 text-sm">
            <p>💡 نظام آمن وموثوق مع دعم كامل للعمليات المالية</p>
          </div>
        </div>
      </div>
    );
  }

  // إذا كان المستخدم مصرح له لكن لم يكن على الصفحة الرئيسية، عرض صفحة فارغة
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <p className="text-gray-600">جاري التحميل...</p>
      </div>
    </div>
  );
}
