import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, CheckCircle, Upload, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import * as XLSX from "xlsx";

interface WorkRow {
  doctorName: string;
  patientName?: string;
  description?: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  status: "pending" | "in_progress" | "completed" | "delivered";
  receptionDate: Date;
  dueDate: Date;
  toothNumbers?: string;
  notes?: string;
}

export function ImportWorksPage() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<WorkRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string>("");

  const importMutation = trpc.import.importWorks.useMutation();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setError("");
    setPreview([]);
    setResult(null);

    try {
      const data = await selectedFile.arrayBuffer();
      const workbook = XLSX.read(data, { type: "array" });
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      
      // قراءة البيانات كمصفوفة بدلاً من JSON للتحكم الدقيق في الأعمدة
      const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];

      const works: WorkRow[] = [];
      const errors: string[] = [];

      // معالجة التواريخ - إذا كانت فارغة، استخدم تاريخ اليوم
      const parseDate = (dateValue: any): Date => {
        if (!dateValue || dateValue === "" || dateValue === null || dateValue === "-") {
          return new Date();
        }
        
        // إذا كانت القيمة رقمية (Excel serial date)
        if (typeof dateValue === "number") {
          // Excel serial date: 1 = 1900-01-01
          const excelDate = new Date((dateValue - 25569) * 86400 * 1000);
          return isNaN(excelDate.getTime()) ? new Date() : excelDate;
        }
        
        // إذا كانت نصية بصيغة YYYY/MM/DD أو YYYY-MM-DD
        if (typeof dateValue === "string") {
          const parsed = new Date(dateValue);
          return isNaN(parsed.getTime()) ? new Date() : parsed;
        }
        
        return new Date();
      };

      // تخطي صف الرأس (الصف الأول)
      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        
        // تخطي الصفوف الفارغة
        if (!row || row.length === 0 || !row[0]) {
          break;
        }

        try {
          // قراءة الأعمدة بالترتيب الصحيح:
          // 0: رقم العمل (لا نحتاجه)
          // 1: اسم الطبيب
          // 2: اسم المريض
          // 3: نوع العمل / الوصف
          // 4: أرقام الأسنان
          // 5: الكمية
          // 6: السعر
          // 7: السعر الإجمالي
          // 8: الحالة
          // 9: تاريخ الاستلام
          // 10: تاريخ التسليم
          // 11: الملاحظات

          const doctorName = String(row[1] || "").trim();
          const patientName = String(row[2] || "").trim();
          const description = String(row[3] || "").trim();
          const toothNumbers = String(row[4] || "").trim();
          const quantity = Number(row[5]) || 1;
          const unitPrice = Number(row[6]) || 0;
          const totalPrice = Number(row[7]) || 0;
          const status = String(row[8] || "pending").toLowerCase().trim();
          const receptionDate = parseDate(row[9]);
          const dueDate = parseDate(row[10]);
          const notes = String(row[11] || "").trim();

          // التحقق من البيانات المطلوبة
          if (!doctorName) {
            errors.push(`الصف ${i + 1}: اسم الطبيب مطلوب`);
            continue;
          }
          if (totalPrice <= 0) {
            errors.push(`الصف ${i + 1}: السعر الإجمالي مطلوب وأكبر من صفر`);
            continue;
          }

          // تحويل حالة العمل إلى القيم المقبولة
          let normalizedStatus: "pending" | "in_progress" | "completed" | "delivered" = "pending";
          if (status === "delivered" || status === "مكتمل" || status === "تم التسليم") {
            normalizedStatus = "delivered";
          } else if (status === "in_progress" || status === "قيد التنفيذ") {
            normalizedStatus = "in_progress";
          } else if (status === "completed" || status === "مكتمل") {
            normalizedStatus = "completed";
          }

          const work: WorkRow = {
            doctorName,
            patientName,
            description,
            quantity,
            unitPrice,
            totalPrice,
            status: normalizedStatus,
            receptionDate,
            dueDate,
            toothNumbers,
            notes,
          };

          works.push(work);
        } catch (err) {
          errors.push(`الصف ${i + 1}: خطأ في معالجة البيانات - ${err}`);
        }
      }

      if (errors.length > 0) {
        setError(errors.join("\n"));
      }

      setPreview(works);
      setFile(selectedFile);
    } catch (err) {
      setError("خطأ في قراءة الملف. تأكد من أن الملف هو ملف Excel صحيح.");
    }
  };

  const handleImport = async () => {
    if (preview.length === 0) {
      setError("لا توجد بيانات للاستيراد");
      return;
    }

    setLoading(true);
    try {
      const result = await importMutation.mutateAsync({
        works: preview,
        deleteExisting: false,
      });

      setResult(result);
      setPreview([]);
      setFile(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطأ في الاستيراد");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <CardTitle className="mb-8">استيراد الأعمال من ملف Excel</CardTitle>

        {/* خطوة 1: رفع الملف */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">الخطوة 1: رفع ملف Excel</CardTitle>
            <CardDescription>
              اختر ملف Excel يحتوي على بيانات الأعمال بالترتيب التالي:
              رقم العمل، اسم الطبيب، اسم المريض، نوع العمل، أرقام الأسنان، الكمية، السعر، السعر الإجمالي، الحالة، تاريخ الاستلام، تاريخ التسليم، الملاحظات
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileChange}
                className="flex-1"
              />
              {file && <span className="text-sm text-green-600">✓ تم اختيار الملف</span>}
            </div>
          </CardContent>
        </Card>

        {/* الأخطاء */}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="whitespace-pre-wrap text-sm">{error}</AlertDescription>
          </Alert>
        )}

        {/* معاينة البيانات */}
        {preview.length > 0 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">الخطوة 2: معاينة البيانات</CardTitle>
              <CardDescription>
                تم العثور على {preview.length} عمل. تحقق من البيانات قبل الاستيراد.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-right p-2">اسم الطبيب</th>
                      <th className="text-right p-2">المريض</th>
                      <th className="text-right p-2">نوع العمل</th>
                      <th className="text-right p-2">السعر</th>
                      <th className="text-right p-2">التاريخ</th>
                      <th className="text-right p-2">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.slice(0, 10).map((work, idx) => (
                      <tr key={idx} className="border-b">
                        <td className="p-2">{work.doctorName}</td>
                        <td className="p-2">{work.patientName || "-"}</td>
                        <td className="p-2 truncate">{work.description || "-"}</td>
                        <td className="p-2">${work.totalPrice.toFixed(2)}</td>
                        <td className="p-2 text-xs">{work.receptionDate.toLocaleDateString("ar-SA")}</td>
                        <td className="p-2">{work.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {preview.length > 10 && (
                  <p className="text-sm text-gray-500 mt-2">
                    ... و {preview.length - 10} عمل آخر
                  </p>
                )}
              </div>

              <div className="mt-6 flex gap-4">
                <Button
                  onClick={handleImport}
                  disabled={loading}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      جاري الاستيراد...
                    </>
                  ) : (
                    <>
                      <Upload className="h-4 w-4 mr-2" />
                      استيراد الأعمال
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* نتيجة الاستيراد */}
        {result && (
          <Card className="bg-green-50 border-green-200">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2 text-green-700">
                <CheckCircle className="h-5 w-5" />
                تم الاستيراد بنجاح
              </CardTitle>
            </CardHeader>
            <CardContent className="text-green-700">
              <p>تم استيراد {result.importedCount || preview.length} عمل بنجاح</p>
              {result.createdDoctors && <p>تم إنشاء {result.createdDoctors} طبيب جديد</p>}
              {result.createdWorkTypes && <p>تم إنشاء {result.createdWorkTypes} نوع عمل جديد</p>}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
