import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function InitializationPage() {
  const [isInitialized, setIsInitialized] = useState(false);

  const statusQuery = trpc.init.checkRoleSettingsStatus.useQuery(undefined, {
    staleTime: 1000 * 60 * 5,
    gcTime: 1000 * 60 * 10,
  });
  const initMutation = trpc.init.initializeRoleSettings.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      setIsInitialized(true);
      statusQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "فشل في تهيئة البيانات");
    },
  });

  useEffect(() => {
    if (statusQuery.data?.initialized) {
      setIsInitialized(true);
    }
  }, [statusQuery.data]);

  const handleInitialize = () => {
    if (confirm("هل أنت متأكد من تهيئة جدول roleSettings؟ سيتم حذف البيانات القديمة.")) {
      initMutation.mutate();
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">تهيئة النظام</h1>
        <p className="text-muted-foreground mt-2">
          تهيئة البيانات الافتراضية للنظام
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {isInitialized ? (
              <>
                <CheckCircle className="w-5 h-5 text-green-600" />
                حالة النظام
              </>
            ) : (
              <>
                <AlertCircle className="w-5 h-5 text-yellow-600" />
                حالة النظام
              </>
            )}
          </CardTitle>
          <CardDescription>
            {isInitialized ? "تم تهيئة النظام بنجاح" : "النظام يحتاج إلى تهيئة"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {statusQuery.isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin" />
            </div>
          ) : (
            <>
              <div>
                <p className="text-sm font-medium mb-2">حالة جدول roleSettings:</p>
                <Badge variant={isInitialized ? "default" : "destructive"}>
                  {isInitialized ? "مهيأ" : "غير مهيأ"}
                </Badge>
              </div>

              {statusQuery.data && (
                <>
                  <div>
                    <p className="text-sm font-medium mb-2">عدد الأدوار:</p>
                    <p className="text-lg font-bold">{statusQuery.data.count}</p>
                  </div>

                  {statusQuery.data.roles && statusQuery.data.roles.length > 0 && (
                    <div>
                      <p className="text-sm font-medium mb-2">الأدوار المهيأة:</p>
                      <div className="flex flex-wrap gap-2">
                        {statusQuery.data.roles.map((role) => (
                          <Badge key={role} variant="outline">
                            {role}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}

              {!isInitialized && (
                <Button
                  onClick={handleInitialize}
                  disabled={initMutation.isPending}
                  className="w-full"
                >
                  {initMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      جاري التهيئة...
                    </>
                  ) : (
                    "تهيئة البيانات الافتراضية"
                  )}
                </Button>
              )}
            </>
          )}
        </CardContent>
      </Card>

      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-base">معلومات التهيئة</CardTitle>
        </CardHeader>
        <CardContent className="text-sm space-y-2">
          <p>
            • تهيئة جدول roleSettings بالأدوار الافتراضية
          </p>
          <p>
            • الأدوار المهيأة: مستخدم عادي، موظف، مدير، مسؤول
          </p>
          <p>
            • كلمات المرور الافتراضية:
          </p>
          <ul className="list-disc list-inside ml-2 space-y-1">
            <li>مسؤول (Admin): admin</li>
            <li>مدير (Manager): 1985</li>
            <li>موظف (Staff): 0000</li>
            <li>مستخدم عادي (User): 0000</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
