import { useState, useMemo, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Edit2, Trash2, Eye, Download, Printer, Filter, RotateCcw, FileText, DollarSign, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import jsPDF from "jspdf";
import { useCallback as useCallbackHook } from "react";
import { exportInvoiceToPDFArabic, printInvoiceToPDFArabic } from "@/utils/exportInvoicePDFArabic";

interface PaymentFormData {
  amount: string;
  paymentMethod: "cash" | "check" | "bank_transfer" | "credit_card" | "other";
  paymentDate: string;
  referenceNumber?: string;
  notes?: string;
}

const LAB_LOGO = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338947951/ZBdmbJuEYmdRfyab.png";

export default function InvoicesListPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showPreviewDialog, setShowPreviewDialog] = useState(false);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<number | null>(null);
  const [previewInvoiceId, setPreviewInvoiceId] = useState<number | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterDoctor, setFilterDoctor] = useState<string>("all");
  const [filterDateFrom, setFilterDateFrom] = useState<string>("");
  const [filterDateTo, setFilterDateTo] = useState<string>("");
  const [sortBy, setSortBy] = useState<"date" | "amount" | "doctor">("date");
  const [paymentForm, setPaymentForm] = useState<PaymentFormData>({
    amount: "",
    paymentMethod: "cash",
    paymentDate: new Date().toISOString().split("T")[0],
  });

  const { data: invoices = [], refetch: refetchInvoices } = trpc.invoices.list.useQuery();
  const { data: payments = [] } = trpc.payments.list.useQuery();
  const { data: doctors = [] } = trpc.doctors.list.useQuery();
  const utils = trpc.useUtils();

  const createPaymentMutation = trpc.payments.create.useMutation({
    onSuccess: () => {
      toast.success("تم تسجيل الدفعة بنجاح");
      setShowPaymentDialog(false);
      setPaymentForm({
        amount: "",
        paymentMethod: "cash",
        paymentDate: new Date().toISOString().split("T")[0],
      });
      setSelectedInvoiceId(null);
      refetchInvoices();
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء تسجيل الدفعة");
    },
  });

  const getDoctorName = (doctorId: number) => {
    return doctors.find((d: any) => d.id === doctorId)?.name || "غير معروف";
  };

  const getInvoicePayments = (invoiceId: number) => {
    return payments.filter((p: any) => p.invoiceId === invoiceId);
  };

  const getInvoiceStatus = (status: string) => {
    const statusMap: Record<string, { label: string; color: string; bgColor: string }> = {
      sent: { label: "مرسلة", color: "bg-blue-100 text-blue-800", bgColor: "bg-blue-50" },
      partial: { label: "مدفوعة جزئياً", color: "bg-yellow-100 text-yellow-800", bgColor: "bg-yellow-50" },
      paid: { label: "مدفوعة بالكامل", color: "bg-green-100 text-green-800", bgColor: "bg-green-50" },
      overdue: { label: "متأخرة", color: "bg-red-100 text-red-800", bgColor: "bg-red-50" },
    };
    return statusMap[status] || { label: status, color: "bg-gray-100 text-gray-800", bgColor: "bg-gray-50" };
  };

  const handlePrintInvoice = useCallbackHook(async (invoiceId: number) => {
    const invoice = invoices.find((i: any) => i.id === invoiceId);
    if (invoice) {
      try {
        const items = await utils.invoices.getItems.fetch({ invoiceId: invoice.id });
        await printInvoiceToPDFArabic(invoice, doctors, items || []);
      } catch (error) {
        console.error("Error fetching items:", error);
        toast.error("فشل جلب بيانات الفاتورة");
      }
    }
  }, [invoices, doctors, utils]);

  const handleExportInvoice = useCallbackHook(async (invoiceId: number) => {
    const invoice = invoices.find((i: any) => i.id === invoiceId);
    if (invoice) {
      try {
        const items = await utils.invoices.getItems.fetch({ invoiceId: invoice.id });
        await exportInvoiceToPDFArabic(invoice, doctors, items || []);
      } catch (error) {
        console.error("Error fetching items:", error);
        toast.error("فشل جلب بيانات الفاتورة");
      }
    }
  }, [invoices, doctors, utils]);

  // حساب الإحصائيات
  const statistics = useMemo(() => {
    const total = invoices.reduce((sum: number, inv: any) => sum + parseFloat(inv.total || "0"), 0);
    const paid = invoices.reduce((sum: number, inv: any) => sum + parseFloat(inv.paidAmount || "0"), 0);
    const remaining = total - paid;
    return {
      total: total.toFixed(2),
      paid: paid.toFixed(2),
      remaining: remaining.toFixed(2),
      count: invoices.length,
    };
  }, [invoices]);

  // تطبيق الفلاتر والترتيب
  const filteredInvoices = useMemo(() => {
    let filtered = invoices.filter((invoice: any) => {
      const doctorName = getDoctorName(invoice.doctorId);
      const invoiceNumber = invoice.invoiceNumber || "";
      const searchMatch =
        doctorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase());

      if (!searchMatch) return false;

      // فلتر الحالة
      if (filterStatus !== "all" && invoice.status !== filterStatus) return false;

      // فلتر الطبيب
      if (filterDoctor !== "all" && invoice.doctorId !== parseInt(filterDoctor)) return false;

      // فلتر التاريخ
      if (filterDateFrom) {
        const invoiceDate = new Date(invoice.invoiceDate);
        const fromDate = new Date(filterDateFrom);
        if (invoiceDate < fromDate) return false;
      }

      if (filterDateTo) {
        const invoiceDate = new Date(invoice.invoiceDate);
        const toDate = new Date(filterDateTo);
        if (invoiceDate > toDate) return false;
      }

      return true;
    });

    // تطبيق الترتيب
    filtered.sort((a: any, b: any) => {
      switch (sortBy) {
        case "amount":
          return parseFloat(b.total || "0") - parseFloat(a.total || "0");
        case "doctor":
          return getDoctorName(a.doctorId).localeCompare(getDoctorName(b.doctorId), "ar");
        case "date":
        default:
          return new Date(b.invoiceDate).getTime() - new Date(a.invoiceDate).getTime();
      }
    });

    return filtered;
  }, [invoices, searchTerm, filterStatus, filterDoctor, filterDateFrom, filterDateTo, sortBy]);

  const handleAddPayment = async () => {
    if (!selectedInvoiceId) {
      toast.error("يرجى اختيار فاتورة");
      return;
    }

    if (!paymentForm.amount || parseFloat(paymentForm.amount) <= 0) {
      toast.error("يرجى إدخال مبلغ صحيح");
      return;
    }

    const selectedInvoice = invoices.find((i: any) => i.id === selectedInvoiceId);
    if (!selectedInvoice) {
      toast.error("الفاتورة غير موجودة");
      return;
    }

    const remainingAmount = parseFloat(selectedInvoice.remainingAmount || "0");
    if (parseFloat(paymentForm.amount) > remainingAmount) {
      toast.error(`المبلغ المدفوع لا يمكن أن يتجاوز المبلغ المتبقي (${remainingAmount.toFixed(2)})`);
      return;
    }

    await createPaymentMutation.mutateAsync({
      invoiceId: selectedInvoiceId,
      doctorId: selectedInvoice.doctorId,
      amount: paymentForm.amount,
      paymentMethod: paymentForm.paymentMethod,
      paymentDate: new Date(paymentForm.paymentDate),
      referenceNumber: paymentForm.referenceNumber,
      notes: paymentForm.notes,
    });
  };

  const resetFilters = () => {
    setSearchTerm("");
    setFilterStatus("all");
    setFilterDoctor("all");
    setFilterDateFrom("");
    setFilterDateTo("");
    setSortBy("date");
  };

  return (
    <div className="space-y-6">
      {/* رأس الصفحة */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">الفواتير</h1>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 ml-2" />
          فاتورة جديدة
        </Button>
      </div>

      {/* لوحة الملخص الإحصائية */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">إجمالي الفواتير</p>
              <p className="text-2xl font-bold text-blue-700">{statistics.count}</p>
            </div>
            <FileText className="w-10 h-10 text-blue-400 opacity-50" />
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">المبلغ الإجمالي</p>
              <p className="text-2xl font-bold text-green-700">${statistics.total}</p>
            </div>
            <DollarSign className="w-10 h-10 text-green-400 opacity-50" />
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-emerald-50 to-emerald-100 border-emerald-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">المبلغ المدفوع</p>
              <p className="text-2xl font-bold text-emerald-700">${statistics.paid}</p>
            </div>
            <TrendingUp className="w-10 h-10 text-emerald-400 opacity-50" />
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-red-50 to-red-100 border-red-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">المبلغ المتبقي</p>
              <p className="text-2xl font-bold text-red-700">${statistics.remaining}</p>
            </div>
            <FileText className="w-10 h-10 text-red-400 opacity-50" />
          </div>
        </Card>
      </div>

      {/* شريط الفلاتر والبحث */}
      <Card className="p-6">
        <div className="space-y-4">
          {/* شريط البحث والأزرار */}
          <div className="flex gap-2 flex-wrap">
            <Input
              placeholder="ابحث عن طبيب أو رقم فاتورة..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 min-w-[200px]"
            />
            <Button
              variant={showFilters ? "default" : "outline"}
              onClick={() => setShowFilters(!showFilters)}
              className="gap-2"
            >
              <Filter className="w-4 h-4" />
              فلاتر
            </Button>
            <Button
              variant="outline"
              onClick={resetFilters}
              className="gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              إعادة تعيين
            </Button>
          </div>

          {/* الفلاتر المتقدمة */}
          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t">
              <div>
                <label className="block text-sm font-medium mb-2">الحالة</label>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="w-full border rounded px-3 py-2 text-sm"
                >
                  <option value="all">جميع الحالات</option>
                  <option value="sent">مرسلة</option>
                  <option value="partial">مدفوعة جزئياً</option>
                  <option value="paid">مدفوعة بالكامل</option>
                  <option value="overdue">متأخرة</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">الطبيب</label>
                <select
                  value={filterDoctor}
                  onChange={(e) => setFilterDoctor(e.target.value)}
                  className="w-full border rounded px-3 py-2 text-sm"
                >
                  <option value="all">جميع الأطباء</option>
                  {doctors.map((doctor: any) => (
                    <option key={doctor.id} value={doctor.id}>
                      {doctor.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">من التاريخ</label>
                <Input
                  type="date"
                  value={filterDateFrom}
                  onChange={(e) => setFilterDateFrom(e.target.value)}
                  className="text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">إلى التاريخ</label>
                <Input
                  type="date"
                  value={filterDateTo}
                  onChange={(e) => setFilterDateTo(e.target.value)}
                  className="text-sm"
                />
              </div>
            </div>
          )}

          {/* خيارات الترتيب */}
          <div className="flex gap-2 flex-wrap">
            <span className="text-sm font-medium self-center">ترتيب حسب:</span>
            <Button
              variant={sortBy === "date" ? "default" : "outline"}
              size="sm"
              onClick={() => setSortBy("date")}
            >
              التاريخ
            </Button>
            <Button
              variant={sortBy === "amount" ? "default" : "outline"}
              size="sm"
              onClick={() => setSortBy("amount")}
            >
              المبلغ
            </Button>
            <Button
              variant={sortBy === "doctor" ? "default" : "outline"}
              size="sm"
              onClick={() => setSortBy("doctor")}
            >
              الطبيب
            </Button>
          </div>

          {/* عرض عدد النتائج */}
          <div className="text-sm text-gray-600">
            عدد النتائج: <span className="font-bold text-gray-800">{filteredInvoices.length}</span> من <span className="font-bold text-gray-800">{invoices.length}</span>
          </div>
        </div>
      </Card>

      {/* جدول الفواتير */}
      <Card className="p-6">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gradient-to-r from-blue-50 to-blue-100 border-b-2 border-blue-200">
                <th className="border p-3 text-right font-semibold text-blue-900">رقم الفاتورة</th>
                <th className="border p-3 text-right font-semibold text-blue-900">الطبيب</th>
                <th className="border p-3 text-right font-semibold text-blue-900">الإجمالي</th>
                <th className="border p-3 text-right font-semibold text-blue-900">المدفوع</th>
                <th className="border p-3 text-right font-semibold text-blue-900">المتبقي</th>
                <th className="border p-3 text-right font-semibold text-blue-900">الحالة</th>
                <th className="border p-3 text-right font-semibold text-blue-900">التاريخ</th>
                <th className="border p-3 text-right font-semibold text-blue-900">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filteredInvoices.map((invoice: any, index: number) => {
                const statusInfo = getInvoiceStatus(invoice.status);
                return (
                  <tr
                    key={invoice.id}
                    className={`border-b hover:${statusInfo.bgColor} transition-colors ${
                      index % 2 === 0 ? "bg-white" : "bg-gray-50"
                    }`}
                  >
                    <td className="border p-3 font-mono text-sm font-semibold">{invoice.invoiceNumber}</td>
                    <td className="border p-3">{getDoctorName(invoice.doctorId)}</td>
                    <td className="border p-3 font-bold text-green-600">${parseFloat(invoice.total || "0").toFixed(2)}</td>
                    <td className="border p-3 font-bold text-emerald-600">
                      ${parseFloat(invoice.paidAmount || "0").toFixed(2)}
                    </td>
                    <td className="border p-3 font-bold text-red-600">
                      ${parseFloat(invoice.remainingAmount || "0").toFixed(2)}
                    </td>
                    <td className="border p-3">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusInfo.color}`}>
                        {statusInfo.label}
                      </span>
                    </td>
                    <td className="border p-3 text-sm">
                      {new Date(invoice.invoiceDate).toLocaleDateString("ar-SA")}
                    </td>
                    <td className="border p-3">
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          title="إضافة دفعة"
                          onClick={() => {
                            setSelectedInvoiceId(invoice.id);
                            setShowPaymentDialog(true);
                          }}
                          disabled={invoice.status === "paid"}
                          className="p-2"
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          title="معاينة"
                          onClick={() => {
                            setPreviewInvoiceId(invoice.id);
                            setShowPreviewDialog(true);
                          }}
                          className="p-2"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          title="طباعة"
                          onClick={() => invoice.id && handlePrintInvoice(invoice.id)}
                          className="p-2"
                        >
                          <Printer className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          title="تصدير PDF"
                          onClick={() => invoice.id && handleExportInvoice(invoice.id)}
                          className="p-2"
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredInvoices.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <FileText className="w-16 h-16 mx-auto mb-4 opacity-20" />
            <p className="text-lg">لا توجد فواتير</p>
          </div>
        )}

        {/* صف الملخص */}
        {filteredInvoices.length > 0 && (
          <div className="mt-6 pt-6 border-t-2 border-blue-200">
            <div className="grid grid-cols-4 gap-4 text-right">
              <div>
                <p className="text-sm text-gray-600">الإجمالي</p>
                <p className="text-xl font-bold text-green-600">
                  ${filteredInvoices.reduce((sum: number, inv: any) => sum + parseFloat(inv.total || "0"), 0).toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600">المدفوع</p>
                <p className="text-xl font-bold text-emerald-600">
                  ${filteredInvoices.reduce((sum: number, inv: any) => sum + parseFloat(inv.paidAmount || "0"), 0).toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600">المتبقي</p>
                <p className="text-xl font-bold text-red-600">
                  ${filteredInvoices.reduce((sum: number, inv: any) => sum + parseFloat(inv.remainingAmount || "0"), 0).toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600">عدد الفواتير</p>
                <p className="text-xl font-bold text-blue-600">{filteredInvoices.length}</p>
              </div>
            </div>
          </div>
        )}
      </Card>

      {/* Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>تسجيل دفعة جديدة</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {selectedInvoiceId && (
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <p className="text-sm text-gray-600">الفاتورة: {invoices.find((i: any) => i.id === selectedInvoiceId)?.invoiceNumber}</p>
                <p className="text-sm text-gray-600">
                  المبلغ المتبقي: ${parseFloat(invoices.find((i: any) => i.id === selectedInvoiceId)?.remainingAmount || "0").toFixed(2)}
                </p>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium mb-2">المبلغ *</label>
              <Input
                type="number"
                placeholder="0.00"
                value={paymentForm.amount}
                onChange={(e) => setPaymentForm({ ...paymentForm, amount: e.target.value })}
                step="0.01"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">طريقة الدفع *</label>
              <select
                value={paymentForm.paymentMethod}
                onChange={(e) =>
                  setPaymentForm({
                    ...paymentForm,
                    paymentMethod: e.target.value as PaymentFormData["paymentMethod"],
                  })
                }
                className="w-full border rounded px-3 py-2"
              >
                <option value="cash">نقداً</option>
                <option value="check">شيك</option>
                <option value="bank_transfer">تحويل بنكي</option>
                <option value="credit_card">بطاقة ائتمان</option>
                <option value="other">أخرى</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">تاريخ الدفع *</label>
              <Input
                type="date"
                value={paymentForm.paymentDate}
                onChange={(e) => setPaymentForm({ ...paymentForm, paymentDate: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">رقم المرجع</label>
              <Input
                placeholder="رقم الشيك أو رقم التحويل..."
                value={paymentForm.referenceNumber || ""}
                onChange={(e) => setPaymentForm({ ...paymentForm, referenceNumber: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">ملاحظات</label>
              <textarea
                placeholder="ملاحظات إضافية..."
                value={paymentForm.notes || ""}
                onChange={(e) => setPaymentForm({ ...paymentForm, notes: e.target.value })}
                className="w-full border rounded px-3 py-2 resize-none"
                rows={3}
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleAddPayment}
                disabled={createPaymentMutation.isPending}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                {createPaymentMutation.isPending ? "جاري التسجيل..." : "تسجيل الدفعة"}
              </Button>
              <Button
                onClick={() => setShowPaymentDialog(false)}
                variant="outline"
                className="flex-1"
              >
                إلغاء
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={showPreviewDialog} onOpenChange={setShowPreviewDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader className="flex justify-between items-center">
            <DialogTitle>معاينة الفاتورة</DialogTitle>
            {previewInvoiceId && (
              <div className="flex gap-2">
                <Button
                  onClick={() => previewInvoiceId && handlePrintInvoice(previewInvoiceId)}
                  className="bg-green-600 hover:bg-green-700 text-white"
                  size="sm"
                >
                  <Printer className="w-4 h-4 ml-2" />
                  طباعة
                </Button>
                <Button
                  onClick={() => previewInvoiceId && handleExportInvoice(previewInvoiceId)}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  size="sm"
                >
                  <Download className="w-4 h-4 ml-2" />
                  تصدير PDF
                </Button>
              </div>
            )}
          </DialogHeader>
          {previewInvoiceId && (() => {
            const invoice = invoices.find((i: any) => i.id === previewInvoiceId);
            if (!invoice) return <div>الفاتورة غير موجودة</div>;

            const doctor = doctors.find((d: any) => d.id === invoice.doctorId);

            return (
              <div className="bg-white p-6 rounded-lg border space-y-4">
                {/* رأس الفاتورة مع الشعار */}
                <div className="text-center pb-6 border-b">
                  <img src={LAB_LOGO} alt="مخبر النجاح" className="h-16 mx-auto mb-4" />
                  <h2 className="text-2xl font-bold mb-2">مخبر النجاح للتعويضات السنية</h2>
                  <p className="text-gray-600">إدارة إيناس الربيع</p>
                  <p className="text-sm text-gray-500 mt-2">رقم الفاتورة: {invoice.invoiceNumber}</p>
                </div>

                {/* معلومات الطبيب */}
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <p className="text-sm text-gray-600">الطبيب</p>
                    <p className="font-semibold">{doctor?.name || "غير معروف"}</p>
                  </div>
                  <div className="text-left">
                    <p className="text-sm text-gray-600">التاريخ</p>
                    <p className="font-semibold">{new Date(invoice.invoiceDate).toLocaleDateString("ar-SA")}</p>
                  </div>
                </div>

                {/* ملخص الدفعات */}
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">الإجمالي</p>
                      <p className="font-bold text-lg text-blue-600">${parseFloat(invoice.total || "0").toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">المدفوع</p>
                      <p className="font-bold text-lg text-green-600">${parseFloat(invoice.paidAmount || "0").toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">المتبقي</p>
                      <p className="font-bold text-lg text-red-600">${parseFloat(invoice.remainingAmount || "0").toFixed(2)}</p>
                    </div>
                  </div>
                </div>

                {/* الحالة */}
                <div className="text-center">
                  <span className={`px-4 py-2 rounded-full text-sm font-medium ${
                    invoice.status === "paid" ? "bg-green-100 text-green-800" :
                    invoice.status === "partial" ? "bg-yellow-100 text-yellow-800" :
                    invoice.status === "overdue" ? "bg-red-100 text-red-800" :
                    "bg-blue-100 text-blue-800"
                  }`}>
                    {invoice.status === "paid" ? "مدفوعة" :
                     invoice.status === "partial" ? "مدفوعة جزئياً" :
                     invoice.status === "overdue" ? "متأخرة" :
                     "مرسلة"}
                  </span>
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}
