import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Download, Eye, FileText, X, Printer } from "lucide-react";
import { toast } from "sonner";
import * as XLSX from "xlsx";

interface InvoiceData {
  doctorId: number;
  doctorName: string;
  month: number;
  year: number;
  works: any[];
  totalAmount: number;
  paidAmount?: number;
  remainingAmount?: number;
  status?: "paid" | "pending" | "partial";
}

type InvoiceStatus = "all" | "paid" | "pending" | "partial";

const LAB_NAME = "مخبر النجاح للتعويضات السنية";
const LAB_MANAGER = "إدارة إيناس الربيع";

const INVOICE_STATUS_OPTIONS: { value: InvoiceStatus; label: string }[] = [
  { value: "all", label: "جميع الحالات" },
  { value: "paid", label: "مدفوعة" },
  { value: "pending", label: "معلقة" },
  { value: "partial", label: "جزئية" },
];

export default function InvoicesPage() {
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>("");
  const [selectedMonth, setSelectedMonth] = useState<string>(new Date().toISOString().slice(0, 7));
  const [invoiceStatus, setInvoiceStatus] = useState<InvoiceStatus>("all");
  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");
  const [showPreview, setShowPreview] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [isCreatingInvoices, setIsCreatingInvoices] = useState(false);

  const { data: doctors = [] } = trpc.doctors.list.useQuery();
  const createAutoInvoicesMutation = trpc.invoices.createAutoInvoices.useMutation();

  const [year, month] = selectedMonth.split("-").map(Number);

  // جلب الأعمال الشهرية للطبيب مع تفاصيل نوع العمل والملاحظات
  const { data: monthlyWorks = [] } = trpc.monthlyInvoices.getByDoctorAndDate.useQuery(
    {
      doctorId: selectedDoctorId ? parseInt(selectedDoctorId) : 0,
      year,
      month,
    },
    {
      enabled: !!selectedDoctorId,
    }
  );

  // جلب تفاصيل الدفعات والمتبقي
  const { data: paymentSummary } = trpc.invoicePayments.getDoctorMonthlySummary.useQuery(
    {
      doctorId: selectedDoctorId ? parseInt(selectedDoctorId) : 0,
      year,
      month,
    },
    {
      enabled: !!selectedDoctorId,
    }
  );

  const currentInvoice = useMemo(() => {
    if (!selectedDoctorId) return null;

    const doctorId = parseInt(selectedDoctorId);
    const doctor = doctors.find((d: any) => d.id === doctorId);

    // البيانات مصفاة بالفعل من الخادم
    let filteredWorks = monthlyWorks || [];

    // تطبيق تصفية نطاق التاريخ إذا تم تحديده
    if (startDate || endDate) {
      filteredWorks = filteredWorks.filter((work: any) => {
        const workDate = new Date(work.dueDate || work.createdAt);
        if (startDate && workDate < new Date(startDate)) return false;
        if (endDate && workDate > new Date(endDate)) return false;
        return true;
      });
    }

    if (filteredWorks.length === 0) return null;

    const totalAmount = filteredWorks.reduce((sum: number, work: any) => {
      const price = work.totalPrice || "0";
      const parsedPrice = parseFloat(String(price));
      return sum + (isNaN(parsedPrice) ? 0 : parsedPrice);
    }, 0);

    // استخدام بيانات الدفعات الفعلية من الخادم
    const paidAmountRaw = paymentSummary?.totalPaidAmount || 0;
    const remainingAmountRaw = paymentSummary?.totalRemainingAmount || totalAmount;
    
    // معالجة القيم غير الصحيحة
    const paidAmount = (() => {
      const parsed = parseFloat(String(paidAmountRaw));
      return isNaN(parsed) ? 0 : parsed;
    })();
    
    const remainingAmount = (() => {
      const parsed = parseFloat(String(remainingAmountRaw));
      return isNaN(parsed) ? totalAmount : parsed;
    })();
    
    let status: InvoiceStatus = "pending";
    if (paidAmount >= totalAmount) {
      status = "paid";
    } else if (paidAmount > 0) {
      status = "partial";
    }

    // تطبيق تصفية الحالة
    if (invoiceStatus !== "all" && status !== invoiceStatus) {
      return null;
    }

    return {
      doctorId,
      doctorName: doctor?.name || "غير معروف",
      month,
      year,
      works: filteredWorks,
      totalAmount,
      paidAmount,
      remainingAmount,
      status,
    };
  }, [selectedDoctorId, selectedMonth, monthlyWorks, doctors, year, month, invoiceStatus, startDate, endDate, paymentSummary]);

  const handleExportPDF = async () => {
    if (!currentInvoice) {
      toast.error("لا توجد أعمال لهذا الطبيب في الشهر المحدد");
      return;
    }

    try {
      const printWindow = window.open("", "_blank");
      if (!printWindow) {
        toast.error("يرجى السماح بفتح النوافذ المنبثقة");
        return;
      }

      const htmlContent = generateInvoiceHTML(currentInvoice);
      
      printWindow.document.write(`
        <!DOCTYPE html>
        <html dir="rtl">
        <head>
          <meta charset="UTF-8">
          <title>فاتورة - ${LAB_NAME}</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Arial', sans-serif; background-color: white; color: rgb(0, 0, 0); padding: 20px; }
            .invoice-container { max-width: 210mm; margin: 0 auto; background-color: white; }
            .header-section { text-align: center; margin-bottom: 30px; padding: 20px; border-bottom: 3px solid rgb(33, 150, 243); }
            .lab-logo { max-width: 200px; height: auto; margin-bottom: 15px; }
            .lab-name { font-size: 26px; font-weight: bold; color: rgb(33, 150, 243); margin: 0; }
            .lab-manager { font-size: 14px; color: rgb(102, 102, 102); margin: 5px 0; }
            .invoice-title { font-size: 20px; font-weight: bold; color: rgb(0, 0, 0); margin: 10px 0; }
            .invoice-header { margin-bottom: 20px; padding: 15px; background-color: rgb(240, 248, 255); border-radius: 5px; }
            .invoice-header p { margin: 8px 0; color: rgb(0, 0, 0); }
            .header-label { font-weight: bold; color: rgb(33, 150, 243); }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th { background-color: rgb(33, 150, 243); border: 1px solid rgb(33, 150, 243); padding: 12px; text-align: right; color: white; font-weight: bold; }
            td { border: 1px solid rgb(221, 221, 221); padding: 10px; color: rgb(0, 0, 0); }
            tr:nth-child(even) { background-color: rgb(245, 245, 245); }
            .invoice-footer { margin-top: 30px; padding: 15px; border-top: 3px solid rgb(33, 150, 243); }
            .footer-row { display: flex; justify-content: space-between; margin: 12px 0; font-weight: bold; color: rgb(0, 0, 0); font-size: 14px; }
            .total-row { font-size: 18px; color: rgb(33, 150, 243); }
            .payment-status { padding: 10px; border-radius: 5px; margin: 10px 0; }
            .payment-status.paid { background-color: rgb(200, 230, 201); color: rgb(27, 94, 32); }
            .payment-status.partial { background-color: rgb(255, 243, 224); color: rgb(230, 124, 15); }
            .payment-status.pending { background-color: rgb(229, 229, 229); color: rgb(66, 66, 66); }
            .signature-section { margin-top: 40px; display: flex; justify-content: space-between; }
            .signature-box { width: 30%; text-align: center; border-top: 1px solid rgb(0, 0, 0); padding-top: 10px; }
            @media print {
              body { padding: 0; }
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <div class="invoice-container">${htmlContent}</div>
          <div class="no-print" style="text-align: center; margin-top: 30px;">
            <button onclick="window.print()" style="padding: 12px 24px; background-color: rgb(33, 150, 243); color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; font-weight: bold;">
              طباعة / حفظ كـ PDF
            </button>
          </div>
        </body>
        </html>
      `);
      printWindow.document.close();
      
      setTimeout(() => {
        printWindow.print();
      }, 500);

      toast.success("تم فتح نافذة الطباعة");
    } catch (error) {
      console.error("Error generating PDF:", error);
      toast.error("حدث خطأ أثناء إنشاء الفاتورة");
    }
  };

  const handleExportExcel = () => {
    if (!currentInvoice) {
      toast.error("لا توجد أعمال لهذا الطبيب في الشهر المحدد");
      return;
    }

    try {
      const workbook = XLSX.utils.book_new();

      // دالة مساعدة لتحويل القيمة الرقمية بشكل آمن
      const safeParsePrice = (price: any): number => {
        const parsed = parseFloat(String(price || "0"));
        return isNaN(parsed) ? 0 : parsed;
      };

      // دالة مساعدة لتحليل JSON بشكل آمن
      const safeJsonParse = (jsonString: any): any[] => {
        try {
          if (!jsonString || jsonString === "-" || jsonString === "") return [];
          return JSON.parse(jsonString);
        } catch (e) {
          return [];
        }
      };

      const data = [
        [LAB_NAME],
        [LAB_MANAGER],
        [],
        ["فاتورة"],
        [],
        ["اسم الطبيب:", currentInvoice.doctorName],
        ["الفترة:", new Date(currentInvoice.year, currentInvoice.month - 1).toLocaleDateString("ar-SA", { month: "long", year: "numeric" })],
        ["عدد الأعمال:", currentInvoice.works.length],
        ["المبلغ الإجمالي:", Math.max(0, currentInvoice.totalAmount || 0)],
        ["المبلغ المدفوع:", Math.max(0, currentInvoice.paidAmount || 0)],
        ["المبلغ المتبقي:", Math.max(0, currentInvoice.remainingAmount || currentInvoice.totalAmount || 0)],
        ["الحالة:", currentInvoice.status === "paid" ? "مدفوعة" : currentInvoice.status === "partial" ? "جزئية" : "معلقة"],
        [],
        ["نوع العمل", "اسم المريض", "أرقام الأسنان", "الملاحظات", "التاريخ", "السعر"],
        ...currentInvoice.works.map((work: any) => {
          const toothNumbers = safeJsonParse(work.toothNumbers);
          return [
            work.workTypeName || "عمل",
            work.patientName || "-",
            toothNumbers.length > 0 ? toothNumbers.join(", ") : "-",
            work.notes || "-",
            (() => {
              try {
                const dateStr = work.dueDate || work.createdAt || work.workDate;
                if (!dateStr) return "-";
                const date = new Date(dateStr);
                if (isNaN(date.getTime())) return "-";
                return date.toLocaleDateString("ar-SA");
              } catch (e) {
                return "-";
              }
            })(),
            safeParsePrice(work.totalPrice),
          ];
        }),
        [],
        ["المجموع:", "", "", "", "", Math.max(0, currentInvoice.totalAmount || 0)],
        ["الإجمالي:", "", "", "", "", Math.max(0, currentInvoice.totalAmount || 0)],
      ];

      const worksheet = XLSX.utils.aoa_to_sheet(data);
      
      worksheet["!cols"] = [
        { wch: 20 },
        { wch: 20 },
        { wch: 20 },
        { wch: 30 },
        { wch: 15 },
        { wch: 15 },
      ];

      XLSX.utils.book_append_sheet(workbook, worksheet, "الفاتورة");

      XLSX.writeFile(
        workbook,
        `فاتورة_${currentInvoice.doctorName}_${currentInvoice.month}_${currentInvoice.year}.xlsx`
      );

      toast.success("تم تصدير الفاتورة كملف Excel بنجاح");
    } catch (error) {
      console.error("Error exporting Excel:", error);
      toast.error("حدث خطأ أثناء تصدير الفاتورة");
    }
  };

  const generateInvoiceHTML = (invoice: InvoiceData): string => {
    const monthName = new Date(invoice.year, invoice.month - 1).toLocaleDateString("ar-SA", { month: "long", year: "numeric" });
    const statusText = invoice.status === "paid" ? "مدفوعة" : invoice.status === "partial" ? "جزئية" : "معلقة";
    const statusClass = invoice.status || "pending";
    
    // دالة مساعدة لتحويل القيمة الرقمية بشكل آمن
    const safeParsePrice = (price: any): number => {
      const parsed = parseFloat(String(price || "0"));
      return isNaN(parsed) ? 0 : parsed;
    };

    // دالة مساعدة لتحليل JSON بشكل آمن
    const safeJsonParse = (jsonString: any): any[] => {
      try {
        if (!jsonString || jsonString === "-" || jsonString === "") return [];
        return JSON.parse(jsonString);
      } catch (e) {
        return [];
      }
    };

    const worksHTML = invoice.works
      .map((work: any) => {
        let workDate = "-";
        try {
          const dateStr = work.dueDate || work.createdAt || work.workDate;
          if (dateStr) {
            const date = new Date(dateStr);
            if (!isNaN(date.getTime())) {
              workDate = date.toLocaleDateString("ar-SA");
            }
          }
        } catch (e) {
          workDate = "-";
        }
        const toothNumbers = safeJsonParse(work.toothNumbers);
        const teethDisplay = toothNumbers.length > 0 ? toothNumbers.join(", ") : "-";
        const price = safeParsePrice(work.totalPrice);
        return `
          <tr>
            <td>${work.workTypeName || "عمل"}</td>
            <td>${work.patientName || "-"}</td>
            <td>${teethDisplay}</td>
            <td>${work.notes || "-"}</td>
            <td>${workDate}</td>
            <td style="text-align: left;">$${price.toFixed(2)}</td>
          </tr>
        `;
      })
      .join("");
    
    return `
      <div class="header-section">
        <img src="/logo.png" alt="مخبر النجاح" class="lab-logo" />
        <p class="lab-name">${LAB_NAME}</p>
        <p class="lab-manager">${LAB_MANAGER}</p>
        <p class="invoice-title">فاتورة</p>
      </div>
      
      <div class="invoice-header">
        <p><span class="header-label">اسم الطبيب:</span> ${invoice.doctorName}</p>
        <p><span class="header-label">الفترة:</span> ${monthName}</p>
        <p><span class="header-label">عدد الأعمال:</span> ${invoice.works.length}</p>
      </div>

      <table>
        <thead>
          <tr>
            <th>نوع العمل</th>
            <th>اسم المريض</th>
            <th>أرقام الأسنان</th>
            <th>الملاحظات</th>
            <th>التاريخ</th>
            <th>السعر</th>
          </tr>
        </thead>
        <tbody>
          ${worksHTML}
        </tbody>
      </table>
      
      <div class="invoice-footer">
        <div class="invoice-summary">
          <p><strong>المبلغ الإجمالي:</strong> $${Math.max(0, invoice.totalAmount || 0).toFixed(2)}</p>
          <p><strong>المبلغ المدفوع:</strong> $${Math.max(0, invoice.paidAmount || 0).toFixed(2)}</p>
          <p><strong>المبلغ المتبقي:</strong> $${Math.max(0, invoice.remainingAmount || invoice.totalAmount || 0).toFixed(2)}</p>
        </div>
        <div class="footer-row">
          <span>المجموع:</span>
          <span>$${Math.max(0, invoice.totalAmount || 0).toFixed(2)}</span>
        </div>
        <div class="footer-row">
          <span>المبلغ المدفوع:</span>
          <span>$${Math.max(0, invoice.paidAmount || 0).toFixed(2)}</span>
        </div>
        <div class="footer-row">
          <span>المبلغ المتبقي:</span>
          <span>$${Math.max(0, invoice.remainingAmount || invoice.totalAmount || 0).toFixed(2)}</span>
        </div>
        <div class="footer-row total-row">
          <span>الإجمالي:</span>
          <span>$${Math.max(0, invoice.totalAmount || 0).toFixed(2)}</span>
        </div>
        <div class="payment-status ${statusClass}">
          <strong>حالة الفاتورة: ${statusText}</strong>
        </div>
      </div>

      <div class="signature-section">
        <div class="signature-box">
          <p>توقيع الطبيب</p>
        </div>
        <div class="signature-box">
          <p>توقيع الإدارة</p>
        </div>
        <div class="signature-box">
          <p>التاريخ: ${new Date().toLocaleDateString("ar-SA")}</p>
        </div>
      </div>
    `;
  };

  const handleCreateAutoInvoices = async () => {
    try {
      setIsCreatingInvoices(true);
      const result = await createAutoInvoicesMutation.mutateAsync();
      toast.success(`✅ ${result.message}`);
    } catch (error) {
      console.error("Error creating invoices:", error);
      toast.error("حدث خطأ أثناء إنشاء الفواتير");
    } finally {
      setIsCreatingInvoices(false);
    }
  };

  const resetFilters = () => {
    setInvoiceStatus("all");
    setStartDate("");
    setEndDate("");
  };

  const hasActiveFilters = invoiceStatus !== "all" || startDate || endDate;

  const getStatusBadgeColor = (status?: string) => {
    switch (status) {
      case "paid":
        return "bg-green-100 text-green-800";
      case "partial":
        return "bg-yellow-100 text-yellow-800";
      case "pending":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusLabel = (status?: string) => {
    switch (status) {
      case "paid":
        return "مدفوعة";
      case "partial":
        return "جزئية";
      case "pending":
        return "معلقة";
      default:
        return "معلقة";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">الفواتير الشهرية</h1>
        <Button
          onClick={handleCreateAutoInvoices}
          disabled={isCreatingInvoices}
          className="bg-green-600 hover:bg-green-700"
        >
          {isCreatingInvoices ? "جاري الإنشاء..." : "إنشاء فواتير تلقائية"}
        </Button>
      </div>

      <Card className="p-6">
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">اختر الطبيب *</label>
              <select
                value={selectedDoctorId}
                onChange={(e) => setSelectedDoctorId(e.target.value)}
                className="w-full border rounded px-3 py-2"
              >
                <option value="">-- اختر الطبيب --</option>
                {doctors?.map((doctor: any) => (
                  <option key={doctor.id} value={doctor.id}>
                    {doctor.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">اختر الشهر *</label>
              <Input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
              />
            </div>

            <div className="flex items-end gap-2">
              <Button
                onClick={() => setShowFilters(!showFilters)}
                variant="outline"
                className="flex-1"
              >
                {hasActiveFilters ? "🔍 تصفية نشطة" : "تصفية"}
              </Button>
              <Button
                onClick={() => setShowPreview(true)}
                disabled={!currentInvoice}
                variant="outline"
                className="flex-1"
              >
                <Eye className="w-4 h-4 ml-2" />
                معاينة
              </Button>
            </div>
          </div>

          {showFilters && (
            <div className="border-t pt-4 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">حالة الفاتورة</label>
                  <select
                    value={invoiceStatus}
                    onChange={(e) => setInvoiceStatus(e.target.value as InvoiceStatus)}
                    className="w-full border rounded px-3 py-2"
                  >
                    {INVOICE_STATUS_OPTIONS.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">من تاريخ</label>
                  <Input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">إلى تاريخ</label>
                  <Input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </div>
              </div>

              {hasActiveFilters && (
                <div className="flex gap-2">
                  <Button
                    onClick={resetFilters}
                    variant="outline"
                    size="sm"
                  >
                    <X className="w-4 h-4 ml-2" />
                    إعادة تعيين الفلاتر
                  </Button>
                </div>
              )}
            </div>
          )}

          {currentInvoice && (
            <div className="flex gap-2 pt-4">
              <Button
                onClick={handleExportPDF}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                <Download className="w-4 h-4 ml-2" />
                تصدير PDF
              </Button>
              <Button
                onClick={handleExportExcel}
                variant="outline"
                className="flex-1"
              >
                <FileText className="w-4 h-4 ml-2" />
                تصدير Excel
              </Button>
            </div>
          )}
        </div>
      </Card>

      {currentInvoice && (
        <Card className="p-6">
          <h2 className="text-xl font-bold mb-4">ملخص الفاتورة</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="text-center">
              <p className="text-sm text-gray-600">الطبيب</p>
              <p className="font-bold">{currentInvoice.doctorName}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-600">الشهر</p>
              <p className="font-bold">{new Date(currentInvoice.year, currentInvoice.month - 1).toLocaleDateString("ar-SA", { month: "long", year: "numeric" })}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-600">عدد الأعمال</p>
              <p className="font-bold text-lg">{currentInvoice.works.length}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-600">الإجمالي</p>
              <p className="font-bold text-lg text-green-600">${currentInvoice.totalAmount.toFixed(2)}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-600">الحالة</p>
              <span className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${getStatusBadgeColor(currentInvoice.status)}`}>
                {getStatusLabel(currentInvoice.status)}
              </span>
            </div>
          </div>
          
          {currentInvoice.paidAmount !== undefined && (
            <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t">
              <div className="text-center">
                <p className="text-sm text-gray-600">المبلغ المدفوع</p>
                <p className="font-bold text-lg text-blue-600">${(currentInvoice.paidAmount || 0).toFixed(2)}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-600">المبلغ المتبقي</p>
                <p className="font-bold text-lg text-orange-600">${(currentInvoice.remainingAmount || currentInvoice.totalAmount).toFixed(2)}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-600">نسبة الدفع</p>
                <p className="font-bold text-lg text-purple-600">
                  {((((currentInvoice.paidAmount || 0) / currentInvoice.totalAmount) * 100) || 0).toFixed(1)}%
                </p>
              </div>
            </div>
          )}
        </Card>
      )}

      {currentInvoice && (
        <Card className="p-6">
          <h2 className="text-xl font-bold mb-4">تفاصيل الأعمال</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b-2">
                  <th className="text-right py-2 px-4">نوع العمل</th>
                  <th className="text-right py-2 px-4">اسم المريض</th>
                  <th className="text-right py-2 px-4">التاريخ</th>
                  <th className="text-right py-2 px-4">السعر</th>
                </tr>
              </thead>
              <tbody>
                {currentInvoice.works.map((work: any, index: number) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="py-2 px-4">{work.description || "عمل"}</td>
                    <td className="py-2 px-4">{work.patientName || "-"}</td>
                    <td className="py-2 px-4">
                      {(() => {
                        try {
                          const dateStr = work.dueDate || work.createdAt || work.workDate;
                          if (!dateStr) return "-";
                          // تحقق: إذا كانت بالفعل Date object، استخدمها مباشرة
                          const date = dateStr instanceof Date ? dateStr : new Date(dateStr);
                          if (isNaN(date.getTime())) return "-";
                          return date.toLocaleDateString("ar-SA");
                        } catch (e) {
                          console.error("[Monthly Invoice] Date parsing error:", e, work);
                          return "-";
                        }
                      })()}
                    </td>
                    <td className="py-2 px-4 text-left font-semibold">${parseFloat(work.totalPrice || "0").toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t-2 font-bold">
                  <td colSpan={3} className="py-2 px-4 text-left">الإجمالي:</td>
                  <td className="py-2 px-4 text-left text-green-600">${currentInvoice.totalAmount.toFixed(2)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </Card>
      )}

      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader className="flex justify-between items-center">
            <DialogTitle>معاينة الفاتورة</DialogTitle>
            <Button
              onClick={() => window.print()}
              className="bg-blue-600 hover:bg-blue-700 text-white"
              size="sm"
            >
              <Printer className="w-4 h-4 ml-2" />
              طباعة
            </Button>
          </DialogHeader>
          {currentInvoice && (
            <div
              id="invoice-print"
              dangerouslySetInnerHTML={{
                __html: `
                  <div style="direction: rtl; font-family: Arial, sans-serif; padding: 20px; background-color: white;">
                    ${generateInvoiceHTML(currentInvoice)}
                  </div>
                `,
              }}
            />
          )}
          <style>{`
            @media print {
              body * {
                visibility: hidden;
              }
              #invoice-print,
              #invoice-print * {
                visibility: visible;
              }
              #invoice-print {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
              }
            }
          `}</style>
        </DialogContent>
      </Dialog>
    </div>
  );
}
