import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, LogIn, CheckCircle2, Eye, EyeOff } from "lucide-react";
import { trpc } from "@/lib/trpc";

const REMEMBER_ME_KEY = "loginRememberMe";
const USERNAME_KEY = "loginUsername";

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const utils = trpc.useUtils();

  // Load saved username on component mount and clear sensitive data
  useEffect(() => {
    // مسح حقول كلمة المرور والبيانات الحساسة
    setPassword("");
    setError("");
    setShowPassword(false);
    
    const savedUsername = localStorage.getItem(USERNAME_KEY);
    const isRemembered = localStorage.getItem(REMEMBER_ME_KEY) === "true";
    if (savedUsername && isRemembered) {
      setUsername(savedUsername);
      setRememberMe(true);
    } else {
      setUsername("");
    }
  }, []);

  const loginMutation = trpc.authUsername.loginWithUsername.useMutation({
    onSuccess: async () => {
      // Save username if "Remember Me" is checked
      if (rememberMe) {
        localStorage.setItem(USERNAME_KEY, username);
        localStorage.setItem(REMEMBER_ME_KEY, "true");
      } else {
        // Clear saved data if "Remember Me" is unchecked
        localStorage.removeItem(USERNAME_KEY);
        localStorage.removeItem(REMEMBER_ME_KEY);
      }
      
      // إعادة تحميل بيانات المستخدم فوراً
      try {
        await utils.auth.me.refetch();
      } catch (e) {
        console.error("Error refetching auth data:", e);
      }
      
      // انتظر قليلاً للتأكد من استقرار البيانات
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // العودة إلى الصفحة الرئيسية
      setLocation("/");
    },
    onError: (error) => {
      // Handle Zod validation errors and other errors
      const errorData = error.data as any;
      
      // Check if error is a Zod validation error array
      if (Array.isArray(errorData)) {
        // This is a Zod validation error array
        if (errorData.length > 0) {
          const firstError = errorData[0];
          setError(firstError.message || "بيانات غير صحيحة");
        } else {
          setError("بيانات غير صحيحة");
        }
      } else if (errorData?.zodError) {
        // Alternative format: zodError property
        const zodErrors = errorData.zodError;
        if (Array.isArray(zodErrors) && zodErrors.length > 0) {
          const firstError = zodErrors[0];
          setError(firstError.message || "بيانات غير صحيحة");
        } else {
          setError("بيانات غير صحيحة");
        }
      } else {
        // Other error types
        setError(error.message || "فشل تسجيل الدخول");
      }
      setIsLoading(false);
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    if (!username.trim()) {
      setError("يرجى إدخال اسم المستخدم");
      setIsLoading(false);
      return;
    }

    if (!password.trim()) {
      setError("يرجى إدخال كلمة المرور");
      setIsLoading(false);
      return;
    }

    try {
      await loginMutation.mutateAsync({
        username: username.trim(),
        password,
      });
      // مسح كلمة المرور بعد محاولة تسجيل الدخول
      setPassword("");
    } catch (err) {
      // Error is handled by onError callback
      // مسح كلمة المرور عند حدوث خطأ
      setPassword("");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo/Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-full mb-4">
            <LogIn className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">مخبر النجاح</h1>
          <p className="text-gray-600">نظام الإدارة والمحاسبة</p>
        </div>

        {/* Login Card */}
        <Card className="shadow-lg">
          <CardHeader className="space-y-2">
            <CardTitle className="text-2xl text-center">تسجيل الدخول</CardTitle>
            <CardDescription className="text-center">
              أدخل بيانات حسابك للمتابعة
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Error Alert */}
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {/* Username Input */}
              <div className="space-y-2">
                <label htmlFor="username" className="block text-sm font-medium text-gray-700">
                  اسم المستخدم
                </label>
                <Input
                  id="username"
                  type="text"
                  placeholder="أدخل اسم المستخدم"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  disabled={isLoading}
                  autoFocus
                  className="text-right"
                  dir="rtl"
                />
              </div>

              {/* Password Input */}
              <div className="space-y-2">
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  كلمة المرور
                </label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="أدخل كلمة المرور"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={isLoading}
                    className="text-right pr-10"
                    dir="rtl"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading}
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    title={showPassword ? "إخفاء كلمة المرور" : "عرض كلمة المرور"}
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5" />
                    ) : (
                      <Eye className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Remember Me Checkbox */}
              <div className="flex items-center gap-2">
                <input
                  id="rememberMe"
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  disabled={isLoading}
                  className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                />
                <label htmlFor="rememberMe" className="text-sm text-gray-700 cursor-pointer">
                  تذكرني في المرة القادمة
                </label>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold py-2 rounded-lg transition-all duration-300"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    جاري التحميل...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <LogIn className="w-4 h-4" />
                    تسجيل الدخول
                  </span>
                )}
              </Button>
            </form>


          </CardContent>
        </Card>

        {/* Footer */}
        <div className="mt-6 text-center text-sm text-gray-600">
          <p>© 2026 مخبر النجاح للتعويضات السنية. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </div>
  );
}
