import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Calendar, FileText, Download, Loader2, TrendingUp } from "lucide-react";
import { toast } from "sonner";

export default function MonthlyReportsPage() {
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedDoctor, setSelectedDoctor] = useState<number | null>(null);

  // جلب البيانات
  const { data: monthlyReport } = trpc.monthlyReports.getMonthlyReport.useQuery({
    year: selectedYear,
    month: selectedMonth,
  });

  const { data: doctorReport } = trpc.monthlyReports.getDoctorMonthlyReport.useQuery(
    selectedDoctor ? {
      doctorId: selectedDoctor,
      year: selectedYear,
      month: selectedMonth,
    } : { doctorId: 0, year: 0, month: 0 },
    { enabled: !!selectedDoctor }
  );

  const { data: doctors = [] } = trpc.doctors.list.useQuery();
  const { data: allDoctors = [] } = trpc.doctors.list.useQuery();
  
  const { mutate: generateReports, isPending } = trpc.monthlyReports.generateMonthlyReports.useMutation({
    onSuccess: () => {
      toast.success("تم توليد التقارير بنجاح");
    },
    onError: () => {
      toast.error("فشل توليد التقارير");
    },
  });

  const monthNames = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];

  // بيانات الرسم البياني
  const chartData = useMemo(() => {
    if (!monthlyReport) return [];
    return [
      {
        name: "الأعمال المسلمة",
        value: monthlyReport.deliveredWorks,
        revenue: monthlyReport.deliveredRevenue,
      },
      {
        name: "الأعمال المعلقة",
        value: monthlyReport.pendingWorks,
        revenue: monthlyReport.pendingRevenue,
      },
    ];
  }, [monthlyReport]);

  const COLORS = ["#10b981", "#f59e0b"];

  const handleGenerateReports = () => {
    generateReports({
      year: selectedYear,
      month: selectedMonth,
    });
  };

  const handleExportPDF = () => {
    if (!monthlyReport) {
      toast.error("لا توجد بيانات للتصدير");
      return;
    }

    const content = `
التقرير الشهري - ${monthNames[selectedMonth - 1]} ${selectedYear}
=====================================

الإحصائيات العامة:
- إجمالي الأعمال: ${monthlyReport.totalWorks}
- الأعمال المسلمة: ${monthlyReport.deliveredWorks}
- الأعمال المعلقة: ${monthlyReport.pendingWorks}
- عدد الأطباء: ${monthlyReport.doctors}

الإيرادات:
- إيرادات الأعمال المسلمة: $${monthlyReport.deliveredRevenue.toFixed(2)}
- إيرادات الأعمال المعلقة: $${monthlyReport.pendingRevenue.toFixed(2)}
- إجمالي الإيرادات: $${monthlyReport.totalRevenue.toFixed(2)}

تاريخ التقرير: ${new Date(monthlyReport.generatedAt).toLocaleDateString('ar-SA')}
    `;

    const element = document.createElement("a");
    element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(content));
    element.setAttribute("download", `report-${selectedYear}-${selectedMonth}.txt`);
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    toast.success("تم تحميل التقرير بنجاح");
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* رأس الصفحة */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-2">
          <FileText className="text-blue-600" size={32} />
          التقارير الشهرية التلقائية
        </h1>
        <p className="text-gray-600">تقارير شاملة لأداء المخبر والأطباء شهرياً</p>
      </div>

      {/* خيارات الفترة الزمنية */}
      <div className="mb-6 bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">السنة</label>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {[2024, 2025, 2026].map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">الشهر</label>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(Number(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {monthNames.map((name, idx) => (
                <option key={idx} value={idx + 1}>{name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">الطبيب</label>
            <select
              value={selectedDoctor || ""}
              onChange={(e) => setSelectedDoctor(e.target.value ? Number(e.target.value) : null)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">جميع الأطباء</option>
              {doctors.map(doctor => (
                <option key={doctor.id} value={doctor.id}>{doctor.name}</option>
              ))}
            </select>
          </div>

          <div className="flex items-end gap-2">
            <Button
              onClick={handleGenerateReports}
              disabled={isPending}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  جاري التوليد...
                </>
              ) : (
                <>
                  <FileText className="mr-2 h-4 w-4" />
                  توليد التقرير
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* بطاقات الإحصائيات */}
      {monthlyReport && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600">
                  إجمالي الأعمال
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">
                  {monthlyReport.totalWorks}
                </div>
                <p className="text-xs text-gray-500 mt-2">عمل في الشهر</p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-green-500">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600">
                  الأعمال المسلمة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">
                  {monthlyReport.deliveredWorks}
                </div>
                <p className="text-xs text-gray-500 mt-2">${monthlyReport.deliveredRevenue.toFixed(2)}</p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-yellow-500">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600">
                  الأعمال المعلقة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-yellow-600">
                  {monthlyReport.pendingWorks}
                </div>
                <p className="text-xs text-gray-500 mt-2">${monthlyReport.pendingRevenue.toFixed(2)}</p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-500">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600">
                  إجمالي الإيرادات
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-purple-600">
                  ${monthlyReport.totalRevenue.toFixed(2)}
                </div>
                <p className="text-xs text-gray-500 mt-2">من جميع الأعمال</p>
              </CardContent>
            </Card>
          </div>

          {/* الرسوم البيانية */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* توزيع الأعمال */}
            <Card>
              <CardHeader>
                <CardTitle>توزيع الأعمال حسب الحالة</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={chartData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {COLORS.map((color, index) => (
                        <Cell key={`cell-${index}`} fill={color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* الإيرادات حسب الحالة */}
            <Card>
              <CardHeader>
                <CardTitle>الإيرادات حسب حالة العمل</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="revenue" fill="#3b82f6" name="الإيرادات ($)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* زر التصدير */}
          <div className="flex justify-end gap-2">
            <Button
              onClick={handleExportPDF}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Download className="mr-2 h-4 w-4" />
              تحميل التقرير
            </Button>
          </div>
        </>
      )}

      {/* تقرير الطبيب */}
      {selectedDoctor && doctorReport && (
        <div className="mt-8 bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            تقرير {doctorReport.doctorName} - {monthNames[selectedMonth - 1]} {selectedYear}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">إجمالي الأعمال</p>
              <p className="text-2xl font-bold text-blue-600">{doctorReport.totalWorks}</p>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">الأعمال المسلمة</p>
              <p className="text-2xl font-bold text-green-600">{doctorReport.deliveredWorks}</p>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">إجمالي الإيرادات</p>
              <p className="text-2xl font-bold text-purple-600">${doctorReport.totalRevenue.toFixed(2)}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
