import { useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, Check, X, Loader2, Filter } from "lucide-react";
import { toast } from "sonner";

type FilterType = "all" | "warning" | "success" | "info" | "error";
type ReadFilter = "all" | "read" | "unread";

export default function NotificationsPage() {
  const [filterType, setFilterType] = useState<FilterType>("all");
  const [filterRead, setFilterRead] = useState<ReadFilter>("all");

  // جلب الإشعارات غير المقروءة
  const { data: unreadAlerts = [] } = trpc.alerts.getUnread.useQuery(undefined, {
    refetchInterval: 5000, // تحديث كل 5 ثواني
  });

  // جلب البيانات الأخرى المطلوبة لإنشاء الإشعارات
  const { data: invoicesData } = trpc.invoices.list.useQuery();
  const { data: worksData } = trpc.works.list.useQuery();
  const { data: paymentsData } = trpc.payments.list.useQuery();
  const { data: expensesData } = trpc.expenses.list.useQuery();
  const { data: doctors = [] } = trpc.doctors.list.useQuery();
  
  const invoices = (Array.isArray(invoicesData) ? invoicesData : (invoicesData as any)?.data) || [];
  const works = (Array.isArray(worksData) ? worksData : (worksData as any)?.data) || [];
  const payments = (Array.isArray(paymentsData) ? paymentsData : (paymentsData as any)?.data) || [];
  const expenses = (Array.isArray(expensesData) ? expensesData : (expensesData as any)?.data) || [];

  // دالة لتحديث الإشعار كمقروء
  const markAsReadMutation = trpc.alerts.markAsRead.useMutation();

  const handleMarkAsRead = async (id: number) => {
    try {
      await markAsReadMutation.mutateAsync({ id });
      toast.success("تم تحديث الإشعار");
    } catch (error) {
      toast.error("حدث خطأ أثناء تحديث الإشعار");
    }
  };

  // دالة لحذف الإشعار
  const deleteAlertMutation = trpc.alerts.delete.useMutation();

  const handleDeleteNotification = async (notification: any) => {
    try {
      if (notification.dbId) {
        await deleteAlertMutation.mutateAsync({ id: notification.dbId });
      }
      toast.success("تم حذف الإشعار");
    } catch (error) {
      toast.error("حدث خطأ أثناء حذف الإشعار");
    }
  };

  // إنشاء الإشعارات من البيانات الحقيقية باستخدام useMemo لتجنب التحديثات اللانهائية
  const generatedNotifications = useMemo(() => {
    const notifications: any[] = [];

    // 1. الفواتير المتأخرة
    const overdueInvoices = invoices.filter((inv: any) => {
      const dueDate = new Date(inv.dueDate);
      return dueDate < new Date() && inv.status !== "paid";
    });

    overdueInvoices.forEach((invoice: any) => {
      const doctor = doctors.find((d: any) => d.id === invoice.doctorId);
      notifications.push({
        id: `invoice-${invoice.id}`,
        title: "فاتورة متأخرة",
        message: `الفاتورة ${invoice.invoiceNumber} من د. ${doctor?.name || "غير معروف"} متأخرة عن السداد`,
        type: "warning",
        date: new Date(invoice.dueDate).toLocaleDateString("ar-SA"),
        read: false,
        severity: "high",
      });
    });

    // 2. الأعمال المعلقة
    const pendingWorks = works.filter((w: any) => w.status === "pending" || w.status === "in_progress");

    pendingWorks.slice(0, 5).forEach((work: any) => {
      const doctor = doctors.find((d: any) => d.id === work.doctorId);
      notifications.push({
        id: `work-${work.id}`,
        title: "عمل معلق",
        message: `العمل من د. ${doctor?.name || "غير معروف"} - ${work.description || "بدون وصف"} لم يكتمل بعد`,
        type: "info",
        date: new Date(work.createdAt).toLocaleDateString("ar-SA"),
        read: false,
        severity: "medium",
      });
    });

    // 3. الدفعات الجديدة
    const recentPayments = payments.slice(-3);

    recentPayments.forEach((payment: any) => {
      const doctor = doctors.find((d: any) => d.id === payment.doctorId);
      notifications.push({
        id: `payment-${payment.id}`,
        title: "دفعة جديدة",
        message: `تم استلام دفعة بقيمة $${parseFloat(payment.amount).toFixed(2)} من د. ${doctor?.name || "غير معروف"}`,
        type: "success",
        date: new Date(payment.paymentDate).toLocaleDateString("ar-SA"),
        read: true,
        severity: "low",
      });
    });

    // 4. المصروفات الجديدة
    const recentExpenses = expenses.slice(-3);

    recentExpenses.forEach((expense: any) => {
      notifications.push({
        id: `expense-${expense.id}`,
        title: "مصروف جديد",
        message: `تم تسجيل مصروف ${expense.category} بقيمة $${parseFloat(expense.amount).toFixed(2)}`,
        type: "info",
        date: new Date(expense.expenseDate).toLocaleDateString("ar-SA"),
        read: true,
        severity: "low",
      });
    });

    // 5. الإشعارات من قاعدة البيانات
    unreadAlerts.forEach((alert: any) => {
      notifications.push({
        id: `alert-${alert.id}`,
        title: alert.title,
        message: alert.message,
        type: alert.severity === "high" ? "warning" : alert.severity === "medium" ? "info" : "success",
        date: new Date(alert.createdAt).toLocaleDateString("ar-SA"),
        read: alert.isRead,
        severity: alert.severity,
        dbId: alert.id,
      });
    });

    // ترتيب الإشعارات حسب التاريخ (الأحدث أولاً)
    notifications.sort((a, b) => {
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      return dateB.getTime() - dateA.getTime();
    });

    return notifications;
  }, [invoices, works, payments, expenses, doctors, unreadAlerts]);

  // تطبيق الفلاتر على الإشعارات
  const filteredNotifications = useMemo(() => {
    return generatedNotifications.filter((notification) => {
      const typeMatch = filterType === "all" || notification.type === filterType;
      const readMatch = 
        filterRead === "all" || 
        (filterRead === "read" && notification.read) || 
        (filterRead === "unread" && !notification.read);
      return typeMatch && readMatch;
    });
  }, [generatedNotifications, filterType, filterRead]);

  // حساب الإحصائيات باستخدام useMemo لتجنب التحديثات اللانهائية
  const unreadCount = useMemo(() => generatedNotifications.filter((n) => !n.read).length, [generatedNotifications]);
  
  const typeStats = useMemo(() => ({
    warning: generatedNotifications.filter((n) => n.type === "warning").length,
    success: generatedNotifications.filter((n) => n.type === "success").length,
    info: generatedNotifications.filter((n) => n.type === "info").length,
    error: generatedNotifications.filter((n) => n.type === "error").length,
  }), [generatedNotifications]);
  
  const readStats = useMemo(() => ({
    read: generatedNotifications.filter((n) => n.read).length,
    unread: generatedNotifications.filter((n) => !n.read).length,
  }), [generatedNotifications]);

  const isLoading = !invoices.length && !works.length && !payments.length && !expenses.length && !doctors.length;

  const getTypeColor = (type: string) => {
    switch (type) {
      case "warning":
        return "bg-yellow-50 border-l-4 border-yellow-400";
      case "success":
        return "bg-green-50 border-l-4 border-green-400";
      case "error":
        return "bg-red-50 border-l-4 border-red-400";
      default:
        return "bg-blue-50 border-l-4 border-blue-400";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "warning":
        return "text-yellow-600";
      case "success":
        return "text-green-600";
      case "error":
        return "text-red-600";
      default:
        return "text-blue-600";
    }
  };

  const getTypeLabel = (type: FilterType) => {
    const labels: Record<FilterType, string> = {
      all: "جميع الأنواع",
      warning: "تحذيرات",
      success: "نجاحات",
      info: "معلومات",
      error: "أخطاء",
    };
    return labels[type];
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">التنبيهات والإشعارات</h1>
        <div className="flex items-center gap-4">
          <div className="bg-blue-100 text-blue-800 px-4 py-2 rounded-lg font-semibold">
            {unreadCount} إشعارات جديدة
          </div>
        </div>
      </div>

      {/* قسم الفلاتر */}
      <Card className="p-6 bg-white">
        <div className="flex items-center gap-4 mb-4">
          <Filter className="h-5 w-5 text-gray-600" />
          <h2 className="text-lg font-semibold text-gray-900">تصفية الإشعارات</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* فلتر النوع */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">حسب النوع</label>
            <div className="flex flex-wrap gap-2">
              {(["all", "warning", "success", "info", "error"] as FilterType[]).map((type) => (
                <Button
                  key={type}
                  variant={filterType === type ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterType(type)}
                  className={filterType === type ? "bg-blue-600 text-white" : ""}
                >
                  {getTypeLabel(type)}
                  {type !== "all" && (
                    <span className="mr-2 text-xs bg-gray-200 px-2 py-1 rounded">
                      {typeStats[type as keyof typeof typeStats]}
                    </span>
                  )}
                </Button>
              ))}
            </div>
          </div>

          {/* فلتر حالة القراءة */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">حسب حالة القراءة</label>
            <div className="flex gap-2">
              {(["all", "unread", "read"] as ReadFilter[]).map((status) => (
                <Button
                  key={status}
                  variant={filterRead === status ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterRead(status)}
                  className={filterRead === status ? "bg-blue-600 text-white" : ""}
                >
                  {status === "all" && "الكل"}
                  {status === "unread" && `غير مقروء (${readStats.unread})`}
                  {status === "read" && `مقروء (${readStats.read})`}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* عرض الإشعارات */}
      {filteredNotifications.length === 0 ? (
        <Card className="p-8 text-center">
          <Bell className="h-12 w-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">لا توجد إشعارات تطابق المرشحات المختارة</p>
        </Card>
      ) : (
        <div className="space-y-3">
          <p className="text-sm text-gray-600">
            عرض {filteredNotifications.length} من {generatedNotifications.length} إشعار
          </p>
          {filteredNotifications.map((notification) => (
            <Card
              key={notification.id}
              className={`p-4 ${getTypeColor(notification.type)} ${notification.read ? "opacity-60" : ""}`}
            >
              <div className="flex justify-between items-start">
                <div className="flex gap-4 flex-1">
                  <Bell className={`h-5 w-5 mt-1 flex-shrink-0 ${getTypeIcon(notification.type)}`} />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-gray-900">{notification.title}</h3>
                      {!notification.read && (
                        <span className="inline-block w-2 h-2 bg-red-500 rounded-full"></span>
                      )}
                    </div>
                    <p className="text-sm text-gray-700 mt-1">{notification.message}</p>
                    <p className="text-xs text-gray-500 mt-2">{notification.date}</p>
                  </div>
                </div>
                <div className="flex gap-2 ml-4">
                  {!notification.read && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-green-600"
                      onClick={() => {
                        if (notification.dbId) {
                          handleMarkAsRead(notification.dbId);
                        }
                      }}
                      title="تحديث كمقروء"
                    >
                      <Check className="h-4 w-4" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-red-600"
                    onClick={() => handleDeleteNotification(notification)}
                    title="حذف الإشعار"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
