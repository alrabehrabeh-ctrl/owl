import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, CheckCircle2, Clock } from "lucide-react";

export function OTPVerificationPage() {
  const [otp, setOtp] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [timeLeft, setTimeLeft] = useState(300); // 5 دقائق
  const [isLocked, setIsLocked] = useState(false);
  const [, setLocation] = useLocation();

  const generateOTPMutation = trpc.otp.generateOTP.useMutation();
  const verifyOTPMutation = trpc.otp.verifyOTP.useMutation();

  // توليد رمز OTP عند تحميل الصفحة
  useEffect(() => {
    generateOTPMutation.mutate();
  }, []);

  // عداد الوقت المتبقي
  useEffect(() => {
    if (timeLeft <= 0) {
      setError("انتهت صلاحية الرمز. يرجى طلب رمز جديد.");
      setIsLocked(true);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const handleVerify = async () => {
    if (otp.length !== 6) {
      setError("الرمز يجب أن يكون 6 أرقام");
      return;
    }

    try {
      await verifyOTPMutation.mutateAsync({ code: otp });
      setSuccess(true);
      setError("");
      setTimeout(() => {
        setLocation("/");
      }, 2000);
    } catch (err: any) {
      setError(err.message || "فشل التحقق من الرمز");
      setOtp("");
    }
  };

  const handleRequestNewCode = () => {
    setOtp("");
    setError("");
    setTimeLeft(300);
    generateOTPMutation.mutate();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-2">
          <CardTitle className="text-2xl text-center">التحقق الثنائي</CardTitle>
          <CardDescription className="text-center">
            أدخل رمز التحقق المرسل إلى بريدك الإلكتروني
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {success && (
            <Alert className="border-green-200 bg-green-50">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                تم التحقق بنجاح! جاري إعادة التوجيه...
              </AlertDescription>
            </Alert>
          )}

          {error && (
            <Alert className="border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">{error}</AlertDescription>
            </Alert>
          )}

          {!success && (
            <>
              {/* عرض الرمز للاختبار فقط */}
              {generateOTPMutation.data?.code && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-center">
                  <p className="text-sm text-blue-600 mb-2">رمز الاختبار:</p>
                  <p className="text-2xl font-bold text-blue-900 font-mono">
                    {generateOTPMutation.data.code}
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <label className="text-sm font-medium">رمز التحقق</label>
                <Input
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  placeholder="000000"
                  value={otp}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, "");
                    setOtp(value);
                    setError("");
                  }}
                  disabled={isLocked || generateOTPMutation.isPending}
                  className="text-center text-2xl font-bold tracking-widest"
                />
              </div>

              {/* عرض الوقت المتبقي */}
              <div className="flex items-center justify-center gap-2 text-sm">
                <Clock className="h-4 w-4 text-amber-600" />
                <span className={timeLeft < 60 ? "text-red-600 font-semibold" : "text-amber-600"}>
                  الوقت المتبقي: {formatTime(timeLeft)}
                </span>
              </div>

              <Button
                onClick={handleVerify}
                disabled={otp.length !== 6 || isLocked || verifyOTPMutation.isPending}
                className="w-full"
                size="lg"
              >
                {verifyOTPMutation.isPending ? "جاري التحقق..." : "التحقق"}
              </Button>

              <Button
                onClick={handleRequestNewCode}
                variant="outline"
                className="w-full"
                disabled={generateOTPMutation.isPending}
              >
                {generateOTPMutation.isPending ? "جاري الإرسال..." : "طلب رمز جديد"}
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
