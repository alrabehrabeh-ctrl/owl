import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Loader2, Lock, Eye, EyeOff, RotateCcw } from "lucide-react";
import { toast } from "sonner";

export default function PasswordManagementPage() {
  const [selectedRole, setSelectedRole] = useState<"user" | "admin" | "manager" | "staff">("staff");
  const [newPassword, setNewPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [reason, setReason] = useState("");
  const [isInitializing, setIsInitializing] = useState(true);

  // التحقق من تهيئة إعدادات الأدوار
  useEffect(() => {
    setIsInitializing(false);
  }, []);

  const { data: initStatus } = trpc.init.checkRoleSettingsStatus.useQuery(undefined, {
    staleTime: 1000 * 60 * 5,
    gcTime: 1000 * 60 * 10,
  });

  const { data: passwordLogs = [], isLoading: logsLoading } = trpc.passwordChange.getPasswordChangeLogs.useQuery(
    { role: selectedRole, limit: 50 },
    { enabled: !isInitializing, staleTime: 1000 * 60 * 5, gcTime: 1000 * 60 * 10 }
  );

  const utils = trpc.useUtils();
  const changePasswordMutation = trpc.passwordChange.changeRolePassword.useMutation({
    onSuccess: () => {
      toast.success("تم تغيير كلمة المرور بنجاح");
      setNewPassword("");
      setReason("");
      utils.passwordChange.getPasswordChangeLogs.invalidate({ role: selectedRole });
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ في تغيير كلمة المرور");
    },
  });

  const resetPasswordMutation = trpc.passwordChange.resetRolePasswordToDefault.useMutation({
    onSuccess: () => {
      toast.success("تم إعادة تعيين كلمة المرور إلى الافتراضية");
      utils.passwordChange.getPasswordChangeLogs.invalidate({ role: selectedRole });
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ في إعادة التعيين");
    },
  });

  const handleChangePassword = () => {
    if (!newPassword) {
      toast.error("يرجى إدخال كلمة المرور الجديدة");
      return;
    }
    if (newPassword.length < 1) {
      toast.error("كلمة المرور يجب أن تكون على الأقل حرف واحد");
      return;
    }
    changePasswordMutation.mutate({
      role: selectedRole,
      newPassword,
      reason: reason || undefined,
    });
  };

  const handleResetPassword = () => {
    if (confirm("هل أنت متأكد من إعادة تعيين كلمة المرور إلى الافتراضية؟")) {
      resetPasswordMutation.mutate({ role: selectedRole });
    }
  };

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      user: "bg-blue-100 text-blue-800",
      staff: "bg-green-100 text-green-800",
      manager: "bg-purple-100 text-purple-800",
      admin: "bg-red-100 text-red-800",
    };
    return colors[role] || "bg-gray-100 text-gray-800";
  };

  const getRoleLabel = (role: string) => {
    const labels: Record<string, string> = {
      user: "مستخدم عادي",
      staff: "موظف",
      manager: "مدير",
      admin: "مسؤول",
    };
    return labels[role] || role;
  };

  // عرض شاشة التحميل أثناء التهيئة
  if (isInitializing) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="text-center space-y-4">
          <Loader2 className="w-8 h-8 animate-spin mx-auto" />
          <p className="text-muted-foreground">جاري تهيئة إعدادات الأدوار...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">إدارة كلمات المرور</h1>
        <p className="text-muted-foreground mt-2">
          تعديل كلمات المرور للأدوار المختلفة وتتبع التغييرات
        </p>
      </div>

      <Tabs defaultValue="change" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="change">تغيير كلمة المرور</TabsTrigger>
          <TabsTrigger value="logs">سجل التغييرات</TabsTrigger>
        </TabsList>

        <TabsContent value="change" className="space-y-4">
          {/* اختيار الدور */}
          <Card>
            <CardHeader>
              <CardTitle>اختر الدور</CardTitle>
              <CardDescription>اختر الدور الذي تريد تغيير كلمة مروره</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {["user", "staff", "manager", "admin"].map((role) => (
                  <Button
                    key={role}
                    variant={selectedRole === role ? "default" : "outline"}
                    onClick={() => setSelectedRole(role as any)}
                    className={selectedRole === role ? getRoleColor(role) : ""}
                  >
                    {getRoleLabel(role)}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* نموذج تغيير كلمة المرور */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="w-5 h-5" />
                تغيير كلمة مرور {getRoleLabel(selectedRole)}
              </CardTitle>
              <CardDescription>
                أدخل كلمة المرور الجديدة للدور
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">كلمة المرور الجديدة</label>
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="أدخل كلمة المرور الجديدة"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">السبب (اختياري)</label>
                <Input
                  placeholder="أدخل سبب التغيير"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                />
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={handleChangePassword}
                  disabled={changePasswordMutation.isPending}
                  className="flex-1"
                >
                  {changePasswordMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      جاري التغيير...
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4 mr-2" />
                      تغيير كلمة المرور
                    </>
                  )}
                </Button>
                <Button
                  onClick={handleResetPassword}
                  disabled={resetPasswordMutation.isPending}
                  variant="outline"
                >
                  {resetPasswordMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    </>
                  ) : (
                    <>
                      <RotateCcw className="w-4 h-4 mr-2" />
                      إعادة تعيين
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-amber-50 border-amber-200">
            <CardHeader>
              <CardTitle className="text-base">تنبيهات أمان</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-2">
              <p>
                • تأكد من أن كلمة المرور الجديدة قوية وليست سهلة التخمين
              </p>
              <p>
                • سيتم تسجيل جميع تغييرات كلمات المرور في السجل
              </p>
              <p>
                • يجب إخطار المستخدمين بكلمات المرور الجديدة بشكل آمن
              </p>
              <p>
                • يمكن إعادة تعيين كلمة المرور إلى الافتراضية في أي وقت
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>سجل تغييرات كلمات المرور</CardTitle>
              <CardDescription>
                جميع التغييرات التي تم إجراؤها على كلمة مرور دور {getRoleLabel(selectedRole)}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {logsLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin" />
                </div>
              ) : passwordLogs.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  لا توجد تغييرات مسجلة
                </p>
              ) : (
                <div className="space-y-4">
                  {passwordLogs.map((log: any) => (
                    <div key={log.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <Badge variant="outline" className="mb-2">
                            تغيير كلمة المرور
                          </Badge>
                          <p className="text-sm text-muted-foreground">
                            {new Date(log.createdAt).toLocaleString("ar-EG")}
                          </p>
                        </div>
                      </div>
                      {log.reason && (
                        <p className="text-sm mb-2">
                          <strong>السبب:</strong> {log.reason}
                        </p>
                      )}
                      <p className="text-xs text-muted-foreground font-mono break-all">
                        <strong>Hash القديم:</strong> {log.oldPasswordHash.substring(0, 20)}...
                      </p>
                      <p className="text-xs text-muted-foreground font-mono break-all mt-1">
                        <strong>Hash الجديد:</strong> {log.newPasswordHash.substring(0, 20)}...
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
