import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Loader2, Edit2, Trash2 } from "lucide-react";
import { toast } from "sonner";

export default function PaymentsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<string>("");
  const [formData, setFormData] = useState({
    doctorId: "",
    amount: "",
    paymentMethod: "cash",
    referenceNumber: "",
  });
  const [editingPaymentId, setEditingPaymentId] = useState<number | null>(null);
  const [editFormData, setEditFormData] = useState({
    amount: "",
    paymentMethod: "cash",
    referenceNumber: "",
  });

  const { data: payments, isLoading, refetch } = trpc.payments.list.useQuery();
  const { data: invoices } = trpc.invoices.list.useQuery();
  const { data: doctors } = trpc.doctors.list.useQuery();
  const createMutation = trpc.payments.create.useMutation();
  const deleteMutation = trpc.payments.delete.useMutation();
  const updateMutation = trpc.payments.update.useMutation();

  const filteredPayments = payments?.filter(
    (payment) =>
      payment.referenceNumber?.includes(searchTerm) ||
      payment.paymentMethod.includes(searchTerm)
  );

  // حساب إجمالي المديونية لكل طبيب
  const getDoctorTotalDue = (doctorId: number) => {
    const doctorInvoices = invoices?.filter((inv) => inv.doctorId === doctorId) || [];
    const totalInvoiced = doctorInvoices.reduce((sum, inv) => sum + parseFloat(inv.total), 0);
    const totalPaid = payments
      ?.filter((p) => p.doctorId === doctorId)
      .reduce((sum, p) => sum + parseFloat(p.amount), 0) || 0;
    return totalInvoiced - totalPaid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const amount = parseFloat(formData.amount);

      await createMutation.mutateAsync({
        invoiceId: 0,
        doctorId: parseInt(formData.doctorId),
        amount: formData.amount,
        paymentMethod: formData.paymentMethod as any,
        paymentDate: new Date(),
        referenceNumber: formData.referenceNumber,
      });
      toast.success(`تم تسجيل الدفعة بنجاح - تم خصم $${amount} من مديونية الطبيب`);
      setFormData({
        doctorId: "",
        amount: "",
        paymentMethod: "cash",
        referenceNumber: "",
      });
      setIsDialogOpen(false);
      refetch();
    } catch (error) {
      toast.error("حدث خطأ أثناء تسجيل الدفعة");
    }
  };

  const handleDeletePayment = async (paymentId: number) => {
    if (confirm("هل أنت متأكد من حذف هذه الدفعة؟")) {
      try {
        await deleteMutation.mutateAsync({ id: paymentId });
        toast.success("تم حذف الدفعة بنجاح");
        refetch();
      } catch (error) {
        toast.error("حدث خطأ أثناء حذف الدفعة");
      }
    }
  };

  const handleEditPayment = (payment: any) => {
    setEditingPaymentId(payment.id);
    setEditFormData({
      amount: payment.amount,
      paymentMethod: payment.paymentMethod,
      referenceNumber: payment.referenceNumber || "",
    });
  };

  const handleUpdatePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPaymentId) return;
    try {
      await updateMutation.mutateAsync({
        id: editingPaymentId,
        amount: editFormData.amount,
        paymentMethod: editFormData.paymentMethod as any,
        referenceNumber: editFormData.referenceNumber,
      });
      toast.success("تم تحديث الدفعة بنجاح");
      setEditingPaymentId(null);
      refetch();
    } catch (error) {
      toast.error("حدث خطأ أثناء تحديث الدفعة");
    }
  };

  const getPaymentMethodLabel = (method: string) => {
    switch (method) {
      case "cash":
        return "نقداً";
      case "check":
        return "شيك";
      case "bank_transfer":
        return "تحويل بنكي";
      case "credit_card":
        return "بطاقة ائتمان";
      case "other":
        return "أخرى";
      default:
        return method;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const totalPayments = payments?.reduce((sum, p) => sum + parseFloat(p.amount), 0) || 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">إدارة الدفعات والمديونيات</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 ml-2" />
              تسجيل دفعة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>تسجيل دفعة جديدة</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">اختر الطبيب</label>
                <select
                  value={formData.doctorId}
                  onChange={(e) => {
                    setFormData({ ...formData, doctorId: e.target.value });
                    setSelectedDoctor(e.target.value);
                  }}
                  className="w-full border rounded px-3 py-2"
                  required
                >
                  <option value="">-- اختر الطبيب --</option>
                  {doctors?.map((doctor) => (
                    <option key={doctor.id} value={doctor.id}>
                      {doctor.name} - المديونية: ${getDoctorTotalDue(doctor.id).toFixed(2)}
                    </option>
                  ))}
                </select>
              </div>

              <Input
                type="number"
                placeholder="المبلغ"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
              />
              <select
                value={formData.paymentMethod}
                onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                className="w-full border rounded px-3 py-2"
              >
                <option value="cash">نقداً</option>
                <option value="check">شيك</option>
                <option value="bank_transfer">تحويل بنكي</option>
                <option value="credit_card">بطاقة ائتمان</option>
                <option value="other">أخرى</option>
              </select>
              <Input
                placeholder="رقم المرجع"
                value={formData.referenceNumber}
                onChange={(e) => setFormData({ ...formData, referenceNumber: e.target.value })}
              />
              <Button type="submit" className="w-full">
                تسجيل الدفعة
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* إحصائيات المديونيات */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الدفعات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">${totalPayments.toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">عدد الفواتير</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{invoices?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">عدد الأطباء</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{doctors?.length || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* جدول مديونيات الأطباء */}
      <div>
        <h2 className="text-2xl font-bold mb-4">مديونيات الأطباء</h2>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-100">
                <th className="border p-3 text-right">اسم الطبيب</th>
                <th className="border p-3 text-right">إجمالي الفواتير</th>
                <th className="border p-3 text-right">المبلغ المدفوع</th>
                <th className="border p-3 text-right">المتبقي</th>
              </tr>
            </thead>
            <tbody>
              {doctors?.map((doctor) => {
                const totalInvoiced = invoices
                  ?.filter((inv) => inv.doctorId === doctor.id)
                  .reduce((sum, inv) => sum + parseFloat(inv.total), 0) || 0;
                const totalPaid = payments
                  ?.filter((p) => p.doctorId === doctor.id)
                  .reduce((sum, p) => sum + parseFloat(p.amount), 0) || 0;
                const remaining = totalInvoiced - totalPaid;

                return (
                  <tr key={doctor.id} className="border-b hover:bg-gray-50">
                    <td className="border p-3 font-medium">{doctor.name}</td>
                    <td className="border p-3">${totalInvoiced.toFixed(2)}</td>
                    <td className="border p-3 text-green-600">${totalPaid.toFixed(2)}</td>
                    <td className={`border p-3 font-bold ${remaining > 0 ? "text-red-600" : "text-green-600"}`}>
                      ${remaining.toFixed(2)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* جدول الدفعات */}
      <div>
        <h2 className="text-2xl font-bold mb-4">سجل الدفعات</h2>
        <div className="flex gap-4 mb-4">
          <Input
            placeholder="بحث عن دفعة..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-sm"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-100">
                <th className="border p-3 text-right">رقم الفاتورة</th>
                <th className="border p-3 text-right">اسم الطبيب</th>
                <th className="border p-3 text-right">المبلغ</th>
                <th className="border p-3 text-right">طريقة الدفع</th>
                <th className="border p-3 text-right">رقم المرجع</th>
                <th className="border p-3 text-right">التاريخ</th>
              </tr>
            </thead>
            <tbody>
              {filteredPayments?.map((payment) => {
                const invoice = invoices?.find((inv) => inv.id === payment.invoiceId);
                const doctor = doctors?.find((d) => d.id === payment.doctorId);
                return (
                  <tr key={payment.id} className="border-b hover:bg-gray-50">
                    <td className="border p-3 font-medium">{invoice?.invoiceNumber || "-"}</td>
                    <td className="border p-3">{doctor?.name || "-"}</td>
                    <td className="border p-3 font-bold text-green-600">${parseFloat(payment.amount).toFixed(2)}</td>
                    <td className="border p-3">{getPaymentMethodLabel(payment.paymentMethod)}</td>
                    <td className="border p-3">{payment.referenceNumber || "-"}</td>
                    <td className="border p-3">{new Date(payment.paymentDate).toLocaleDateString("ar-SA")}</td>
                    <td className="border p-3 flex gap-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditPayment(payment)}
                            className="flex items-center gap-1"
                          >
                            <Edit2 className="h-4 w-4" />
                            تعديل
                          </Button>
                        </DialogTrigger>
                        {editingPaymentId === payment.id && (
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>تعديل الدفعة</DialogTitle>
                            </DialogHeader>
                            <form onSubmit={handleUpdatePayment} className="space-y-4">
                              <Input
                                type="number"
                                placeholder="المبلغ"
                                value={editFormData.amount}
                                onChange={(e) => setEditFormData({ ...editFormData, amount: e.target.value })}
                                required
                              />
                              <select
                                value={editFormData.paymentMethod}
                                onChange={(e) => setEditFormData({ ...editFormData, paymentMethod: e.target.value })}
                                className="w-full border rounded px-3 py-2"
                              >
                                <option value="cash">نقداً</option>
                                <option value="check">شيك</option>
                                <option value="bank_transfer">تحويل بنكي</option>
                                <option value="credit_card">بطاقة ائتمان</option>
                                <option value="other">أخرى</option>
                              </select>
                              <Input
                                placeholder="رقم المرجع"
                                value={editFormData.referenceNumber}
                                onChange={(e) => setEditFormData({ ...editFormData, referenceNumber: e.target.value })}
                              />
                              <Button type="submit" className="w-full">
                                حفظ التعديلات
                              </Button>
                            </form>
                          </DialogContent>
                        )}
                      </Dialog>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleDeletePayment(payment.id)}
                        className="flex items-center gap-1"
                      >
                        <Trash2 className="h-4 w-4" />
                        حذف
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
