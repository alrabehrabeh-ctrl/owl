import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Lock, Plus, Trash2, RotateCcw } from "lucide-react";
import { toast } from "sonner";

export default function PermissionsManagerPage() {
  const [selectedRole, setSelectedRole] = useState<"user" | "admin" | "manager" | "staff">("admin");
  const [password, setPassword] = useState("");
  const [isPasswordVerified, setIsPasswordVerified] = useState(false);
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);
  const [reason, setReason] = useState("");

  const { data: allPermissions = [], isLoading: permissionsLoading } = trpc.roles.getAllPermissions.useQuery(undefined, {
    staleTime: 1000 * 60 * 5,
    gcTime: 1000 * 60 * 10,
  });
  const { data: currentPermissions = [], isLoading: currentLoading } = trpc.permissionsManager.getRoleCurrentPermissions.useQuery(
    { role: selectedRole },
    { enabled: isPasswordVerified, staleTime: 1000 * 60 * 5, gcTime: 1000 * 60 * 10 }
  );
  const { data: changeLogs = [], isLoading: logsLoading } = trpc.permissionsManager.getPermissionChangeLogs.useQuery(
    { role: selectedRole, limit: 50 },
    { enabled: isPasswordVerified, staleTime: 1000 * 60 * 5, gcTime: 1000 * 60 * 10 }
  );

  const verifyPasswordMutation = trpc.permissionsManager.verifyRolePassword.useMutation({
    onSuccess: (data) => {
      if (data.isValid) {
        setIsPasswordVerified(true);
        setSelectedPermissions(currentPermissions);
        toast.success("تم التحقق من كلمة المرور بنجاح");
      } else {
        toast.error("كلمة المرور غير صحيحة");
      }
    },
    onError: () => {
      toast.error("حدث خطأ في التحقق من كلمة المرور");
    },
  });

  const updatePermissionsMutation = trpc.permissionsManager.updateRolePermissions.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث الصلاحيات بنجاح");
      setReason("");
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ في تحديث الصلاحيات");
    },
  });

  const resetPermissionsMutation = trpc.permissionsManager.resetRolePermissionsToDefault.useMutation({
    onSuccess: () => {
      toast.success("تم إعادة تعيين الصلاحيات إلى الافتراضية");
      setSelectedPermissions(currentPermissions);
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ في إعادة التعيين");
    },
  });

  const handleVerifyPassword = () => {
    if (!password) {
      toast.error("يرجى إدخال كلمة المرور");
      return;
    }
    verifyPasswordMutation.mutate({ role: selectedRole, password });
  };

  const handleUpdatePermissions = () => {
    if (!isPasswordVerified) {
      toast.error("يرجى التحقق من كلمة المرور أولاً");
      return;
    }
    updatePermissionsMutation.mutate({
      role: selectedRole,
      permissions: selectedPermissions,
      reason: reason || undefined,
    });
  };

  const handleResetPermissions = () => {
    if (!isPasswordVerified) {
      toast.error("يرجى التحقق من كلمة المرور أولاً");
      return;
    }
    if (confirm("هل أنت متأكد من إعادة تعيين الصلاحيات إلى الافتراضية؟")) {
      resetPermissionsMutation.mutate({ role: selectedRole });
    }
  };

  const togglePermission = (permission: string) => {
    setSelectedPermissions((prev) =>
      prev.includes(permission) ? prev.filter((p) => p !== permission) : [...prev, permission]
    );
  };

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      user: "bg-blue-100 text-blue-800",
      staff: "bg-green-100 text-green-800",
      manager: "bg-purple-100 text-purple-800",
      admin: "bg-red-100 text-red-800",
    };
    return colors[role] || "bg-gray-100 text-gray-800";
  };

  const getPermissionCategory = (permission: string): string => {
    const categories: Record<string, string> = {
      "users.": "إدارة المستخدمين",
      "doctors.": "إدارة الأطباء",
      "works.": "إدارة الأعمال",
      "invoices.": "إدارة الفواتير",
      "expenses.": "إدارة المصروفات",
      "payments.": "إدارة الدفعات",
      "salaries.": "إدارة الرواتب",
      "reports.": "التقارير",
      "audit_log.": "سجل التدقيق",
      "settings.": "الإعدادات",
    };

    for (const [key, category] of Object.entries(categories)) {
      if (permission.startsWith(key)) {
        return category;
      }
    }
    return "أخرى";
  };

  const groupPermissionsByCategory = (permissions: any[]) => {
    const grouped: Record<string, any[]> = {};
    permissions.forEach((p) => {
      const category = getPermissionCategory(p.id || p);
      if (!grouped[category]) {
        grouped[category] = [];
      }
      grouped[category].push(p);
    });
    return grouped;
  };

  if (permissionsLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">إدارة الصلاحيات المتقدمة</h1>
        <p className="text-muted-foreground mt-2">
          تعديل الصلاحيات لكل دور والتحكم الكامل بنظام الصلاحيات
        </p>
      </div>

      <Tabs defaultValue="editor" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="editor">محرر الصلاحيات</TabsTrigger>
          <TabsTrigger value="logs">سجل التغييرات</TabsTrigger>
          <TabsTrigger value="info">معلومات</TabsTrigger>
        </TabsList>

        <TabsContent value="editor" className="space-y-4">
          {/* اختيار الدور */}
          <Card>
            <CardHeader>
              <CardTitle>اختر الدور</CardTitle>
              <CardDescription>اختر الدور الذي تريد تعديل صلاحياته</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {["user", "staff", "manager", "admin"].map((role) => (
                  <Button
                    key={role}
                    variant={selectedRole === role ? "default" : "outline"}
                    onClick={() => {
                      setSelectedRole(role as any);
                      setIsPasswordVerified(false);
                      setPassword("");
                    }}
                    className={selectedRole === role ? getRoleColor(role) : ""}
                  >
                    {role === "user" ? "مستخدم عادي" : role === "staff" ? "موظف" : role === "manager" ? "مدير" : "مسؤول"}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* التحقق من كلمة المرور */}
          {!isPasswordVerified && (
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="w-5 h-5" />
                  التحقق من كلمة المرور
                </CardTitle>
                <CardDescription>
                  يرجى إدخال كلمة مرور الدور للتحقق
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium">كلمة مرور دور {selectedRole}</label>
                  <Input
                    type="password"
                    placeholder="أدخل كلمة المرور"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleVerifyPassword()}
                  />
                </div>
                <Button
                  onClick={handleVerifyPassword}
                  disabled={verifyPasswordMutation.isPending}
                  className="w-full"
                >
                  {verifyPasswordMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      جاري التحقق...
                    </>
                  ) : (
                    "التحقق"
                  )}
                </Button>
              </CardContent>
            </Card>
          )}

          {/* محرر الصلاحيات */}
          {isPasswordVerified && (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>صلاحيات دور {selectedRole}</CardTitle>
                  <CardDescription>
                    اختر الصلاحيات المراد تفعيلها لهذا الدور
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {Object.entries(groupPermissionsByCategory(allPermissions)).map(
                    ([category, permissions]) => (
                      <div key={category}>
                        <h4 className="font-semibold text-sm mb-3 text-foreground">
                          {category}
                        </h4>
                        <div className="space-y-2 pl-4">
                          {permissions.map((permission: any) => (
                            <div
                              key={permission.id}
                              className="flex items-start gap-3 p-2 rounded hover:bg-muted"
                            >
                              <Checkbox
                                checked={selectedPermissions.includes(permission.id)}
                                onCheckedChange={() => togglePermission(permission.id)}
                                className="mt-1"
                              />
                              <div className="flex-1">
                                <p className="font-medium text-sm">{permission.name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {permission.description}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )
                  )}
                </CardContent>
              </Card>

              {/* سبب التغيير والأزرار */}
              <Card>
                <CardHeader>
                  <CardTitle>حفظ التغييرات</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">سبب التغيير (اختياري)</label>
                    <Input
                      placeholder="أدخل سبب التغيير"
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={handleUpdatePermissions}
                      disabled={updatePermissionsMutation.isPending}
                      className="flex-1"
                    >
                      {updatePermissionsMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          جاري الحفظ...
                        </>
                      ) : (
                        <>
                          <Plus className="w-4 h-4 mr-2" />
                          حفظ التغييرات
                        </>
                      )}
                    </Button>
                    <Button
                      onClick={handleResetPermissions}
                      disabled={resetPermissionsMutation.isPending}
                      variant="outline"
                    >
                      {resetPermissionsMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        </>
                      ) : (
                        <>
                          <RotateCcw className="w-4 h-4 mr-2" />
                          إعادة تعيين
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>سجل التغييرات</CardTitle>
              <CardDescription>
                جميع التغييرات التي تم إجراؤها على صلاحيات دور {selectedRole}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {logsLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin" />
                </div>
              ) : changeLogs.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  لا توجد تغييرات مسجلة
                </p>
              ) : (
                <div className="space-y-4">
                  {changeLogs.map((log: any) => (
                    <div key={log.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <Badge variant="outline">
                            {log.changeType === "add"
                              ? "إضافة"
                              : log.changeType === "remove"
                              ? "حذف"
                              : "إعادة تعيين"}
                          </Badge>
                          <p className="text-sm text-muted-foreground mt-1">
                            {new Date(log.createdAt).toLocaleString("ar-EG")}
                          </p>
                        </div>
                      </div>
                      {log.reason && (
                        <p className="text-sm mb-2">
                          <strong>السبب:</strong> {log.reason}
                        </p>
                      )}
                      {log.permission && (
                        <p className="text-sm">
                          <strong>الصلاحية:</strong> {log.permission}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="info" className="space-y-4">
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle>كلمات المرور الافتراضية</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-3 bg-white rounded border">
                  <p className="font-semibold">مسؤول (Admin)</p>
                  <p className="text-sm text-muted-foreground font-mono">admin</p>
                </div>
                <div className="p-3 bg-white rounded border">
                  <p className="font-semibold">مدير (Manager)</p>
                  <p className="text-sm text-muted-foreground font-mono">1985</p>
                </div>
                <div className="p-3 bg-white rounded border">
                  <p className="font-semibold">موظف (Staff)</p>
                  <p className="text-sm text-muted-foreground font-mono">0000</p>
                </div>
                <div className="p-3 bg-white rounded border">
                  <p className="font-semibold">مستخدم عادي (User)</p>
                  <p className="text-sm text-muted-foreground font-mono">0000</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-amber-50 border-amber-200">
            <CardHeader>
              <CardTitle className="text-base">ملاحظات مهمة</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-2">
              <p>
                • يمكن فقط للمسؤول (Admin) تعديل الصلاحيات
              </p>
              <p>
                • يتم تسجيل جميع التغييرات في سجل التدقيق
              </p>
              <p>
                • يمكن إعادة تعيين الصلاحيات إلى الافتراضية في أي وقت
              </p>
              <p>
                • التغييرات تسري مباشرة بعد الحفظ
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
