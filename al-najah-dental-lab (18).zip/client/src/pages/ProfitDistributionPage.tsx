import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useState, useMemo } from "react";
import { Download, Send, Loader2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function ProfitDistributionPage() {
  const [startDate, setStartDate] = useState(new Date(new Date().getFullYear(), 0, 1).toISOString().split("T")[0]);
  const [endDate, setEndDate] = useState(new Date().toISOString().split("T")[0]);

  // جلب بيانات الأعمال والمصروفات
  const { data: worksData } = trpc.works.list.useQuery();
  const { data: expensesData } = trpc.expenses.list.useQuery();
  
  const works = (Array.isArray(worksData) ? worksData : (worksData as any)?.data) || [];
  const expenses = (Array.isArray(expensesData) ? expensesData : (expensesData as any)?.data) || [];

  // حساب الإيرادات والمصروفات بناءً على الفترة المحددة
  const { revenue, totalExpenses, filteredWorksCount, filteredExpensesCount } = useMemo(() => {
    // تحويل التواريخ بشكل صحيح
    const start = new Date(startDate + "T00:00:00");
    const end = new Date(endDate + "T23:59:59");

    console.log("تصفية الأعمال من", start, "إلى", end);

    // حساب الإيرادات من الأعمال المسلمة أو المكتملة
    const filteredWorks = works.filter((work: any) => {
      if (!work.createdAt) return false;
      
      // تحويل التاريخ بشكل صحيح
      const workDate = new Date(work.createdAt);
      const isInDateRange = workDate >= start && workDate <= end;
      const isDelivered = work.status === "delivered" || work.status === "completed";
      
      return isInDateRange && isDelivered;
    });

    const totalRevenue = filteredWorks.reduce((sum: number, work: any) => {
      const price = parseFloat(String(work.totalPrice || "0"));
      return sum + (isNaN(price) ? 0 : price);
    }, 0);

    // حساب المصروفات
    const filteredExpenses = expenses.filter((expense: any) => {
      if (!expense.expenseDate) return false;
      
      const expenseDate = new Date(expense.expenseDate);
      return expenseDate >= start && expenseDate <= end;
    });

    const total = filteredExpenses.reduce((sum: number, expense: any) => {
      const amount = parseFloat(String(expense.amount || "0"));
      return sum + (isNaN(amount) ? 0 : amount);
    }, 0);

    return { 
      revenue: totalRevenue, 
      totalExpenses: total,
      filteredWorksCount: filteredWorks.length,
      filteredExpensesCount: filteredExpenses.length
    };
  }, [works, expenses, startDate, endDate]);

  const netProfit = revenue - totalExpenses;
  const profitMargin = revenue > 0 ? ((netProfit / revenue) * 100).toFixed(2) : "0";

  // توزيع الأرباح على الثلاثة أشخاص
  const distributions = [
    {
      name: "إيناس الربيع",
      percentage: 40,
      amount: netProfit * 0.4,
      color: "#10b981",
    },
    {
      name: "ربيع الربيع",
      percentage: 40,
      amount: netProfit * 0.4,
      color: "#3b82f6",
    },
    {
      name: "حسان الحسون",
      percentage: 20,
      amount: netProfit * 0.2,
      color: "#f59e0b",
    },
  ];

  const chartData = distributions.map((dist) => ({
    name: dist.name,
    value: dist.amount,
  }));

  const handleDownloadReport = () => {
    try {
      const reportContent = `
تقرير توزيع الأرباح
==================

الفترة: من ${startDate} إلى ${endDate}

الإحصائيات الرئيسية:
- عدد الأعمال المسلمة: ${filteredWorksCount}
- إجمالي الإيرادات: $${revenue.toFixed(2)}
- عدد المصروفات: ${filteredExpensesCount}
- إجمالي المصروفات: $${totalExpenses.toFixed(2)}
- الأرباح الصافية: $${netProfit.toFixed(2)}
- نسبة الأرباح: ${profitMargin}%

توزيع الأرباح:
${distributions.map((d) => `- ${d.name}: $${d.amount.toFixed(2)} (${d.percentage}%)`).join("\n")}
      `;

      const element = document.createElement("a");
      element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(reportContent));
      element.setAttribute("download", `profit-distribution-${startDate}-${endDate}.txt`);
      element.style.display = "none";
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);

      toast.success("تم تحميل التقرير بنجاح");
    } catch (error) {
      toast.error("خطأ في تحميل التقرير");
    }
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* رأس الصفحة */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">💰 توزيع الأرباح</h1>
        <p className="text-gray-600">تحليل توزيع الأرباح بناءً على الفترة الزمنية المحددة</p>
      </div>

      {/* تحديد الفترة الزمنية */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>تحديد الفترة الزمنية</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">من التاريخ</label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">إلى التاريخ</label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full"
              />
            </div>
            <div className="flex items-end">
              <Button onClick={handleDownloadReport} className="w-full bg-green-600 hover:bg-green-700">
                <Download className="w-4 h-4 mr-2" />
                تحميل التقرير
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* البطاقات الإحصائية */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">الأعمال المسلمة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{filteredWorksCount}</div>
            <p className="text-xs text-gray-500 mt-1">من إجمالي {works.length} عمل</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">إجمالي الإيرادات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">${revenue.toFixed(2)}</div>
            <p className="text-xs text-gray-500 mt-1">من الأعمال المسلمة</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">إجمالي المصروفات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">${totalExpenses.toFixed(2)}</div>
            <p className="text-xs text-gray-500 mt-1">من {filteredExpensesCount} مصروف</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">الأرباح الصافية</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${netProfit >= 0 ? "text-blue-600" : "text-red-600"}`}>
              ${netProfit.toFixed(2)}
            </div>
            <p className="text-xs text-gray-500 mt-1">نسبة الأرباح: {profitMargin}%</p>
          </CardContent>
        </Card>
      </div>

      {/* توزيع الأرباح */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* جدول التوزيع */}
        <Card>
          <CardHeader>
            <CardTitle>توزيع الأرباح</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {distributions.map((dist, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 rounded-full" style={{ backgroundColor: dist.color }}></div>
                    <div>
                      <p className="font-medium text-gray-900">{dist.name}</p>
                      <p className="text-sm text-gray-500">{dist.percentage}%</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-900">${dist.amount.toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* مخطط التوزيع */}
        <Card>
          <CardHeader>
            <CardTitle>مخطط التوزيع</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: $${value.toFixed(0)}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {distributions.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: any) => `$${value.toFixed(2)}`} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* ملاحظات مهمة */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-900">ملاحظات مهمة</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-blue-800 space-y-1">
          <p>• يتم حساب الإيرادات من الأعمال المسلمة أو المكتملة فقط</p>
          <p>• يتم استخدام تاريخ إدخال العمل (createdAt) كتاريخ العمل</p>
          <p>• الأرباح الصافية = الإيرادات - المصروفات</p>
          <p>• التوزيع: إيناس الربيع 40%، ربيع الربيع 40%، حسان الحسون 20%</p>
          <p>• تأكد من أن التواريخ المحددة صحيحة قبل تحميل التقرير</p>
        </CardContent>
      </Card>
    </div>
  );
}
