"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Trash2, Edit2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function ReceivablesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  
  const { data: doctors, isLoading: doctorsLoading } = trpc.doctors.list.useQuery();
  const { data: worksData, isLoading: worksLoading } = trpc.works.list.useQuery();
  const { data: paymentsData, isLoading: paymentsLoading } = trpc.payments.list.useQuery();
  
  const works = (Array.isArray(worksData) ? worksData : (worksData as any)?.data) || [];
  const payments = (Array.isArray(paymentsData) ? paymentsData : (paymentsData as any)?.data) || [];
  
  // حساب المديونية الحقيقية لكل طبيب من جدول الأعمال والدفعات
  const receivables = doctors?.map((doctor: any) => {
    const doctorWorks = works?.filter((work: any) => work.doctorId === doctor.id) || [];
    const doctorPayments = payments?.filter((payment: any) => payment.doctorId === doctor.id) || [];
    
    const totalAmount = doctorWorks.reduce((sum: number, work: any) => sum + parseFloat(work.totalPrice || 0), 0);
    const paidAmount = doctorPayments.reduce((sum: number, payment: any) => sum + parseFloat(payment.amount || 0), 0);
    const remainingAmount = Math.max(0, totalAmount - paidAmount); // الباقي = الإجمالي - المدفوع
    
    return {
      ...doctor,
      totalAmount,
      paidAmount,
      remainingAmount,
    };
  }) || [];

  const filteredReceivables = receivables.filter((item: any) =>
    item.name.includes(searchTerm) || item.phone?.includes(searchTerm)
  );

  const totalRemaining = filteredReceivables.reduce((sum: number, item: any) => sum + (item.remainingAmount || 0), 0);

  const isLoading = doctorsLoading || worksLoading || paymentsLoading;

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-96">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">تتبع المديونية</h1>
        <div className="text-2xl font-bold text-red-600">
          إجمالي المديونيات: ${totalRemaining.toFixed(2)}
        </div>
      </div>

      <div className="flex gap-4">
        <Input
          placeholder="ابحث عن طبيب..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1"
        />
      </div>

      <div className="space-y-4">
        {filteredReceivables.length > 0 ? (
          filteredReceivables.map((item: any) => (
            <Card key={item.id} className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{item.name}</h3>
                  <p className="text-sm text-gray-600">الرقم: {item.doctorCode}</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Edit2 className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" className="text-red-600">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">إجمالي المبلغ</p>
                  <p className="text-2xl font-bold text-blue-600">${item.totalAmount.toFixed(2)}</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">المبلغ المدفوع</p>
                  <p className="text-2xl font-bold text-green-600">${item.paidAmount.toFixed(2)}</p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">المبلغ المتبقي</p>
                  <p className="text-2xl font-bold text-red-600">${item.remainingAmount.toFixed(2)}</p>
                </div>
              </div>

              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-green-600 h-2 rounded-full"
                  style={{
                    width: item.totalAmount > 0 ? `${(item.paidAmount / item.totalAmount) * 100}%` : '0%',
                  }}
                />
              </div>
              <p className="text-xs text-gray-600 mt-2">
                نسبة السداد: {item.totalAmount > 0 ? ((item.paidAmount / item.totalAmount) * 100).toFixed(0) : 0}%
              </p>
            </Card>
          ))
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-600">لا توجد مديونيات</p>
          </div>
        )}
      </div>
    </div>
  );
}
