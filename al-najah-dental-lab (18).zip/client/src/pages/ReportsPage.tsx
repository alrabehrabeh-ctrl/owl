import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Download, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function ReportsPage() {
  const [startDate, setStartDate] = useState(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split("T")[0]);
  const [endDate, setEndDate] = useState(new Date().toISOString().split("T")[0]);
  const [activeTab, setActiveTab] = useState<'general' | 'doctors' | 'currencies'>('general');

  const { data: revenueData, isLoading: revenueLoading } = trpc.reports.getTotalRevenue.useQuery({
    startDate: new Date(startDate),
    endDate: new Date(endDate),
  });

  const { data: expensesData, isLoading: expensesLoading } = trpc.reports.getTotalExpenses.useQuery({
    startDate: new Date(startDate),
    endDate: new Date(endDate),
  });

  const { data: overdueInvoices } = trpc.reports.getOverdueInvoices.useQuery();
  const { data: pendingWorks } = trpc.reports.getPendingWorks.useQuery();
  const { data: doctors = [] } = trpc.doctors.list.useQuery();
  const { data: worksData } = trpc.works.list.useQuery();
  const works = (worksData as any)?.data || (Array.isArray(worksData) ? worksData : []);
  const { data: currencyConversion } = trpc.currencies.calculateConversion.useQuery({
    amount: 1,
    fromCurrencyId: 1,
    toCurrencyId: 2,
  });

  const revenue = parseFloat(revenueData as string) || 0;
  const expenses = parseFloat(expensesData as string) || 0;
  const profit = revenue - expenses;
  const profitMargin = revenue > 0 ? ((profit / revenue) * 100).toFixed(2) : 0;

  const handleExport = () => {
    try {
      const reportData = {
        period: `${startDate} إلى ${endDate}`,
        revenue: revenue.toFixed(2),
        expenses: expenses.toFixed(2),
        profit: profit.toFixed(2),
        profitMargin: profitMargin,
        overdueInvoices: overdueInvoices?.length || 0,
        pendingWorks: pendingWorks?.length || 0,
      };

      const csv = `التقرير المالي
الفترة: ${reportData.period}
الإيرادات: ${reportData.revenue} $
المصروفات: ${reportData.expenses} $
الأرباح: ${reportData.profit} $
نسبة الأرباح: ${reportData.profitMargin}%
الفواتير المتأخرة: ${reportData.overdueInvoices}
الأعمال المعلقة: ${reportData.pendingWorks}`;

      const element = document.createElement("a");
      element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(csv));
      element.setAttribute("download", `report-${new Date().toISOString().split("T")[0]}.txt`);
      element.style.display = "none";
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
      toast.success("تم تحميل التقرير بنجاح");
    } catch (error) {
      toast.error("حدث خطأ أثناء تحميل التقرير");
    }
  };

  const chartData = [
    { name: "الإيرادات", value: revenue },
    { name: "المصروفات", value: expenses },
    { name: "الأرباح", value: profit },
  ];

  const COLORS = ["#10b981", "#ef4444", "#3b82f6"];

  const isLoading = revenueLoading || expensesLoading;

  // حساب إحصائيات الأطباء
  const doctorStats = doctors.map((doctor: any) => {
    const doctorWorks = works.filter((w: any) => w.doctorId === doctor.id);
    const totalRevenue = doctorWorks.reduce((sum: number, w: any) => sum + parseFloat(w.totalPrice || 0), 0);
    const workCount = doctorWorks.length;
    return {
      id: doctor.id,
      name: doctor.name,
      totalRevenue,
      workCount,
    };
  }).sort((a, b) => b.totalRevenue - a.totalRevenue);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">التقارير المالية</h1>
        <Button onClick={handleExport}>
          <Download className="h-4 w-4 ml-2" />
          تحميل التقرير
        </Button>
      </div>

      {/* التبويبات */}
      <div className="flex gap-4 border-b">
        <button
          onClick={() => setActiveTab('general')}
          className={`px-4 py-2 font-medium ${
            activeTab === 'general'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          التقارير العامة
        </button>
        <button
          onClick={() => setActiveTab('doctors')}
          className={`px-4 py-2 font-medium ${
            activeTab === 'doctors'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          تقارير الأطباء
        </button>
        <button
          onClick={() => setActiveTab('currencies')}
          className={`px-4 py-2 font-medium ${
            activeTab === 'currencies'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          💱 تقارير العملات
        </button>
      </div>

      {activeTab === 'general' ? (
        // التقارير العامة
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">من تاريخ</label>
              <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">إلى تاريخ</label>
              <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
            </div>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center h-96">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-600">إجمالي الإيرادات</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600">${revenue.toFixed(2)}</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-600">إجمالي المصروفات</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-red-600">${expenses.toFixed(2)}</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-600">الأرباح الصافية</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-2xl font-bold ${profit >= 0 ? "text-blue-600" : "text-red-600"}`}>
                      ${profit.toFixed(2)}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-600">نسبة الأرباح</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-purple-600">{profitMargin}%</div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>توزيع الإيرادات والمصروفات</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="value" fill="#3b82f6" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>نسبة الإيرادات والمصروفات</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie data={chartData} cx="50%" cy="50%" labelLine={false} label={({ name, value }) => `${name}: ${value.toFixed(0)}`} outerRadius={80} fill="#8884d8" dataKey="value">
                          {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>الفواتير المتأخرة ({overdueInvoices?.length || 0})</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {overdueInvoices && overdueInvoices.length > 0 ? (
                      <div className="space-y-2">
                        {overdueInvoices.slice(0, 10).map((invoice: any) => (
                          <div key={invoice.id} className="flex justify-between items-center p-2 border-b">
                            <span className="text-sm">{invoice.invoiceNumber}</span>
                            <span className="text-sm font-bold text-red-600">${invoice.remainingAmount}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 text-sm">لا توجد فواتير متأخرة</p>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>الأعمال المعلقة ({pendingWorks?.length || 0})</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {pendingWorks && pendingWorks.length > 0 ? (
                      <div className="space-y-2">
                        {pendingWorks.slice(0, 10).map((work: any) => (
                          <div key={work.id} className="flex justify-between items-center p-2 border-b">
                            <span className="text-sm">{work.description}</span>
                            <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">معلق</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 text-sm">لا توجد أعمال معلقة</p>
                    )}
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </>
      ) : activeTab === 'doctors' ? (
        <>
          {/* تقارير الأطباء */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>تقارير الأطباء المالية</CardTitle>
              </CardHeader>
              <CardContent>
                {doctorStats.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-right py-2 px-4 font-semibold">اسم الطبيب</th>
                          <th className="text-right py-2 px-4 font-semibold">عدد الأعمال</th>
                          <th className="text-right py-2 px-4 font-semibold">إجمالي الإيرادات</th>
                          <th className="text-right py-2 px-4 font-semibold">متوسط العمل</th>
                        </tr>
                      </thead>
                      <tbody>
                        {doctorStats.map((stat: any) => (
                          <tr key={stat.id} className="border-b hover:bg-gray-50">
                            <td className="py-3 px-4">{stat.name}</td>
                            <td className="py-3 px-4 text-center">{stat.workCount}</td>
                            <td className="py-3 px-4 text-right font-semibold text-green-600">${stat.totalRevenue.toFixed(2)}</td>
                            <td className="py-3 px-4 text-right">${stat.workCount > 0 ? (stat.totalRevenue / stat.workCount).toFixed(2) : '0.00'}</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="font-bold border-t-2">
                          <td className="py-3 px-4">الإجمالي</td>
                          <td className="py-3 px-4 text-center">{doctorStats.reduce((sum: number, s: any) => sum + s.workCount, 0)}</td>
                          <td className="py-3 px-4 text-right text-green-600">${doctorStats.reduce((sum: number, s: any) => sum + s.totalRevenue, 0).toFixed(2)}</td>
                          <td className="py-3 px-4 text-right">${doctorStats.length > 0 && doctorStats.reduce((sum: number, s: any) => sum + s.workCount, 0) > 0 ? (doctorStats.reduce((sum: number, s: any) => sum + s.totalRevenue, 0) / doctorStats.reduce((sum: number, s: any) => sum + s.workCount, 0)).toFixed(2) : '0.00'}</td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-8">لا توجد بيانات للأطباء</p>
                )}
              </CardContent>
            </Card>

            {/* رسم بياني للأطباء الأعلى */}
            {doctorStats.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>أعلى 10 أطباء من حيث الإيرادات</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={doctorStats.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="totalRevenue" fill="#10b981" name="الإيرادات" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}
          </div>
        </>
      ) : activeTab === 'currencies' ? (
        <>
          {/* تقارير العملات */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>💱 تقرير المقارنة بين العملات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h3 className="font-semibold text-blue-900 mb-2">🇺🇸 الإيرادات (دولار)</h3>
                    <div className="text-2xl font-bold text-blue-600">${revenue.toFixed(2)}</div>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg">
                    <h3 className="font-semibold text-green-900 mb-2">🇸🇾 الإيرادات (ليرة)</h3>
                    <div className="text-2xl font-bold text-green-600">ل.س {(revenue * 13000).toFixed(0)}</div>
                  </div>
                  <div className="p-4 bg-red-50 rounded-lg">
                    <h3 className="font-semibold text-red-900 mb-2">🇺🇸 المصروفات (دولار)</h3>
                    <div className="text-2xl font-bold text-red-600">${expenses.toFixed(2)}</div>
                  </div>
                  <div className="p-4 bg-orange-50 rounded-lg">
                    <h3 className="font-semibold text-orange-900 mb-2">🇸🇾 المصروفات (ليرة)</h3>
                    <div className="text-2xl font-bold text-orange-600">ل.س {(expenses * 13000).toFixed(0)}</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-semibold mb-2">🇺🇸 الربح (دولار)</h3>
                    <div className="text-xl font-bold text-blue-600">${profit.toFixed(2)}</div>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-semibold mb-2">🇸🇾 الربح (ليرة)</h3>
                    <div className="text-xl font-bold text-green-600">ل.س {(profit * 13000).toFixed(0)}</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>📈 رسم بياني مقارن بين العملات</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={[
                    { name: "الإيرادات", USD: revenue, SYP: revenue * 13000 / 1000 },
                    { name: "المصروفات", USD: expenses, SYP: expenses * 13000 / 1000 },
                    { name: "الربح", USD: profit, SYP: profit * 13000 / 1000 },
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="USD" fill="#3b82f6" name="USD ($)" />
                    <Bar dataKey="SYP" fill="#ef4444" name="SYP (ل.س)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>💱 معلومات سعر الصرف</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-sm text-gray-600 mb-2">سعر الصرف الحالي</div>
                    <div className="text-3xl font-bold">1 USD = {currencyConversion?.exchangeRate || "غير متوفر"} SYP</div>
                    <div className="text-xs text-gray-500 mt-2">آخر تحديث: الآن</div>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <p className="text-sm text-gray-600">يمكن تحديث سعر الصرف من صفحة <strong>إدارة العملات</strong></p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      ) : (
        <>
          {/* تقارير الأداء */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>أداء العيادة الشهري</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={[
                    { month: 'يناير', revenue: 5000, expenses: 2000, profit: 3000 },
                    { month: 'فبراير', revenue: 6000, expenses: 2500, profit: 3500 },
                    { month: 'مارس', revenue: 7000, expenses: 3000, profit: 4000 },
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="revenue" stroke="#10b981" name="الإيرادات" />
                    <Line type="monotone" dataKey="expenses" stroke="#ef4444" name="المصروفات" />
                    <Line type="monotone" dataKey="profit" stroke="#3b82f6" name="الأرباح" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}


// ============================================
// تقارير العملات المتعددة
// ============================================

export function CurrencyReports() {
  const [startDate, setStartDate] = useState(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split("T")[0]);
  const [endDate, setEndDate] = useState(new Date().toISOString().split("T")[0]);

  // جلب البيانات بالعملات المختلفة
  const { data: revenueUSD, isLoading: revenueLoading } = trpc.reports.getTotalRevenue.useQuery({
    startDate: new Date(startDate),
    endDate: new Date(endDate),
  });

  const { data: expensesUSD, isLoading: expensesLoading } = trpc.reports.getTotalExpenses.useQuery({
    startDate: new Date(startDate),
    endDate: new Date(endDate),
  });

  const { data: exchangeRates = [] } = trpc.currencies.getAll.useQuery();
  const { data: currencyConversion } = trpc.currencies.calculateConversion.useQuery({
    amount: parseFloat(revenueUSD as string) || 0,
    fromCurrencyId: 1, // USD
    toCurrencyId: 2, // SYP
  });

  const revenueSYP = currencyConversion?.priceInSecondCurrency || 0;
  const expensesSYP = (parseFloat(expensesUSD as string) || 0) * (currencyConversion?.exchangeRate ? parseFloat(currencyConversion.exchangeRate) : 12500);

  const revenueUSDNum = parseFloat(revenueUSD as string) || 0;
  const expensesUSDNum = parseFloat(expensesUSD as string) || 0;
  const profitUSD = revenueUSDNum - expensesUSDNum;
  const profitSYP = revenueSYP - expensesSYP;

  const chartData = [
    {
      name: "الإيرادات",
      USD: revenueUSDNum,
      SYP: revenueSYP / 1000, // تقسيم على 1000 لتوضيح الفرق
    },
    {
      name: "المصروفات",
      USD: expensesUSDNum,
      SYP: expensesSYP / 1000,
    },
    {
      name: "الربح",
      USD: profitUSD,
      SYP: profitSYP / 1000,
    },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>📊 تقرير المقارنة بين العملات</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h3 className="font-semibold text-blue-900 mb-2">الإيرادات</h3>
              <div className="space-y-1 text-sm">
                <div>🇺🇸 USD: ${revenueUSDNum.toFixed(2)}</div>
                <div>🇸🇾 SYP: ل.س {revenueSYP.toFixed(0)}</div>
              </div>
            </div>

            <div className="p-4 bg-red-50 rounded-lg">
              <h3 className="font-semibold text-red-900 mb-2">المصروفات</h3>
              <div className="space-y-1 text-sm">
                <div>🇺🇸 USD: ${expensesUSDNum.toFixed(2)}</div>
                <div>🇸🇾 SYP: ل.س {expensesSYP.toFixed(0)}</div>
              </div>
            </div>

            <div className="p-4 bg-green-50 rounded-lg">
              <h3 className="font-semibold text-green-900 mb-2">الربح</h3>
              <div className="space-y-1 text-sm">
                <div>🇺🇸 USD: ${profitUSD.toFixed(2)}</div>
                <div>🇸🇾 SYP: ل.س {profitSYP.toFixed(0)}</div>
              </div>
            </div>

            <div className="p-4 bg-purple-50 rounded-lg">
              <h3 className="font-semibold text-purple-900 mb-2">سعر الصرف الحالي</h3>
              <div className="space-y-1 text-sm">
                <div>1 USD = {currencyConversion?.exchangeRate || "12,500"} SYP</div>
                <div className="text-xs text-purple-600 mt-2">آخر تحديث: الآن</div>
              </div>
            </div>
          </div>

          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="USD" fill="#3b82f6" name="USD ($)" />
                <Bar dataKey="SYP" fill="#ef4444" name="SYP (ل.س)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>💱 تفاصيل التحويل</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-3 border rounded-lg">
                <div className="text-sm text-muted-foreground">الإيرادات بالدولار</div>
                <div className="text-2xl font-bold">${revenueUSDNum.toFixed(2)}</div>
              </div>
              <div className="p-3 border rounded-lg text-center">
                <div className="text-2xl">×</div>
                <div className="text-sm text-muted-foreground">{currencyConversion?.exchangeRate || "12,500"}</div>
              </div>
              <div className="p-3 border rounded-lg">
                <div className="text-sm text-muted-foreground">الإيرادات بالليرة السورية</div>
                <div className="text-2xl font-bold">ل.س {revenueSYP.toFixed(0)}</div>
              </div>
            </div>

            <div className="text-sm text-muted-foreground p-3 bg-muted rounded-lg">
              <strong>ملاحظة:</strong> جميع الأسعار محدثة بناءً على سعر الصرف الحالي. يمكن تحديث سعر الصرف من صفحة إدارة العملات.
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
