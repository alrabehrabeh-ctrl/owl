import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function RolesPage() {
  const [selectedRole, setSelectedRole] = useState<"user" | "admin" | "manager" | "staff">("user");

  const { data: roles = [], isLoading: rolesLoading } = trpc.roles.getAllRoles.useQuery(undefined, {
    staleTime: 1000 * 60 * 5,
    gcTime: 1000 * 60 * 10,
  });
  const { data: rolePermissions = [], isLoading: permissionsLoading } = trpc.roles.getRolePermissions.useQuery(
    { role: selectedRole },
    { enabled: !!selectedRole, staleTime: 1000 * 60 * 5, gcTime: 1000 * 60 * 10 }
  );
  const { data: allPermissions = [], isLoading: allPermissionsLoading } = trpc.roles.getAllPermissions.useQuery(undefined, {
    staleTime: 1000 * 60 * 5,
    gcTime: 1000 * 60 * 10,
  });
  const { data: userRole } = trpc.roles.getCurrentUserRole.useQuery(undefined, {
    staleTime: 1000 * 60 * 5,
    gcTime: 1000 * 60 * 10,
  });

  if (rolesLoading || permissionsLoading || allPermissionsLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      user: "bg-blue-100 text-blue-800",
      staff: "bg-green-100 text-green-800",
      manager: "bg-purple-100 text-purple-800",
      admin: "bg-red-100 text-red-800",
    };
    return colors[role] || "bg-gray-100 text-gray-800";
  };

  const getPermissionCategory = (permission: string): string => {
    const categories: Record<string, string> = {
      "users.": "إدارة المستخدمين",
      "doctors.": "إدارة الأطباء",
      "works.": "إدارة الأعمال",
      "invoices.": "إدارة الفواتير",
      "expenses.": "إدارة المصروفات",
      "payments.": "إدارة الدفعات",
      "salaries.": "إدارة الرواتب",
      "reports.": "التقارير",
      "audit_log.": "سجل التدقيق",
      "settings.": "الإعدادات",
    };

    for (const [key, category] of Object.entries(categories)) {
      if (permission.startsWith(key)) {
        return category;
      }
    }
    return "أخرى";
  };

  const groupPermissionsByCategory = (permissions: any[]) => {
    const grouped: Record<string, any[]> = {};
    permissions.forEach((p) => {
      const category = getPermissionCategory(p.id);
      if (!grouped[category]) {
        grouped[category] = [];
      }
      grouped[category].push(p);
    });
    return grouped;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">إدارة الأدوار والصلاحيات</h1>
        <p className="text-muted-foreground mt-2">
          إدارة الأدوار والصلاحيات المختلفة في النظام
        </p>
      </div>

      {userRole && (
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle>دورك الحالي</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-lg">{userRole.name}</p>
                <p className="text-sm text-muted-foreground">{userRole.description}</p>
              </div>
              <Badge className={getRoleColor(userRole.id)}>
                {userRole.permissionCount} صلاحية
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
          <TabsTrigger value="roles">الأدوار</TabsTrigger>
          <TabsTrigger value="permissions">الصلاحيات</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {roles.map((role) => (
              <Card key={role.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">{role.name}</CardTitle>
                  <CardDescription>{role.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Badge className={getRoleColor(role.id)}>
                    {role.permissionCount} صلاحية
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="roles" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {roles.map((role) => (
              <Card
                key={role.id}
                className={`cursor-pointer transition-all ${
                  selectedRole === role.id ? "ring-2 ring-blue-500" : ""
                }`}
                onClick={() => setSelectedRole(role.id as any)}
              >
                <CardHeader>
                  <CardTitle className="text-lg flex items-center justify-between">
                    {role.name}
                    <Badge className={getRoleColor(role.id)}>
                      {role.permissionCount}
                    </Badge>
                  </CardTitle>
                  <CardDescription>{role.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>

          {selectedRole && (
            <Card>
              <CardHeader>
                <CardTitle>صلاحيات دور {selectedRole}</CardTitle>
                <CardDescription>
                  جميع الصلاحيات المتاحة لهذا الدور
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(groupPermissionsByCategory(rolePermissions)).map(
                    ([category, permissions]) => (
                      <div key={category}>
                        <h4 className="font-semibold text-sm mb-2 text-muted-foreground">
                          {category}
                        </h4>
                        <div className="space-y-2 pl-4">
                          {permissions.map((permission) => (
                            <div
                              key={permission.id}
                              className="flex items-start gap-2 text-sm"
                            >
                              <span className="text-green-600 font-bold">✓</span>
                              <div>
                                <p className="font-medium">{permission.name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {permission.description}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="permissions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>جميع الصلاحيات المتاحة</CardTitle>
              <CardDescription>
                عرض جميع الصلاحيات والأدوار التي تملكها
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {Object.entries(groupPermissionsByCategory(allPermissions)).map(
                  ([category, permissions]) => (
                    <div key={category}>
                      <h4 className="font-semibold text-base mb-3 text-foreground">
                        {category}
                      </h4>
                      <div className="space-y-3 pl-4">
                        {permissions.map((permission: any) => (
                          <div key={permission.id} className="border-l-2 border-gray-200 pl-4">
                            <div className="flex items-start justify-between">
                              <div>
                                <p className="font-medium text-sm">{permission.name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {permission.description}
                                </p>
                              </div>
                              <div className="flex gap-1 flex-wrap justify-end">
                                {permission.roles.map((role: string) => (
                                  <Badge
                                    key={role}
                                    className={getRoleColor(role)}
                                    variant="secondary"
                                  >
                                    {role}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card className="bg-amber-50 border-amber-200">
        <CardHeader>
          <CardTitle className="text-base">معلومات مهمة</CardTitle>
        </CardHeader>
        <CardContent className="text-sm space-y-2">
          <p>
            <strong>المستخدم العادي:</strong> صلاحيات محدودة للعرض فقط
          </p>
          <p>
            <strong>الموظف:</strong> صلاحيات لإدارة الأعمال والفواتير والمصروفات
          </p>
          <p>
            <strong>المدير:</strong> صلاحيات واسعة لإدارة جميع العمليات
          </p>
          <p>
            <strong>المسؤول:</strong> صلاحيات كاملة على جميع النظام
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
