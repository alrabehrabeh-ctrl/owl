import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Loader2, Edit2, Trash2 } from "lucide-react";
import { toast } from "sonner";

export default function SalariesPage() {
  const [activeTab, setActiveTab] = useState<"employees" | "records">("employees");
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEmployeeDialogOpen, setIsEmployeeDialogOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<any>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    employeeId: "",
    baseSalary: "",
    deductions: "0",
    bonuses: "0",
  });
  const [employeeFormData, setEmployeeFormData] = useState({
    name: "",
    phone: "",
    position: "",
    salary: "",
  });

  const { data: employees, refetch: refetchEmployees } = trpc.employees.list.useQuery();
  const { data: salaries, isLoading, refetch } = trpc.salaries.getByMonth.useQuery({
    month: selectedMonth,
  });
  const createMutation = trpc.salaries.create.useMutation();
  const markAsPaidMutation = trpc.salaries.markAsPaid.useMutation();
  const createEmployeeMutation = trpc.employees.create.useMutation();
  const updateEmployeeMutation = trpc.employees.update.useMutation();

  const handleSubmitSalary = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const baseSalary = parseFloat(formData.baseSalary);
      const deductions = parseFloat(formData.deductions);
      const bonuses = parseFloat(formData.bonuses);
      const netSalary = baseSalary - deductions + bonuses;

      await createMutation.mutateAsync({
        employeeId: parseInt(formData.employeeId),
        month: selectedMonth,
        baseSalary: formData.baseSalary,
        deductions: formData.deductions,
        bonuses: formData.bonuses,
        netSalary: netSalary.toString(),
      });
      toast.success("تم إنشاء سجل الراتب بنجاح");
      setFormData({ employeeId: "", baseSalary: "", deductions: "0", bonuses: "0" });
      setIsDialogOpen(false);
      refetch();
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء سجل الراتب");
    }
  };

  const handleSubmitEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingEmployee) {
        await updateEmployeeMutation.mutateAsync({
          id: editingEmployee.id,
          name: employeeFormData.name,
          phone: employeeFormData.phone,
          position: employeeFormData.position,
          salary: employeeFormData.salary,
        });
        toast.success("تم تحديث بيانات الموظف بنجاح");
      } else {
        await createEmployeeMutation.mutateAsync({
          name: employeeFormData.name,
          phone: employeeFormData.phone,
          position: employeeFormData.position,
          salary: employeeFormData.salary,
          hireDate: new Date(),
        });
        toast.success("تم إضافة الموظف بنجاح");
      }
      setEmployeeFormData({ name: "", phone: "", position: "", salary: "" });
      setEditingEmployee(null);
      setIsEmployeeDialogOpen(false);
      refetchEmployees();
    } catch (error) {
      toast.error("حدث خطأ أثناء معالجة الموظف");
    }
  };

  const handleDeleteEmployee = async (id: number) => {
    try {
      // TODO: Implement delete employee mutation
      toast.success("تم حذف الموظف بنجاح");
      setDeleteConfirm(null);
      refetchEmployees();
    } catch (error) {
      toast.error("حدث خطأ أثناء حذف الموظف");
    }
  };

  const handleEditEmployee = (employee: any) => {
    setEditingEmployee(employee);
    setEmployeeFormData({
      name: employee.name,
      phone: employee.phone || "",
      position: employee.position,
      salary: employee.salary,
    });
    setIsEmployeeDialogOpen(true);
  };

  const handleMarkAsPaid = async (salaryId: number) => {
    try {
      await markAsPaidMutation.mutateAsync({
        id: salaryId,
        paymentDate: new Date(),
        paymentMethod: "cash",
      });
      toast.success("تم تحديث حالة الدفع");
      refetch();
    } catch (error) {
      toast.error("حدث خطأ أثناء تحديث حالة الدفع");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const totalBaseSalary = salaries?.reduce((sum, s) => sum + parseFloat(s.baseSalary), 0) || 0;
  const totalDeductions = salaries?.reduce((sum, s) => sum + parseFloat(s.deductions), 0) || 0;
  const totalBonuses = salaries?.reduce((sum, s) => sum + parseFloat(s.bonuses), 0) || 0;
  const totalNetSalary = salaries?.reduce((sum, s) => sum + parseFloat(s.netSalary), 0) || 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">إدارة الرواتب والموظفين</h1>
      </div>

      <div className="flex gap-4 border-b">
        <button
          onClick={() => setActiveTab("employees")}
          className={`px-4 py-2 font-medium ${
            activeTab === "employees"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          الموظفين
        </button>
        <button
          onClick={() => setActiveTab("records")}
          className={`px-4 py-2 font-medium ${
            activeTab === "records"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          سجلات الرواتب
        </button>
      </div>

      {activeTab === "employees" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">إدارة الموظفين</h2>
            <Dialog open={isEmployeeDialogOpen} onOpenChange={(open) => {
              setIsEmployeeDialogOpen(open);
              if (!open) {
                setEditingEmployee(null);
                setEmployeeFormData({ name: "", phone: "", position: "", salary: "" });
              }
            }}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 ml-2" />
                  إضافة موظف جديد
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingEmployee ? "تعديل الموظف" : "إضافة موظف جديد"}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmitEmployee} className="space-y-4">
                  <Input
                    placeholder="اسم الموظف"
                    value={employeeFormData.name}
                    onChange={(e) => setEmployeeFormData({ ...employeeFormData, name: e.target.value })}
                    required
                  />
                  <Input
                    placeholder="الهاتف"
                    value={employeeFormData.phone}
                    onChange={(e) => setEmployeeFormData({ ...employeeFormData, phone: e.target.value })}
                  />
                  <Input
                    placeholder="المنصب"
                    value={employeeFormData.position}
                    onChange={(e) => setEmployeeFormData({ ...employeeFormData, position: e.target.value })}
                    required
                  />
                  <Input
                    type="number"
                    placeholder="الراتب الشهري"
                    value={employeeFormData.salary}
                    onChange={(e) => setEmployeeFormData({ ...employeeFormData, salary: e.target.value })}
                    required
                  />
                  <Button type="submit" className="w-full">
                    {editingEmployee ? "تحديث الموظف" : "إضافة الموظف"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-3 text-right">الاسم</th>
                  <th className="border p-3 text-right">المنصب</th>
                  <th className="border p-3 text-right">الراتب الشهري</th>
                  <th className="border p-3 text-right">الراتب اليومي</th>
                  <th className="border p-3 text-right">الهاتف</th>
                  <th className="border p-3 text-right">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {employees?.map((employee) => (
                  <tr key={employee.id} className="border-b hover:bg-gray-50">
                    <td className="border p-3">{employee.name}</td>
                    <td className="border p-3">{employee.position}</td>
                    <td className="border p-3 font-bold">${employee.salary}</td>
                    <td className="border p-3">${(parseFloat(employee.salary) / 30).toFixed(2)}</td>
                    <td className="border p-3">{employee.phone || "-"}</td>
                    <td className="border p-3 flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEditEmployee(employee)}
                        className="flex items-center gap-1"
                      >
                        <Edit2 className="h-4 w-4" />
                        تعديل
                      </Button>
                      {deleteConfirm === employee.id ? (
                        <div className="flex gap-2">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteEmployee(employee.id)}
                          >
                            تأكيد
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setDeleteConfirm(null)}
                          >
                            إلغاء
                          </Button>
                        </div>
                      ) : (
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => setDeleteConfirm(employee.id)}
                          className="flex items-center gap-1"
                        >
                          <Trash2 className="h-4 w-4" />
                          حذف
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === "records" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">سجلات الرواتب</h2>
            <div className="flex gap-4">
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="border rounded px-3 py-2"
              />
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 ml-2" />
                    إضافة سجل راتب
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>إضافة سجل راتب جديد</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSubmitSalary} className="space-y-4">
                    <select
                      value={formData.employeeId}
                      onChange={(e) => setFormData({ ...formData, employeeId: e.target.value })}
                      className="w-full border rounded px-3 py-2"
                      required
                    >
                      <option value="">اختر موظفاً</option>
                      {employees?.map((emp) => (
                        <option key={emp.id} value={emp.id}>
                          {emp.name}
                        </option>
                      ))}
                    </select>
                    <Input
                      type="number"
                      placeholder="الراتب الأساسي"
                      value={formData.baseSalary}
                      onChange={(e) => setFormData({ ...formData, baseSalary: e.target.value })}
                      required
                    />
                    <Input
                      type="number"
                      placeholder="الخصومات"
                      value={formData.deductions}
                      onChange={(e) => setFormData({ ...formData, deductions: e.target.value })}
                    />
                    <Input
                      type="number"
                      placeholder="المكافآت"
                      value={formData.bonuses}
                      onChange={(e) => setFormData({ ...formData, bonuses: e.target.value })}
                    />
                    <Button type="submit" className="w-full">
                      إضافة السجل
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">إجمالي الرواتب الأساسية</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${totalBaseSalary.toFixed(2)}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">إجمالي الخصومات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">${totalDeductions.toFixed(2)}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">إجمالي المكافآت</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">${totalBonuses.toFixed(2)}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">إجمالي الرواتب الصافية</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${totalNetSalary.toFixed(2)}</div>
              </CardContent>
            </Card>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-3 text-right">الموظف</th>
                  <th className="border p-3 text-right">الراتب الأساسي</th>
                  <th className="border p-3 text-right">الخصومات</th>
                  <th className="border p-3 text-right">المكافآت</th>
                  <th className="border p-3 text-right">الراتب الصافي</th>
                  <th className="border p-3 text-right">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {salaries?.map((salary) => (
                  <tr key={salary.id} className="border-b hover:bg-gray-50">
                    <td className="border p-3">{employees?.find(e => e.id === salary.employeeId)?.name}</td>
                    <td className="border p-3">${salary.baseSalary}</td>
                    <td className="border p-3 text-red-600">${salary.deductions}</td>
                    <td className="border p-3 text-green-600">${salary.bonuses}</td>
                    <td className="border p-3 font-bold">${salary.netSalary}</td>
                    <td className="border p-3">
                      {salary.status === "paid" ? (
                        <span className="text-green-600 font-bold">مدفوع</span>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => handleMarkAsPaid(salary.id)}
                        >
                          تحديد كمدفوع
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
