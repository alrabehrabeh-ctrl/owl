import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, Mail } from "lucide-react";
import { toast } from "sonner";

export default function StatementPage() {
  const [selectedDoctor, setSelectedDoctor] = useState<string>("");
  const [selectedMonth, setSelectedMonth] = useState<string>(new Date().toISOString().slice(0, 7));

  // Queries
  const { data: doctors = [] } = trpc.doctors.list.useQuery();
  const { data: works = [] } = trpc.works.list.useQuery();
  const { data: invoices = [] } = trpc.invoices.list.useQuery();
  const { data: payments = [] } = trpc.payments.list.useQuery();

  // Filter data by selected doctor and month
  const doctorId = selectedDoctor ? parseInt(selectedDoctor) : null;
  const [year, month] = selectedMonth.split("-");

  const doctorWorks = doctorId
    ? (works as any[]).filter((w: any) => w.doctorId === doctorId && new Date(w.createdAt).getMonth() === parseInt(month) - 1)
    : [];

  const doctorInvoices = doctorId
    ? (invoices as any[]).filter((i: any) => i.doctorId === doctorId && new Date(i.invoiceDate).getMonth() === parseInt(month) - 1)
    : [];

  const doctorPayments = doctorId
    ? (payments as any[]).filter((p: any) => {
        const invoice = (invoices as any[]).find((i: any) => i.id === p.invoiceId);
        return invoice?.doctorId === doctorId && new Date(p.paymentDate).getMonth() === parseInt(month) - 1;
      })
    : [];

  // Calculate totals
  const totalWorks = doctorWorks.reduce((sum: number, w: any) => sum + parseFloat(w.totalPrice || "0"), 0);
  const totalInvoiced = doctorInvoices.reduce((sum: number, i: any) => sum + parseFloat(i.totalAmount || "0"), 0);
  const totalPaid = doctorPayments.reduce((sum: number, p: any) => sum + parseFloat(p.amount || "0"), 0);
  const totalDue = totalInvoiced - totalPaid;

  const doctor = doctors.find((d: any) => d.id === doctorId);

  const handleDownloadStatement = () => {
    // Generate PDF or Excel file
    toast.success("جاري تحميل كشف الحساب...");
  };

  const handleSendEmail = () => {
    if (!doctor?.email) {
      toast.error("لا يوجد بريد إلكتروني للطبيب");
      return;
    }
    toast.success("جاري إرسال كشف الحساب عبر البريد الإلكتروني...");
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">كشف الحساب الشهري</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleDownloadStatement} className="gap-2">
            <Download className="w-4 h-4" />
            تحميل
          </Button>
          <Button variant="outline" onClick={handleSendEmail} className="gap-2">
            <Mail className="w-4 h-4" />
            إرسال بريد
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-2">الطبيب</label>
          <Select value={selectedDoctor} onValueChange={setSelectedDoctor}>
            <SelectTrigger>
              <SelectValue placeholder="اختر الطبيب" />
            </SelectTrigger>
            <SelectContent>
              {doctors.map((doctor: any) => (
                <SelectItem key={doctor.id} value={String(doctor.id)}>
                  {doctor.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">الشهر والسنة</label>
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="w-full border rounded px-3 py-2"
          />
        </div>
      </div>

      {selectedDoctor && doctor && (
        <div className="space-y-6">
          {/* Doctor Info */}
          <Card className="p-6">
            <h2 className="text-2xl font-bold mb-4">بيانات الطبيب</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-gray-600">الاسم</p>
                <p className="text-lg font-semibold">{doctor.name}</p>
              </div>
              <div>
                <p className="text-gray-600">الرقم</p>
                <p className="text-lg font-semibold">{doctor.id}</p>
              </div>
              <div>
                <p className="text-gray-600">البريد الإلكتروني</p>
                <p className="text-lg font-semibold">{doctor.email || "-"}</p>
              </div>
              <div>
                <p className="text-gray-600">الهاتف</p>
                <p className="text-lg font-semibold">{doctor.phone || "-"}</p>
              </div>
            </div>
          </Card>

          {/* Summary */}
          <div className="grid grid-cols-4 gap-4">
            <Card className="p-4">
              <p className="text-gray-600 text-sm">إجمالي الأعمال</p>
              <p className="text-2xl font-bold text-blue-600">{totalWorks.toFixed(2)} ر.س</p>
            </Card>
            <Card className="p-4">
              <p className="text-gray-600 text-sm">إجمالي الفواتير</p>
              <p className="text-2xl font-bold text-purple-600">{totalInvoiced.toFixed(2)} ر.س</p>
            </Card>
            <Card className="p-4">
              <p className="text-gray-600 text-sm">المبلغ المدفوع</p>
              <p className="text-2xl font-bold text-green-600">{totalPaid.toFixed(2)} ر.س</p>
            </Card>
            <Card className="p-4">
              <p className="text-gray-600 text-sm">المبلغ المستحق</p>
              <p className={`text-2xl font-bold ${totalDue > 0 ? "text-red-600" : "text-green-600"}`}>
                {totalDue.toFixed(2)} ر.س
              </p>
            </Card>
          </div>

          {/* Works Table */}
          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">الأعمال المقدمة</h3>
            {doctorWorks.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="p-2 text-right">رقم العمل</th>
                      <th className="p-2 text-right">الوصف</th>
                      <th className="p-2 text-right">التاريخ</th>
                      <th className="p-2 text-right">المبلغ</th>
                      <th className="p-2 text-right">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {doctorWorks.map((work: any) => (
                      <tr key={work.id} className="border-b">
                        <td className="p-2">{work.id}</td>
                        <td className="p-2">{work.description}</td>
                        <td className="p-2">{new Date(work.createdAt).toLocaleDateString("ar-SA")}</td>
                        <td className="p-2">{parseFloat(work.totalPrice || "0").toFixed(2)} ر.س</td>
                        <td className="p-2">
                          <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                            {work.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-600">لا توجد أعمال في هذا الشهر</p>
            )}
          </Card>

          {/* Invoices Table */}
          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">الفواتير</h3>
            {doctorInvoices.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="p-2 text-right">رقم الفاتورة</th>
                      <th className="p-2 text-right">التاريخ</th>
                      <th className="p-2 text-right">المبلغ</th>
                      <th className="p-2 text-right">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {doctorInvoices.map((invoice: any) => (
                      <tr key={invoice.id} className="border-b">
                        <td className="p-2">{invoice.invoiceNumber}</td>
                        <td className="p-2">{new Date(invoice.invoiceDate).toLocaleDateString("ar-SA")}</td>
                        <td className="p-2">{parseFloat(invoice.totalAmount || "0").toFixed(2)} ر.س</td>
                        <td className="p-2">
                          <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded text-xs">
                            {invoice.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-600">لا توجد فواتير في هذا الشهر</p>
            )}
          </Card>

          {/* Payments Table */}
          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">الدفعات المستلمة</h3>
            {doctorPayments.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="p-2 text-right">التاريخ</th>
                      <th className="p-2 text-right">المبلغ</th>
                      <th className="p-2 text-right">طريقة الدفع</th>
                      <th className="p-2 text-right">الملاحظات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {doctorPayments.map((payment: any) => (
                      <tr key={payment.id} className="border-b">
                        <td className="p-2">{new Date(payment.paymentDate).toLocaleDateString("ar-SA")}</td>
                        <td className="p-2">{parseFloat(payment.amount || "0").toFixed(2)} ر.س</td>
                        <td className="p-2">{payment.paymentMethod}</td>
                        <td className="p-2">{payment.notes || "-"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-600">لا توجد دفعات في هذا الشهر</p>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}
