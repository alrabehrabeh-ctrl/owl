import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  Trash2,
  Edit2,
  Key,
  Search,
  Users,
  ArrowUpDown,
  Mail,
  Calendar,
} from "lucide-react";
import { toast } from "sonner";

type SortField = "name" | "email" | "role" | "createdAt";
type SortOrder = "asc" | "desc";

export default function UsersPage() {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortField, setSortField] = useState<SortField>("createdAt");
  const [sortOrder, setSortOrder] = useState<SortOrder>("desc");
  const [roleFilter, setRoleFilter] = useState<"all" | "user" | "admin">("all");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    role: "user" as "user" | "admin",
  });

  const utils = trpc.useUtils();
  const { data: users = [], isLoading } = trpc.users.getAll.useQuery(undefined, {
    staleTime: 1000 * 60 * 5, // 5 minutes
    gcTime: 1000 * 60 * 10, // 10 minutes
  });
  const createMutation = trpc.users.create.useMutation();
  const updateMutation = trpc.users.update.useMutation();
  const deleteMutation = trpc.users.delete.useMutation();
  const switchUserMutation = trpc.users.switchUser.useMutation();
  const resetPasswordMutation = trpc.authUsername.resetPassword.useMutation();

  // البحث والفرز والتصفية
  const filteredAndSortedUsers = useMemo(() => {
    let filtered = users.filter((user) => {
      const matchesSearch =
        user.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.username?.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesRole =
        roleFilter === "all" || user.role === roleFilter;

      return matchesSearch && matchesRole;
    });

    // الترتيب
    filtered.sort((a, b) => {
      let aValue: any;
      let bValue: any;

      switch (sortField) {
        case "name":
          aValue = a.name || "";
          bValue = b.name || "";
          break;
        case "email":
          aValue = a.email || "";
          bValue = b.email || "";
          break;
        case "role":
          aValue = a.role;
          bValue = b.role;
          break;
        case "createdAt":
          aValue = new Date(a.createdAt).getTime();
          bValue = new Date(b.createdAt).getTime();
          break;
      }

      if (aValue < bValue) return sortOrder === "asc" ? -1 : 1;
      if (aValue > bValue) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });

    return filtered;
  }, [users, searchQuery, sortField, sortOrder, roleFilter]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (isSubmitting) return;
    setIsSubmitting(true);

    try {
      if (editingId) {
        await updateMutation.mutateAsync({
          id: editingId,
          data: formData,
        });
        toast.success("تم تحديث بيانات المستخدم بنجاح");
      } else {
        await createMutation.mutateAsync(formData);
        toast.success("تم إضافة المستخدم الجديد بنجاح");
      }

      setFormData({ name: "", email: "", role: "user" as "user" | "admin" });
      setEditingId(null);
      setOpen(false);
      utils.users.getAll.invalidate();
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء العملية");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (user: any) => {
    setFormData({
      name: user.name || "",
      email: user.email || "",
      role: user.role,
    });
    setEditingId(user.id);
    setOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف هذا المستخدم؟")) return;

    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("تم حذف المستخدم بنجاح");
      utils.users.getAll.invalidate();
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء الحذف");
    }
  };

  const handleRoleChange = async (userId: number, newRole: "user" | "admin") => {
    try {
      await updateMutation.mutateAsync({
        id: userId,
        data: { role: newRole },
      });
      toast.success("تم تحديث دور المستخدم بنجاح");
      setTimeout(() => {
        utils.users.getAll.invalidate();
      }, 500);
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء التحديث");
    }
  };

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("asc");
    }
  };

  const getRoleBadgeColor = (role: string) => {
    return role === "admin"
      ? "bg-red-100 text-red-800"
      : "bg-blue-100 text-blue-800";
  };

  const getRoleLabel = (role: string) => {
    return role === "admin" ? "مسؤول" : "مستخدم عادي";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-blue-100 p-3 rounded-lg">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">إدارة المستخدمين</h1>
              <p className="text-muted-foreground mt-1">
                إدارة المستخدمين وصلاحياتهم في النظام
              </p>
            </div>
          </div>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button
              onClick={() => {
                setFormData({ name: "", email: "", role: "user" as "user" | "admin" });
                setEditingId(null);
              }}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              إضافة مستخدم جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingId ? "تعديل المستخدم" : "إضافة مستخدم جديد"}
              </DialogTitle>
              <DialogDescription>
                {editingId
                  ? "قم بتعديل بيانات المستخدم أدناه"
                  : "أضف مستخدم جديد إلى النظام"}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">الاسم الكامل</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  placeholder="أدخل اسم المستخدم"
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">البريد الإلكتروني</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  placeholder="أدخل البريد الإلكتروني"
                  required
                />
              </div>
              <div>
                <Label htmlFor="role">الدور</Label>
                <Select
                  value={formData.role}
                  onValueChange={(value) =>
                    setFormData({
                      ...formData,
                      role: value as "user" | "admin",
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">مستخدم عادي</SelectItem>
                    <SelectItem value="admin">مسؤول</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1" disabled={isSubmitting}>
                  {isSubmitting ? "جاري المعالجة..." : editingId ? "تحديث" : "إضافة"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setOpen(false)}
                  className="flex-1"
                >
                  إلغاء
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm">إجمالي المستخدمين</p>
              <p className="text-3xl font-bold mt-2">{users.length}</p>
            </div>
            <Users className="w-8 h-8 text-blue-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm">المسؤولون</p>
              <p className="text-3xl font-bold mt-2">
                {users.filter((u) => u.role === "admin").length}
              </p>
            </div>
            <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
              <span className="text-red-600 font-bold">A</span>
            </div>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm">مستخدمون عاديون</p>
              <p className="text-3xl font-bold mt-2">
                {users.filter((u) => u.role === "user").length}
              </p>
            </div>
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
              <span className="text-blue-600 font-bold">U</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card className="p-6">
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="ابحث عن المستخدمين بالاسم أو البريد الإلكتروني..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
            </div>
            <Select value={roleFilter} onValueChange={(value: any) => setRoleFilter(value)}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الأدوار</SelectItem>
                <SelectItem value="user">مستخدم عادي</SelectItem>
                <SelectItem value="admin">مسؤول</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {/* Users Table */}
      <Card className="overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center">
            <div className="inline-block">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
            <p className="mt-4 text-muted-foreground">جاري تحميل المستخدمين...</p>
          </div>
        ) : filteredAndSortedUsers.length === 0 ? (
          <div className="p-12 text-center">
            <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground">
              {searchQuery || roleFilter !== "all"
                ? "لا توجد مستخدمين تطابق معايير البحث"
                : "لا توجد مستخدمين في النظام"}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead
                    className="cursor-pointer hover:bg-gray-100 transition"
                    onClick={() => toggleSort("name")}
                  >
                    <div className="flex items-center gap-2">
                      الاسم
                      {sortField === "name" && (
                        <ArrowUpDown className="w-4 h-4" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead>اسم المستخدم</TableHead>
                  <TableHead
                    className="cursor-pointer hover:bg-gray-100 transition"
                    onClick={() => toggleSort("email")}
                  >
                    <div className="flex items-center gap-2">
                      البريد الإلكتروني
                      {sortField === "email" && (
                        <ArrowUpDown className="w-4 h-4" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead
                    className="cursor-pointer hover:bg-gray-100 transition"
                    onClick={() => toggleSort("role")}
                  >
                    <div className="flex items-center gap-2">
                      الدور
                      {sortField === "role" && (
                        <ArrowUpDown className="w-4 h-4" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead
                    className="cursor-pointer hover:bg-gray-100 transition"
                    onClick={() => toggleSort("createdAt")}
                  >
                    <div className="flex items-center gap-2">
                      تاريخ الإنشاء
                      {sortField === "createdAt" && (
                        <ArrowUpDown className="w-4 h-4" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead className="text-center">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAndSortedUsers.map((user) => (
                  <TableRow
                    key={user.id}
                    className="hover:bg-gray-50 transition"
                  >
                    <TableCell className="font-semibold">{user.name}</TableCell>
                    <TableCell className="font-mono text-sm text-muted-foreground">
                      {user.username}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-muted-foreground" />
                        {user.email}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getRoleBadgeColor(user.role)}>
                        {getRoleLabel(user.role)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        {new Date(user.createdAt).toLocaleDateString("ar-SA")}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2 justify-center">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(user)}
                          title="تعديل المستخدم"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            if (!switchUserMutation.isPending) {
                              switchUserMutation.mutate({ userId: user.id });
                              toast.success("تم تبديل المستخدم بنجاح");
                            }
                          }}
                          disabled={switchUserMutation.isPending}
                          title="تبديل المستخدم"
                        >
                          تبديل
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const newPassword = prompt("أدخل كلمة المرور الجديدة:");
                            if (newPassword && newPassword.length >= 6) {
                              resetPasswordMutation.mutate(
                                { userId: user.id, newPassword },
                                {
                                  onSuccess: () => {
                                    toast.success("تم إعادة تعيين كلمة المرور بنجاح");
                                  },
                                  onError: (error: any) => {
                                    toast.error(
                                      error.message ||
                                        "فشل إعادة تعيين كلمة المرور"
                                    );
                                  },
                                }
                              );
                            } else if (newPassword) {
                              toast.error("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
                            }
                          }}
                          title="إعادة تعيين كلمة المرور"
                        >
                          <Key className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(user.id)}
                          title="حذف المستخدم"
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>

      {/* Footer Info */}
      {filteredAndSortedUsers.length > 0 && (
        <div className="text-sm text-muted-foreground text-center">
          عرض {filteredAndSortedUsers.length} من {users.length} مستخدم
        </div>
      )}
    </div>
  );
}
