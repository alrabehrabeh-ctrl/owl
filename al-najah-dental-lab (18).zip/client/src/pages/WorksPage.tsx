import { useState, useEffect, useRef, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Loader2, X, Upload, Edit2, Trash2, Calendar, ChevronDown, ChevronUp, Copy, Zap, Download } from "lucide-react";
import { toast } from "sonner";
import { exportWorksToExcel } from "@/lib/exportToExcel";
import { TeethSelector } from "@/components/TeethSelector";
import { TeethPreview } from "@/components/TeethPreview";
import { SelectedTeethPreview } from "@/components/SelectedTeethPreview";

function safeJsonParse(jsonString: string | null | undefined, defaultValue: any = []) {
  if (!jsonString) return defaultValue;
  try {
    const parsed = JSON.parse(jsonString);
    return Array.isArray(parsed) ? parsed : defaultValue;
  } catch (error) {
    console.warn("Failed to parse JSON:", jsonString, error);
    return defaultValue;
  }
}

const STATUS_COLORS: { [key: string]: { bg: string; border: string; label: string } } = {
  pending: {
    bg: "bg-gradient-to-br from-yellow-200 to-yellow-300",
    border: "border-yellow-400",
    label: "معلق"
  },
  in_progress: {
    bg: "bg-gradient-to-br from-blue-200 to-blue-300",
    border: "border-blue-400",
    label: "قيد التنفيذ"
  },
  completed: {
    bg: "bg-gradient-to-br from-green-200 to-green-300",
    border: "border-green-400",
    label: "مكتمل"
  },
  delivered: {
    bg: "bg-gradient-to-br from-purple-200 to-purple-300",
    border: "border-purple-400",
    label: "تم التسليم"
  }
};

function getCardColorByStatus(status: string) {
  return STATUS_COLORS[status] || STATUS_COLORS.pending;
}

export default function WorksPage() {
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingWork, setEditingWork] = useState<any>(null);
  const [quickMode, setQuickMode] = useState(false);
  const [recentPatients, setRecentPatients] = useState<string[]>([]);
  const [lastWorkData, setLastWorkData] = useState<any>(null);
  
  const [formData, setFormData] = useState<{
    doctorId: string;
    patientName: string;
    workType: string;
    workTypeId: string;
    receptionDate: string;
    deliveryDate: string;
    amount: string;
    status: "pending" | "in_progress" | "completed" | "delivered";
    notes: string;
    toothNumbers: string[];
  }>({
    doctorId: "",
    patientName: "",
    workType: "",
    workTypeId: "",
    receptionDate: new Date().toISOString().split("T")[0],
    deliveryDate: "",
    amount: "",
    status: "pending",
    notes: "",
    toothNumbers: [] as string[],
  });
  
  const calculateDefaultDeliveryDate = (receptionDate: string) => {
    const date = new Date(receptionDate);
    date.setDate(date.getDate() + 5);
    return date.toISOString().split("T")[0];
  };
  
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterDoctor, setFilterDoctor] = useState<string>("all");
  const [filterDateFrom, setFilterDateFrom] = useState<string>("");
  const [filterDateTo, setFilterDateTo] = useState<string>("");
  const patientInputRef = useRef<HTMLInputElement>(null);
  const doctorSelectRef = useRef<HTMLSelectElement>(null);

  const { data: works, isLoading, refetch } = trpc.works.listWithDoctorAndTypes.useQuery();
  
  useEffect(() => {
    console.log('Works loaded:', works?.length, 'isLoading:', isLoading);
    if (works && works.length > 0) {
      console.log('First work:', works[0]);
    }
  }, [works, isLoading]);
  
  const { data: doctors } = trpc.doctors.list.useQuery();
  const { data: workTypes = [] } = trpc.workTypes.list.useQuery();
  const createMutation = trpc.works.create.useMutation();
  const updateMutation = trpc.works.update.useMutation();
  const deleteMutation = trpc.works.delete.useMutation();

  useEffect(() => {
    const saved = localStorage.getItem("recentPatients");
    if (saved) {
      setRecentPatients(JSON.parse(saved));
    }
    const lastWork = localStorage.getItem("lastWorkData");
    if (lastWork) {
      setLastWorkData(JSON.parse(lastWork));
    }
  }, []);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "n") {
        e.preventDefault();
        setIsDialogOpen(true);
        setEditingWork(null);
        const today = new Date().toISOString().split("T")[0];
        setFormData({
          doctorId: "",
          patientName: "",
          workType: "",
          workTypeId: "",
          receptionDate: today,
          deliveryDate: calculateDefaultDeliveryDate(today),
          amount: "",
          status: "pending",
          notes: "",
          toothNumbers: [],
        });
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, []);

  const getDoctorName = (doctorId: number) => {
    return doctors?.find((d: any) => d.id === doctorId)?.name || `طبيب #${doctorId}`;
  };

  const getStatusLabel = (status: string) => {
    const labels: { [key: string]: string } = {
      pending: "معلق",
      in_progress: "قيد التنفيذ",
      completed: "مكتمل",
      delivered: "تم التسليم",
    };
    return labels[status] || status;
  };

  const getStatusColor = (status: string) => {
    const colors: { [key: string]: string } = {
      pending: "bg-yellow-100 text-yellow-800",
      in_progress: "bg-blue-100 text-blue-800",
      completed: "bg-green-100 text-green-800",
      delivered: "bg-purple-100 text-purple-800",
    };
    return colors[status] || "bg-gray-100 text-gray-800";
  };

  const formatDate = (date: string | Date | undefined) => {
    if (!date) return "-";
    const d = new Date(date);
    return d.toLocaleDateString("ar-SA");
  };

  const filteredWorks = works?.filter((work) => {
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = !searchTerm || 
      (work.patientName?.toLowerCase().includes(searchLower)) ||
      (work.doctorName?.toLowerCase().includes(searchLower)) ||
      (work.description?.toLowerCase().includes(searchLower)) ||
      (work.workTypeName?.toLowerCase().includes(searchLower));
    const matchesStatus = filterStatus === "all" || work.status === filterStatus;
    const matchesDoctor = filterDoctor === "all" || work.doctorId.toString() === filterDoctor;
    let matchesDate = true;
    if (filterDateFrom || filterDateTo) {
      const workDate = work.createdAt ? new Date(work.createdAt).getTime() : 0;
      if (filterDateFrom) {
        const fromDate = new Date(filterDateFrom).getTime();
        if (workDate < fromDate) matchesDate = false;
      }
      if (filterDateTo) {
        const toDate = new Date(filterDateTo).getTime();
        if (workDate > toDate) matchesDate = false;
      }
    }
    return matchesSearch && matchesStatus && matchesDoctor && matchesDate;
  }).sort((a, b) => {
    const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    return dateB - dateA; // ترتيب تنازلي - الأحدث في الأعلى
  });

  const handleStatusChange = async (workId: number, newStatus: string) => {
    try {
      await updateMutation.mutateAsync({
        id: workId,
        status: newStatus as "pending" | "in_progress" | "completed" | "delivered",
      });
      refetch();
      toast.success("تم تحديث حالة العمل");
    } catch (error) {
      toast.error("فشل تحديث حالة العمل");
    }
  };

  const handleEditWork = (work: any) => {
    setEditingWork(work);
    setFormData({
      doctorId: work.doctorId.toString(),
      patientName: work.patientName,
      workType: work.workTypeId.toString(),
      workTypeId: work.workTypeId.toString(),
      receptionDate: work.receptionDate ? new Date(work.receptionDate).toISOString().split("T")[0] : "",
      deliveryDate: work.dueDate ? new Date(work.dueDate).toISOString().split("T")[0] : "",
      amount: work.totalPrice?.toString() || "",
      status: work.status,
      notes: work.notes || "",
      toothNumbers: safeJsonParse(work.toothNumbers),
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (workId: number) => {
    if (confirm("هل أنت متأكد من حذف هذا العمل؟")) {
      try {
        await deleteMutation.mutateAsync({ id: workId });
        refetch();
        toast.success("تم حذف العمل");
      } catch (error) {
        toast.error("فشل حذف العمل");
      }
    }
  };  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // تحديد تاريخ التسليم - استخدام القيمة المدخلة أو حساب افتراضي
      const deliveryDate = formData.deliveryDate 
        ? new Date(formData.deliveryDate)
        : calculateDefaultDeliveryDate(formData.receptionDate) 
          ? new Date(calculateDefaultDeliveryDate(formData.receptionDate))
          : new Date(formData.receptionDate);

      if (editingWork) {
        await updateMutation.mutateAsync({
          id: editingWork.id,
          doctorId: parseInt(formData.doctorId),
          patientName: formData.patientName || "- غير معروف",
          workTypeId: parseInt(formData.workTypeId),
          receptionDate: new Date(formData.receptionDate),
          dueDate: deliveryDate,
          unitPrice: formData.amount,
          totalPrice: formData.amount,
          status: formData.status as "pending" | "in_progress" | "completed" | "delivered",
          notes: formData.notes,
          toothNumbers: JSON.stringify(formData.toothNumbers),
        });
        toast.success("تم تحديث العمل");
      } else {
        await createMutation.mutateAsync({
          doctorId: parseInt(formData.doctorId),
          patientName: formData.patientName || "- غير معروف",
          workTypeId: parseInt(formData.workTypeId),
          receptionDate: new Date(formData.receptionDate),
          dueDate: deliveryDate,
          unitPrice: formData.amount,
          totalPrice: formData.amount,
          status: formData.status as "pending" | "in_progress" | "completed" | "delivered",
          notes: formData.notes,
          toothNumbers: JSON.stringify(formData.toothNumbers),
        });
        toast.success("تم إضافة العمل");
        
        const newRecentPatients = [formData.patientName, ...recentPatients.filter(p => p !== formData.patientName)].slice(0, 10);
        setRecentPatients(newRecentPatients);
        localStorage.setItem("recentPatients", JSON.stringify(newRecentPatients));
        
        setLastWorkData({
          doctorId: formData.doctorId,
          workTypeId: formData.workTypeId,
        });
        localStorage.setItem("lastWorkData", JSON.stringify({
          doctorId: formData.doctorId,
          workTypeId: formData.workTypeId,
        }));
      }
      
      refetch();
      setIsDialogOpen(false);
      setEditingWork(null);
      setFormData({
        doctorId: "",
        patientName: "",
        workType: "",
        workTypeId: "",
        receptionDate: new Date().toISOString().split("T")[0],
        deliveryDate: "",
        amount: "",
        status: "pending",
        notes: "",
        toothNumbers: [],
      });
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">الأعمال</h1>
        <div className="flex gap-2">
          <Button
            onClick={() => exportWorksToExcel(filteredWorks || [])}
            variant="outline"
            className="gap-2"
          >
            <Download className="h-4 w-4" />
            تصدير
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button
                onClick={() => {
                  setEditingWork(null);
                  const today = new Date().toISOString().split("T")[0];
                  setFormData({
                    doctorId: lastWorkData?.doctorId || "",
                    patientName: "",
                    workType: "",
                    workTypeId: lastWorkData?.workTypeId || "",
                    receptionDate: today,
                    deliveryDate: calculateDefaultDeliveryDate(today),
                    amount: "",
                    status: "pending" as const,
                    notes: "",
                    toothNumbers: [],
                  });
                }}
                className="gap-2"
              >
                <Plus className="h-4 w-4" />
                عمل جديد
              </Button>
            </DialogTrigger>
            <DialogContent className="w-screen h-screen max-w-none p-0 rounded-none flex" style={{ maxWidth: '1800px', margin: '0 auto' }}>
              <div className="flex flex-col p-8 overflow-y-auto bg-white" style={{ width: '50%', maxWidth: '100%' }}>
                <DialogHeader className="mb-6">
                  <DialogTitle className="text-2xl">{editingWork ? "تعديل العمل" : "إضافة عمل جديد"}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 flex-1">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">الطبيب *</label>
                      <select
                        ref={doctorSelectRef}
                        value={formData.doctorId}
                        onChange={(e) => setFormData({ ...formData, doctorId: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full border rounded px-3 py-2"
                      >
                        <option value="">اختر طبيب</option>
                        {doctors?.map((doc: any) => (
                          <option key={doc.id} value={doc.id}>
                            {doc.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">اسم المريض *</label>
                      <input
                        ref={patientInputRef}
                        type="text"
                        value={formData.patientName}
                        onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        list="patients"
                        placeholder="اسم المريض"
                        className="w-full border rounded px-3 py-2"
                      />
                      <datalist id="patients">
                        {recentPatients.map((patient) => (
                          <option key={patient} value={patient} />
                        ))}
                      </datalist>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">نوع العمل *</label>
                      <select
                        value={formData.workTypeId}
                        onChange={(e) => setFormData({ ...formData, workTypeId: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full border rounded px-3 py-2"
                      >
                        <option value="">اختر نوع العمل</option>
                        {workTypes.map((type: any) => (
                          <option key={type.id} value={type.id}>
                            {type.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">المبلغ</label>
                      <input
                        type="number"
                        value={formData.amount}
                        onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        placeholder="0.00"
                        step="0.01"
                        className="w-full border rounded px-3 py-2"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">تاريخ الاستقبال</label>
                      <input
                        type="date"
                        value={formData.receptionDate}
                        onChange={(e) => {
                          const newDate = e.target.value;
                          setFormData({
                            ...formData,
                            receptionDate: newDate,
                            deliveryDate: calculateDefaultDeliveryDate(newDate),
                          });
                        }}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full border rounded px-3 py-2"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">تاريخ التسليم</label>
                      <input
                        type="date"
                        value={formData.deliveryDate}
                        onChange={(e) => setFormData({ ...formData, deliveryDate: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full border rounded px-3 py-2"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">الحالة</label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value as "pending" | "in_progress" | "completed" | "delivered" })}
                      onClick={(e) => e.stopPropagation()}
                      className="w-full border rounded px-3 py-2"
                    >
                      <option value="pending">معلق</option>
                      <option value="in_progress">قيد التنفيذ</option>
                      <option value="completed">مكتمل</option>
                      <option value="delivered">تم التسليم</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">الملاحظات</label>
                    <textarea
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      onClick={(e) => e.stopPropagation()}
                      placeholder="أضف ملاحظات إضافية"
                      className="w-full border rounded px-3 py-2 h-20"
                    />
                  </div>

                  <div className="flex gap-2 justify-end">
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                      إلغاء
                    </Button>
                    <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                      {createMutation.isPending || updateMutation.isPending ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          جاري...
                        </>
                      ) : (
                        "حفظ"
                      )}
                    </Button>
                  </div>
                </form>
              </div>
              <div className="bg-gray-50 p-8 overflow-y-auto border-l border-gray-200" style={{ width: '50%' }}>
                <h3 className="text-lg font-semibold mb-4">ارقام الاسنان</h3>
                <TeethSelector
                  selectedTeeth={formData.toothNumbers}
                  onChange={(teeth) => {
                    setFormData({ ...formData, toothNumbers: teeth });
                  }}
                />
                {formData.toothNumbers.length > 0 && (
                  <div className="mt-6">
                    <h4 className="text-sm font-medium mb-2">الاسنان المختارة:</h4>
                    <SelectedTeethPreview selectedTeeth={formData.toothNumbers} />
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="bg-blue-50 rounded-lg p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">بحث</label>
            <Input
              type="text"
              placeholder="ابحث عن عمل..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">الحالة</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full border rounded px-3 py-2 text-sm"
            >
              <option value="all">الكل</option>
              <option value="pending">معلق</option>
              <option value="in_progress">قيد التنفيذ</option>
              <option value="completed">مكتمل</option>
              <option value="delivered">تم التسليم</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">الطبيب</label>
            <select
              value={filterDoctor}
              onChange={(e) => setFilterDoctor(e.target.value)}
              className="w-full border rounded px-3 py-2 text-sm"
            >
              <option value="all">الكل</option>
              {doctors?.map((doc: any) => (
                <option key={doc.id} value={doc.id}>
                  {doc.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">من التاريخ</label>
            <Input
              type="date"
              value={filterDateFrom}
              onChange={(e) => setFilterDateFrom(e.target.value)}
              className="text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">إلى التاريخ</label>
            <Input
              type="date"
              value={filterDateTo}
              onChange={(e) => setFilterDateTo(e.target.value)}
              className="text-sm"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredWorks?.map((work: any) => {
          const colorConfig = getCardColorByStatus(work.status);
          const isOverdue = work.dueDate && new Date(work.dueDate) < new Date() && work.status !== "delivered" && work.status !== "completed";
          return (
            <div
              key={work.id}
              className={`bg-white text-gray-800 rounded-lg p-4 shadow-md hover:shadow-lg transition-all duration-300 relative overflow-hidden group border-l-4 ${colorConfig.border}`}
            >
              <div className="absolute top-2 right-2 px-3 py-1 rounded-full text-xs font-bold border border-2" style={{
                backgroundColor: colorConfig.border.replace('border-', 'bg-').split('-')[1] ? `var(--color-${colorConfig.border.split('-')[1]})` : '#f0f0f0',
                borderColor: 'currentColor',
                color: colorConfig.border.includes('yellow') ? '#b8860b' : colorConfig.border.includes('blue') ? '#1e40af' : colorConfig.border.includes('green') ? '#15803d' : '#6b21a8'
              }}>
                {colorConfig.label}
              </div>
              
              <div className="relative z-10 pt-6">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <h3 className="font-bold text-lg line-clamp-2">{work.patientName || "بدون اسم"}</h3>
                    <p className="text-sm opacity-90">{work.doctorName || "-"}</p>
                  </div>
                </div>

                <div className="space-y-2 mb-3 text-sm opacity-95">
                  <div className="flex justify-between">
                    <span className="font-semibold">النوع:</span>
                    <span>{work.workTypeName || "-"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold">التاريخ:</span>
                    <span>{formatDate(work.dueDate || work.receptionDate)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold">السعر:</span>
                    <span className="font-bold">${parseFloat(work.totalPrice || "0").toFixed(2)}</span>
                  </div>
                  
                  {work.toothNumbers && work.toothNumbers !== '[]' && (
                    <div className="pt-2 border-t border-gray-200">
                      <p className="text-xs font-semibold mb-1">أرقام الأسنان:</p>
                      <TeethPreview selectedTeeth={safeJsonParse(work.toothNumbers)} size="sm" />
                    </div>
                  )}
                  
                  {work.notes && (
                    <div className="pt-2 border-t border-gray-200">
                      <p className="text-xs text-gray-600">{work.notes}</p>
                    </div>
                  )}
                </div>

                <div className="flex gap-2 pt-3 border-t border-gray-200">
                  <select
                    value={work.status}
                    onChange={(e) => handleStatusChange(work.id, e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                    className="flex-1 text-xs border-0 rounded px-2 py-1 bg-white bg-opacity-90 text-gray-800"
                  >
                    <option value="pending">معلق</option>
                    <option value="in_progress">قيد التنفيذ</option>
                    <option value="completed">مكتمل</option>
                    <option value="delivered">تم التسليم</option>
                  </select>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleEditWork(work)}
                    className="h-8 w-8 p-0 bg-white bg-opacity-90 hover:bg-opacity-100"
                  >
                    <Edit2 className="h-4 w-4 text-gray-800" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDelete(work.id)}
                    className="h-8 w-8 p-0 bg-white bg-opacity-90 hover:bg-opacity-100"
                  >
                    <Trash2 className="h-4 w-4 text-red-600" />
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {(!filteredWorks || filteredWorks.length === 0) && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">لا توجد أعمال لعرضها</p>
        </div>
      )}
    </div>
  );
}
