import jsPDF from "jspdf";
import { toast } from "sonner";

export interface InvoiceItem {
  id: number;
  invoiceId: number;
  workId?: number | null;
  description: string;
  quantity: number;
  unitPrice: string | number;
  totalPrice: string | number;
}

export interface Invoice {
  id: number;
  invoiceNumber: string;
  invoiceDate: string | Date;
  dueDate?: string | Date;
  doctorId: number;
  subtotal: string | number;
  taxRate: string | number;
  taxAmount: string | number;
  total: string | number;
  paidAmount: string | number;
  remainingAmount: string | number;
  status: "sent" | "partial" | "paid" | "overdue" | "draft" | "cancelled";
  notes?: string | null;
}

export interface Doctor {
  id: number;
  name: string;
  email?: string | null;
  phone?: string | null;
}

export const exportInvoiceToPDF = (
  invoice: Invoice,
  doctors: Doctor[],
  invoiceItems: InvoiceItem[] = []
) => {
  try {
    const doctor = doctors.find((d) => d.id === invoice.doctorId);
    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    });

    // إعدادات الصفحة
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 12;
    let yPosition = margin;

    // ===== رأس الفاتورة =====
    pdf.setFillColor(30, 90, 150);
    pdf.setTextColor(255, 255, 255);
    pdf.setFontSize(16);
    pdf.text("مخبر النجاح للتعويضات السنية", pageWidth / 2, yPosition, {
      align: "center",
    });

    yPosition += 7;
    pdf.setFontSize(10);
    pdf.text("إدارة إيناس الربيع", pageWidth / 2, yPosition, { align: "center" });

    // خط فاصل
    yPosition += 6;
    pdf.setDrawColor(30, 90, 150);
    pdf.line(margin, yPosition, pageWidth - margin, yPosition);

    // ===== معلومات الفاتورة الأساسية =====
    yPosition += 6;
    pdf.setTextColor(0, 0, 0);
    pdf.setFontSize(10);
    (pdf.setFont as any)(undefined, "bold");
    pdf.text(`رقم الفاتورة: ${invoice.invoiceNumber}`, margin, yPosition);

    yPosition += 5;
    (pdf.setFont as any)(undefined, "normal");
    pdf.setFontSize(9);
    pdf.text(
      `التاريخ: ${new Date(invoice.invoiceDate).toLocaleDateString("ar-SA")}`,
      margin,
      yPosition
    );

    if (invoice.dueDate) {
      pdf.text(
        `تاريخ الاستحقاق: ${new Date(invoice.dueDate).toLocaleDateString("ar-SA")}`,
        pageWidth / 2,
        yPosition
      );
    }

    // ===== معلومات الطبيب =====
    yPosition += 7;
    (pdf.setFont as any)(undefined, "bold");
    pdf.setFontSize(9);
    pdf.text("معلومات الطبيب:", margin, yPosition);

    yPosition += 5;
    (pdf.setFont as any)(undefined, "normal");
    pdf.setFontSize(8);
    pdf.text(`الاسم: ${doctor?.name || "غير معروف"}`, margin, yPosition);

    if (doctor?.email) {
      yPosition += 4;
      pdf.text(`البريد الإلكتروني: ${doctor.email}`, margin, yPosition);
    }

    if (doctor?.phone) {
      yPosition += 4;
      pdf.text(`الهاتف: ${doctor.phone}`, margin, yPosition);
    }

    // ===== جدول البنود =====
    yPosition += 8;
    const tableStartY = yPosition;
    const colWidths = {
      description: pageWidth - margin * 2 - 60,
      quantity: 15,
      unitPrice: 20,
      totalPrice: 25,
    };

    // رأس الجدول
    pdf.setFillColor(30, 90, 150);
    pdf.setTextColor(255, 255, 255);
    (pdf.setFont as any)(undefined, "bold");
    pdf.setFontSize(8);

    const headerHeight = 6;
    pdf.rect(margin, yPosition - 4, pageWidth - margin * 2, headerHeight, "F");

    let xPos = margin + 2;
    pdf.text("الوصف", xPos, yPosition);
    xPos += colWidths.description;
    pdf.text("الكمية", xPos, yPosition, { align: "center" });
    xPos += colWidths.quantity;
    pdf.text("السعر", xPos, yPosition, { align: "right" });
    xPos += colWidths.unitPrice;
    pdf.text("الإجمالي", xPos, yPosition, { align: "right" });

    // بيانات الجدول
    yPosition += headerHeight + 2;
    pdf.setTextColor(0, 0, 0);
    (pdf.setFont as any)(undefined, "normal");
    pdf.setFontSize(8);

    let rowCount = 0;
    const itemsToDisplay = invoiceItems.length > 0 ? invoiceItems : [
      {
        id: 1,
        invoiceId: invoice.id,
        description: "الأعمال والخدمات",
        quantity: 1,
        unitPrice: invoice.subtotal,
        totalPrice: invoice.subtotal,
      },
    ];

    itemsToDisplay.forEach((item, index) => {
      // تحقق من ارتفاع الصفحة
      if (yPosition > pageHeight - 40) {
        pdf.addPage();
        yPosition = margin;
      }

      // خلفية بديلة للصفوف
      if (index % 2 === 0) {
        pdf.setFillColor(240, 245, 250);
        pdf.rect(margin, yPosition - 3, pageWidth - margin * 2, 5, "F");
      }

      xPos = margin + 2;
      const description = String(item.description || "").substring(0, 40);
      pdf.text(description, xPos, yPosition);

      xPos += colWidths.description;
      pdf.text(String(item.quantity || 1), xPos, yPosition, { align: "center" });

      xPos += colWidths.quantity;
      const unitPrice = parseFloat(String(item.unitPrice || "0")).toFixed(2);
      pdf.text(`$${unitPrice}`, xPos, yPosition, { align: "right" });

      xPos += colWidths.unitPrice;
      const totalPrice = parseFloat(String(item.totalPrice || "0")).toFixed(2);
      pdf.text(`$${totalPrice}`, xPos, yPosition, { align: "right" });

      yPosition += 5;
      rowCount++;
    });

    // خط فاصل تحت الجدول
    yPosition += 2;
    pdf.setDrawColor(30, 90, 150);
    pdf.line(margin, yPosition, pageWidth - margin, yPosition);

    // ===== ملخص المبالغ =====
    yPosition += 5;
    (pdf.setFont as any)(undefined, "normal");
    pdf.setFontSize(9);

    const summaryX = pageWidth - margin - 50;

    // الإجمالي الفرعي
    pdf.text("الإجمالي الفرعي:", summaryX, yPosition, { align: "right" } as any);
    const subtotal = parseFloat(String(invoice.subtotal) || "0").toFixed(2);
    pdf.text(`$${subtotal}`, pageWidth - margin - 5, yPosition, { align: "right" } as any);

    // الضريبة
    yPosition += 5;
    const taxRate = parseFloat(String(invoice.taxRate) || "0");
    if (taxRate > 0) {
      pdf.text(`الضريبة (${taxRate}%):`, summaryX, yPosition, { align: "right" } as any);
      const taxAmount = parseFloat(String(invoice.taxAmount) || "0").toFixed(2);
      pdf.text(`$${taxAmount}`, pageWidth - margin - 5, yPosition, { align: "right" } as any);

      yPosition += 5;
    }

    // الإجمالي
    (pdf.setFont as any)(undefined, "bold");
    pdf.setFontSize(10);
    pdf.setFillColor(200, 220, 255);
    pdf.rect(summaryX - 40, yPosition - 4, 45, 6, "F");
    pdf.text("الإجمالي:", summaryX, yPosition, { align: "right" } as any);
    const total = parseFloat(String(invoice.total) || "0").toFixed(2);
    pdf.text(`$${total}`, pageWidth - margin - 5, yPosition, { align: "right" } as any);

    // ===== ملخص الدفعات =====
    yPosition += 8;
    (pdf.setFont as any)(undefined, "normal");
    pdf.setFontSize(9);
    pdf.setFillColor(240, 248, 255);
    pdf.rect(margin, yPosition - 4, pageWidth - margin * 2, 20, "F");

    pdf.text("ملخص الدفعات:", margin + 3, yPosition);

    yPosition += 5;
    pdf.text("المدفوع:", margin + 3, yPosition);
    const paidAmount = parseFloat(String(invoice.paidAmount || "0")).toFixed(2);
    pdf.setTextColor(0, 100, 0);
    (pdf.setFont as any)(undefined, "bold");
    pdf.text(`$${paidAmount}`, pageWidth - margin - 5, yPosition, { align: "right" } as any);

    yPosition += 5;
    pdf.setTextColor(0, 0, 0);
    (pdf.setFont as any)(undefined, "normal");
    pdf.text("المتبقي:", margin + 3, yPosition);
    const remainingAmount = parseFloat(String(invoice.remainingAmount || "0")).toFixed(2);
    pdf.setTextColor(200, 0, 0);
    (pdf.setFont as any)(undefined, "bold");
    pdf.text(`$${remainingAmount}`, pageWidth - margin - 5, yPosition, { align: "right" } as any);

    // ===== الحالة والملاحظات =====
    yPosition += 8;
    pdf.setTextColor(0, 0, 0);
    (pdf.setFont as any)(undefined, "normal");
    pdf.setFontSize(9);

    const statusText =
      invoice.status === "paid"
        ? "مدفوعة"
        : invoice.status === "partial"
          ? "مدفوعة جزئياً"
          : invoice.status === "overdue"
            ? "متأخرة"
            : invoice.status === "draft"
              ? "مسودة"
              : invoice.status === "sent"
                ? "مرسلة"
                : "ملغاة";

    (pdf.setFont as any)(undefined, "bold");
    pdf.text(`الحالة: ${statusText}`, margin, yPosition);

    // الملاحظات
    if (invoice.notes) {
      const notesStr = String(invoice.notes || "");
      if (notesStr.length > 0) {
        yPosition += 6;
        (pdf.setFont as any)(undefined, "normal");
        pdf.setFontSize(8);
        pdf.text("الملاحظات:", margin, yPosition);
        yPosition += 4;
        const noteLines = pdf.splitTextToSize(notesStr, pageWidth - margin * 2);
        pdf.text(noteLines as any, margin, yPosition);
      }
    }

    // ===== التوقيع والتاريخ =====
    yPosition = pageHeight - 15;
    pdf.setFontSize(8);
    pdf.setTextColor(100, 100, 100);
    pdf.text(
      "تم إنشاء هذه الفاتورة بواسطة نظام مخبر النجاح",
      pageWidth / 2,
      yPosition,
      { align: "center" }
    );
    pdf.text(new Date().toLocaleDateString("ar-SA"), pageWidth / 2, yPosition + 4, {
      align: "center",
    });

    // حفظ الملف
    pdf.save(`فاتورة-${invoice.invoiceNumber}.pdf`);
    toast.success("تم تصدير الفاتورة بنجاح");
  } catch (error) {
    console.error("Error exporting PDF:", error);
    toast.error("فشل تصدير الفاتورة");
  }
};


export const printInvoiceToPDF = (
  invoice: Invoice,
  doctors: Doctor[],
  invoiceItems: InvoiceItem[] = []
) => {
  try {
    const doctor = doctors.find((d) => d.id === invoice.doctorId);
    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    });

    // إعدادات الصفحة
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 15;
    let yPosition = margin;

    // ===== الرأس =====
    pdf.setFillColor(30, 90, 150);
    pdf.rect(0, 0, pageWidth, 25, "F");
    pdf.setTextColor(255, 255, 255);
    pdf.setFontSize(20);
    (pdf.setFont as any)(undefined, "bold");
    pdf.text("مخبر النجاح للتعويضات السنية", pageWidth / 2, 12, { align: "center" });
    pdf.setFontSize(10);
    (pdf.setFont as any)(undefined, "normal");
    pdf.text("إدارة: إيناس الربيع", pageWidth / 2, 20, { align: "center" });

    yPosition = 35;

    // ===== معلومات الفاتورة الأساسية =====
    yPosition += 6;
    pdf.setTextColor(0, 0, 0);
    pdf.setFontSize(10);
    (pdf.setFont as any)(undefined, "bold");
    pdf.text(`رقم الفاتورة: ${invoice.invoiceNumber}`, margin, yPosition);

    yPosition += 5;
    (pdf.setFont as any)(undefined, "normal");
    pdf.setFontSize(9);
    pdf.text(
      `التاريخ: ${new Date(invoice.invoiceDate).toLocaleDateString("ar-SA")}`,
      margin,
      yPosition
    );

    if (invoice.dueDate) {
      yPosition += 5;
      pdf.text(
        `تاريخ الاستحقاق: ${new Date(invoice.dueDate).toLocaleDateString("ar-SA")}`,
        margin,
        yPosition
      );
    }

    // ===== معلومات الطبيب =====
    yPosition += 7;
    (pdf.setFont as any)(undefined, "bold");
    pdf.setFontSize(9);
    pdf.text("معلومات الطبيب:", margin, yPosition);

    yPosition += 5;
    (pdf.setFont as any)(undefined, "normal");
    pdf.setFontSize(8);
    pdf.text(`الاسم: ${doctor?.name || "غير معروف"}`, margin, yPosition);

    if (doctor?.email) {
      yPosition += 4;
      pdf.text(`البريد: ${doctor.email}`, margin, yPosition);
    }

    if (doctor?.phone) {
      yPosition += 4;
      pdf.text(`الهاتف: ${doctor.phone}`, margin, yPosition);
    }

    // ===== جدول الأعمال =====
    yPosition += 10;
    const colWidths = {
      description: 80,
      quantity: 20,
      unitPrice: 30,
      totalPrice: 30,
    };

    // رأس الجدول
    pdf.setFillColor(30, 90, 150);
    pdf.setTextColor(255, 255, 255);
    (pdf.setFont as any)(undefined, "bold");
    pdf.setFontSize(8);

    const headerHeight = 6;
    pdf.rect(margin, yPosition - 4, pageWidth - margin * 2, headerHeight, "F");

    let xPos = pageWidth - margin;
    pdf.text("الإجمالي", xPos, yPosition, { align: "right" });
    xPos -= colWidths.totalPrice;
    pdf.text("السعر", xPos, yPosition, { align: "right" });
    xPos -= colWidths.unitPrice;
    pdf.text("الكمية", xPos, yPosition, { align: "right" });
    xPos -= colWidths.quantity;
    pdf.text("الوصف", xPos, yPosition, { align: "right" });

    // بيانات الجدول
    yPosition += headerHeight + 2;
    pdf.setTextColor(0, 0, 0);
    (pdf.setFont as any)(undefined, "normal");
    pdf.setFontSize(8);

    let rowCount = 0;
    const itemsToDisplay = invoiceItems.length > 0 ? invoiceItems : [
      {
        id: 1,
        invoiceId: invoice.id,
        description: "خدمة طب الأسنان",
        quantity: 1,
        unitPrice: "20",
        totalPrice: "25",
      },
    ];

    for (const item of itemsToDisplay) {
      if (yPosition > pageHeight - 40) {
        pdf.addPage();
        yPosition = margin;
      }

      const description = String(item.description || "");
      const quantity = Number(item.quantity || 0);
      const unitPrice = parseFloat(String(item.unitPrice || "0")).toFixed(2);
      const totalPrice = parseFloat(String(item.totalPrice || "0")).toFixed(2);

      xPos = pageWidth - margin;
      pdf.text(`$${totalPrice}`, xPos, yPosition, { align: "right" });
      xPos -= colWidths.totalPrice;
      pdf.text(`$${unitPrice}`, xPos, yPosition, { align: "right" });
      xPos -= colWidths.unitPrice;
      pdf.text(String(quantity), xPos, yPosition, { align: "right" });
      xPos -= colWidths.quantity;

      const descLines = pdf.splitTextToSize(description, colWidths.description - 5);
      pdf.text(descLines as any, xPos, yPosition, { align: "right" });

      const lineHeight = descLines.length > 1 ? descLines.length * 3.5 : 4;
      yPosition += lineHeight + 2;
      rowCount++;
    }

    // الإجمالي
    (pdf.setFont as any)(undefined, "bold");
    pdf.setFontSize(10);
    pdf.setFillColor(200, 220, 255);
    pdf.rect(pageWidth - margin - 60, yPosition - 4, 60, 6, "F");
    pdf.text("الإجمالي:", pageWidth - margin - 5, yPosition, { align: "right" } as any);
    const total = parseFloat(String(invoice.total) || "0").toFixed(2);
    pdf.text(`$${total}`, pageWidth - margin - 5, yPosition, { align: "right" } as any);

    // ملخص الدفعات
    yPosition += 8;
    (pdf.setFont as any)(undefined, "normal");
    pdf.setFontSize(9);
    pdf.setFillColor(240, 248, 255);
    pdf.rect(margin, yPosition - 4, pageWidth - margin * 2, 20, "F");

    pdf.text("ملخص الدفعات:", margin + 3, yPosition);

    yPosition += 5;
    pdf.text("المدفوع:", margin + 3, yPosition);
    const paidAmount = parseFloat(String(invoice.paidAmount || "0")).toFixed(2);
    pdf.setTextColor(0, 100, 0);
    (pdf.setFont as any)(undefined, "bold");
    pdf.text(`$${paidAmount}`, pageWidth - margin - 5, yPosition, { align: "right" } as any);

    yPosition += 5;
    pdf.setTextColor(0, 0, 0);
    (pdf.setFont as any)(undefined, "normal");
    pdf.text("المتبقي:", margin + 3, yPosition);
    const remainingAmount = parseFloat(String(invoice.remainingAmount || "0")).toFixed(2);
    pdf.setTextColor(200, 0, 0);
    (pdf.setFont as any)(undefined, "bold");
    pdf.text(`$${remainingAmount}`, pageWidth - margin - 5, yPosition, { align: "right" } as any);

    // الحالة والملاحظات
    yPosition += 8;
    pdf.setTextColor(0, 0, 0);
    (pdf.setFont as any)(undefined, "normal");
    pdf.setFontSize(9);

    const statusText =
      invoice.status === "paid"
        ? "مدفوعة"
        : invoice.status === "partial"
          ? "مدفوعة جزئياً"
          : invoice.status === "overdue"
            ? "متأخرة"
            : invoice.status === "draft"
              ? "مسودة"
              : invoice.status === "sent"
                ? "مرسلة"
                : "ملغاة";

    (pdf.setFont as any)(undefined, "bold");
    pdf.text(`الحالة: ${statusText}`, margin, yPosition);

    // الملاحظات
    if (invoice.notes) {
      const notesStr = String(invoice.notes || "");
      if (notesStr.length > 0) {
        yPosition += 6;
        (pdf.setFont as any)(undefined, "normal");
        pdf.setFontSize(8);
        pdf.text("الملاحظات:", margin, yPosition);
        yPosition += 4;
        const noteLines = pdf.splitTextToSize(notesStr, pageWidth - margin * 2);
        pdf.text(noteLines as any, margin, yPosition);
      }
    }

    // طباعة المستند
    try {
      const pdfBlob = pdf.output("blob");
      const pdfUrl = URL.createObjectURL(pdfBlob);
      const printWindow = window.open(pdfUrl, "_blank");
      if (printWindow) {
        setTimeout(() => {
          printWindow.print();
          setTimeout(() => {
            URL.revokeObjectURL(pdfUrl);
          }, 1000);
        }, 500);
        toast.success("تم فتح الفاتورة للطباعة");
      } else {
        toast.error("لم يتمكن فتح نافذة الطباعة. يرجى تعطيل محجوب النوافذ المنبثقة");
      }
    } catch (printError) {
      console.error("Print error:", printError);
      toast.error("خطأ في عملية الطباعة");
    }
  } catch (error) {
    console.error("Error printing PDF:", error);
    toast.error("فشل فتح الفاتورة للطباعة");
  }
};
