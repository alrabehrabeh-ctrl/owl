import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import { toast } from "sonner";

export interface Invoice {
  id: number;
  invoiceNumber: string;
  doctorId: number;
  invoiceDate: string;
  status: string;
  totalAmount: number;
  paidAmount: number;
}

export interface InvoiceItem {
  id: number;
  invoiceId: number;
  workId: number | null;
  description: string;
  quantity: number;
  unitPrice: string | number;
  totalPrice: string | number;
}

export interface Doctor {
  id: number;
  name: string;
  email: string | null;
  phone: string | null;
  specialization: string | null;
  clinic: string | null;
  address: string | null;
  notes: string | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const LOGO_URL = "/logo.png";

const getStatusBadge = (status: string) => {
  const statusMap: Record<string, { label: string; color: string }> = {
    sent: { label: "مرسلة", color: "#0066CC" },
    partial: { label: "مدفوعة جزئياً", color: "#FBBF24" },
    paid: { label: "مدفوعة بالكامل", color: "#10B981" },
    overdue: { label: "متأخرة", color: "#EF4444" },
  };
  return statusMap[status] || { label: status, color: "#6B7280" };
};

export const exportInvoiceToPDFArabic = async (
  invoice: any,
  doctors: Doctor[],
  invoiceItems: InvoiceItem[] = []
) => {
  try {
    const doctor = doctors.find((d) => d.id === invoice.doctorId);
    const statusBadge = getStatusBadge(invoice.status);
    
    // التعامل مع أسماء الحقول المختلفة
    const totalAmount = parseFloat(invoice.totalAmount || invoice.total || "0");
    const paidAmount = parseFloat(invoice.paidAmount || invoice.paid || "0");
    const remainingAmount = totalAmount - paidAmount;

    // تنسيق التاريخ
    const invoiceDate = new Date(invoice.invoiceDate);
    const formattedDate = invoiceDate.toLocaleDateString("ar-SA", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    });

    const htmlContent = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          
          body {
            font-family: Arial, sans-serif;
            background: white;
            direction: rtl;
            color: #000;
            line-height: 1.6;
          }
          
          .invoice-wrapper {
            width: 210mm;
            height: 297mm;
            padding: 20px;
            background: white;
          }
          
          .invoice-container {
            height: 100%;
            display: flex;
            flex-direction: column;
            background: white;
            overflow: hidden;
          }
          
          /* Header Section */
          .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 3px solid #0066CC;
          }
          
          .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 0 0 auto;
          }
          
          .logo {
            width: 80px;
            height: 80px;
            background: white;
            padding: 5px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
          }
          
          .logo img {
            width: 100%;
            height: 100%;
            object-fit: contain;
          }
          
          .header-text {
            flex: 1;
            text-align: right;
          }
          
          .header-text h1 {
            font-size: 22px;
            color: #0066CC;
            font-weight: bold;
            margin-bottom: 3px;
          }
          
          .header-text p {
            font-size: 12px;
            color: #333;
            margin-bottom: 2px;
          }
          
          .header-text .services {
            font-size: 10px;
            color: #666;
            margin-bottom: 5px;
            line-height: 1.4;
          }
          
          .header-text .contact {
            font-size: 11px;
            color: #000;
            font-weight: bold;
          }
          
          /* Info Section */
          .info-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 15px;
            font-size: 11px;
          }
          
          .info-box {
            padding: 8px 10px;
            background: #f5f5f5;
            border-right: 3px solid #0066CC;
          }
          
          .info-label {
            color: #666;
            font-weight: bold;
            margin-bottom: 2px;
          }
          
          .info-value {
            color: #000;
            font-weight: bold;
          }
          
          /* Items Table */
          .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            border: 1px solid #0066CC;
            font-size: 10px;
          }
          
          .items-table thead {
            background: #E8F4F8;
            border-bottom: 2px solid #0066CC;
          }
          
          .items-table th {
            padding: 8px;
            text-align: right;
            font-weight: bold;
            color: #0066CC;
            border-right: 1px solid #0066CC;
          }
          
          .items-table th:last-child {
            border-right: none;
          }
          
          .items-table td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
            border-right: 1px solid #ddd;
          }
          
          .items-table td:last-child {
            border-right: none;
          }
          
          .items-table tbody tr:last-child td {
            border-bottom: 1px solid #0066CC;
          }
          
          /* Summary Section */
          .summary-section {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
            margin-top: auto;
            font-size: 11px;
          }
          
          .summary-box {
            padding: 12px;
            text-align: center;
            background: #f5f5f5;
            border: 2px solid #0066CC;
            border-radius: 4px;
          }
          
          .summary-label {
            color: #666;
            font-weight: bold;
            margin-bottom: 5px;
            font-size: 10px;
          }
          
          .summary-value {
            color: #0066CC;
            font-weight: bold;
            font-size: 14px;
          }
        </style>
      </head>
      <body>
        <div class="invoice-wrapper">
          <div class="invoice-container">
            <!-- Header with Logo and Company Info -->
            <div class="header">
              <div class="logo-section">
                <div class="logo">
                  <img src="${LOGO_URL}" alt="Logo">
                </div>
              </div>
              <div class="header-text">
                <h1>مخبر النجاح للتعويضات السنية</h1>
                <p>إدارة إيناس الربيع</p>
                <p class="services">زيركون - خزف - أجهزة متحركة - تقطيع طبعات - فاكيوم (تثبيت - تبييض)</p>
                <p class="contact">موبايل: 0954748697</p>
              </div>
            </div>
            
            <!-- Doctor and Invoice Info -->
            <div class="info-section">
              <div class="info-box">
                <div class="info-label">اسم الطبيب:</div>
                <div class="info-value">${doctor?.name || "-"}</div>
              </div>
              <div class="info-box">
                <div class="info-label">رقم الفاتورة:</div>
                <div class="info-value">${invoice.invoiceNumber}</div>
              </div>
              <div class="info-box">
                <div class="info-label">التاريخ:</div>
                <div class="info-value">${formattedDate}</div>
              </div>
              <div class="info-box">
                <div class="info-label">عدد الأعمال:</div>
                <div class="info-value">${invoiceItems.length}</div>
              </div>
            </div>
            
            <!-- Items Table -->
            <table class="items-table">
              <thead>
                <tr>
                  <th>نوع العمل</th>
                  <th>اسم المريض</th>
                  <th>الملاحظات</th>
                  <th>التاريخ</th>
                  <th>السعر</th>
                </tr>
              </thead>
              <tbody>
                ${invoiceItems.map(item => `
                  <tr>
                    <td>${item.description || "-"}</td>
                    <td>-</td>
                    <td>-</td>
                    <td>${new Date(invoice.invoiceDate).toLocaleDateString("ar-SA")}</td>
                    <td>$${(parseFloat(item.totalPrice?.toString() || "0")).toFixed(2)}</td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
            
            <!-- Summary Section -->
            <div class="summary-section">
              <div class="summary-box">
                <div class="summary-label">المبلغ الإجمالي</div>
                <div class="summary-value">$${totalAmount.toFixed(2)}</div>
              </div>
              <div class="summary-box">
                <div class="summary-label">المبلغ المدفوع</div>
                <div class="summary-value">$${paidAmount.toFixed(2)}</div>
              </div>
              <div class="summary-box">
                <div class="summary-label">المبلغ المتبقي</div>
                <div class="summary-value">$${remainingAmount.toFixed(2)}</div>
              </div>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;

    // إنشاء عنصر مؤقت
    const element = document.createElement("div");
    element.innerHTML = htmlContent;
    element.style.position = "absolute";
    element.style.left = "-9999px";
    element.style.top = "-9999px";
    document.body.appendChild(element);

    // تحويل إلى صورة
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      backgroundColor: "#ffffff",
      imageTimeout: 10000,
    });

    // إنشاء PDF من Canvas
    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    });

    const imgData = canvas.toDataURL("image/png");
    const imgWidth = 210; // عرض A4 بالملليمتر
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
    pdf.save(`فاتورة-${invoice.invoiceNumber}.pdf`);

    // تنظيف
    document.body.removeChild(element);

    toast.success("تم تصدير الفاتورة بنجاح");
  } catch (error) {
    console.error("Error exporting invoice:", error);
    toast.error("فشل تصدير الفاتورة");
  }
};

export const printInvoiceToPDFArabic = async (
  invoice: any,
  doctors: Doctor[],
  invoiceItems: InvoiceItem[] = []
) => {
  try {
    const doctor = doctors.find((d) => d.id === invoice.doctorId);
    const statusBadge = getStatusBadge(invoice.status);
    
    // التعامل مع أسماء الحقول المختلفة
    const totalAmount = parseFloat(invoice.totalAmount || invoice.total || "0");
    const paidAmount = parseFloat(invoice.paidAmount || invoice.paid || "0");
    const remainingAmount = totalAmount - paidAmount;

    // تنسيق التاريخ
    const invoiceDate = new Date(invoice.invoiceDate);
    const formattedDate = invoiceDate.toLocaleDateString("ar-SA", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    });

    const htmlContent = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          
          body {
            font-family: Arial, sans-serif;
            background: white;
            direction: rtl;
            color: #000;
            line-height: 1.6;
          }
          
          .invoice-wrapper {
            width: 210mm;
            height: 297mm;
            padding: 20px;
            background: white;
          }
          
          .invoice-container {
            height: 100%;
            display: flex;
            flex-direction: column;
            background: white;
            overflow: hidden;
          }
          
          /* Header Section */
          .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 3px solid #0066CC;
          }
          
          .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 0 0 auto;
          }
          
          .logo {
            width: 80px;
            height: 80px;
            background: white;
            padding: 5px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
          }
          
          .logo img {
            width: 100%;
            height: 100%;
            object-fit: contain;
          }
          
          .header-text {
            flex: 1;
            text-align: right;
          }
          
          .header-text h1 {
            font-size: 22px;
            color: #0066CC;
            font-weight: bold;
            margin-bottom: 3px;
          }
          
          .header-text p {
            font-size: 12px;
            color: #333;
            margin-bottom: 2px;
          }
          
          .header-text .services {
            font-size: 10px;
            color: #666;
            margin-bottom: 5px;
            line-height: 1.4;
          }
          
          .header-text .contact {
            font-size: 11px;
            color: #000;
            font-weight: bold;
          }
          
          /* Info Section */
          .info-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 15px;
            font-size: 11px;
          }
          
          .info-box {
            padding: 8px 10px;
            background: #f5f5f5;
            border-right: 3px solid #0066CC;
          }
          
          .info-label {
            color: #666;
            font-weight: bold;
            margin-bottom: 2px;
          }
          
          .info-value {
            color: #000;
            font-weight: bold;
          }
          
          /* Items Table */
          .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            border: 1px solid #0066CC;
            font-size: 10px;
          }
          
          .items-table thead {
            background: #E8F4F8;
            border-bottom: 2px solid #0066CC;
          }
          
          .items-table th {
            padding: 8px;
            text-align: right;
            font-weight: bold;
            color: #0066CC;
            border-right: 1px solid #0066CC;
          }
          
          .items-table th:last-child {
            border-right: none;
          }
          
          .items-table td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
            border-right: 1px solid #ddd;
          }
          
          .items-table td:last-child {
            border-right: none;
          }
          
          .items-table tbody tr:last-child td {
            border-bottom: 1px solid #0066CC;
          }
          
          /* Summary Section */
          .summary-section {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
            margin-top: auto;
            font-size: 11px;
          }
          
          .summary-box {
            padding: 12px;
            text-align: center;
            background: #f5f5f5;
            border: 2px solid #0066CC;
            border-radius: 4px;
          }
          
          .summary-label {
            color: #666;
            font-weight: bold;
            margin-bottom: 5px;
            font-size: 10px;
          }
          
          .summary-value {
            color: #0066CC;
            font-weight: bold;
            font-size: 14px;
          }
          
          @media print {
            body {
              margin: 0;
              padding: 0;
            }
            .invoice-wrapper {
              padding: 0;
              width: 100%;
              height: 100%;
            }
          }
        </style>
      </head>
      <body>
        <div class="invoice-wrapper">
          <div class="invoice-container">
            <!-- Header with Logo and Company Info -->
            <div class="header">
              <div class="logo-section">
                <div class="logo">
                  <img src="${LOGO_URL}" alt="Logo">
                </div>
              </div>
              <div class="header-text">
                <h1>مخبر النجاح للتعويضات السنية</h1>
                <p>إدارة إيناس الربيع</p>
                <p class="services">زيركون - خزف - أجهزة متحركة - تقطيع طبعات - فاكيوم (تثبيت - تبييض)</p>
                <p class="contact">موبايل: 0954748697</p>
              </div>
            </div>
            
            <!-- Doctor and Invoice Info -->
            <div class="info-section">
              <div class="info-box">
                <div class="info-label">اسم الطبيب:</div>
                <div class="info-value">${doctor?.name || "-"}</div>
              </div>
              <div class="info-box">
                <div class="info-label">رقم الفاتورة:</div>
                <div class="info-value">${invoice.invoiceNumber}</div>
              </div>
              <div class="info-box">
                <div class="info-label">التاريخ:</div>
                <div class="info-value">${formattedDate}</div>
              </div>
              <div class="info-box">
                <div class="info-label">عدد الأعمال:</div>
                <div class="info-value">${invoiceItems.length}</div>
              </div>
            </div>
            
            <!-- Items Table -->
            <table class="items-table">
              <thead>
                <tr>
                  <th>نوع العمل</th>
                  <th>اسم المريض</th>
                  <th>الملاحظات</th>
                  <th>التاريخ</th>
                  <th>السعر</th>
                </tr>
              </thead>
              <tbody>
                ${invoiceItems.map(item => `
                  <tr>
                    <td>${item.description || "-"}</td>
                    <td>-</td>
                    <td>-</td>
                    <td>${new Date(invoice.invoiceDate).toLocaleDateString("ar-SA")}</td>
                    <td>$${(parseFloat(item.totalPrice?.toString() || "0")).toFixed(2)}</td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
            
            <!-- Summary Section -->
            <div class="summary-section">
              <div class="summary-box">
                <div class="summary-label">المبلغ الإجمالي</div>
                <div class="summary-value">$${totalAmount.toFixed(2)}</div>
              </div>
              <div class="summary-box">
                <div class="summary-label">المبلغ المدفوع</div>
                <div class="summary-value">$${paidAmount.toFixed(2)}</div>
              </div>
              <div class="summary-box">
                <div class="summary-label">المبلغ المتبقي</div>
                <div class="summary-value">$${remainingAmount.toFixed(2)}</div>
              </div>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;

    // فتح نافذة الطباعة
    const printWindow = window.open("", "", "width=900,height=700");
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      setTimeout(() => {
        printWindow.print();
      }, 250);
    }

    toast.success("تم فتح نافذة الطباعة");
  } catch (error) {
    console.error("Error printing invoice:", error);
    toast.error("فشل فتح نافذة الطباعة");
  }
};
