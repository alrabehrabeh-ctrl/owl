import crypto from 'crypto';
import { createConnection } from 'mysql2/promise';

const password = 'admin1985';

// دالة بسيطة لتشفير كلمة المرور (في الواقع يجب استخدام bcrypt)
// لكن لأغراض التطوير، سنستخدم SHA256
const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

console.log('Creating admin account...');
console.log('Username: admin');
console.log('Password: admin1985');
console.log('Role: admin');

try {
  const connection = await createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'manus_dev',
  });

  // حذف أي حساب admin قديم
  await connection.execute('DELETE FROM users WHERE username = ?', ['admin']);
  
  // إنشاء حساب admin جديد
  const [result] = await connection.execute(
    'INSERT INTO users (openId, username, password, name, email, loginMethod, role, createdAt, updatedAt, lastSignedIn) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW(), NOW())',
    ['admin-system-fixed', 'admin', hashedPassword, 'مسؤول النظام', 'admin@system.local', 'local', 'admin']
  );

  console.log('✅ تم إنشاء حساب admin بنجاح');
  
  await connection.end();
} catch (error) {
  console.error('❌ خطأ في إنشاء حساب admin:', error.message);
  process.exit(1);
}
