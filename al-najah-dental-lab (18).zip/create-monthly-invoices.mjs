import mysql from 'mysql2/promise';
import { config } from 'dotenv';

config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'dental_lab',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

async function createMonthlyInvoices() {
  const connection = await pool.getConnection();
  
  try {
    console.log('جاري إنشاء الفواتير الشهرية...\n');
    
    // الحصول على جميع الأعمال مع معلومات الطبيب
    const [works] = await connection.query(`
      SELECT 
        w.id,
        w.doctorId,
        d.name as doctorName,
        w.totalPrice,
        w.receptionDate,
        YEAR(w.receptionDate) as year,
        MONTH(w.receptionDate) as month
      FROM works w
      JOIN doctors d ON w.doctorId = d.id
      WHERE w.receptionDate IS NOT NULL
      ORDER BY w.doctorId, YEAR(w.receptionDate), MONTH(w.receptionDate)
    `);
    
    console.log(`عدد الأعمال: ${works.length}\n`);
    
    // تجميع الأعمال حسب الطبيب والشهر
    const groupedWorks = {};
    for (const work of works) {
      const key = `${work.doctorId}-${work.year}-${work.month}`;
      if (!groupedWorks[key]) {
        groupedWorks[key] = {
          doctorId: work.doctorId,
          doctorName: work.doctorName,
          year: work.year,
          month: work.month,
          works: [],
          total: 0
        };
      }
      groupedWorks[key].works.push(work);
      groupedWorks[key].total += parseFloat(work.totalPrice);
    }
    
    console.log(`عدد الفواتير الشهرية المراد إنشاؤها: ${Object.keys(groupedWorks).length}\n`);
    
    let createdCount = 0;
    let failedCount = 0;
    
    // إنشاء فاتورة لكل مجموعة
    for (const [key, group] of Object.entries(groupedWorks)) {
      try {
        // إنشاء رقم فاتورة فريد
        const invoiceNumber = `INV-${group.doctorId}-${group.year}${String(group.month).padStart(2, '0')}-${Date.now()}`;
        
        // تاريخ الفاتورة (آخر يوم من الشهر)
        const invoiceDate = new Date(group.year, group.month, 0);
        const dueDate = new Date(group.year, group.month + 1, 0);
        
        // إدراج الفاتورة
        const [result] = await connection.query(
          `INSERT INTO invoices (
            invoiceNumber, doctorId, subtotal, taxRate, taxAmount, total, 
            paidAmount, remainingAmount, status, invoiceDate, dueDate
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            invoiceNumber,
            group.doctorId,
            group.total,
            0,
            0,
            group.total,
            0,
            group.total,
            'draft',
            invoiceDate,
            dueDate
          ]
        );
        
        const invoiceId = result.insertId;
        
        // إدراج تفاصيل الفاتورة (الأعمال)
        for (const work of group.works) {
          await connection.query(
            `INSERT INTO invoiceItems (invoiceId, workId, description, quantity, unitPrice, totalPrice)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [
              invoiceId,
              work.id,
              `عمل رقم ${work.id}`,
              1,
              work.totalPrice,
              work.totalPrice
            ]
          );
        }
        
        console.log(`✅ تم إنشاء فاتورة: ${group.doctorName} - ${group.month}/${group.year} (${group.works.length} عمل) - الإجمالي: $${group.total.toFixed(2)}`);
        createdCount++;
      } catch (error) {
        console.error(`❌ فشل إنشاء فاتورة: ${group.doctorName} - ${group.month}/${group.year}`);
        console.error(`   الخطأ: ${error.message}`);
        failedCount++;
      }
    }
    
    console.log(`\n${'='.repeat(80)}`);
    console.log(`النتائج:`);
    console.log(`${'='.repeat(80)}`);
    console.log(`✅ عدد الفواتير المُنشأة: ${createdCount}`);
    console.log(`❌ عدد الفواتير الفاشلة: ${failedCount}`);
    console.log(`${'='.repeat(80)}\n`);
    
  } catch (error) {
    console.error('خطأ:', error.message);
  } finally {
    await connection.release();
    await pool.end();
  }
}

createMonthlyInvoices();
