import { getDb } from "./server/db.ts";
import { users } from "./drizzle/schema.ts";

async function createTestUsers() {
  const db = await getDb();
  if (!db) {
    console.error("Failed to connect to database");
    process.exit(1);
  }

  const testUsers = [
    {
      email: "user1@test.com",
      name: "المستخدم الأول",
      role: "user",
    },
    {
      email: "user2@test.com",
      name: "المستخدم الثاني",
      role: "manager",
    },
    {
      email: "user3@test.com",
      name: "المستخدم الثالث",
      role: "staff",
    },
  ];

  console.log("Creating test users...\n");

  for (const testUser of testUsers) {
    const tempOpenId = `temp-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    try {
      await db.insert(users).values({
        email: testUser.email,
        name: testUser.name,
        role: testUser.role,
        openId: tempOpenId,
        loginMethod: "manual",
      });

      console.log(`✅ Created: ${testUser.name}`);
      console.log(`   Email: ${testUser.email}`);
      console.log(`   Role: ${testUser.role}\n`);
    } catch (error) {
      console.error(`❌ Failed to create ${testUser.name}:`, error.message);
    }
  }

  console.log("Fetching all users...\n");
  const allUsers = await db.select().from(users);
  
  console.log("All users in database:");
  allUsers.forEach((user) => {
    console.log(`- ID: ${user.id}, Name: ${user.name}, Email: ${user.email}, Role: ${user.role}`);
  });

  process.exit(0);
}

createTestUsers().catch((error) => {
  console.error("Error creating test users:", error);
  process.exit(1);
});
