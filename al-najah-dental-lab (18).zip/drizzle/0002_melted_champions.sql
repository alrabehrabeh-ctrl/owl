CREATE TABLE `advancedSalaries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`month` varchar(7) NOT NULL,
	`baseSalary` decimal(10,2) NOT NULL,
	`performanceBonus` decimal(10,2) DEFAULT '0',
	`attendance` int DEFAULT 0,
	`absences` int DEFAULT 0,
	`leaves` int DEFAULT 0,
	`deductions` decimal(10,2) DEFAULT '0',
	`socialSecurityDeduction` decimal(10,2) DEFAULT '0',
	`incomeTaxDeduction` decimal(10,2) DEFAULT '0',
	`otherDeductions` decimal(10,2) DEFAULT '0',
	`netSalary` decimal(10,2) NOT NULL,
	`status` enum('pending','paid','cancelled') NOT NULL DEFAULT 'pending',
	`paymentDate` datetime,
	`paymentMethod` enum('cash','check','bank_transfer','credit_card','other'),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `advancedSalaries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `attendance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`date` datetime NOT NULL,
	`checkInTime` datetime,
	`checkOutTime` datetime,
	`status` enum('present','absent','late','leave','half_day') NOT NULL,
	`leaveType` enum('sick','vacation','personal','unpaid','other'),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `attendance_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `forecasts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`doctorId` int,
	`forecastType` enum('revenue','profit','expense','general') NOT NULL,
	`period` varchar(7) NOT NULL,
	`predictedValue` decimal(10,2) NOT NULL,
	`actualValue` decimal(10,2),
	`variance` decimal(10,2),
	`confidence` decimal(5,2) DEFAULT '0',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `forecasts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `incentives` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`type` enum('bonus','raise','commission','award','other') NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`reason` text NOT NULL,
	`effectiveDate` datetime NOT NULL,
	`approvedBy` varchar(255),
	`status` enum('pending','approved','rejected','implemented') NOT NULL DEFAULT 'pending',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `incentives_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `performanceEvaluations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`evaluationDate` datetime NOT NULL,
	`evaluator` varchar(255) NOT NULL,
	`overallRating` decimal(3,1) NOT NULL,
	`workQuality` decimal(3,1) NOT NULL,
	`productivity` decimal(3,1) NOT NULL,
	`teamwork` decimal(3,1) NOT NULL,
	`communication` decimal(3,1) NOT NULL,
	`punctuality` decimal(3,1) NOT NULL,
	`strengths` text,
	`areasForImprovement` text,
	`comments` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `performanceEvaluations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `performanceReports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`doctorId` int NOT NULL,
	`period` varchar(7) NOT NULL,
	`totalWorks` int NOT NULL DEFAULT 0,
	`completedWorks` int NOT NULL DEFAULT 0,
	`totalRevenue` decimal(10,2) NOT NULL DEFAULT '0',
	`totalExpenses` decimal(10,2) NOT NULL DEFAULT '0',
	`netProfit` decimal(10,2) NOT NULL DEFAULT '0',
	`averageWorkValue` decimal(10,2) NOT NULL DEFAULT '0',
	`profitMargin` decimal(5,2) NOT NULL DEFAULT '0',
	`rating` decimal(3,1) DEFAULT '0',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `performanceReports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `taxReports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`period` varchar(7) NOT NULL,
	`totalIncome` decimal(10,2) NOT NULL,
	`totalExpenses` decimal(10,2) NOT NULL,
	`taxableIncome` decimal(10,2) NOT NULL,
	`taxRate` decimal(5,2) NOT NULL,
	`taxAmount` decimal(10,2) NOT NULL,
	`deductions` decimal(10,2) DEFAULT '0',
	`netTax` decimal(10,2) NOT NULL,
	`status` enum('draft','submitted','approved','paid') NOT NULL DEFAULT 'draft',
	`submissionDate` datetime,
	`paymentDate` datetime,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `taxReports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `advancedSalaries` ADD CONSTRAINT `advancedSalaries_employeeId_employees_id_fk` FOREIGN KEY (`employeeId`) REFERENCES `employees`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `attendance` ADD CONSTRAINT `attendance_employeeId_employees_id_fk` FOREIGN KEY (`employeeId`) REFERENCES `employees`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `forecasts` ADD CONSTRAINT `forecasts_doctorId_doctors_id_fk` FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `incentives` ADD CONSTRAINT `incentives_employeeId_employees_id_fk` FOREIGN KEY (`employeeId`) REFERENCES `employees`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `performanceEvaluations` ADD CONSTRAINT `performanceEvaluations_employeeId_employees_id_fk` FOREIGN KEY (`employeeId`) REFERENCES `employees`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `performanceReports` ADD CONSTRAINT `performanceReports_doctorId_doctors_id_fk` FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE no action ON UPDATE no action;