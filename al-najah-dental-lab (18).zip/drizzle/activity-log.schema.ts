import { int, mysqlTable, text, timestamp, varchar, mysqlEnum, json } from "drizzle-orm/mysql-core";

/**
 * جدول سجل الأنشطة - لتتبع جميع الإضافات والتعديلات
 */
export const activityLogs = mysqlTable("activityLogs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // المستخدم الذي قام بالنشاط
  action: varchar("action", { length: 100 }).notNull(), // نوع النشاط (create, update, delete, etc)
  entityType: varchar("entityType", { length: 100 }).notNull(), // نوع الكائن (doctor, work, payment, etc)
  entityId: int("entityId"), // معرف الكائن
  entityName: varchar("entityName", { length: 255 }), // اسم الكائن
  description: text("description"), // وصف النشاط
  oldValues: json("oldValues"), // القيم القديمة (للتعديلات)
  newValues: json("newValues"), // القيم الجديدة
  ipAddress: varchar("ipAddress", { length: 45 }), // عنوان IP
  userAgent: text("userAgent"), // معلومات المتصفح
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(), // حالة المراجعة
  reviewedBy: int("reviewedBy"), // المسؤول الذي راجع النشاط
  reviewedAt: timestamp("reviewedAt"), // وقت المراجعة
  reviewNotes: text("reviewNotes"), // ملاحظات المراجعة
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = typeof activityLogs.$inferInsert;
