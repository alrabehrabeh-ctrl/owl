import { mysqlTable, int, varchar, text, timestamp, boolean } from "drizzle-orm/mysql-core";

/**
 * جدول سجل التدقيق لتتبع محاولات تبديل المستخدمين
 */
export const userSwitchAuditLog = mysqlTable("userSwitchAuditLog", {
  id: int("id").autoincrement().primaryKey(),
  
  // معرّف المستخدم الذي قام بالتبديل
  switchedBy: int("switchedBy").notNull(),
  
  // معرّف المستخدم الذي تم التبديل إليه
  switchedTo: int("switchedTo").notNull(),
  
  // حالة المحاولة (success, failed)
  status: varchar("status", { length: 20 }).notNull(), // "success" | "failed"
  
  // سبب الفشل (إن وجد)
  failureReason: text("failureReason"),
  
  // عنوان IP
  ipAddress: varchar("ipAddress", { length: 45 }),
  
  // معلومات المتصفح
  userAgent: text("userAgent"),
  
  // تاريخ ووقت المحاولة
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserSwitchAuditLog = typeof userSwitchAuditLog.$inferSelect;
export type InsertUserSwitchAuditLog = typeof userSwitchAuditLog.$inferInsert;

/**
 * جدول سجل تدقيق كلمات المرور
 */
export const passwordAuditLog = mysqlTable("passwordAuditLog", {
  id: int("id").autoincrement().primaryKey(),
  
  // الدور الذي تم تغيير كلمة المرور له
  role: varchar("role", { length: 50 }).notNull(),
  
  // معرّف المستخدم الذي قام بالتغيير
  changedBy: int("changedBy").notNull(),
  
  // حالة المحاولة
  status: varchar("status", { length: 20 }).notNull(), // "success" | "failed"
  
  // سبب الفشل (إن وجد)
  failureReason: text("failureReason"),
  
  // عنوان IP
  ipAddress: varchar("ipAddress", { length: 45 }),
  
  // معلومات المتصفح
  userAgent: text("userAgent"),
  
  // تاريخ ووقت المحاولة
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PasswordAuditLog = typeof passwordAuditLog.$inferSelect;
export type InsertPasswordAuditLog = typeof passwordAuditLog.$inferInsert;

/**
 * جدول سجل تدقيق الصلاحيات
 */
export const permissionAuditLog = mysqlTable("permissionAuditLog", {
  id: int("id").autoincrement().primaryKey(),
  
  // الدور الذي تم تغيير صلاحياته
  role: varchar("role", { length: 50 }).notNull(),
  
  // معرّف المستخدم الذي قام بالتغيير
  changedBy: int("changedBy").notNull(),
  
  // نوع التغيير (add, remove, reset)
  changeType: varchar("changeType", { length: 50 }).notNull(),
  
  // الصلاحية التي تم تغييرها
  permission: varchar("permission", { length: 255 }),
  
  // الصلاحيات القديمة (JSON)
  oldPermissions: text("oldPermissions"),
  
  // الصلاحيات الجديدة (JSON)
  newPermissions: text("newPermissions"),
  
  // حالة المحاولة
  status: varchar("status", { length: 20 }).notNull(), // "success" | "failed"
  
  // سبب الفشل (إن وجد)
  failureReason: text("failureReason"),
  
  // عنوان IP
  ipAddress: varchar("ipAddress", { length: 45 }),
  
  // معلومات المتصفح
  userAgent: text("userAgent"),
  
  // تاريخ ووقت المحاولة
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PermissionAuditLog = typeof permissionAuditLog.$inferSelect;
export type InsertPermissionAuditLog = typeof permissionAuditLog.$inferInsert;
