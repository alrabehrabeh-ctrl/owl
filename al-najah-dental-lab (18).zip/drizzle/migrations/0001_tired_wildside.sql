ALTER TABLE `doctors` DROP COLUMN `taxId`;--> statement-breakpoint
ALTER TABLE `doctors` DROP COLUMN `bankAccount`;--> statement-breakpoint
ALTER TABLE `doctors` DROP COLUMN `profileImage`;--> statement-breakpoint
ALTER TABLE `doctors` DROP COLUMN `rating`;--> statement-breakpoint
ALTER TABLE `doctors` DROP COLUMN `ratingCount`;--> statement-breakpoint
ALTER TABLE `doctors` DROP COLUMN `internalNotes`;--> statement-breakpoint
ALTER TABLE `doctors` DROP COLUMN `yearsOfExperience`;--> statement-breakpoint
ALTER TABLE `doctors` DROP COLUMN `certificates`;--> statement-breakpoint
ALTER TABLE `doctors` DROP COLUMN `hourlyRate`;--> statement-breakpoint
ALTER TABLE `doctors` DROP COLUMN `licenseNumber`;