import { mysqlTable, varchar, int, timestamp, boolean, text } from "drizzle-orm/mysql-core";
import { users } from "./schema";

/**
 * جدول تخزين رموز OTP (One-Time Password)
 * يتم استخدامه للتحقق الثنائي (2FA)
 */
export const otpCodes = mysqlTable("otp_codes", {
  id: int("id").primaryKey().autoincrement(),
  userId: int("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  code: varchar("code", { length: 6 }).notNull(), // رمز OTP من 6 أرقام
  isUsed: boolean("is_used").default(false), // هل تم استخدام الرمز
  expiresAt: timestamp("expires_at").notNull(), // وقت انتهاء صلاحية الرمز
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
});

/**
 * جدول تخزين إعدادات 2FA للمستخدمين
 */
export const twoFactorSettings = mysqlTable("two_factor_settings", {
  id: int("id").primaryKey().autoincrement(),
  userId: int("user_id")
    .notNull()
    .unique()
    .references(() => users.id, { onDelete: "cascade" }),
  isEnabled: boolean("is_enabled").default(false), // هل تم تفعيل 2FA
  backupCodes: text("backup_codes"), // رموز احتياطية (JSON array)
  lastUsedAt: timestamp("last_used_at"), // آخر استخدام للـ 2FA
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
});

/**
 * جدول سجل محاولات التحقق من OTP
 */
export const otpAttempts = mysqlTable("otp_attempts", {
  id: int("id").primaryKey().autoincrement(),
  userId: int("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  attemptCount: int("attempt_count").default(0), // عدد المحاولات الفاشلة
  lastAttemptAt: timestamp("last_attempt_at"), // آخر محاولة
  isLocked: boolean("is_locked").default(false), // هل تم قفل الحساب مؤقتاً
  lockedUntil: timestamp("locked_until"), // وقت فتح القفل
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
});

export type OTPCode = typeof otpCodes.$inferSelect;
export type TwoFactorSettings = typeof twoFactorSettings.$inferSelect;
export type OTPAttempt = typeof otpAttempts.$inferSelect;
