import { mysqlTable, int, varchar, text, timestamp, json, boolean } from "drizzle-orm/mysql-core";

/**
 * جدول الصلاحيات - تعريف جميع الصلاحيات المتاحة في النظام
 */
export const permissions = mysqlTable("permissions", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 100 }).notNull().unique(), // مثل: "doctors.view", "doctors.create", "doctors.edit", "doctors.delete"
  name: varchar("name", { length: 255 }).notNull(), // مثل: "عرض الأطباء"
  description: text("description"), // وصف الصلاحية
  category: varchar("category", { length: 100 }).notNull(), // "doctors", "works", "invoices", "users", "roles", "system"
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Permission = typeof permissions.$inferSelect;
export type InsertPermission = typeof permissions.$inferInsert;

/**
 * جدول الأدوار - تعريف الأدوار المختلفة في النظام
 */
export const roles = mysqlTable("roles", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(), // "admin", "manager", "staff", "user"
  displayName: varchar("displayName", { length: 255 }).notNull(), // "مسؤول النظام", "مدير", "موظف", "مستخدم"
  description: text("description"), // وصف الدور
  level: int("level").notNull(), // مستوى الدور (1: مسؤول، 2: مدير، 3: موظف، 4: مستخدم)
  isSystem: boolean("isSystem").default(false).notNull(), // هل هو دور نظام (لا يمكن حذفه)
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Role = typeof roles.$inferSelect;
export type InsertRole = typeof roles.$inferInsert;

/**
 * جدول ربط الأدوار بالصلاحيات - تحديد الصلاحيات لكل دور
 */
export const rolePermissions = mysqlTable("rolePermissions", {
  id: int("id").autoincrement().primaryKey(),
  roleId: int("roleId").notNull(), // معرّف الدور
  permissionId: int("permissionId").notNull(), // معرّف الصلاحية
  grantedAt: timestamp("grantedAt").defaultNow().notNull(),
  grantedBy: int("grantedBy"), // معرّف المستخدم الذي منح الصلاحية
});

export type RolePermission = typeof rolePermissions.$inferSelect;
export type InsertRolePermission = typeof rolePermissions.$inferInsert;

/**
 * جدول ربط المستخدمين بالأدوار - تحديد أدوار المستخدمين
 */
export const userRoles = mysqlTable("userRoles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // معرّف المستخدم
  roleId: int("roleId").notNull(), // معرّف الدور
  assignedAt: timestamp("assignedAt").defaultNow().notNull(),
  assignedBy: int("assignedBy"), // معرّف المستخدم الذي أسند الدور
  expiresAt: timestamp("expiresAt"), // تاريخ انتهاء الدور (اختياري)
  isActive: boolean("isActive").default(true).notNull(),
});

export type UserRole = typeof userRoles.$inferSelect;
export type InsertUserRole = typeof userRoles.$inferInsert;

/**
 * جدول الصلاحيات المخصصة - صلاحيات إضافية خارج الأدوار
 */
export const customPermissions = mysqlTable("customPermissions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // معرّف المستخدم
  permissionId: int("permissionId").notNull(), // معرّف الصلاحية
  grantedAt: timestamp("grantedAt").defaultNow().notNull(),
  grantedBy: int("grantedBy"), // معرّف المستخدم الذي منح الصلاحية
  expiresAt: timestamp("expiresAt"), // تاريخ انتهاء الصلاحية (اختياري)
  reason: text("reason"), // السبب وراء منح الصلاحية
});

export type CustomPermission = typeof customPermissions.$inferSelect;
export type InsertCustomPermission = typeof customPermissions.$inferInsert;

/**
 * جدول سجل تغييرات الصلاحيات - لتتبع جميع التغييرات
 */
export const permissionAuditLogs = mysqlTable("permissionAuditLogs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // معرّف المستخدم المتأثر
  changedBy: int("changedBy").notNull(), // معرّف المستخدم الذي قام بالتغيير
  changeType: varchar("changeType", { length: 50 }).notNull(), // "role_assigned", "role_removed", "permission_granted", "permission_revoked"
  targetType: varchar("targetType", { length: 50 }).notNull(), // "role" أو "permission"
  targetId: int("targetId"), // معرّف الدور أو الصلاحية
  oldValue: json("oldValue"), // القيمة القديمة
  newValue: json("newValue"), // القيمة الجديدة
  reason: text("reason"), // السبب
  ipAddress: varchar("ipAddress", { length: 45 }), // عنوان IP
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PermissionAuditLogEntry = typeof permissionAuditLogs.$inferSelect;
export type InsertPermissionAuditLogEntry = typeof permissionAuditLogs.$inferInsert;
