import { mysqlTable, int, varchar, text, timestamp, json } from "drizzle-orm/mysql-core";

/**
 * جدول إعدادات الأدوار - لتخزين كلمات المرور والصلاحيات المخصصة
 */
export const roleSettings = mysqlTable("roleSettings", {
  id: int("id").autoincrement().primaryKey(),
  role: varchar("role", { length: 50 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  customPermissions: json("customPermissions").$type<string[]>(), // صلاحيات مخصصة (null = استخدام الافتراضية)
  isActive: varchar("isActive", { length: 10 }).default("true").notNull(),
  lastModifiedBy: int("lastModifiedBy"), // معرّف المستخدم الذي عدّل الإعدادات
  lastModifiedAt: timestamp("lastModifiedAt").defaultNow().onUpdateNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type RoleSettings = typeof roleSettings.$inferSelect;
export type InsertRoleSettings = typeof roleSettings.$inferInsert;

/**
 * جدول سجل تغييرات الصلاحيات - لتتبع جميع التغييرات
 */
export const permissionChangeLogs = mysqlTable("permissionChangeLogs", {
  id: int("id").autoincrement().primaryKey(),
  role: varchar("role", { length: 50 }).notNull(),
  changedBy: int("changedBy").notNull(), // معرّف المسؤول الذي قام بالتغيير
  changeType: varchar("changeType", { length: 50 }).notNull(), // "add", "remove", "reset"
  permission: varchar("permission", { length: 255 }), // الصلاحية المتغيرة (null إذا كان التغيير على كل الصلاحيات)
  oldPermissions: json("oldPermissions").$type<string[]>(), // الصلاحيات القديمة
  newPermissions: json("newPermissions").$type<string[]>(), // الصلاحيات الجديدة
  reason: text("reason"), // السبب وراء التغيير
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PermissionChangeLog = typeof permissionChangeLogs.$inferSelect;
export type InsertPermissionChangeLog = typeof permissionChangeLogs.$inferInsert;

/**
 * جدول سجل تغييرات كلمات المرور - لتتبع جميع تغييرات كلمات المرور
 */
export const passwordChangeLogs = mysqlTable("passwordChangeLogs", {
  id: int("id").autoincrement().primaryKey(),
  role: varchar("role", { length: 50 }).notNull(),
  changedBy: int("changedBy").notNull(), // معرّف المسؤول الذي قام بالتغيير
  oldPasswordHash: varchar("oldPasswordHash", { length: 255 }).notNull(),
  newPasswordHash: varchar("newPasswordHash", { length: 255 }).notNull(),
  reason: text("reason"), // السبب وراء التغيير
  ipAddress: varchar("ipAddress", { length: 45 }), // عنوان IP
  userAgent: text("userAgent"), // معلومات المتصفح
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PasswordChangeLog = typeof passwordChangeLogs.$inferSelect;
export type InsertPasswordChangeLog = typeof passwordChangeLogs.$inferInsert;


/**
 * جدول النسخ الاحتياطية - لتخزين نسخ احتياطية من إعدادات الأدوار
 */
export const systemBackups = mysqlTable("systemBackups", {
  id: int("id").autoincrement().primaryKey(),
  backupName: varchar("backupName", { length: 255 }).notNull(),
  backupType: varchar("backupType", { length: 50 }).notNull(), // "manual", "automatic", "scheduled"
  roleSettingsSnapshot: json("roleSettingsSnapshot").$type<any>(), // نسخة من جدول roleSettings
  permissionsSnapshot: json("permissionsSnapshot").$type<any>(), // نسخة من الصلاحيات
  createdBy: int("createdBy").notNull(), // معرّف المستخدم الذي قام بالنسخ الاحتياطي
  description: text("description"), // وصف النسخة الاحتياطية
  size: int("size"), // حجم النسخة بالبايت
  isRestored: varchar("isRestored", { length: 10 }).default("false").notNull(),
  restoredAt: timestamp("restoredAt"),
  restoredBy: int("restoredBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt"), // تاريخ انتهاء صلاحية النسخة
});

export type SystemBackup = typeof systemBackups.$inferSelect;
export type InsertSystemBackup = typeof systemBackups.$inferInsert;

/**
 * جدول سجل استعادة النسخ الاحتياطية
 */
export const backupRestoreLogs = mysqlTable("backupRestoreLogs", {
  id: int("id").autoincrement().primaryKey(),
  backupId: int("backupId").notNull(),
  restoredBy: int("restoredBy").notNull(),
  status: varchar("status", { length: 50 }).notNull(), // "success", "failed", "partial"
  errorMessage: text("errorMessage"),
  itemsRestored: int("itemsRestored"), // عدد العناصر المستعادة
  itemsFailed: int("itemsFailed"), // عدد العناصر التي فشلت
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BackupRestoreLog = typeof backupRestoreLogs.$inferSelect;
export type InsertBackupRestoreLog = typeof backupRestoreLogs.$inferInsert;

/**
 * جدول إعدادات النسخ الاحتياطية - للتحكم في سياسة النسخ الاحتياطي
 */
export const backupSettings = mysqlTable("backupSettings", {
  id: int("id").autoincrement().primaryKey(),
  autoBackupEnabled: varchar("autoBackupEnabled", { length: 10 }).default("true").notNull(),
  backupFrequency: varchar("backupFrequency", { length: 50 }).default("daily").notNull(), // "hourly", "daily", "weekly", "monthly"
  backupRetentionDays: int("backupRetentionDays").default(30).notNull(), // عدد أيام الاحتفاظ بالنسخ
  maxBackups: int("maxBackups").default(10).notNull(), // الحد الأقصى للنسخ المحفوظة
  lastBackupAt: timestamp("lastBackupAt"),
  nextBackupAt: timestamp("nextBackupAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BackupSettings = typeof backupSettings.$inferSelect;
export type InsertBackupSettings = typeof backupSettings.$inferInsert;
