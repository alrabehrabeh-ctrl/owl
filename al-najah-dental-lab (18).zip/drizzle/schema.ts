import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  datetime,
  json,
} from "drizzle-orm/mysql-core";

// استيراد جداول إعدادات الأدوار والنسخ الاحتياطية
export { roleSettings, permissionChangeLogs, passwordChangeLogs, systemBackups, backupRestoreLogs, backupSettings } from "./role-settings.schema";
export type { RoleSettings, InsertRoleSettings, PermissionChangeLog, InsertPermissionChangeLog, PasswordChangeLog, InsertPasswordChangeLog, SystemBackup, InsertSystemBackup, BackupRestoreLog, InsertBackupRestoreLog, BackupSettings, InsertBackupSettings } from "./role-settings.schema";

// استيراد جداول الصلاحيات والأدوار المتقدمة
export { permissions, roles, rolePermissions, userRoles, customPermissions, permissionAuditLogs } from "./permissions.schema";
export type { Permission, InsertPermission, Role, InsertRole, RolePermission, InsertRolePermission, UserRole, InsertUserRole, CustomPermission, InsertCustomPermission, PermissionAuditLogEntry, InsertPermissionAuditLogEntry } from "./permissions.schema";

// استيراد جداول سجل التدقيق
export { userSwitchAuditLog, passwordAuditLog, permissionAuditLog } from "./audit-log.schema";
export type { UserSwitchAuditLog, InsertUserSwitchAuditLog, PasswordAuditLog, InsertPasswordAuditLog, PermissionAuditLog, InsertPermissionAuditLog } from "./audit-log.schema";

// استيراد جداول سجل الأنشطة
export { activityLogs } from "./activity-log.schema";
export type { ActivityLog, InsertActivityLog } from "./activity-log.schema";

// استيراد جداول OTP والتحقق الثنائي
export { otpCodes, twoFactorSettings, otpAttempts } from "./otp.schema";
export type { OTPCode, TwoFactorSettings, OTPAttempt } from "./otp.schema";

/**
 * جدول المستخدمين - للمصادقة والتحكم بالصلاحيات
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  username: varchar("username", { length: 100 }).unique(),
  password: varchar("password", { length: 255 }),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "manager", "staff"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * جدول الأطباء - المتعاملين مع المخبر
 */
export const doctors = mysqlTable("doctors", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  specialization: varchar("specialization", { length: 255 }),
  clinic: varchar("clinic", { length: 255 }),
  address: text("address"),
  notes: text("notes"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Doctor = typeof doctors.$inferSelect;
export type InsertDoctor = typeof doctors.$inferInsert;

/**
 * جدول أنواع الأعمال - تصنيفات الأعمال المختلفة
 */
export const workTypes = mysqlTable("workTypes", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  basePrice: decimal("basePrice", { precision: 10, scale: 2 }).default("0"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WorkType = typeof workTypes.$inferSelect;
export type InsertWorkType = typeof workTypes.$inferInsert;

/**
 * جدول الأعمال - الأعمال المسجلة في المخبر
 */
export const works = mysqlTable("works", {
  id: int("id").autoincrement().primaryKey(),
  doctorId: int("doctorId").notNull(),
  workTypeId: int("workTypeId").notNull(),
  description: text("description"),
  quantity: int("quantity").default(1).notNull(),
  unitPrice: decimal("unitPrice", { precision: 10, scale: 2 }).notNull(),
  totalPrice: decimal("totalPrice", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "delivered"]).default("pending").notNull(),
  dueDate: datetime("dueDate"),
  completedDate: datetime("completedDate"),
  receptionDate: datetime("receptionDate"), // تاريخ استقبال العمل
  patientName: varchar("patientName", { length: 255 }), // اسم المريض
  toothNumbers: text("toothNumbers"), // JSON array of selected tooth numbers
  notes: text("notes"),
  attachments: text("attachments"), // JSON array of file URLs
  currencyId: int("currencyId").default(1), // العملة المستخدمة (افتراضياً الدولار)
  priceInSecondCurrency: decimal("priceInSecondCurrency", { precision: 10, scale: 2 }), // السعر بالعملة الثانية
  exchangeRateUsed: decimal("exchangeRateUsed", { precision: 18, scale: 6 }), // سعر الصرف المستخدم
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Work = typeof works.$inferSelect;
export type InsertWork = typeof works.$inferInsert;

/**
 * جدول الفواتير - فواتير الأطباء
 */
export const invoices = mysqlTable("invoices", {
  id: int("id").autoincrement().primaryKey(),
  invoiceNumber: varchar("invoiceNumber", { length: 50 }).notNull().unique(),
  doctorId: int("doctorId").notNull(),
  subtotal: decimal("subtotal", { precision: 10, scale: 2 }).notNull(),
  taxRate: decimal("taxRate", { precision: 5, scale: 2 }).default("0").notNull(),
  taxAmount: decimal("taxAmount", { precision: 10, scale: 2 }).default("0").notNull(),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  paidAmount: decimal("paidAmount", { precision: 10, scale: 2 }).default("0").notNull(),
  remainingAmount: decimal("remainingAmount", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["draft", "sent", "paid", "partial", "overdue", "cancelled"]).default("draft").notNull(),
  invoiceDate: datetime("invoiceDate").notNull(),
  dueDate: datetime("dueDate").notNull(),
  notes: text("notes"),
  attachments: text("attachments"), // JSON array of file URLs
  currencyId: int("currencyId").default(1), // العملة المستخدمة (افتراضياً الدولار)
  totalInSecondCurrency: decimal("totalInSecondCurrency", { precision: 10, scale: 2 }), // الإجمالي بالعملة الثانية
  exchangeRateUsed: decimal("exchangeRateUsed", { precision: 18, scale: 6 }), // سعر الصرف المستخدم
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = typeof invoices.$inferInsert;

/**
 * جدول تفاصيل الفاتورة - ربط الأعمال بالفواتير
 */
export const invoiceItems = mysqlTable("invoiceItems", {
  id: int("id").autoincrement().primaryKey(),
  invoiceId: int("invoiceId").notNull(),
  workId: int("workId"),
  description: varchar("description", { length: 255 }).notNull(),
  quantity: int("quantity").default(1).notNull(),
  unitPrice: decimal("unitPrice", { precision: 10, scale: 2 }).notNull(),
  totalPrice: decimal("totalPrice", { precision: 10, scale: 2 }).notNull(),
});

export type InvoiceItem = typeof invoiceItems.$inferSelect;
export type InsertInvoiceItem = typeof invoiceItems.$inferInsert;

/**
 * جدول الدفعات - تسجيل الدفعات المستلمة
 */
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  invoiceId: int("invoiceId").notNull(),
  doctorId: int("doctorId").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "check", "bank_transfer", "credit_card", "other"]).notNull(),
  paymentDate: datetime("paymentDate").notNull(),
  referenceNumber: varchar("referenceNumber", { length: 100 }),
  notes: text("notes"),
  attachments: text("attachments"), // JSON array of file URLs
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

/**
 * جدول ربط الدفعات بالأعمال - لربط دفعة واحدة بعدة أعمال
 */
export const paymentWorks = mysqlTable("paymentWorks", {
  id: int("id").autoincrement().primaryKey(),
  paymentId: int("paymentId").notNull(),
  workId: int("workId").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PaymentWork = typeof paymentWorks.$inferSelect;
export type InsertPaymentWork = typeof paymentWorks.$inferInsert;

/**
 * جدول المصروفات - مصروفات المخبر
 */
export const expenses = mysqlTable("expenses", {
  id: int("id").autoincrement().primaryKey(),
  category: mysqlEnum("category", ["salary", "rent", "materials", "utilities", "maintenance", "other"]).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  vendor: varchar("vendor", { length: 255 }),
  expenseDate: datetime("expenseDate").notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "check", "bank_transfer", "credit_card", "other"]).notNull(),
  referenceNumber: varchar("referenceNumber", { length: 100 }),
  notes: text("notes"),
  attachments: text("attachments"), // JSON array of file URLs
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = typeof expenses.$inferInsert;

/**
 * جدول الموظفين - موظفو المخبر
 */
export const employees = mysqlTable("employees", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  position: varchar("position", { length: 255 }).notNull(),
  salary: decimal("salary", { precision: 10, scale: 2 }).notNull(),
  hireDate: datetime("hireDate").notNull(),
  bankAccount: varchar("bankAccount", { length: 100 }),
  taxId: varchar("taxId", { length: 100 }),
  notes: text("notes"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = typeof employees.$inferInsert;

/**
 * جدول الرواتب - سجل دفعات الرواتب
 */
export const salaries = mysqlTable("salaries", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(),
  month: varchar("month", { length: 7 }).notNull(), // YYYY-MM format
  baseSalary: decimal("baseSalary", { precision: 10, scale: 2 }).notNull(),
  deductions: decimal("deductions", { precision: 10, scale: 2 }).default("0").notNull(),
  bonuses: decimal("bonuses", { precision: 10, scale: 2 }).default("0").notNull(),
  netSalary: decimal("netSalary", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "paid", "cancelled"]).default("pending").notNull(),
  paymentDate: datetime("paymentDate"),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "check", "bank_transfer", "credit_card", "other"]),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Salary = typeof salaries.$inferSelect;
export type InsertSalary = typeof salaries.$inferInsert;

/**
 * جدول التنبيهات - إدارة التنبيهات والإشعارات
 */
export const alerts = mysqlTable("alerts", {
  id: int("id").autoincrement().primaryKey(),
  type: mysqlEnum("type", ["overdue_work", "overdue_invoice", "payment_received", "low_balance", "salary_due"]).notNull(),
  relatedId: int("relatedId"), // ID of related entity (work, invoice, etc.)
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  severity: mysqlEnum("severity", ["low", "medium", "high"]).default("medium").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  emailSent: boolean("emailSent").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = typeof alerts.$inferInsert;

/**
 * جدول الملفات والمستندات
 */
export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileUrl: text("fileUrl").notNull(),
  fileSize: int("fileSize"),
  mimeType: varchar("mimeType", { length: 100 }),
  documentType: mysqlEnum("documentType", ["work_image", "invoice", "contract", "payment_receipt", "other"]).notNull(),
  relatedType: mysqlEnum("relatedType", ["work", "invoice", "doctor", "employee"]),
  relatedId: int("relatedId"),
  uploadedBy: int("uploadedBy"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = typeof documents.$inferInsert;

/**
 * جدول الإعدادات - إعدادات النظام
 */
export const settings = mysqlTable("settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 255 }).notNull().unique(),
  value: text("value"),
  description: text("description"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Setting = typeof settings.$inferSelect;
export type InsertSetting = typeof settings.$inferInsert;


/**
 * جدول العملات - دعم العملات المتعددة
 */
export const currencies = mysqlTable("currencies", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 3 }).notNull().unique(), // USD, SYP, etc.
  name: varchar("name", { length: 100 }).notNull(), // الدولار الأمريكي، الليرة السورية
  symbol: varchar("symbol", { length: 10 }).notNull(), // $, £, etc.
  isDefault: boolean("isDefault").default(false).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Currency = typeof currencies.$inferSelect;
export type InsertCurrency = typeof currencies.$inferInsert;

/**
 * جدول أسعار الصرف - تحديث أسعار الصرف بين العملات
 */
export const exchangeRates = mysqlTable("exchangeRates", {
  id: int("id").autoincrement().primaryKey(),
  fromCurrencyId: int("fromCurrencyId").notNull().references(() => currencies.id),
  toCurrencyId: int("toCurrencyId").notNull().references(() => currencies.id),
  rate: decimal("rate", { precision: 18, scale: 6 }).notNull(), // سعر الصرف
  date: datetime("date").notNull(), // تاريخ سعر الصرف
  source: varchar("source", { length: 100 }), // مصدر السعر (مثل: البنك المركزي)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ExchangeRate = typeof exchangeRates.$inferSelect;
export type InsertExchangeRate = typeof exchangeRates.$inferInsert;

/**
 * جدول سجل التدقيق - تتبع جميع الأنشطة الحساسة في النظام
 */
export const auditLog = mysqlTable("auditLog", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  action: varchar("action", { length: 100 }).notNull(), // user_switched, role_changed, user_created, etc.
  actionType: mysqlEnum("actionType", ["user_switch", "role_change", "user_create", "user_delete", "user_update", "login", "logout", "password_change", "other"]).notNull(),
  targetUserId: int("targetUserId").references(() => users.id), // ID of the user being acted upon
  targetType: varchar("targetType", { length: 100 }), // Type of entity affected (user, invoice, work, etc.)
  targetId: int("targetId"), // ID of the entity affected
  description: text("description"), // Detailed description of the action
  oldValue: text("oldValue"), // Previous value (for updates)
  newValue: text("newValue"), // New value (for updates)
  ipAddress: varchar("ipAddress", { length: 45 }), // IPv4 or IPv6
  userAgent: text("userAgent"), // Browser/client info
  status: mysqlEnum("status", ["success", "failed", "pending"]).default("success").notNull(),
  errorMessage: text("errorMessage"), // Error details if status is failed
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuditLog = typeof auditLog.$inferSelect;
export type InsertAuditLog = typeof auditLog.$inferInsert;


/**
 * جدول تقارير الأداء - تحليل أداء كل طبيب
 */
export const performanceReports = mysqlTable("performanceReports", {
  id: int("id").autoincrement().primaryKey(),
  doctorId: int("doctorId").notNull().references(() => doctors.id),
  period: varchar("period", { length: 7 }).notNull(), // YYYY-MM format
  totalWorks: int("totalWorks").default(0).notNull(),
  completedWorks: int("completedWorks").default(0).notNull(),
  totalRevenue: decimal("totalRevenue", { precision: 10, scale: 2 }).default("0").notNull(),
  totalExpenses: decimal("totalExpenses", { precision: 10, scale: 2 }).default("0").notNull(),
  netProfit: decimal("netProfit", { precision: 10, scale: 2 }).default("0").notNull(),
  averageWorkValue: decimal("averageWorkValue", { precision: 10, scale: 2 }).default("0").notNull(),
  profitMargin: decimal("profitMargin", { precision: 5, scale: 2 }).default("0").notNull(), // النسبة المئوية
  rating: decimal("rating", { precision: 3, scale: 1 }).default("0"), // تقييم من 0 إلى 5
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PerformanceReport = typeof performanceReports.$inferSelect;
export type InsertPerformanceReport = typeof performanceReports.$inferInsert;

/**
 * جدول التنبؤات والتوقعات - توقعات الأرباح والإيرادات
 */
export const forecasts = mysqlTable("forecasts", {
  id: int("id").autoincrement().primaryKey(),
  doctorId: int("doctorId").references(() => doctors.id), // null للتنبؤات العامة
  forecastType: mysqlEnum("forecastType", ["revenue", "profit", "expense", "general"]).notNull(),
  period: varchar("period", { length: 7 }).notNull(), // YYYY-MM format
  predictedValue: decimal("predictedValue", { precision: 10, scale: 2 }).notNull(),
  actualValue: decimal("actualValue", { precision: 10, scale: 2 }), // يتم تحديثه لاحقاً
  variance: decimal("variance", { precision: 10, scale: 2 }), // الفرق بين التنبؤ والفعلي
  confidence: decimal("confidence", { precision: 5, scale: 2 }).default("0"), // نسبة الثقة
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Forecast = typeof forecasts.$inferSelect;
export type InsertForecast = typeof forecasts.$inferInsert;

/**
 * جدول تقارير الضرائب - تقارير الضرائب والالتزامات المالية
 */
export const taxReports = mysqlTable("taxReports", {
  id: int("id").autoincrement().primaryKey(),
  period: varchar("period", { length: 7 }).notNull(), // YYYY-MM format
  totalIncome: decimal("totalIncome", { precision: 10, scale: 2 }).notNull(),
  totalExpenses: decimal("totalExpenses", { precision: 10, scale: 2 }).notNull(),
  taxableIncome: decimal("taxableIncome", { precision: 10, scale: 2 }).notNull(),
  taxRate: decimal("taxRate", { precision: 5, scale: 2 }).notNull(),
  taxAmount: decimal("taxAmount", { precision: 10, scale: 2 }).notNull(),
  deductions: decimal("deductions", { precision: 10, scale: 2 }).default("0"),
  netTax: decimal("netTax", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["draft", "submitted", "approved", "paid"]).default("draft").notNull(),
  submissionDate: datetime("submissionDate"),
  paymentDate: datetime("paymentDate"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TaxReport = typeof taxReports.$inferSelect;
export type InsertTaxReport = typeof taxReports.$inferInsert;

/**
 * جدول الحضور والإجازات - تتبع حضور الموظفين
 */
export const attendance = mysqlTable("attendance", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull().references(() => employees.id),
  date: datetime("date").notNull(),
  checkInTime: datetime("checkInTime"),
  checkOutTime: datetime("checkOutTime"),
  status: mysqlEnum("status", ["present", "absent", "late", "leave", "half_day"]).notNull(),
  leaveType: mysqlEnum("leaveType", ["sick", "vacation", "personal", "unpaid", "other"]),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = typeof attendance.$inferInsert;

/**
 * جدول تقييمات الأداء - تقييم أداء الموظفين
 */
export const performanceEvaluations = mysqlTable("performanceEvaluations", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull().references(() => employees.id),
  evaluationDate: datetime("evaluationDate").notNull(),
  evaluator: varchar("evaluator", { length: 255 }).notNull(), // اسم المقيّم
  overallRating: decimal("overallRating", { precision: 3, scale: 1 }).notNull(), // من 0 إلى 5
  workQuality: decimal("workQuality", { precision: 3, scale: 1 }).notNull(),
  productivity: decimal("productivity", { precision: 3, scale: 1 }).notNull(),
  teamwork: decimal("teamwork", { precision: 3, scale: 1 }).notNull(),
  communication: decimal("communication", { precision: 3, scale: 1 }).notNull(),
  punctuality: decimal("punctuality", { precision: 3, scale: 1 }).notNull(),
  strengths: text("strengths"),
  areasForImprovement: text("areasForImprovement"),
  comments: text("comments"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PerformanceEvaluation = typeof performanceEvaluations.$inferSelect;
export type InsertPerformanceEvaluation = typeof performanceEvaluations.$inferInsert;

/**
 * جدول الحوافز والعلاوات - إدارة الحوافز والعلاوات
 */
export const incentives = mysqlTable("incentives", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull().references(() => employees.id),
  type: mysqlEnum("type", ["bonus", "raise", "commission", "award", "other"]).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  reason: text("reason").notNull(),
  effectiveDate: datetime("effectiveDate").notNull(),
  approvedBy: varchar("approvedBy", { length: 255 }),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "implemented"]).default("pending").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Incentive = typeof incentives.$inferSelect;
export type InsertIncentive = typeof incentives.$inferInsert;

/**
 * جدول الرواتب المتقدم - تفاصيل أكثر تفصيلاً لحساب الرواتب
 */
export const advancedSalaries = mysqlTable("advancedSalaries", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull().references(() => employees.id),
  month: varchar("month", { length: 7 }).notNull(), // YYYY-MM format
  baseSalary: decimal("baseSalary", { precision: 10, scale: 2 }).notNull(),
  performanceBonus: decimal("performanceBonus", { precision: 10, scale: 2 }).default("0"),
  attendance: int("attendance").default(0), // عدد أيام الحضور
  absences: int("absences").default(0), // عدد أيام الغياب
  leaves: int("leaves").default(0), // عدد أيام الإجازة
  deductions: decimal("deductions", { precision: 10, scale: 2 }).default("0"),
  socialSecurityDeduction: decimal("socialSecurityDeduction", { precision: 10, scale: 2 }).default("0"),
  incomeTaxDeduction: decimal("incomeTaxDeduction", { precision: 10, scale: 2 }).default("0"),
  otherDeductions: decimal("otherDeductions", { precision: 10, scale: 2 }).default("0"),
  netSalary: decimal("netSalary", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "paid", "cancelled"]).default("pending").notNull(),
  paymentDate: datetime("paymentDate"),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "check", "bank_transfer", "credit_card", "other"]),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdvancedSalary = typeof advancedSalaries.$inferSelect;
export type InsertAdvancedSalary = typeof advancedSalaries.$inferInsert;
