import openpyxl from 'openpyxl';
import mysql from 'mysql2/promise';

const filePath = '/home/ubuntu/upload/جميعالاعمال.xlsx';

// قراءة الملف
const workbook = openpyxl.load_workbook(filePath);
const worksheet = workbook.active;

const works = [];
let rowCount = 0;

for (let row of worksheet.iter_rows(min_row=2, values_only=true)) {
  if (!row[0]) break; // توقف عند الصف الفارغ
  
  const [
    workId, doctorName, patientName, description, quantity, unitPrice, totalPrice, 
    status, receptionDate, dueDate, toothNumbers, notes
  ] = row;
  
  // تحويل التواريخ
  let recDate = null;
  let dueD = null;
  
  if (receptionDate) {
    if (typeof receptionDate === 'string') {
      recDate = new Date(receptionDate);
    } else if (receptionDate instanceof Date) {
      recDate = receptionDate;
    }
  }
  
  if (dueDate) {
    if (typeof dueDate === 'string') {
      dueD = new Date(dueDate);
    } else if (dueDate instanceof Date) {
      dueD = dueDate;
    }
  }
  
  works.push({
    doctorName: doctorName?.trim() || 'Unknown',
    patientName: patientName?.trim() || '',
    description: description?.trim() || '',
    quantity: parseInt(quantity) || 1,
    unitPrice: parseFloat(unitPrice) || 0,
    totalPrice: parseFloat(totalPrice) || 0,
    status: status?.trim() || 'pending',
    receptionDate: recDate,
    dueDate: dueD,
    toothNumbers: toothNumbers || '',
    notes: notes || ''
  });
  
  rowCount++;
}

console.log(`✅ تم قراءة ${rowCount} عمل من الملف`);
console.log('أول 3 أعمال:');
works.slice(0, 3).forEach((w, i) => {
  console.log(`${i+1}. ${w.doctorName} - ${w.patientName} - ${w.description}`);
  console.log(`   التاريخ: ${w.receptionDate} -> ${w.dueDate}`);
});

// حفظ البيانات في ملف JSON
import fs from 'fs';
fs.writeFileSync('/tmp/works_data.json', JSON.stringify(works, null, 2));
console.log(`\n✅ تم حفظ البيانات في /tmp/works_data.json`);
