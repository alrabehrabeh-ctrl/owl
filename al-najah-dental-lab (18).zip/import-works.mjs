import XLSX from 'xlsx';
import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import { doctors, works, workTypes } from './drizzle/schema.ts';
import { eq } from 'drizzle-orm';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import * as dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// دالة لتحويل التاريخ من Excel إلى Date
function parseExcelDate(dateValue) {
  if (!dateValue || dateValue === '-') return null;
  
  // إذا كان التاريخ كائن Date بالفعل
  if (dateValue instanceof Date) {
    return dateValue;
  }
  
  // إذا كان رقم (Excel serial number)
  if (typeof dateValue === 'number') {
    // Excel serial date: 1 = January 1, 1900
    const excelEpoch = new Date(1900, 0, 1);
    const date = new Date(excelEpoch.getTime() + (dateValue - 1) * 24 * 60 * 60 * 1000);
    return date;
  }
  
  // إذا كان نص
  if (typeof dateValue === 'string') {
    // تحويل الأرقام العربية إلى إنجليزية
    const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    
    let normalizedDate = dateValue;
    for (let i = 0; i < arabicNumbers.length; i++) {
      normalizedDate = normalizedDate.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
    }
    
    // إزالة الأحرف الخاصة
    normalizedDate = normalizedDate.replace(/[\u200E\u200F\u202A\u202B\u202C]/g, '').trim();
    
    // محاولة تحليل التاريخ بصيغ مختلفة
    // DD/MM/YYYY
    let parts = normalizedDate.split('/');
    if (parts.length === 3) {
      const day = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10);
      const year = parseInt(parts[2], 10);
      
      if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
        return new Date(year, month - 1, day);
      }
    }
    
    // YYYY-MM-DD
    parts = normalizedDate.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10);
      const day = parseInt(parts[2], 10);
      
      if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
        return new Date(year, month - 1, day);
      }
    }
    
    // محاولة تحليل التاريخ باستخدام Date.parse
    const parsedDate = new Date(normalizedDate);
    if (!isNaN(parsedDate.getTime())) {
      return parsedDate;
    }
  }
  
  return null;
}

async function importWorks() {
  let connection = null;
  let db = null;
  
  try {
    console.log('جاري الاتصال بقاعدة البيانات...');
    
    // إنشاء اتصال بقاعدة البيانات
    connection = await mysql.createConnection(process.env.DATABASE_URL);
    db = drizzle(connection);
    
    console.log('تم الاتصال بقاعدة البيانات بنجاح');
    console.log('جاري قراءة ملف Excel...');
    
    const filePath = join(__dirname, './الأعمال.xlsx');
    const workbook = XLSX.readFile(filePath);
    const worksheet = workbook.Sheets['الأعمال'];
    
    if (!worksheet) {
      console.error('لم يتم العثور على ورقة "الأعمال" في الملف');
      process.exit(1);
    }
    
    const data = XLSX.utils.sheet_to_json(worksheet);
    console.log(`تم قراءة ${data.length} صف من البيانات`);
    
    // تنظيف جدول الأعمال الحالي
    console.log('جاري حذف البيانات القديمة...');
    await db.delete(works);
    
    // الحصول على قائمة الأطباء الموجودين
    const existingDoctors = await db.select().from(doctors);
    const doctorMap = new Map();
    existingDoctors.forEach(doc => {
      doctorMap.set(doc.name.toLowerCase(), doc.id);
    });
    
    // الحصول على قائمة أنواع الأعمال المتاحة
    const workTypesList = await db.select().from(workTypes);
    const workTypeMap = new Map();
    workTypesList.forEach(wt => {
      workTypeMap.set(wt.name.toLowerCase(), wt.id);
    });
    console.log('Work Types Map:', Array.from(workTypeMap.entries()));
    
    // نوع العمل الافتراضي
    let defaultWorkTypeId = workTypesList.length > 0 ? workTypesList[0].id : 1;
    
    let successCount = 0;
    let errorCount = 0;
    
    // استيراد كل عمل
    for (let i = 0; i < data.length; i++) {
      const row = data[i];
      
      try {
        let doctorId = null;
        const doctorName = row['اسم الطبيب'] ? row['اسم الطبيب'].trim() : null;
        
        if (doctorName) {
          // البحث عن الطبيب في الخريطة
          doctorId = doctorMap.get(doctorName.toLowerCase());
          
          if (!doctorId) {
            // إنشاء طبيب جديد
            const result = await db.insert(doctors).values({
              name: doctorName,
              isActive: true,
            });
            doctorId = result.insertId;
            doctorMap.set(doctorName.toLowerCase(), doctorId);
          }
        }
        
        const receptionDate = parseExcelDate(row['تاريخ الاستقبال']);
        const deliveryDate = parseExcelDate(row['تاريخ التسليم']);
        
        const totalPrice = parseFloat(row['السعر الإجمالي']) || 0;
        const unitPrice = parseFloat(row['السعر']) || totalPrice;
        const quantity = parseInt(row['الكمية']) || 1;
        
        // تحديد الحالة
        let status = 'pending';
        if (row['الحالة'] === 'delivered' || deliveryDate) {
          status = 'delivered';
        }
        
        // استخدام تاريخ الاستقبال كتاريخ العمل (workDate)
        const workDate = receptionDate || new Date();
        
        // قراءة نوع العمل من حقل الوصف (الوصف يحتوي على نوع العمل)
        let workTypeId = defaultWorkTypeId;
        const workTypeName = row['الوصف'] ? row['الوصف'].trim() : null;
        if (workTypeName && workTypeName !== '-') {
          let mappedTypeId = workTypeMap.get(workTypeName.toLowerCase());
          
          if (!mappedTypeId) {
            for (const [key, id] of workTypeMap.entries()) {
              if (key.includes(workTypeName.toLowerCase()) || workTypeName.toLowerCase().includes(key)) {
                mappedTypeId = id;
                break;
              }
            }
          }
          
          if (mappedTypeId) {
            workTypeId = mappedTypeId;
          } else {
            workTypeId = defaultWorkTypeId;
          }
        }
        
        await db.insert(works).values({
          doctorId: doctorId || 1,
          workTypeId: workTypeId,
          description: row['الوصف'] && row['الوصف'] !== '-' ? row['الوصف'] : null,
          quantity: quantity,
          unitPrice: unitPrice.toString(),
          totalPrice: totalPrice.toString(),
          status: status,
          receptionDate: receptionDate,
          completedDate: deliveryDate,
          patientName: row['اسم المريض'] && row['اسم المريض'] !== '-' ? row['اسم المريض'] : null,
          toothNumbers: row['أرقام الأسنان'] && row['أرقام الأسنان'] !== '-' ? JSON.stringify(row['أرقام الأسنان'].split(',').map(t => t.trim())) : null,
          notes: row['الملاحظات'] && row['الملاحظات'] !== '-' ? row['الملاحظات'] : null,
          createdAt: workDate,
        });
        
        successCount++;
        
        if ((i + 1) % 50 === 0) {
          console.log(`تم استيراد ${i + 1} عمل...`);
        }
      } catch (error) {
        errorCount++;
        console.error(`خطأ في الصف ${i + 1}:`, error.message);
      }
    }
    
    console.log(`\n=== ملخص الاستيراد ===`);
    console.log(`عدد الأعمال المستوردة بنجاح: ${successCount}`);
    console.log(`عدد الأخطاء: ${errorCount}`);
    console.log(`إجمالي: ${successCount + errorCount}`);
    
    // التحقق من البيانات المستوردة
    const allWorks = await db.select().from(works);
    const deliveredWorks = allWorks.filter(w => w.status === 'delivered');
    const pendingWorks = allWorks.filter(w => w.status === 'pending');
    const totalRevenue = allWorks.reduce((sum, w) => sum + parseFloat(w.totalPrice || 0), 0);
    
    console.log(`\n=== إحصائيات البيانات ===`);
    console.log(`إجمالي الأعمال: ${allWorks.length}`);
    console.log(`الأعمال المسلمة: ${deliveredWorks.length}`);
    console.log(`الأعمال المعلقة: ${pendingWorks.length}`);
    console.log(`إجمالي الإيرادات: $${totalRevenue.toFixed(2)}`);
    
    await connection.end();
    process.exit(0);
  } catch (error) {
    console.error('خطأ في الاستيراد:', error);
    if (connection) {
      await connection.end();
    }
    process.exit(1);
  }
}

importWorks();
