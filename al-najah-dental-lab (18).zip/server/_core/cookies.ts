import type { CookieOptions, Request } from "express";

const LOCAL_HOSTS = new Set(["localhost", "127.0.0.1", "::1"]);

function isIpAddress(host: string) {
  // Basic IPv4 check and IPv6 presence detection.
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return true;
  return host.includes(":");
}

function isSecureRequest(req: Request) {
  // Check X-Forwarded-Proto header FIRST (for proxy/load balancer)
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (forwardedProto) {
    const protoList = Array.isArray(forwardedProto)
      ? forwardedProto
      : forwardedProto.split(",");
    const isHttps = protoList.some(proto => proto.trim().toLowerCase() === "https");
    if (isHttps) {
      return true;
    }
  }

  // Check if the request protocol is HTTPS
  if (req.protocol === "https") return true;

  // For development/local environments, allow non-secure cookies
  const hostname = req.hostname || "";
  if (hostname.includes("localhost") || hostname.includes("127.0.0.1") || hostname.includes("::1")) {
    return false;
  }

  // For other cases, default to non-secure (will be overridden by x-forwarded-proto if present)
  return false;
}

export function getSessionCookieOptions(
  req: Request
): Pick<CookieOptions, "domain" | "httpOnly" | "path" | "sameSite" | "secure"> {
  const hostname = req.hostname;
  
  // Don't set domain for session cookies - let the browser handle it
  const domain = undefined;

  // Check if this is a secure request (HTTPS)
  const isProduction = process.env.NODE_ENV === "production";
  const isSecure = isSecureRequest(req);
  
  // For production/HTTPS, use Secure flag
  // For development, don't use Secure flag
  const secure = isProduction || isSecure;

  console.log("[Cookies] hostname:", hostname);
  console.log("[Cookies] domain:", domain);
  console.log("[Cookies] secure:", secure);
  console.log("[Cookies] isProduction:", isProduction);
  console.log("[Cookies] isSecure:", isSecure);
  console.log("[Cookies] sameSite: Lax");

  return {
    domain,
    httpOnly: true,
    path: "/",
    sameSite: "lax",
    secure,
  };
}
