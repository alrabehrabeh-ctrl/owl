/**
 * وحدة إدارة أسعار الصرف من API خارجي
 * تدعم تحديث أسعار الصرف تلقائياً من مصادر موثوقة
 */

import { getDb } from "../db";
import { exchangeRates } from "../../drizzle/schema";
import type { MySqlDatabase } from "drizzle-orm/mysql2";
import { eq, and } from "drizzle-orm";

// استخدام exchangerate-api.com (مجاني بدون مفتاح API)
const EXCHANGE_RATE_API_URL = "https://api.exchangerate-api.com/v4/latest";

/**
 * جلب سعر الصرف من API خارجي
 * @param baseCurrency العملة الأساسية (مثل USD)
 * @param targetCurrency العملة المستهدفة (مثل SYP)
 * @returns سعر الصرف
 */
export async function fetchExchangeRateFromAPI(
  baseCurrency: string,
  targetCurrency: string
): Promise<number | null> {
  try {
    const response = await fetch(`${EXCHANGE_RATE_API_URL}/${baseCurrency}`);
    
    if (!response.ok) {
      console.error(`Failed to fetch exchange rates: ${response.statusText}`);
      return null;
    }

    const data = await response.json();
    const rate = data.rates?.[targetCurrency];

    if (!rate) {
      console.error(`Exchange rate not found for ${targetCurrency}`);
      return null;
    }

    return rate;
  } catch (error) {
    console.error("Error fetching exchange rates:", error);
    return null;
  }
}

/**
 * تحديث سعر الصرف في قاعدة البيانات
 * @param fromCurrencyId معرف العملة الأساسية
 * @param toCurrencyId معرف العملة المستهدفة
 * @param rate سعر الصرف الجديد
 */
export async function updateExchangeRate(
  fromCurrencyId: number,
  toCurrencyId: number,
  rate: number
) {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    const existingRate = await db
      .select()
      .from(exchangeRates)
      .where(
        and(
          eq(exchangeRates.fromCurrencyId, fromCurrencyId),
          eq(exchangeRates.toCurrencyId, toCurrencyId)
        )
      )
      .limit(1);

    if (existingRate.length > 0) {
      await db
        .update(exchangeRates)
        .set({ rate: rate as any, updatedAt: new Date() })
        .where(
          and(
            eq(exchangeRates.fromCurrencyId, fromCurrencyId),
            eq(exchangeRates.toCurrencyId, toCurrencyId)
          )
        );
    } else {
      await db.insert(exchangeRates).values({
        fromCurrencyId: fromCurrencyId as any,
        toCurrencyId: toCurrencyId as any,
        rate: rate as any,
        date: new Date(),
      });
    }

    console.log(
      `Exchange rate updated: ${fromCurrencyId} -> ${toCurrencyId} = ${rate}`
    );
    return true;
  } catch (error) {
    console.error("Error updating exchange rate:", error);
    return false;
  }
}

/**
 * تحديث أسعار الصرف تلقائياً من API
 * يتم استدعاء هذه الدالة يومياً
 */
export async function updateExchangeRatesDaily() {
  try {
    console.log("Starting daily exchange rate update...");

    // جلب سعر الصرف من USD إلى SYP
    const usdToSypRate = await fetchExchangeRateFromAPI("USD", "SYP");

    if (usdToSypRate) {
      // افترض أن معرفات العملات هي: USD = 1, SYP = 2
      await updateExchangeRate(1, 2, usdToSypRate);
      console.log(`USD to SYP rate updated: 1 USD = ${usdToSypRate} SYP`);
    }

    // يمكن إضافة عملات أخرى هنا
    // const eurToSypRate = await fetchExchangeRateFromAPI("EUR", "SYP");
    // if (eurToSypRate) {
    //   await updateExchangeRate(3, 2, eurToSypRate);
    // }

    console.log("Daily exchange rate update completed");
    return true;
  } catch (error) {
    console.error("Error in daily exchange rate update:", error);
    return false;
  }
}

/**
 * جدولة التحديث التلقائي اليومي
 * يتم استدعاء هذه الدالة عند بدء الخادم
 */
export function scheduleExchangeRateUpdates() {
  // تحديث أسعار الصرف كل يوم في الساعة 12:00 صباحاً
  const now = new Date();
  const nextRun = new Date(now);
  nextRun.setHours(0, 0, 0, 0);
  nextRun.setDate(nextRun.getDate() + 1);

  const delay = nextRun.getTime() - now.getTime();

  console.log(`Exchange rate update scheduled for ${nextRun}`);

  // تشغيل التحديث الأول بعد التأخير المحسوب
  setTimeout(() => {
    updateExchangeRatesDaily();

    // ثم تشغيل التحديث كل 24 ساعة
    setInterval(updateExchangeRatesDaily, 24 * 60 * 60 * 1000);
  }, delay);
}
