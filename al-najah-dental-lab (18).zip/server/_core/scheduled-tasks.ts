import { getDb } from "../db";
import { exchangeRates, currencies } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";

// متغير عام لتتبع حالة المهمة المجدولة
let dailyUpdateInterval: NodeJS.Timeout | null = null;
let isAutoUpdateEnabled = false;

/**
 * ابدأ التحديث التلقائي اليومي لأسعار الصرف
 * يتم التحديث في الساعة 00:00 كل يوم
 */
export async function startDailyExchangeRateUpdate() {
  if (isAutoUpdateEnabled) {
    console.log("[ScheduledTasks] التحديث التلقائي قيد التشغيل بالفعل");
    return;
  }

  isAutoUpdateEnabled = true;
  console.log("[ScheduledTasks] بدء التحديث التلقائي اليومي لأسعار الصرف");

  // حساب الوقت حتى منتصف الليل
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(0, 0, 0, 0);

  const timeUntilMidnight = tomorrow.getTime() - now.getTime();

  // جدول التحديث الأول في منتصف الليل
  setTimeout(async () => {
    console.log("[ScheduledTasks] تشغيل التحديث التلقائي لأسعار الصرف");
    await performDailyUpdate();

    // ثم جدول التحديث كل 24 ساعة
    dailyUpdateInterval = setInterval(async () => {
      console.log("[ScheduledTasks] تشغيل التحديث التلقائي اليومي لأسعار الصرف");
      await performDailyUpdate();
    }, 24 * 60 * 60 * 1000); // كل 24 ساعة
  }, timeUntilMidnight);

  console.log(
    `[ScheduledTasks] سيتم التحديث الأول في ${tomorrow.toLocaleString("ar-SA")}`
  );
}

/**
 * أوقف التحديث التلقائي اليومي
 */
export function stopDailyExchangeRateUpdate() {
  if (dailyUpdateInterval) {
    clearInterval(dailyUpdateInterval);
    dailyUpdateInterval = null;
  }
  isAutoUpdateEnabled = false;
  console.log("[ScheduledTasks] تم إيقاف التحديث التلقائي لأسعار الصرف");
}

/**
 * تنفيذ التحديث اليومي
 */
async function performDailyUpdate() {
  try {
    console.log("[ScheduledTasks] بدء تحديث أسعار الصرف من API...");

    const db = await getDb();
    if (!db) {
      console.error("[ScheduledTasks] لم يتم الاتصال بقاعدة البيانات");
      return;
    }
    // جلب العملات المتاحة
    const allCurrencies = await db.select().from(currencies);

    if (allCurrencies.length < 2) {
      console.warn(
        "[ScheduledTasks] لا توجد عملات كافية لتحديث أسعار الصرف"
      );
      return;
    }

    // تحديث أسعار الصرف بين جميع العملات
    for (let i = 0; i < allCurrencies.length; i++) {
      for (let j = i + 1; j < allCurrencies.length; j++) {
        const fromCurrency = allCurrencies[i];
        const toCurrency = allCurrencies[j];

        try {
          // محاولة جلب سعر الصرف من API
          const response = await fetch(
            `https://api.exchangerate-api.com/v4/latest/${fromCurrency.code}`
          );

          if (!response.ok) {
            console.warn(
              `[ScheduledTasks] فشل جلب سعر الصرف من ${fromCurrency.code}`
            );
            continue;
          }

          const data = await response.json();
          const rate = data.rates[toCurrency.code];

          if (!rate) {
            console.warn(
              `[ScheduledTasks] لم يتم العثور على سعر صرف من ${fromCurrency.code} إلى ${toCurrency.code}`
            );
            continue;
          }

          // تحديث قاعدة البيانات
          const db = await getDb();
          if (!db) continue;
          const existingRate = await db
            .select()
            .from(exchangeRates)
            .where(
              and(
                eq(exchangeRates.fromCurrencyId, fromCurrency.id),
                eq(exchangeRates.toCurrencyId, toCurrency.id)
              )
            )
            .limit(1);

          if (existingRate.length > 0) {
            // تحديث السعر الموجود
            await db
              .update(exchangeRates)
              .set({
                rate: rate.toString(),
                date: new Date(),
                updatedAt: new Date(),
              })
              .where(eq(exchangeRates.id, existingRate[0].id));

            console.log(
              `[ScheduledTasks] تم تحديث سعر الصرف: 1 ${fromCurrency.code} = ${rate} ${toCurrency.code}`
            );
          } else {
            // إضافة سعر جديد
            await db.insert(exchangeRates).values({
              date: new Date(),
              fromCurrencyId: fromCurrency.id,
              toCurrencyId: toCurrency.id,
              rate: rate.toString(),
              createdAt: new Date(),
              updatedAt: new Date(),
            });

            console.log(
              `[ScheduledTasks] تم إضافة سعر صرف جديد: 1 ${fromCurrency.code} = ${rate} ${toCurrency.code}`
            );
          }
        } catch (error) {
          console.error(
            `[ScheduledTasks] خطأ في تحديث سعر الصرف من ${fromCurrency.code} إلى ${toCurrency.code}:`,
            error
          );
        }
      }
    }

    console.log("[ScheduledTasks] اكتمل التحديث اليومي لأسعار الصرف");
  } catch (error) {
    console.error(
      "[ScheduledTasks] خطأ في تنفيذ التحديث اليومي لأسعار الصرف:",
      error
    );
  }
}

/**
 * الحصول على حالة التحديث التلقائي
 */
export function isAutoUpdateActive(): boolean {
  return isAutoUpdateEnabled;
}

/**
 * تحديث أسعار الصرف يدوياً
 */
export async function manualUpdateExchangeRates() {
  try {
    console.log("[ScheduledTasks] بدء التحديث اليدوي لأسعار الصرف");
    await performDailyUpdate();
    console.log("[ScheduledTasks] اكتمل التحديث اليدوي لأسعار الصرف");
    return { success: true, message: "تم تحديث أسعار الصرف بنجاح" };
  } catch (error) {
    console.error("[ScheduledTasks] خطأ في التحديث اليدوي:", error);
    return {
      success: false,
      message: "حدث خطأ أثناء تحديث أسعار الصرف",
    };
  }
}
