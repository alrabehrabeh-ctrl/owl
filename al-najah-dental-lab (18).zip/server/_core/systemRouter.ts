import { z } from "zod";
import { notifyOwner } from "./notification";
import { adminProcedure, publicProcedure, router } from "./trpc";
import {
  startDailyExchangeRateUpdate,
  stopDailyExchangeRateUpdate,
  isAutoUpdateActive,
  manualUpdateExchangeRates,
} from "./scheduled-tasks";

export const systemRouter = router({
  health: publicProcedure
    .input(
      z.object({
        timestamp: z.number().min(0, "timestamp cannot be negative"),
      })
    )
    .query(() => ({
      ok: true,
    })),

  notifyOwner: adminProcedure
    .input(
      z.object({
        title: z.string().min(1, "title is required"),
        content: z.string().min(1, "content is required"),
      })
    )
    .mutation(async ({ input }) => {
      const delivered = await notifyOwner(input);
      return {
        success: delivered,
      } as const;
    }),

  // بدء التحديث التلقائي لأسعار الصرف
  startAutoUpdate: adminProcedure.mutation(async () => {
    startDailyExchangeRateUpdate();
    return { success: true, message: "تم بدء التحديث التلقائي", isActive: isAutoUpdateActive() };
  }),

  // إيقاف التحديث التلقائي لأسعار الصرف
  stopAutoUpdate: adminProcedure.mutation(async () => {
    stopDailyExchangeRateUpdate();
    return { success: true, message: "تم إيقاف التحديث التلقائي", isActive: isAutoUpdateActive() };
  }),

  // الحصول على حالة التحديث التلقائي
  getAutoUpdateStatus: publicProcedure.query(async () => {
    return { isActive: isAutoUpdateActive() };
  }),

  // تحديث يدوي فوري لأسعار الصرف
  manualUpdateExchangeRates: adminProcedure.mutation(async () => {
    return await manualUpdateExchangeRates();
  }),
});
