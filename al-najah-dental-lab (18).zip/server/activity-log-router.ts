import { router, publicProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { getDb } from "./db";
import { activityLogs } from "../drizzle/schema";
import { eq, desc, and } from "drizzle-orm";

export const activityLogRouter = router({
  /**
   * تسجيل نشاط جديد
   */
  logActivity: publicProcedure
    .input(
      z.object({
        action: z.string(), // create, update, delete
        entityType: z.string(), // doctor, work, payment
        entityId: z.number().optional(),
        entityName: z.string().optional(),
        description: z.string().optional(),
        oldValues: z.any().optional(),
        newValues: z.any().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const database = await getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        await database.insert(activityLogs).values({
          userId: ctx.user?.id || 0,
          action: input.action,
          entityType: input.entityType,
          entityId: input.entityId,
          entityName: input.entityName,
          description: input.description,
          oldValues: input.oldValues ? JSON.stringify(input.oldValues) : null,
          newValues: input.newValues ? JSON.stringify(input.newValues) : null,
          ipAddress: ctx.req.headers["x-forwarded-for"]?.toString() || ctx.req.socket?.remoteAddress || "",
          userAgent: ctx.req.headers["user-agent"]?.toString() || "",
          status: "pending",
        });

        return { success: true };
      } catch (error) {
        console.error("[LogActivity] Error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل تسجيل النشاط",
        });
      }
    }),

  /**
   * الحصول على جميع الأنشطة المعلقة (للمسؤول)
   */
  getPendingActivities: publicProcedure
    .input(
      z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input, ctx }) => {
      const database = await getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // التحقق من أن المستخدم مسؤول
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "ليس لديك صلاحية للوصول إلى هذه البيانات",
        });
      }

      try {
        const activities = await database
          .select()
          .from(activityLogs)
          .where(eq(activityLogs.status, "pending"))
          .orderBy(desc(activityLogs.createdAt))
          .limit(input.limit)
          .offset(input.offset);

        const total = await database
          .select({ count: activityLogs.id })
          .from(activityLogs)
          .where(eq(activityLogs.status, "pending"));

        return {
          activities,
          total: total[0]?.count || 0,
        };
      } catch (error) {
        console.error("[GetPendingActivities] Error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل جلب الأنشطة",
        });
      }
    }),

  /**
   * الحصول على جميع الأنشطة
   */
  getAllActivities: publicProcedure
    .input(
      z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
        status: z.enum(["pending", "approved", "rejected"]).optional(),
      })
    )
    .query(async ({ input, ctx }) => {
      const database = await getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // التحقق من أن المستخدم مسؤول
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "ليس لديك صلاحية للوصول إلى هذه البيانات",
        });
      }

      try {
        const whereConditions = input.status
          ? eq(activityLogs.status, input.status)
          : undefined;

        const activities = await database
          .select()
          .from(activityLogs)
          .where(whereConditions)
          .orderBy(desc(activityLogs.createdAt))
          .limit(input.limit)
          .offset(input.offset);

        return { activities };
      } catch (error) {
        console.error("[GetAllActivities] Error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل جلب الأنشطة",
        });
      }
    }),

  /**
   * الموافقة على نشاط
   */
  approveActivity: publicProcedure
    .input(
      z.object({
        activityId: z.number(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const database = await getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // التحقق من أن المستخدم مسؤول
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "ليس لديك صلاحية للقيام بهذا الإجراء",
        });
      }

      try {
        await database
          .update(activityLogs)
          .set({
            status: "approved",
            reviewedBy: ctx.user?.id || 0,
            reviewedAt: new Date(),
            reviewNotes: input.notes,
          })
          .where(eq(activityLogs.id, input.activityId));

        return { success: true };
      } catch (error) {
        console.error("[ApproveActivity] Error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل الموافقة على النشاط",
        });
      }
    }),

  /**
   * رفض نشاط
   */
  rejectActivity: publicProcedure
    .input(
      z.object({
        activityId: z.number(),
        reason: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const database = await getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // التحقق من أن المستخدم مسؤول
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "ليس لديك صلاحية للقيام بهذا الإجراء",
        });
      }

      try {
        await database
          .update(activityLogs)
          .set({
            status: "rejected",
            reviewedBy: ctx.user?.id || 0,
            reviewedAt: new Date(),
            reviewNotes: input.reason,
          })
          .where(eq(activityLogs.id, input.activityId));

        return { success: true };
      } catch (error) {
        console.error("[RejectActivity] Error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل رفض النشاط",
        });
      }
    }),

  /**
   * الحصول على إحصائيات الأنشطة
   */
  getActivityStats: publicProcedure.query(async ({ ctx }) => {
    const database = await getDb();
    if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    // التحقق من أن المستخدم مسؤول
    if (ctx.user?.role !== "admin") {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "ليس لديك صلاحية للوصول إلى هذه البيانات",
      });
    }

    try {
      const pending = await database
        .select({ count: activityLogs.id })
        .from(activityLogs)
        .where(eq(activityLogs.status, "pending"));

      const approved = await database
        .select({ count: activityLogs.id })
        .from(activityLogs)
        .where(eq(activityLogs.status, "approved"));

      const rejected = await database
        .select({ count: activityLogs.id })
        .from(activityLogs)
        .where(eq(activityLogs.status, "rejected"));

      return {
        pending: pending[0]?.count || 0,
        approved: approved[0]?.count || 0,
        rejected: rejected[0]?.count || 0,
        total: (pending[0]?.count || 0) + (approved[0]?.count || 0) + (rejected[0]?.count || 0),
      };
    } catch (error) {
      console.error("[GetActivityStats] Error:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "فشل جلب الإحصائيات",
      });
    }
  }),
});
