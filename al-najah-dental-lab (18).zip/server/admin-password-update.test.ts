import { describe, it, expect } from "vitest";
import { getDb } from "./db";
import { roleSettings } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { hashPassword, verifyPassword } from "./password-manager";

describe("Admin Password Update Tests", () => {
  it("should verify that admin password is correctly hashed", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // جلب إعدادات المسؤول
    const adminSettings = await db
      .select()
      .from(roleSettings)
      .where(eq(roleSettings.role, "admin"))
      .limit(1);

    expect(adminSettings.length).toBeGreaterThan(0);
    expect(adminSettings[0].passwordHash).toBeDefined();

    // التحقق من أن كلمة المرور admin1985 تطابق الـ hash
    const isValid = verifyPassword("admin1985", adminSettings[0].passwordHash);
    expect(isValid).toBe(true);
  });

  it("should reject incorrect password for admin", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    const adminSettings = await db
      .select()
      .from(roleSettings)
      .where(eq(roleSettings.role, "admin"))
      .limit(1);

    expect(adminSettings.length).toBeGreaterThan(0);

    // التحقق من أن كلمة مرور خاطئة ترفع
    const isValid = verifyPassword("wrongPassword", adminSettings[0].passwordHash);
    expect(isValid).toBe(false);
  });

  it("should have consistent password hash", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    const adminSettings = await db
      .select()
      .from(roleSettings)
      .where(eq(roleSettings.role, "admin"))
      .limit(1);

    expect(adminSettings.length).toBeGreaterThan(0);

    // التحقق من أن الـ hash لا يتغير
    const hash1 = adminSettings[0].passwordHash;
    const hash2 = adminSettings[0].passwordHash;

    expect(hash1).toBe(hash2);
  });

  it("should verify admin password multiple times", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    const adminSettings = await db
      .select()
      .from(roleSettings)
      .where(eq(roleSettings.role, "admin"))
      .limit(1);

    expect(adminSettings.length).toBeGreaterThan(0);

    // التحقق من كلمة المرور عدة مرات
    for (let i = 0; i < 5; i++) {
      const isValid = verifyPassword("admin1985", adminSettings[0].passwordHash);
      expect(isValid).toBe(true);
    }
  });

  it("should have different hash for different password", () => {
    const password1 = "admin1985";
    const password2 = "admin";

    const hash1 = hashPassword(password1);
    const hash2 = hashPassword(password2);

    expect(hash1).not.toBe(hash2);
    expect(verifyPassword(password1, hash1)).toBe(true);
    expect(verifyPassword(password2, hash2)).toBe(true);
    expect(verifyPassword(password1, hash2)).toBe(false);
    expect(verifyPassword(password2, hash1)).toBe(false);
  });

  it("should ensure password is case sensitive", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    const adminSettings = await db
      .select()
      .from(roleSettings)
      .where(eq(roleSettings.role, "admin"))
      .limit(1);

    expect(adminSettings.length).toBeGreaterThan(0);

    // التحقق من حساسية الأحرف الكبيرة والصغيرة
    expect(verifyPassword("admin1985", adminSettings[0].passwordHash)).toBe(true);
    expect(verifyPassword("ADMIN1985", adminSettings[0].passwordHash)).toBe(false);
    expect(verifyPassword("Admin1985", adminSettings[0].passwordHash)).toBe(false);
  });
});
