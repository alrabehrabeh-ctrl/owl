import { z } from "zod";
import { getDb } from "./db";
import { userSwitchAuditLog, passwordAuditLog, permissionAuditLog } from "../drizzle/audit-log.schema";
import { users } from "../drizzle/schema";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { router, publicProcedure, protectedProcedure } from "./_core/trpc";

export const auditLogRouter = router({
  // تسجيل محاولة تبديل المستخدم
  logUserSwitch: protectedProcedure
    .input(
      z.object({
        switchedTo: z.number(),
        status: z.enum(["success", "failed"]),
        failureReason: z.string().optional(),
        ipAddress: z.string().optional(),
        userAgent: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        await db.insert(userSwitchAuditLog).values({
          switchedBy: ctx.user.id,
          switchedTo: input.switchedTo,
          status: input.status,
          failureReason: input.failureReason,
          ipAddress: input.ipAddress,
          userAgent: input.userAgent,
        });

        return { success: true };
      } catch (error) {
        console.error("[auditLogRouter] Failed to log user switch:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل تسجيل محاولة تبديل المستخدم",
        });
      }
    }),

  // الحصول على سجل تبديل المستخدمين
  getUserSwitchLog: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      })
    )
    .query(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        let whereConditions = undefined;
        
        if (input.startDate || input.endDate) {
          const conditions = [];
          if (input.startDate) {
            conditions.push(gte(userSwitchAuditLog.createdAt, input.startDate));
          }
          if (input.endDate) {
            conditions.push(lte(userSwitchAuditLog.createdAt, input.endDate));
          }
          if (conditions.length > 0) {
            whereConditions = and(...conditions);
          }
        }

        const query = db
          .select()
          .from(userSwitchAuditLog)
          .orderBy(desc(userSwitchAuditLog.createdAt))
          .limit(input.limit)
          .offset(input.offset);

        const logs = whereConditions ? await query.where(whereConditions) : await query;

        return logs;
      } catch (error) {
        console.error("[auditLogRouter] Failed to fetch user switch log:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل جلب سجل تبديل المستخدمين",
        });
      }
    }),

  // الحصول على سجل تغيير كلمات المرور
  getPasswordAuditLog: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        const logs = await db
          .select()
          .from(passwordAuditLog)
          .orderBy(desc(passwordAuditLog.createdAt))
          .limit(input.limit)
          .offset(input.offset);

        return logs;
      } catch (error) {
        console.error("[auditLogRouter] Failed to fetch password audit log:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل جلب سجل تغيير كلمات المرور",
        });
      }
    }),

  // الحصول على سجل تغيير الصلاحيات
  getPermissionAuditLog: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        const logs = await db
          .select()
          .from(permissionAuditLog)
          .orderBy(desc(permissionAuditLog.createdAt))
          .limit(input.limit)
          .offset(input.offset);

        return logs;
      } catch (error) {
        console.error("[auditLogRouter] Failed to fetch permission audit log:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل جلب سجل تغيير الصلاحيات",
        });
      }
    }),
});
