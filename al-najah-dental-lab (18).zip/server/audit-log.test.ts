import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { userSwitchAuditLog, passwordAuditLog, permissionAuditLog } from "../drizzle/audit-log.schema";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";

describe("Audit Log Tests", () => {
  let db: any;
  let testUserId: number;

  beforeAll(async () => {
    db = await getDb();

    const result = await db.insert(users).values({
      openId: `test-${Date.now()}`,
      name: "مستخدم الاختبار",
      email: `test-${Date.now()}@example.com`,
      role: "admin",
      loginMethod: "manual",
    });

    const inserted = await db
      .select()
      .from(users)
      .where(eq(users.email, `test-${Date.now()}@example.com`))
      .limit(1);

    testUserId = inserted[0]?.id || 1;
  });

  afterAll(async () => {
    if (db && testUserId) {
      await db.delete(userSwitchAuditLog);
      await db.delete(passwordAuditLog);
      await db.delete(permissionAuditLog);
    }
  });

  describe("User Switch Audit Log", () => {
    it("should log successful user switch", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: testUserId,
        switchedTo: testUserId + 1,
        status: "success",
        ipAddress: "192.168.1.1",
        userAgent: "Mozilla/5.0",
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.status, "success"));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[0].status).toBe("success");
    });

    it("should log failed user switch with reason", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: testUserId,
        switchedTo: testUserId + 1,
        status: "failed",
        failureReason: "كلمة السر غير صحيحة",
        ipAddress: "192.168.1.2",
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.status, "failed"));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[0].failureReason).toBe("كلمة السر غير صحيحة");
    });

    it("should record IP address and user agent", async () => {
      const ipAddress = "10.0.0.1";
      const userAgent = "Chrome/91.0";

      await db.insert(userSwitchAuditLog).values({
        switchedBy: testUserId,
        switchedTo: testUserId + 1,
        status: "success",
        ipAddress,
        userAgent,
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.ipAddress, ipAddress));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[0].userAgent).toBe(userAgent);
    });

    it("should record timestamp", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: testUserId,
        switchedTo: testUserId + 1,
        status: "success",
      });

      const logs = await db.select().from(userSwitchAuditLog);

      expect(logs.length).toBeGreaterThan(0);
      const logTime = new Date(logs[logs.length - 1].createdAt);
      expect(logTime).toBeDefined();
      expect(logTime.getTime()).toBeGreaterThan(0);
    });
  });

  describe("Password Audit Log", () => {
    it("should log password change attempt", async () => {
      await db.insert(passwordAuditLog).values({
        role: "admin",
        changedBy: testUserId,
        status: "success",
        ipAddress: "192.168.1.1",
      });

      const logs = await db
        .select()
        .from(passwordAuditLog)
        .where(eq(passwordAuditLog.role, "admin"));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[0].status).toBe("success");
    });

    it("should log failed password change", async () => {
      await db.insert(passwordAuditLog).values({
        role: "manager",
        changedBy: testUserId,
        status: "failed",
        failureReason: "الدور غير موجود",
      });

      const logs = await db
        .select()
        .from(passwordAuditLog)
        .where(eq(passwordAuditLog.role, "manager"));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[0].failureReason).toBe("الدور غير موجود");
    });
  });

  describe("Permission Audit Log", () => {
    it("should log permission addition", async () => {
      await db.insert(permissionAuditLog).values({
        role: "staff",
        changedBy: testUserId,
        changeType: "add",
        permission: "view_reports",
        status: "success",
      });

      const logs = await db
        .select()
        .from(permissionAuditLog)
        .where(eq(permissionAuditLog.changeType, "add"));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[0].permission).toBe("view_reports");
    });

    it("should log permission removal", async () => {
      await db.insert(permissionAuditLog).values({
        role: "user",
        changedBy: testUserId,
        changeType: "remove",
        permission: "delete_users",
        status: "success",
      });

      const logs = await db
        .select()
        .from(permissionAuditLog)
        .where(eq(permissionAuditLog.changeType, "remove"));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[0].permission).toBe("delete_users");
    });

    it("should log permission reset", async () => {
      await db.insert(permissionAuditLog).values({
        role: "admin",
        changedBy: testUserId,
        changeType: "reset",
        status: "success",
        newPermissions: JSON.stringify(["all"]),
      });

      const logs = await db
        .select()
        .from(permissionAuditLog)
        .where(eq(permissionAuditLog.changeType, "reset"));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[0].newPermissions).toBeDefined();
    });

    it("should record old and new permissions", async () => {
      const oldPerms = JSON.stringify(["view", "edit"]);
      const newPerms = JSON.stringify(["view", "edit", "delete"]);

      await db.insert(permissionAuditLog).values({
        role: "manager",
        changedBy: testUserId,
        changeType: "add",
        permission: "delete",
        oldPermissions: oldPerms,
        newPermissions: newPerms,
        status: "success",
      });

      const logs = await db
        .select()
        .from(permissionAuditLog)
        .where(eq(permissionAuditLog.role, "manager"));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[0].oldPermissions).toBe(oldPerms);
      expect(logs[0].newPermissions).toBe(newPerms);
    });
  });

  describe("Audit Log Data Integrity", () => {
    it("should maintain audit trail with valid data", async () => {
      const timestamps = [];

      for (let i = 0; i < 3; i++) {
        await db.insert(userSwitchAuditLog).values({
          switchedBy: testUserId,
          switchedTo: testUserId + 1,
          status: "success",
        });

        const logs = await db.select().from(userSwitchAuditLog);
        const logTime = new Date(logs[logs.length - 1].createdAt).getTime();
        timestamps.push(logTime);

        await new Promise((resolve) => setTimeout(resolve, 50));
      }

      expect(timestamps.length).toBe(3);
      expect(timestamps.every((t) => t > 0)).toBe(true);
    });

    it("should store required fields correctly", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: testUserId,
        switchedTo: testUserId + 1,
        status: "success",
      });

      const logs = await db.select().from(userSwitchAuditLog);
      expect(logs.length).toBeGreaterThan(0);
      expect(logs[logs.length - 1].switchedBy).toBe(testUserId);
      expect(logs[logs.length - 1].status).toBe("success");
    });
  });
});
