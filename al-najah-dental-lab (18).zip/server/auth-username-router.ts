import { router, publicProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { scryptSync, randomBytes } from "crypto";
import { COOKIE_NAME, ONE_YEAR_MS } from "../shared/const";
import { getSessionCookieOptions } from "./_core/cookies";

/**
 * تجزئة كلمة المرور باستخدام scrypt
 */
function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const derivedKey = scryptSync(password, salt, 64);
  return salt.toString("hex") + ":" + derivedKey.toString("hex");
}

/**
 * التحقق من كلمة المرور
 */
function verifyPassword(password: string, hash: string): boolean {
  const [saltHex, keyHex] = hash.split(":");
  const salt = Buffer.from(saltHex, "hex");
  const derivedKey = scryptSync(password, salt, 64);
  return derivedKey.toString("hex") === keyHex;
}

export const authUsernameRouter = router({
  /**
   * تسجيل دخول باستخدام اسم المستخدم وكلمة المرور
   */
  loginWithUsername: publicProcedure
    .input(
      z.object({
        username: z.string().min(3, "اسم المستخدم يجب أن يكون 3 أحرف على الأقل"),
        password: z.string().min(6, "كلمة المرور يجب أن تكون 6 أحرف على الأقل"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const database = await getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        // البحث عن المستخدم باسم المستخدم
        const targetUsers = await database
          .select()
          .from(users)
          .where(eq(users.username, input.username))
          .limit(1);

        if (targetUsers.length === 0) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "اسم المستخدم أو كلمة المرور غير صحيحة",
          });
        }

        const user = targetUsers[0];

        // التحقق من كلمة المرور
        if (!user.password) {
          // المستخدم لم يقم بتعيين كلمة مرور محلية بعد
          // سمح له بتعيين كلمة مرور الآن
          const hashedPassword = hashPassword(input.password);
          await database
            .update(users)
            .set({ password: hashedPassword })
            .where(eq(users.id, user.id));
        } else if (!verifyPassword(input.password, user.password)) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "اسم المستخدم أو كلمة المرور غير صحيحة",
          });
        }

        // إنشاء جلسة جديدة
        try {
          const { sdk } = await import("./_core/sdk");

          // التحقق من وجود openId، إذا لم يكن موجوداً، أنشئ واحداً
          let openId = user.openId;
          if (!openId) {
            // إنشاء openId فريد للمستخدم المحلي
            openId = `local-${user.id}-${Date.now()}`;
            await database
              .update(users)
              .set({ openId })
              .where(eq(users.id, user.id));
          }

          const sessionToken = await sdk.createSessionToken(openId, {
            name: user.name || "",
            expiresInMs: ONE_YEAR_MS,
          });

          // تعيين ملف الجلسة
          const cookieOptions = getSessionCookieOptions(ctx.req);
          ctx.res.cookie(COOKIE_NAME, sessionToken, {
            ...cookieOptions,
            maxAge: ONE_YEAR_MS,
          });

          // تحديث آخر وقت دخول
          await database
            .update(users)
            .set({ lastSignedIn: new Date() })
            .where(eq(users.id, user.id));

          return {
            success: true,
            user: {
              id: user.id,
              name: user.name,
              email: user.email,
              role: user.role,
              username: user.username,
            },
          };
        } catch (error) {
          console.error("[LoginWithUsername] Failed to create session", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "فشل تسجيل الدخول",
          });
        }
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[LoginWithUsername] Error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "خطأ في تسجيل الدخول",
        });
      }
    }),

  /**
   * تعيين اسم مستخدم وكلمة مرور لمستخدم موجود
   */
  setUsernamePassword: publicProcedure
    .input(
      z.object({
        userId: z.number(),
        username: z.string().min(3),
        password: z.string().min(6),
      })
    )
    .mutation(async ({ input }) => {
      const database = await getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        // التحقق من أن اسم المستخدم غير مستخدم
        const existingUser = await database
          .select()
          .from(users)
          .where(eq(users.username, input.username))
          .limit(1);

        if (existingUser.length > 0 && existingUser[0].id !== input.userId) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "اسم المستخدم مستخدم بالفعل",
          });
        }

        // تجزئة كلمة المرور
        const hashedPassword = hashPassword(input.password);

        // تحديث المستخدم
        await database
          .update(users)
          .set({
            username: input.username,
            password: hashedPassword,
          })
          .where(eq(users.id, input.userId));

        return { success: true };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[SetUsernamePassword] Error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل تعيين اسم المستخدم وكلمة المرور",
        });
      }
    }),

  /**
   * تغيير كلمة المرور
   */
  changePassword: publicProcedure
    .input(
      z.object({
        userId: z.number(),
        oldPassword: z.string(),
        newPassword: z.string().min(6),
      })
    )
    .mutation(async ({ input }) => {
      const database = await getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        // جلب المستخدم
        const targetUsers = await database
          .select()
          .from(users)
          .where(eq(users.id, input.userId))
          .limit(1);

        if (targetUsers.length === 0) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "المستخدم غير موجود",
          });
        }

        const user = targetUsers[0];

        // التحقق من كلمة المرور القديمة
        if (!user.password || !verifyPassword(input.oldPassword, user.password)) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "كلمة المرور القديمة غير صحيحة",
          });
        }

        // تجزئة كلمة المرور الجديدة
        const hashedPassword = hashPassword(input.newPassword);

        // تحديث كلمة المرور
        await database
          .update(users)
          .set({ password: hashedPassword })
          .where(eq(users.id, input.userId));

        return { success: true };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[ChangePassword] Error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل تغيير كلمة المرور",
        });
      }
    }),

  /**
   * إعادة تعيين كلمة المرور من قبل المسؤول
   */
  resetPassword: publicProcedure
    .input(
      z.object({
        userId: z.number(),
        newPassword: z.string().min(6, "كلمة المرور يجب أن تكون 6 أحرف على الأقل"),
      })
    )
    .mutation(async ({ input }) => {
      const database = await getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        // جلب المستخدم
        const targetUsers = await database
          .select()
          .from(users)
          .where(eq(users.id, input.userId))
          .limit(1);

        if (targetUsers.length === 0) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "المستخدم غير موجود",
          });
        }

        // تجزئة كلمة المرور الجديدة
        const hashedPassword = hashPassword(input.newPassword);

        // تحديث كلمة المرور
        await database
          .update(users)
          .set({ password: hashedPassword })
          .where(eq(users.id, input.userId));

        return { success: true };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[ResetPassword] Error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل إعادة تعيين كلمة المرور",
        });
      }
    }),
});
