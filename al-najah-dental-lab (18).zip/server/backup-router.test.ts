import { describe, it, expect, beforeEach } from "vitest";
import { getDb } from "./db";
import { systemBackups, backupSettings } from "../drizzle/role-settings.schema";
import { eq } from "drizzle-orm";

describe("Backup Router", () => {
  let db: any;

  beforeEach(async () => {
    db = await getDb();
  });

  describe("createManualBackup", () => {
    it("should create a manual backup", async () => {
      // تنظيف البيانات السابقة
      await db.delete(systemBackups);

      // إنشاء نسخة احتياطية
      const backupName = `manual_${new Date().toISOString().replace(/[:.]/g, "-")}`;
      await db.insert(systemBackups).values({
        backupName,
        backupType: "manual",
        roleSettingsSnapshot: [
          {
            role: "admin",
            passwordHash: "test_hash",
            isActive: "true",
          },
        ],
        createdBy: 1,
        description: "Test backup",
        size: 100,
      });

      // التحقق من أن النسخة تم إنشاؤها
      const backups = await db.select().from(systemBackups);
      expect(backups.length).toBeGreaterThan(0);
      expect(backups[0].backupType).toBe("manual");
    });
  });

  describe("listBackups", () => {
    it("should list all backups", async () => {
      // تنظيف البيانات السابقة
      await db.delete(systemBackups);

      // إدراج بيانات اختبار
      await db.insert(systemBackups).values({
        backupName: "test_backup_1",
        backupType: "manual",
        roleSettingsSnapshot: [],
        createdBy: 1,
        size: 100,
      });

      await db.insert(systemBackups).values({
        backupName: "test_backup_2",
        backupType: "automatic",
        roleSettingsSnapshot: [],
        createdBy: 1,
        size: 200,
      });

      // الحصول على قائمة النسخ
      const backups = await db.select().from(systemBackups);
      expect(backups.length).toBe(2);
    });
  });

  describe("deleteBackup", () => {
    it("should delete a backup", async () => {
      // تنظيف البيانات السابقة
      await db.delete(systemBackups);

      // إنشاء نسخة احتياطية
      await db.insert(systemBackups).values({
        backupName: "test_delete",
        backupType: "manual",
        roleSettingsSnapshot: [],
        createdBy: 1,
        size: 100,
      });

      // الحصول على معرّف النسخة
      let backups = await db.select().from(systemBackups);
      const backupId = backups[0].id;

      // حذف النسخة
      await db.delete(systemBackups).where(eq(systemBackups.id, backupId));

      // التحقق من الحذف
      backups = await db.select().from(systemBackups);
      expect(backups.length).toBe(0);
    });
  });

  describe("getBackupSettings", () => {
    it("should get backup settings", async () => {
      // تنظيف البيانات السابقة
      await db.delete(backupSettings);

      // إنشاء إعدادات افتراضية
      await db.insert(backupSettings).values({
        autoBackupEnabled: "true",
        backupFrequency: "daily",
        backupRetentionDays: 30,
        maxBackups: 10,
      });

      // الحصول على الإعدادات
      const settings = await db.select().from(backupSettings);
      expect(settings.length).toBeGreaterThan(0);
      expect(settings[0].autoBackupEnabled).toBe("true");
      expect(settings[0].backupFrequency).toBe("daily");
      expect(settings[0].backupRetentionDays).toBe(30);
    });
  });

  describe("updateBackupSettings", () => {
    it("should update backup settings", async () => {
      // تنظيف البيانات السابقة
      await db.delete(backupSettings);

      // إنشاء إعدادات افتراضية
      await db.insert(backupSettings).values({
        autoBackupEnabled: "true",
        backupFrequency: "daily",
        backupRetentionDays: 30,
        maxBackups: 10,
      });

      // الحصول على الإعدادات
      let settings = await db.select().from(backupSettings);
      const settingsId = settings[0].id;

      // تحديث الإعدادات
      await db
        .update(backupSettings)
        .set({
          backupFrequency: "weekly",
          backupRetentionDays: 60,
        })
        .where(eq(backupSettings.id, settingsId));

      // التحقق من التحديث
      settings = await db.select().from(backupSettings);
      expect(settings[0].backupFrequency).toBe("weekly");
      expect(settings[0].backupRetentionDays).toBe(60);
    });
  });

  describe("Backup data integrity", () => {
    it("should preserve backup data correctly", async () => {
      // تنظيف البيانات السابقة
      await db.delete(systemBackups);

      const backupData = [
        {
          role: "admin",
          passwordHash: "admin_hash_123",
          customPermissions: ["read", "write", "delete"],
          isActive: "true",
        },
        {
          role: "manager",
          passwordHash: "manager_hash_456",
          customPermissions: ["read", "write"],
          isActive: "true",
        },
      ];

      // إنشاء نسخة احتياطية
      await db.insert(systemBackups).values({
        backupName: "integrity_test",
        backupType: "manual",
        roleSettingsSnapshot: backupData,
        createdBy: 1,
        description: "Test data integrity",
        size: JSON.stringify(backupData).length,
      });

      // الحصول على النسخة
      const backups = await db.select().from(systemBackups);
      const backup = backups[0];

      // التحقق من سلامة البيانات
      expect(backup.roleSettingsSnapshot).toEqual(backupData);
      expect(backup.description).toBe("Test data integrity");
      expect(backup.size).toBeGreaterThan(0);
    });
  });

  describe("Backup metadata", () => {
    it("should store backup metadata correctly", async () => {
      // تنظيف البيانات السابقة
      await db.delete(systemBackups);

      // إنشاء نسخة احتياطية مع بيانات وصفية
      await db.insert(systemBackups).values({
        backupName: "metadata_test",
        backupType: "manual",
        roleSettingsSnapshot: [],
        createdBy: 1,
        description: "Test backup with metadata",
        size: 500,
      });

      // الحصول على النسخة
      const backups = await db.select().from(systemBackups);
      const backup = backups[0];

      // التحقق من البيانات الوصفية
      expect(backup.backupName).toBe("metadata_test");
      expect(backup.backupType).toBe("manual");
      expect(backup.createdBy).toBe(1);
      expect(backup.description).toBe("Test backup with metadata");
      expect(backup.size).toBe(500);
      expect(backup.isRestored).toBe("false");
    });
  });

  describe("Automatic backup scheduling", () => {
    it("should support automatic backup scheduling", async () => {
      // تنظيف البيانات السابقة
      await db.delete(backupSettings);

      // إنشاء إعدادات النسخ الاحتياطية التلقائية
      await db.insert(backupSettings).values({
        autoBackupEnabled: "true",
        backupFrequency: "daily",
        backupRetentionDays: 30,
        maxBackups: 10,
      });

      // الحصول على الإعدادات
      const settings = await db.select().from(backupSettings);
      expect(settings[0].autoBackupEnabled).toBe("true");
      expect(settings[0].backupFrequency).toBe("daily");
    });
  });
});
