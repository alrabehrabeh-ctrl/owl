import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { systemBackups, backupRestoreLogs, backupSettings, roleSettings } from "../drizzle/role-settings.schema";
import { TRPCError } from "@trpc/server";
import { eq, desc, lte } from "drizzle-orm";

export const backupRouter = router({
  /**
   * إنشاء نسخة احتياطية يدوية
   */
  createManualBackup: publicProcedure
    .input(
      z.object({
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        // الحصول على بيانات الأدوار الحالية
        const currentSettings = await db.select().from(roleSettings);

        if (currentSettings.length === 0) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "لا توجد إعدادات أدوار لنسخها احتياطياً",
          });
        }

        // إنشاء النسخة الاحتياطية
        const backupName = `manual_${new Date().toISOString().replace(/[:.]/g, "-")}`;
        const backupData = JSON.stringify(currentSettings);

        const result = await db.insert(systemBackups).values({
          backupName,
          backupType: "manual",
          roleSettingsSnapshot: currentSettings,
          createdBy: ctx.user.id,
          description: input.description,
          size: backupData.length,
        });

        // تحديث إعدادات النسخ الاحتياطية
        await db
          .update(backupSettings)
          .set({ lastBackupAt: new Date() })
          .where(eq(backupSettings.id, 1));

        return {
          success: true,
          message: "تم إنشاء النسخة الاحتياطية بنجاح",
          backupName,
        };
      } catch (error) {
        console.error("Error creating backup:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل في إنشاء النسخة الاحتياطية",
        });
      }
    }),

  /**
   * الحصول على قائمة النسخ الاحتياطية
   */
  listBackups: publicProcedure
    .input(
      z.object({
        limit: z.number().default(20),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        const backups = await db
          .select({
            id: systemBackups.id,
            backupName: systemBackups.backupName,
            backupType: systemBackups.backupType,
            createdBy: systemBackups.createdBy,
            description: systemBackups.description,
            size: systemBackups.size,
            isRestored: systemBackups.isRestored,
            restoredAt: systemBackups.restoredAt,
            restoredBy: systemBackups.restoredBy,
            createdAt: systemBackups.createdAt,
            expiresAt: systemBackups.expiresAt,
          })
          .from(systemBackups)
          .orderBy(desc(systemBackups.createdAt))
          .limit(input.limit)
          .offset(input.offset);

        return backups;
      } catch (error) {
        console.error("Error listing backups:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل في الحصول على قائمة النسخ الاحتياطية",
        });
      }
    }),

  /**
   * استعادة نسخة احتياطية
   */
  restoreBackup: publicProcedure
    .input(
      z.object({
        backupId: z.number(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        // الحصول على النسخة الاحتياطية
        const backup = await db
          .select()
          .from(systemBackups)
          .where(eq(systemBackups.id, input.backupId))
          .limit(1);

        if (backup.length === 0) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "النسخة الاحتياطية غير موجودة",
          });
        }

        const backupData = backup[0];
        const roleSettingsSnapshot = backupData.roleSettingsSnapshot as any[];

        if (!roleSettingsSnapshot || roleSettingsSnapshot.length === 0) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "النسخة الاحتياطية لا تحتوي على بيانات صحيحة",
          });
        }

        // حذف الإعدادات الحالية
        await db.delete(roleSettings);

        // استعادة الإعدادات من النسخة الاحتياطية
        let itemsRestored = 0;
        let itemsFailed = 0;

        for (const setting of roleSettingsSnapshot) {
          try {
            await db.insert(roleSettings).values({
              role: setting.role,
              passwordHash: setting.passwordHash,
              customPermissions: setting.customPermissions,
              isActive: setting.isActive,
            });
            itemsRestored++;
          } catch (error) {
            console.error("Error restoring role setting:", error);
            itemsFailed++;
          }
        }

        // تسجيل عملية الاستعادة
        await db.insert(backupRestoreLogs).values({
          backupId: input.backupId,
          restoredBy: ctx.user.id,
          status: itemsFailed === 0 ? "success" : "partial",
          itemsRestored,
          itemsFailed,
        });

        // تحديث حالة النسخة الاحتياطية
        await db
          .update(systemBackups)
          .set({
            isRestored: "true",
            restoredAt: new Date(),
            restoredBy: ctx.user.id,
          })
          .where(eq(systemBackups.id, input.backupId));

        return {
          success: itemsFailed === 0,
          message:
            itemsFailed === 0
              ? "تم استعادة النسخة الاحتياطية بنجاح"
              : `تم استعادة النسخة الاحتياطية جزئياً (${itemsRestored} نجح، ${itemsFailed} فشل)`,
          itemsRestored,
          itemsFailed,
        };
      } catch (error) {
        console.error("Error restoring backup:", error);
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل في استعادة النسخة الاحتياطية",
        });
      }
    }),

  /**
   * حذف نسخة احتياطية
   */
  deleteBackup: publicProcedure
    .input(
      z.object({
        backupId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        await db.delete(systemBackups).where(eq(systemBackups.id, input.backupId));

        return {
          success: true,
          message: "تم حذف النسخة الاحتياطية بنجاح",
        };
      } catch (error) {
        console.error("Error deleting backup:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل في حذف النسخة الاحتياطية",
        });
      }
    }),

  /**
   * الحصول على إعدادات النسخ الاحتياطية
   */
  getBackupSettings: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    try {
      const settings = await db.select().from(backupSettings).limit(1);

      if (settings.length === 0) {
        // إنشاء إعدادات افتراضية
        await db.insert(backupSettings).values({
          autoBackupEnabled: "true",
          backupFrequency: "daily",
          backupRetentionDays: 30,
          maxBackups: 10,
        });

        return {
          autoBackupEnabled: "true",
          backupFrequency: "daily",
          backupRetentionDays: 30,
          maxBackups: 10,
        };
      }

      return settings[0];
    } catch (error) {
      console.error("Error getting backup settings:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "فشل في الحصول على إعدادات النسخ الاحتياطية",
      });
    }
  }),

  /**
   * تحديث إعدادات النسخ الاحتياطية
   */
  updateBackupSettings: publicProcedure
    .input(
      z.object({
        autoBackupEnabled: z.string().optional(),
        backupFrequency: z.enum(["hourly", "daily", "weekly", "monthly"]).optional(),
        backupRetentionDays: z.number().optional(),
        maxBackups: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      try {
        const settings = await db.select().from(backupSettings).limit(1);

        if (settings.length === 0) {
          await db.insert(backupSettings).values({
            autoBackupEnabled: input.autoBackupEnabled || "true",
            backupFrequency: input.backupFrequency || "daily",
            backupRetentionDays: input.backupRetentionDays || 30,
            maxBackups: input.maxBackups || 10,
          });
        } else {
          await db
            .update(backupSettings)
            .set({
              autoBackupEnabled: input.autoBackupEnabled,
              backupFrequency: input.backupFrequency,
              backupRetentionDays: input.backupRetentionDays,
              maxBackups: input.maxBackups,
            })
            .where(eq(backupSettings.id, settings[0].id));
        }

        return {
          success: true,
          message: "تم تحديث إعدادات النسخ الاحتياطية بنجاح",
        };
      } catch (error) {
        console.error("Error updating backup settings:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل في تحديث إعدادات النسخ الاحتياطية",
        });
      }
    }),

  /**
   * حذف النسخ الاحتياطية المنتهية الصلاحية
   */
  cleanupExpiredBackups: publicProcedure.mutation(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    try {
      const settings = await db.select().from(backupSettings).limit(1);
      const retentionDays = settings.length > 0 ? settings[0].backupRetentionDays : 30;

      const expirationDate = new Date();
      expirationDate.setDate(expirationDate.getDate() - retentionDays);

      const result = await db
        .delete(systemBackups)
        .where(lte(systemBackups.createdAt, expirationDate));

      return {
        success: true,
        message: "تم تنظيف النسخ الاحتياطية المنتهية الصلاحية بنجاح",
      };
    } catch (error) {
      console.error("Error cleaning up backups:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "فشل في تنظيف النسخ الاحتياطية",
      });
    }
  }),
});
