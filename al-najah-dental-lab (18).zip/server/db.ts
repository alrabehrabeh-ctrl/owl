import { eq, and, gte, lte, desc, asc, sql, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  doctors,
  works,
  invoices,
  payments,
  paymentWorks,
  expenses,
  employees,
  salaries,
  alerts,
  documents,
  workTypes,
  invoiceItems,
  currencies,
  exchangeRates,
  auditLog,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      // Only set admin role if it's the owner and not already set
      values.role = "admin";
      updateSet.role = "admin";
    }
    // IMPORTANT: Do NOT set default role "user" on upsert
    // This would override existing roles every time user signs in
    // Only set default role when creating NEW users

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    // Only insert/update if there are actual changes to make
    // Don't insert role field if it's not being set (to avoid overwriting existing roles)
    if (!values.role && user.role === undefined) {
      delete values.role;
    }
    
    console.log("[upsertUser] values:", values);
    console.log("[upsertUser] updateSet:", updateSet);
    
    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
    
    console.log("[upsertUser] Successfully upserted user:", user.openId);
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ Doctors ============

export async function getAllDoctors() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(doctors).orderBy(asc(doctors.name));
}

export async function getDoctorById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(doctors).where(eq(doctors.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createDoctor(data: typeof doctors.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(doctors).values(data);
  return result;
}

export async function updateDoctor(id: number, data: Partial<typeof doctors.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(doctors).set(data).where(eq(doctors.id, id));
}

export async function getAllWorks(limit?: number, offset: number = 0) {
  const db = await getDb();
  if (!db) return { data: [], total: 0 };
  
  const pageSize = limit || 10000; // جلب جميع الأعمال (حد أقصى 10000)
  
  const result = await db
    .select({
      id: works.id,
      doctorId: works.doctorId,
      doctorName: doctors.name,
      workTypeId: works.workTypeId,
      workTypeName: workTypes.name,
      quantity: works.quantity,
      unitPrice: works.unitPrice,
      totalPrice: works.totalPrice,
      status: works.status,
      dueDate: works.dueDate,
      receptionDate: works.receptionDate,
      patientName: works.patientName,
      description: works.description,
      notes: works.notes,
      createdAt: works.createdAt,
      updatedAt: works.updatedAt,
    })
    .from(works)
    .leftJoin(doctors, eq(works.doctorId, doctors.id))
    .leftJoin(workTypes, eq(works.workTypeId, workTypes.id))
    .orderBy(desc(works.createdAt))
    .limit(pageSize)
    .offset(offset);
  
  return { data: result, total: result.length };
}

export async function getWorksByDoctor(doctorId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(works).where(eq(works.doctorId, doctorId)).orderBy(desc(works.createdAt));
}

export async function getWorkById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(works).where(eq(works.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createWork(data: typeof works.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  console.log('[createWork] Input data:', JSON.stringify(data, null, 2));
  
  // تحويل toothNumbers إلى JSON إذا كانت array
  const processedData = {
    ...data,
    toothNumbers: typeof data.toothNumbers === 'string' 
      ? data.toothNumbers 
      : data.toothNumbers ? JSON.stringify(data.toothNumbers) : null,
    // تعيين createdAt بناءً على receptionDate إذا لم يكن محدداً
    createdAt: data.createdAt || data.receptionDate || new Date()
  };
  
  console.log('[createWork] Processed data:', JSON.stringify(processedData, null, 2));
  
  return db.insert(works).values(processedData);
}

export async function updateWork(id: number, data: Partial<typeof works.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // تحويل البيانات إلى الصيغة الصحيحة
  const processedData = {
    ...data,
    receptionDate: data.receptionDate ? new Date(data.receptionDate) : undefined,
    dueDate: data.dueDate ? new Date(data.dueDate) : undefined,
    completedDate: data.completedDate ? new Date(data.completedDate) : undefined,
    // تحديث createdAt إذا تم تحديث receptionDate
    createdAt: data.receptionDate ? new Date(data.receptionDate) : undefined,
    updatedAt: new Date(), // فرض تحديث الوقت لضمان تسجيل التحديث
  };
  
  // حذف الحقول غير المعرفة
  const cleanedData = Object.fromEntries(
    Object.entries(processedData).filter(([_, v]) => v !== undefined)
  );
  
  return db.update(works).set(cleanedData).where(eq(works.id, id));
}

// دالة جديدة لجلب الأعمال مع بيانات الطبيب وأنواع الخدمات
export async function getAllWorksWithDoctorAndTypes(limit?: number) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db
    .select({
      id: works.id,
      doctorId: works.doctorId,
      doctorName: doctors.name,
      workTypeId: works.workTypeId,
      workTypeName: workTypes.name,
      quantity: works.quantity,
      unitPrice: works.unitPrice,
      totalPrice: works.totalPrice,
      status: works.status,
      dueDate: works.dueDate,
      receptionDate: works.receptionDate,
      patientName: works.patientName,
      description: works.description,
      notes: works.notes,
      toothNumbers: works.toothNumbers,
      createdAt: works.createdAt,
      updatedAt: works.updatedAt,
    })
    .from(works)
    .leftJoin(doctors, eq(works.doctorId, doctors.id))
    .leftJoin(workTypes, eq(works.workTypeId, workTypes.id))
    .orderBy(desc(works.createdAt));
  
  if (limit) return result.slice(0, limit);
  return result;
}

// دالة لجلب الأعمال مع أسماء أنواع الخدمات
export async function getAllWorksWithTypes(limit?: number) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db
    .select({
      id: works.id,
      doctorId: works.doctorId,
      workTypeId: works.workTypeId,
      workTypeName: workTypes.name,
      quantity: works.quantity,
      unitPrice: works.unitPrice,
      totalPrice: works.totalPrice,
      status: works.status,
      dueDate: works.dueDate,
      completedDate: works.completedDate,
      receptionDate: works.receptionDate,
      patientName: works.patientName,
      notes: works.notes,
      toothNumbers: works.toothNumbers,
      createdAt: works.createdAt,
      updatedAt: works.updatedAt,
    })
    .from(works)
    .leftJoin(workTypes, eq(works.workTypeId, workTypes.id))
    .orderBy(desc(works.createdAt));
  
  if (limit) return result.slice(0, limit);
  return result;
}

// ============ Invoices ============

export async function getAllInvoices(limit?: number) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(invoices).orderBy(desc(invoices.createdAt));
  if (limit) return query.limit(limit);
  return query;
}

export async function getInvoicesByDoctor(doctorId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(invoices).where(eq(invoices.doctorId, doctorId)).orderBy(desc(invoices.invoiceDate));
}

export async function getInvoiceById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(invoices).where(eq(invoices.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createInvoice(data: typeof invoices.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(invoices).values(data);
}

export async function updateInvoice(id: number, data: Partial<typeof invoices.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(invoices).set(data).where(eq(invoices.id, id));
}

// ============ Payments ============

export async function getAllPayments(limit?: number) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(payments).orderBy(desc(payments.createdAt));
  if (limit) return query.limit(limit);
  return query;
}

export async function getPaymentsByInvoice(invoiceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(payments).where(eq(payments.invoiceId, invoiceId)).orderBy(desc(payments.paymentDate));
}

export async function createPayment(data: typeof payments.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // إدراج الدفعة
  const result = await db.insert(payments).values(data);
  
  // تحديث الفاتورة: حساب المبلغ المدفوع والمتبقي
  const invoice = await getInvoiceById(data.invoiceId);
  if (invoice) {
    const allPayments = await getPaymentsByInvoice(data.invoiceId);
    const totalPaid = allPayments.reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0);
    const remainingAmount = parseFloat(invoice.total.toString()) - totalPaid;
    
    // تحديث حالة الفاتورة بناءً على المبلغ المدفوع
    let status = invoice.status;
    if (totalPaid >= parseFloat(invoice.total.toString())) {
      status = 'paid';
    } else if (totalPaid > 0) {
      status = 'partial';
    }
    
    await updateInvoice(data.invoiceId, {
      paidAmount: totalPaid.toString(),
      remainingAmount: remainingAmount.toString(),
      status: status as any,
    });
  }
  
  return result;
}

export async function deletePayment(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // الحصول على الدفعة قبل حذفها
  const payment = await db.select().from(payments).where(eq(payments.id, id)).limit(1);
  const paymentData = payment.length > 0 ? payment[0] : null;
  
  // حذف الدفعة
  const result = await db.delete(payments).where(eq(payments.id, id));
  
  // تحديث الفاتورة إذا كانت الدفعة موجودة
  if (paymentData) {
    const invoice = await getInvoiceById(paymentData.invoiceId);
    if (invoice) {
      const allPayments = await getPaymentsByInvoice(paymentData.invoiceId);
      const totalPaid = allPayments.reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0);
      const remainingAmount = parseFloat(invoice.total.toString()) - totalPaid;
      
      // تحديث حالة الفاتورة
      let status = 'sent';
      if (totalPaid >= parseFloat(invoice.total.toString())) {
        status = 'paid';
      } else if (totalPaid > 0) {
        status = 'partial';
      }
      
      await updateInvoice(paymentData.invoiceId, {
        paidAmount: totalPaid.toString(),
        remainingAmount: remainingAmount.toString(),
        status: status as any,
      });
    }
  }
  
  return result;
}

export async function updatePayment(id: number, data: Partial<typeof payments.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // الحصول على الدفعة الحالية
  const payment = await db.select().from(payments).where(eq(payments.id, id)).limit(1);
  const paymentData = payment.length > 0 ? payment[0] : null;
  
  // تحديث الدفعة
  const result = await db.update(payments).set(data).where(eq(payments.id, id));
  
  // تحديث الفاتورة إذا كانت الدفعة موجودة
  if (paymentData) {
    const invoice = await getInvoiceById(paymentData.invoiceId);
    if (invoice) {
      const allPayments = await getPaymentsByInvoice(paymentData.invoiceId);
      const totalPaid = allPayments.reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0);
      const remainingAmount = parseFloat(invoice.total.toString()) - totalPaid;
      
      // تحديث حالة الفاتورة
      let status = 'sent';
      if (totalPaid >= parseFloat(invoice.total.toString())) {
        status = 'paid';
      } else if (totalPaid > 0) {
        status = 'partial';
      }
      
      await updateInvoice(paymentData.invoiceId, {
        paidAmount: totalPaid.toString(),
        remainingAmount: remainingAmount.toString(),
        status: status as any,
      });
    }
  }
  
  return result;
}

// ============ Expenses ============

export async function getAllExpenses(limit?: number) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(expenses).orderBy(desc(expenses.expenseDate));
  if (limit) return query.limit(limit);
  return query;
}

export async function getExpensesByCategory(category: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(expenses).where(eq(expenses.category, category as any)).orderBy(desc(expenses.expenseDate));
}

export async function createExpense(data: typeof expenses.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(expenses).values(data);
}

export async function updateExpense(id: number, data: Partial<typeof expenses.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(expenses).set(data).where(eq(expenses.id, id));
}

export async function deleteExpense(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(expenses).where(eq(expenses.id, id));
}

// ============ Employees ============

export async function getAllEmployees() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(employees).where(eq(employees.isActive, true)).orderBy(asc(employees.name));
}

export async function getEmployeeById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(employees).where(eq(employees.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createEmployee(data: typeof employees.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(employees).values(data);
}

export async function updateEmployee(id: number, data: Partial<typeof employees.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(employees).set(data).where(eq(employees.id, id));
}

// ============ Salaries ============

export async function getSalariesByEmployee(employeeId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(salaries).where(eq(salaries.employeeId, employeeId)).orderBy(desc(salaries.month));
}

export async function getSalariesByMonth(month: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(salaries).where(eq(salaries.month, month)).orderBy(asc(salaries.employeeId));
}

export async function createSalary(data: typeof salaries.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(salaries).values(data);
}

export async function updateSalary(id: number, data: Partial<typeof salaries.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(salaries).set(data).where(eq(salaries.id, id));
}

// ============ Alerts ============

export async function getUnreadAlerts() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(alerts).where(eq(alerts.isRead, false)).orderBy(desc(alerts.createdAt));
}

export async function createAlert(data: typeof alerts.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(alerts).values(data);
}

export async function markAlertAsRead(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(alerts).set({ isRead: true }).where(eq(alerts.id, id));
}

export async function deleteAlert(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(alerts).where(eq(alerts.id, id));
}

// ============ Documents ============

export async function createDocument(data: typeof documents.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(documents).values(data);
}

export async function getDocumentsByRelated(relatedType: string, relatedId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(documents)
    .where(and(eq(documents.relatedType, relatedType as any), eq(documents.relatedId, relatedId)))
    .orderBy(desc(documents.createdAt));
}

// ============ Financial Reports ============

export async function getTotalRevenue(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return "0";
  const result = await db
    .select({
      total: sql`SUM(CAST(${works.totalPrice} AS DECIMAL(10,2)))`.as('total'),
    })
    .from(works)
    .where(and(gte(works.createdAt, startDate), lte(works.createdAt, endDate)));
  return result[0]?.total || "0";
}

export async function getTotalExpenses(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return "0";
  const result = await db
    .select({
      total: sql`SUM(CAST(${expenses.amount} AS DECIMAL(10,2)))`.as('total'),
    })
    .from(expenses)
    .where(and(gte(expenses.expenseDate, startDate), lte(expenses.expenseDate, endDate)));
  return result[0]?.total || "0";
}

export async function getOverdueInvoices() {
  const db = await getDb();
  if (!db) return [];
  const now = new Date();
  return db
    .select()
    .from(invoices)
    .where(and(lte(invoices.dueDate, now), eq(invoices.status, "overdue")))
    .orderBy(asc(invoices.dueDate));
}

export async function getPendingWorks() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(works)
    .where(eq(works.status, "pending"))
    .orderBy(asc(works.dueDate));
}

export async function deleteWork(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(works).where(eq(works.id, id));
}

// ============ Payment Works ============

export async function createPaymentWork(data: typeof paymentWorks.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(paymentWorks).values(data);
}

export async function getPaymentWorksByPayment(paymentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paymentWorks).where(eq(paymentWorks.paymentId, paymentId)).orderBy(asc(paymentWorks.createdAt));
}

export async function getPaymentWorksByWork(workId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paymentWorks).where(eq(paymentWorks.workId, workId)).orderBy(desc(paymentWorks.createdAt));
}

export async function deletePaymentWork(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(paymentWorks).where(eq(paymentWorks.id, id));
}

// ============ Monthly Revenue and Expenses ============

export async function getMonthlyRevenue(year: number) {
  const db = await getDb();
  if (!db) return [];
  
  try {
    const result = await db.execute(sql`
      SELECT 
        YEAR(createdAt) as year,
        MONTH(createdAt) as month,
        SUM(CAST(totalPrice AS DECIMAL(10,2))) as total
      FROM works
      WHERE createdAt >= ${new Date(`${year}-01-01`)}
        AND createdAt <= ${new Date(`${year}-12-31`)}
      GROUP BY YEAR(createdAt), MONTH(createdAt)
      ORDER BY year ASC, month ASC
    `);
    
    return result as any[];
  } catch (error) {
    console.error("Error in getMonthlyRevenue:", error);
    return [];
  }
}

export async function getMonthlyExpenses(year: number) {
  const db = await getDb();
  if (!db) return [];
  
  try {
    const result = await db.execute(sql`
      SELECT 
        YEAR(expenseDate) as year,
        MONTH(expenseDate) as month,
        SUM(CAST(amount AS DECIMAL(10,2))) as total
      FROM expenses
      WHERE expenseDate >= ${new Date(`${year}-01-01`)}
        AND expenseDate <= ${new Date(`${year}-12-31`)}
      GROUP BY YEAR(expenseDate), MONTH(expenseDate)
      ORDER BY year ASC, month ASC
    `);
    
    return result as any[];
  } catch (error) {
    console.error("Error in getMonthlyExpenses:", error);
    return [];
  }
}

// ============ Monthly Invoices ============

export async function getMonthlyInvoicesByDoctorAndDate(doctorId: number, year: number, month: number) {
  const db = await getDb();
  if (!db) return [];
  
  // حساب تاريخ البداية والنهاية للشهر
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0, 23, 59, 59);
  
  // جلب جميع الأعمال للطبيب في الشهر المحدد
  const result = await db
    .select({
      id: works.id,
      doctorId: works.doctorId,
      workTypeId: works.workTypeId,
      workTypeName: workTypes.name,
      quantity: works.quantity,
      unitPrice: works.unitPrice,
      totalPrice: works.totalPrice,
      status: works.status,
      dueDate: works.dueDate,
      receptionDate: works.receptionDate,
      createdAt: works.createdAt,
      patientName: works.patientName,
      notes: works.notes,
      toothNumbers: works.toothNumbers,
    })
    .from(works)
    .leftJoin(workTypes, eq(works.workTypeId, workTypes.id))
    .where(
      and(
        eq(works.doctorId, doctorId),
        eq(works.status, 'delivered'),
        gte(works.createdAt, startDate),
        lte(works.createdAt, endDate)
      )
    )
    .orderBy(asc(works.dueDate));
  
  console.log(`[Monthly Invoice] Doctor ${doctorId}, ${month}/${year}: Found ${result.length} works`);
  if (result.length > 0) {
    console.log(`[Monthly Invoice] First work:`, result[0]);
  }
  return result;
}

export async function getMonthlyInvoiceSummary(doctorId: number, year: number, month: number) {
  const db = await getDb();
  if (!db) return null;
  
  const works_list = await getMonthlyInvoicesByDoctorAndDate(doctorId, year, month);
  
  if (works_list.length === 0) {
    return null;
  }
  
  const doctor = await getDoctorById(doctorId);
  const subtotal = works_list.reduce((sum, w) => sum + parseFloat(w.totalPrice.toString()), 0);
  
  return {
    doctor,
    works: works_list,
    subtotal,
    total: subtotal,
    month,
    year,
  };
}


// ============ Invoice Payment Details ============

/**
 * حساب تفاصيل الدفعات لفاتورة محددة
 */
export async function getInvoicePaymentDetails(invoiceId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const invoice = await getInvoiceById(invoiceId);
  if (!invoice) return null;
  
  const invoicePayments = await getPaymentsByInvoice(invoiceId);
  
  const totalPaid = invoicePayments.reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0);
  const totalAmount = parseFloat(invoice.total.toString());
  const remainingAmount = totalAmount - totalPaid;
  
  // تحديد حالة الفاتورة
  let status: "paid" | "pending" | "partial" = "pending";
  if (totalPaid >= totalAmount) {
    status = "paid";
  } else if (totalPaid > 0) {
    status = "partial";
  }
  
  return {
    invoiceId,
    totalAmount,
    totalPaid,
    remainingAmount,
    status,
    payments: invoicePayments.map(p => ({
      id: p.id,
      amount: parseFloat(p.amount.toString()),
      paymentDate: p.paymentDate,
      paymentMethod: p.paymentMethod,
      referenceNumber: p.referenceNumber,
      notes: p.notes,
    })),
  };
}

/**
 * حساب ملخص الدفعات لطبيب محدد في شهر معين
 */
export async function getDoctorMonthlyPaymentSummary(doctorId: number, year: number, month: number) {
  const db = await getDb();
  if (!db) return null;
  
  const doctor = await getDoctorById(doctorId);
  if (!doctor) return null;
  
  // الحصول على الفواتير الخاصة بالطبيب في الشهر المحدد
  const doctorInvoices = await getInvoicesByDoctor(doctorId);
  
  const monthInvoices = doctorInvoices.filter(inv => {
    const invDate = new Date(inv.invoiceDate);
    return invDate.getFullYear() === year && invDate.getMonth() + 1 === month;
  });
  
  let totalInvoiceAmount = 0;
  let totalPaidAmount = 0;
  let totalRemainingAmount = 0;
  const invoiceDetails: any[] = [];
  
  for (const invoice of monthInvoices) {
    const paymentDetails = await getInvoicePaymentDetails(invoice.id);
    if (paymentDetails) {
      totalInvoiceAmount += paymentDetails.totalAmount;
      totalPaidAmount += paymentDetails.totalPaid;
      totalRemainingAmount += paymentDetails.remainingAmount;
      
      invoiceDetails.push({
        invoiceId: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
        totalAmount: paymentDetails.totalAmount,
        totalPaid: paymentDetails.totalPaid,
        remainingAmount: paymentDetails.remainingAmount,
        status: paymentDetails.status,
      });
    }
  }
  
  return {
    doctorId,
    doctorName: doctor.name,
    year,
    month,
    totalInvoiceAmount,
    totalPaidAmount,
    totalRemainingAmount,
    invoiceCount: monthInvoices.length,
    invoiceDetails,
  };
}

/**
 * حساب ملخص الدفعات لكل الأطباء في شهر معين
 */
export async function getMonthlyPaymentsSummary(year: number, month: number) {
  const db = await getDb();
  if (!db) return null;
  
  const allDoctors = await getAllDoctors();
  const summaries: any[] = [];
  
  let totalInvoiceAmount = 0;
  let totalPaidAmount = 0;
  let totalRemainingAmount = 0;
  
  for (const doctor of allDoctors) {
    const summary = await getDoctorMonthlyPaymentSummary(doctor.id, year, month);
    if (summary && summary.invoiceCount > 0) {
      summaries.push(summary);
      totalInvoiceAmount += summary.totalInvoiceAmount;
      totalPaidAmount += summary.totalPaidAmount;
      totalRemainingAmount += summary.totalRemainingAmount;
    }
  }
  
  return {
    year,
    month,
    totalInvoiceAmount,
    totalPaidAmount,
    totalRemainingAmount,
    doctorCount: summaries.length,
    doctorSummaries: summaries,
  };
}


export async function getTotalReceivables() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get total receivables: database not available");
    return 0;
  }

  try {
    // حساب المديونيات من جدول الأعمال (مصدر الحقيقة)
    // بدلاً من جدول الفواتير، لأن الأعمال قد لا تكون لها فواتير مرتبطة بعد
    const allWorks = await db.select().from(works);
    
    const total = allWorks.reduce((sum, work) => {
      return sum + (parseFloat(work.totalPrice?.toString() || '0'));
    }, 0);
    
    return total;
  } catch (error) {
    console.error("Error in getTotalReceivables:", error);
    return 0;
  }
}


// ============ التوقعات والتنبؤات ============

/**
 * حساب متوسط الإيرادات الشهرية للأشهر الماضية
 */
export async function getMonthlyRevenueHistory(monthsBack: number = 12) {
  const db = await getDb();
  if (!db) return [];
  
  try {
    const result = await db.execute(sql`
      SELECT 
        MONTH(${works.receptionDate}) as month,
        YEAR(${works.receptionDate}) as year,
        SUM(CAST(${works.totalPrice} AS DECIMAL(10,2))) as revenue
      FROM ${works}
      WHERE ${works.receptionDate} >= DATE_SUB(NOW(), INTERVAL ${monthsBack} MONTH) 
        AND ${works.status} = 'delivered'
      GROUP BY YEAR(${works.receptionDate}), MONTH(${works.receptionDate})
      ORDER BY YEAR(${works.receptionDate}), MONTH(${works.receptionDate})
    `);
    
    // معالجة النتائج - تحويل البيانات من قاعدة البيانات
    if (!result || !Array.isArray(result)) {
      return [];
    }
    
    return result.map((r: any) => {
      // تحويل القيم إلى الأنواع الصحيحة
      const revenue = typeof r.revenue === 'string' ? parseFloat(r.revenue) : (r.revenue || 0);
      const month = typeof r.month === 'string' ? parseInt(r.month) : (r.month || 0);
      const year = typeof r.year === 'string' ? parseInt(r.year) : (r.year || 0);
      
      return {
        month,
        year,
        revenue: Math.round(revenue * 100) / 100,
      };
    });
  } catch (error) {
    console.error('Error in getMonthlyRevenueHistory:', error);
    return [];
  }
}

/**
 * حساب التوقعات للأشهر القادمة باستخدام المتوسط المتحرك
 */
export async function getForecastedRevenue(monthsAhead: number = 3) {
  const db = await getDb();
  if (!db) return [];
  
  // جلب البيانات التاريخية للـ 6 أشهر الماضية
  const history = await getMonthlyRevenueHistory(6);
  
  if (history.length === 0) {
    return [];
  }
  
  // حساب المتوسط المتحرك (3 أشهر)
  const movingAverages: number[] = [];
  for (let i = 2; i < history.length; i++) {
    const avg = (history[i].revenue + history[i - 1].revenue + history[i - 2].revenue) / 3;
    movingAverages.push(avg);
  }
  
  // حساب الاتجاه (Trend)
  const lastAvg = movingAverages[movingAverages.length - 1] || 0;
  const prevAvg = movingAverages[movingAverages.length - 2] || lastAvg;
  const trend = lastAvg - prevAvg;
  
  // توليد التوقعات
  const forecasts: any[] = [];
  const today = new Date();
  
  for (let i = 1; i <= monthsAhead; i++) {
    const forecastDate = new Date(today.getFullYear(), today.getMonth() + i, 1);
    const month = forecastDate.getMonth() + 1;
    const year = forecastDate.getFullYear();
    
    // التوقعة = آخر متوسط + الاتجاه
    const forecastedValue = Math.max(0, lastAvg + (trend * i * 0.5));
    
    forecasts.push({
      month,
      year,
      forecastedRevenue: Math.round(forecastedValue * 100) / 100,
      confidence: Math.max(0.5, 1 - (i * 0.1)), // الثقة تنخفض مع الوقت
    });
  }
  
  return forecasts;
}

/**
 * حساب التوقعات حسب نوع الخدمة
 */
export async function getForecastedRevenueByType(monthsAhead: number = 3) {
  const db = await getDb();
  if (!db) return [];
  
  // جلب البيانات التاريخية لكل نوع خدمة
  const result = await db
    .select({
      workTypeId: works.workTypeId,
      workTypeName: workTypes.name,
      month: sql<number>`MONTH(${works.createdAt})`,
      year: sql<number>`YEAR(${works.createdAt})`,
      revenue: sql<string>`SUM(CAST(${works.totalPrice} AS DECIMAL(10,2)))`,
    })
    .from(works)
    .leftJoin(workTypes, eq(works.workTypeId, workTypes.id))
    .where(
      sql`${works.createdAt} >= DATE_SUB(NOW(), INTERVAL 6 MONTH) AND ${works.status} = 'delivered'`
    )
    .groupBy(works.workTypeId, workTypes.name, sql`YEAR(${works.createdAt}), MONTH(${works.createdAt})`)
    .orderBy(works.workTypeId, sql`YEAR(${works.createdAt}), MONTH(${works.createdAt})`);
  
  // تجميع البيانات حسب نوع الخدمة
  const typeMap = new Map<number, any[]>();
  
  result.forEach(r => {
    if (!typeMap.has(r.workTypeId)) {
      typeMap.set(r.workTypeId, []);
    }
    typeMap.get(r.workTypeId)!.push({
      month: Number(r.month) || 0,
      year: Number(r.year) || 0,
      revenue: parseFloat(r.revenue || '0'),
      typeName: r.workTypeName || 'أخرى',
    });
  });
  
  // حساب التوقعات لكل نوع خدمة
  const forecasts: any[] = [];
  
  typeMap.forEach((history, typeId) => {
    if (history.length < 2) return;
    
    // حساب المتوسط المتحرك
    const movingAverages: number[] = [];
    for (let i = Math.min(2, history.length - 1); i < history.length; i++) {
      const start = Math.max(0, i - 2);
      const slice = history.slice(start, i + 1);
      const avg = slice.reduce((sum, h) => sum + h.revenue, 0) / slice.length;
      movingAverages.push(avg);
    }
    
    const lastAvg = movingAverages[movingAverages.length - 1] || 0;
    const prevAvg = movingAverages[movingAverages.length - 2] || lastAvg;
    const trend = lastAvg - prevAvg;
    
    const today = new Date();
    const typeName = history[0].typeName;
    
    for (let i = 1; i <= monthsAhead; i++) {
      const forecastDate = new Date(today.getFullYear(), today.getMonth() + i, 1);
      const month = forecastDate.getMonth() + 1;
      const year = forecastDate.getFullYear();
      
      const forecastedValue = Math.max(0, lastAvg + (trend * i * 0.5));
      
      forecasts.push({
        workTypeId: typeId,
        workTypeName: typeName,
        month,
        year,
        forecastedRevenue: Math.round(forecastedValue * 100) / 100,
      });
    }
  });
  
  return forecasts;
}

/**
 * حساب التوقعات حسب الطبيب
 */
export async function getForecastedRevenueByDoctor(monthsAhead: number = 3) {
  const db = await getDb();
  if (!db) return [];
  
  // جلب البيانات التاريخية لكل طبيب
  const result = await db
    .select({
      doctorId: works.doctorId,
      doctorName: doctors.name,
      month: sql<number>`MONTH(${works.createdAt})`,
      year: sql<number>`YEAR(${works.createdAt})`,
      revenue: sql<string>`SUM(CAST(${works.totalPrice} AS DECIMAL(10,2)))`,
    })
    .from(works)
    .leftJoin(doctors, eq(works.doctorId, doctors.id))
    .where(
      sql`${works.createdAt} >= DATE_SUB(NOW(), INTERVAL 6 MONTH) AND ${works.status} = 'delivered'`
    )
    .groupBy(works.doctorId, doctors.name, sql`YEAR(${works.createdAt}), MONTH(${works.createdAt})`)
    .orderBy(works.doctorId, sql`YEAR(${works.createdAt}), MONTH(${works.createdAt})`);
  
  // تجميع البيانات حسب الطبيب
  const doctorMap = new Map<number, any[]>();
  
  result.forEach(r => {
    if (!doctorMap.has(r.doctorId)) {
      doctorMap.set(r.doctorId, []);
    }
    doctorMap.get(r.doctorId)!.push({
      month: Number(r.month) || 0,
      year: Number(r.year) || 0,
      revenue: parseFloat(r.revenue || '0'),
      doctorName: r.doctorName || 'غير معروف',
    });
  });
  
  // حساب التوقعات لكل طبيب
  const forecasts: any[] = [];
  
  doctorMap.forEach((history, doctorId) => {
    if (history.length < 2) return;
    
    // حساب المتوسط المتحرك
    const movingAverages: number[] = [];
    for (let i = Math.min(2, history.length - 1); i < history.length; i++) {
      const start = Math.max(0, i - 2);
      const slice = history.slice(start, i + 1);
      const avg = slice.reduce((sum, h) => sum + h.revenue, 0) / slice.length;
      movingAverages.push(avg);
    }
    
    const lastAvg = movingAverages[movingAverages.length - 1] || 0;
    const prevAvg = movingAverages[movingAverages.length - 2] || lastAvg;
    const trend = lastAvg - prevAvg;
    
    const today = new Date();
    const doctorName = history[0].doctorName;
    
    for (let i = 1; i <= monthsAhead; i++) {
      const forecastDate = new Date(today.getFullYear(), today.getMonth() + i, 1);
      const month = forecastDate.getMonth() + 1;
      const year = forecastDate.getFullYear();
      
      const forecastedValue = Math.max(0, lastAvg + (trend * i * 0.5));
      
      forecasts.push({
        doctorId,
        doctorName,
        month,
        year,
        forecastedRevenue: Math.round(forecastedValue * 100) / 100,
      });
    }
  });
  
  return forecasts;
}


export async function getAllWorkTypes() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get work types: database not available");
    return [];
  }

  try {
    return db.select().from(workTypes);
  } catch (error) {
    console.error("[Database] Error getting work types:", error);
    return [];
  }
}


// ============================================
// دوال إدارة العملات وأسعار الصرف
// ============================================

/**
 * الحصول على جميع العملات
 */
export async function getAllCurrencies() {
  const db = await getDb();
  if (!db) return [];
  try {
    return await db.select().from(currencies).where(eq(currencies.isActive, true));
  } catch (error) {
    console.error("Error fetching currencies:", error);
    return [];
  }
}

/**
 * الحصول على العملة الافتراضية
 */
export async function getDefaultCurrency() {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.select().from(currencies).where(eq(currencies.isDefault, true)).limit(1);
    return result[0] || null;
  } catch (error) {
    console.error("Error fetching default currency:", error);
    return null;
  }
}

/**
 * الحصول على سعر الصرف بين عملتين
 */
export async function getExchangeRate(fromCurrencyId: number, toCurrencyId: number) {
  const db = await getDb();
  if (!db) return null;
  try {
    // البحث عن سعر صرف مباشر
    const result = await db
      .select()
      .from(exchangeRates)
      .where(
        and(
          eq(exchangeRates.fromCurrencyId, fromCurrencyId),
          eq(exchangeRates.toCurrencyId, toCurrencyId)
        )
      )
      .orderBy(desc(exchangeRates.date))
      .limit(1);
    
    if (result.length > 0) {
      return result[0];
    }
    
    // إذا لم يوجد سعر مباشر، ابحث عن السعر العكسي
    const reverseResult = await db
      .select()
      .from(exchangeRates)
      .where(
        and(
          eq(exchangeRates.fromCurrencyId, toCurrencyId),
          eq(exchangeRates.toCurrencyId, fromCurrencyId)
        )
      )
      .orderBy(desc(exchangeRates.date))
      .limit(1);
    
    if (reverseResult.length > 0) {
      // حساب المقلوب
      const reverseRate = reverseResult[0];
      const invertedRate = (1 / parseFloat(reverseRate.rate)).toString();
      
      return {
        ...reverseRate,
        rate: invertedRate,
        fromCurrencyId: toCurrencyId,
        toCurrencyId: fromCurrencyId,
      };
    }
    
    return null;
  } catch (error) {
    console.error("Error fetching exchange rate:", error);
    return null;
  }
}

/**
 * إضافة أو تحديث سعر صرف
 */
export async function upsertExchangeRate(
  fromCurrencyId: number,
  toCurrencyId: number,
  rate: string,
  date: Date,
  source?: string
) {
  const db = await getDb();
  if (!db) return null;
  try {
    // البحث عن سعر صرف موجود لنفس اليوم
    const existing = await db
      .select()
      .from(exchangeRates)
      .where(
        and(
          eq(exchangeRates.fromCurrencyId, fromCurrencyId),
          eq(exchangeRates.toCurrencyId, toCurrencyId),
          sql`DATE(${exchangeRates.date}) = DATE(${date})`
        )
      )
      .limit(1);

    if (existing.length > 0) {
      // تحديث السعر الموجود
      const updatedAt = new Date();
      await db
        .update(exchangeRates)
        .set({
          rate,
          source,
          updatedAt,
        })
        .where(eq(exchangeRates.id, existing[0].id));
      // إرجاع البيانات المحدثة
      return {
        ...existing[0],
        rate,
        source,
        updatedAt,
      }
    } else {
      // إضافة سعر جديد
      const now = new Date();
      await db.insert(exchangeRates).values({
        fromCurrencyId,
        toCurrencyId,
        rate,
        date,
        source,
        createdAt: now,
        updatedAt: now,
      });
      // البحث عن السعر المضاف للتأكد من البيانات
      const inserted = await db
        .select()
        .from(exchangeRates)
        .where(
          and(
            eq(exchangeRates.fromCurrencyId, fromCurrencyId),
            eq(exchangeRates.toCurrencyId, toCurrencyId),
            sql`DATE(${exchangeRates.date}) = DATE(${date})`
          )
        )
        .orderBy(desc(exchangeRates.id))
        .limit(1);
      
      return inserted.length > 0 ? inserted[0] : null;
    }
  } catch (error) {
    console.error("Error upserting exchange rate:", error);
    return null;
  }
}

/**
 * تحويل المبلغ من عملة إلى أخرى
 */
export async function convertCurrency(
  amount: number,
  fromCurrencyId: number,
  toCurrencyId: number
): Promise<number | null> {
  if (fromCurrencyId === toCurrencyId) {
    return amount;
  }

  const rate = await getExchangeRate(fromCurrencyId, toCurrencyId);
  if (!rate) {
    console.warn(`No exchange rate found for currencies ${fromCurrencyId} to ${toCurrencyId}`);
    return null;
  }

  return amount * parseFloat(rate.rate);
}

/**
 * إضافة عملة جديدة
 */
export async function addCurrency(
  code: string,
  name: string,
  symbol: string,
  isDefault: boolean = false
) {
  const db = await getDb();
  if (!db) return null;
  try {
    // إذا كانت العملة الجديدة افتراضية، أزل الافتراضية من العملات الأخرى
    if (isDefault) {
      await db.update(currencies).set({ isDefault: false });
    }

    const result = await db.insert(currencies).values({
      code,
      name,
      symbol,
      isDefault,
      isActive: true,
    });
    return result;
  } catch (error) {
    console.error("Error adding currency:", error);
    return null;
  }
}

/**
 * تحديث العملة
 */
export async function updateCurrency(
  currencyId: number,
  updates: { name?: string; symbol?: string; isDefault?: boolean; isActive?: boolean }
) {
  const db = await getDb();
  if (!db) return null;
  try {
    // إذا تم تعيين هذه العملة كافتراضية، أزل الافتراضية من العملات الأخرى
    if (updates.isDefault) {
      await db.update(currencies).set({ isDefault: false });
    }

    await db.update(currencies).set(updates).where(eq(currencies.id, currencyId));
    return true;
  } catch (error) {
    console.error("Error updating currency:", error);
    return null;
  }
}


// ============================================
// دوال التحويل التلقائي للأسعار
// ============================================

/**
 * حساب السعر بالعملة الثانية مع سعر الصرف
 */
export async function calculatePriceInSecondCurrency(
  priceInFirstCurrency: number,
  fromCurrencyId: number,
  toCurrencyId: number
): Promise<{ priceInSecondCurrency: number | null; exchangeRate: string | null }> {
  if (fromCurrencyId === toCurrencyId) {
    return {
      priceInSecondCurrency: priceInFirstCurrency,
      exchangeRate: "1",
    };
  }

  const exchangeRate = await getExchangeRate(fromCurrencyId, toCurrencyId);
  if (!exchangeRate) {
    return {
      priceInSecondCurrency: null,
      exchangeRate: null,
    };
  }

  const priceInSecondCurrency = priceInFirstCurrency * parseFloat(exchangeRate.rate);
  return {
    priceInSecondCurrency,
    exchangeRate: exchangeRate.rate,
  };
}

/**
 * تحديث سعر العمل بالعملة الثانية
 */
export async function updateWorkWithCurrencyConversion(
  workId: number,
  currencyId: number,
  totalPrice: number,
  secondCurrencyId: number = 2 // الليرة السورية افتراضياً
) {
  const db = await getDb();
  if (!db) return null;

  try {
    const { priceInSecondCurrency, exchangeRate } = await calculatePriceInSecondCurrency(
      totalPrice,
      currencyId,
      secondCurrencyId
    );

    if (priceInSecondCurrency === null) {
      console.warn(`Cannot calculate price in second currency for work ${workId}`);
      return null;
    }

    await db
      .update(works)
      .set({
        currencyId,
        priceInSecondCurrency: priceInSecondCurrency.toString(),
        exchangeRateUsed: exchangeRate,
        updatedAt: new Date(),
      })
      .where(eq(works.id, workId));

    return true;
  } catch (error) {
    console.error("Error updating work with currency conversion:", error);
    return null;
  }
}

/**
 * تحديث سعر الفاتورة بالعملة الثانية
 */
export async function updateInvoiceWithCurrencyConversion(
  invoiceId: number,
  currencyId: number,
  totalPrice: number,
  secondCurrencyId: number = 2 // الليرة السورية افتراضياً
) {
  const db = await getDb();
  if (!db) return null;

  try {
    const { priceInSecondCurrency, exchangeRate } = await calculatePriceInSecondCurrency(
      totalPrice,
      currencyId,
      secondCurrencyId
    );

    if (priceInSecondCurrency === null) {
      console.warn(`Cannot calculate price in second currency for invoice ${invoiceId}`);
      return null;
    }

    await db
      .update(invoices)
      .set({
        currencyId,
        totalInSecondCurrency: priceInSecondCurrency.toString(),
        exchangeRateUsed: exchangeRate,
        updatedAt: new Date(),
      })
      .where(eq(invoices.id, invoiceId));

    return true;
  } catch (error) {
    console.error("Error updating invoice with currency conversion:", error);
    return null;
  }
}

/**
 * الحصول على سعر العمل بالعملتين
 */
export async function getWorkWithBothCurrencies(workId: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    const work = await db.select().from(works).where(eq(works.id, workId)).limit(1);
    if (!work || work.length === 0) return null;

    const workData = work[0];
    const currency = await db
      .select()
      .from(currencies)
      .where(eq(currencies.id, workData.currencyId || 1))
      .limit(1);

    const secondCurrency = await db
      .select()
      .from(currencies)
      .where(eq(currencies.id, 2)) // الليرة السورية
      .limit(1);

    return {
      ...workData,
      currency: currency[0] || null,
      secondCurrency: secondCurrency[0] || null,
      priceInFirstCurrency: workData.totalPrice,
      priceInSecondCurrency: workData.priceInSecondCurrency,
      exchangeRateUsed: workData.exchangeRateUsed,
    };
  } catch (error) {
    console.error("Error fetching work with both currencies:", error);
    return null;
  }
}

/**
 * الحصول على سعر الفاتورة بالعملتين
 */
export async function getInvoiceWithBothCurrencies(invoiceId: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    const invoice = await db
      .select()
      .from(invoices)
      .where(eq(invoices.id, invoiceId))
      .limit(1);

    if (!invoice || invoice.length === 0) return null;

    const invoiceData = invoice[0];
    const currency = await db
      .select()
      .from(currencies)
      .where(eq(currencies.id, invoiceData.currencyId || 1))
      .limit(1);

    const secondCurrency = await db
      .select()
      .from(currencies)
      .where(eq(currencies.id, 2)) // الليرة السورية
      .limit(1);

    return {
      ...invoiceData,
      currency: currency[0] || null,
      secondCurrency: secondCurrency[0] || null,
      totalInFirstCurrency: invoiceData.total,
      totalInSecondCurrency: invoiceData.totalInSecondCurrency,
      exchangeRateUsed: invoiceData.exchangeRateUsed,
    };
  } catch (error) {
    console.error("Error fetching invoice with both currencies:", error);
    return null;
  }
}


/**
 * تسجيل نشاط في سجل التدقيق
 */
export async function logAuditActivity(data: {
  userId: number;
  action: string;
  actionType: "user_switch" | "role_change" | "user_create" | "user_delete" | "user_update" | "login" | "logout" | "password_change" | "other";
  targetUserId?: number;
  targetType?: string;
  targetId?: number;
  description?: string;
  oldValue?: string;
  newValue?: string;
  ipAddress?: string;
  userAgent?: string;
  status?: "success" | "failed" | "pending";
  errorMessage?: string;
}) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot log audit activity: database not available");
    return null;
  }

  try {
    const result = await db.insert(auditLog).values({
      userId: data.userId,
      action: data.action,
      actionType: data.actionType,
      targetUserId: data.targetUserId,
      targetType: data.targetType,
      targetId: data.targetId,
      description: data.description,
      oldValue: data.oldValue,
      newValue: data.newValue,
      ipAddress: data.ipAddress,
      userAgent: data.userAgent,
      status: data.status || "success",
      errorMessage: data.errorMessage,
    });
    return result;
  } catch (error) {
    console.error("Error logging audit activity:", error);
    return null;
  }
}

/**
 * الحصول على سجل التدقيق
 */
export async function getAuditLog(limit: number = 100, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];

  try {
    const logs = await db
      .select()
      .from(auditLog)
      .orderBy((t) => desc(t.createdAt))
      .limit(limit)
      .offset(offset);
    return logs;
  } catch (error) {
    console.error("Error fetching audit log:", error);
    return [];
  }
}

/**
 * الحصول على سجل التدقيق لمستخدم معين
 */
export async function getUserAuditLog(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  try {
    const logs = await db
      .select()
      .from(auditLog)
      .where(eq(auditLog.userId, userId))
      .orderBy((t) => desc(t.createdAt))
      .limit(limit);
    return logs;
  } catch (error) {
    console.error("Error fetching user audit log:", error);
    return [];
  }
}

/**
 * الحصول على سجل التدقيق لعملية تبديل مستخدم معين
 */
export async function getTargetUserAuditLog(targetUserId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  try {
    const logs = await db
      .select()
      .from(auditLog)
      .where(eq(auditLog.targetUserId, targetUserId))
      .orderBy((t) => desc(t.createdAt))
      .limit(limit);
    return logs;
  } catch (error) {
    console.error("Error fetching target user audit log:", error);
    return [];
  }
}


export async function getInvoiceItems(invoiceId: number) {
  const db = await getDb();
  if (!db) return [];
  try {
    const items = await db
      .select()
      .from(invoiceItems)
      .where(eq(invoiceItems.invoiceId, invoiceId));
    
    // جلب بيانات الأعمال المرتبطة بكل عنصر فاتورة
    const itemsWithWorkData = await Promise.all(
      items.map(async (item) => {
        let workData = null;
        if (item.workId) {
          try {
            const workResult = await db
              .select()
              .from(works)
              .where(eq(works.id, item.workId))
              .limit(1);
            workData = workResult[0] || null;
          } catch (error) {
            console.error(`Error fetching work ${item.workId}:`, error);
          }
        }
        return {
          ...item,
          work: workData,
          workDate: workData?.createdAt || null,
        };
      })
    );
    
    return itemsWithWorkData;
  } catch (error) {
    console.error("Error fetching invoice items:", error);
    return [];
  }
}


// ============================================
// دوال التقارير الشهرية التلقائية
// ============================================

/**
 * الحصول على التقرير الشهري الشامل
 */
export async function getMonthlyReport(year: number, month: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0, 23, 59, 59);

    // الحصول على الأعمال المسلمة في الشهر
    const deliveredWorks = await db
      .select()
      .from(works)
      .where(
        and(
          gte(works.createdAt, startDate),
          lte(works.createdAt, endDate),
          eq(works.status, 'delivered')
        )
      );

    // الحصول على الأعمال المعلقة في الشهر
    const pendingWorks = await db
      .select()
      .from(works)
      .where(
        and(
          gte(works.createdAt, startDate),
          lte(works.createdAt, endDate),
          eq(works.status, 'pending')
        )
      );

    const deliveredRevenue = deliveredWorks.reduce((sum, w) => sum + parseFloat(w.totalPrice || '0'), 0);
    const pendingRevenue = pendingWorks.reduce((sum, w) => sum + parseFloat(w.totalPrice || '0'), 0);

    // الحصول على الأطباء المشاركين
    const doctorIds = new Set([...deliveredWorks, ...pendingWorks].map(w => w.doctorId));
    const doctorsList = await db.select().from(doctors).where(
      inArray(doctors.id, Array.from(doctorIds))
    );

    return {
      year,
      month,
      startDate,
      endDate,
      deliveredWorks: deliveredWorks.length,
      pendingWorks: pendingWorks.length,
      totalWorks: deliveredWorks.length + pendingWorks.length,
      deliveredRevenue: Math.round(deliveredRevenue * 100) / 100,
      pendingRevenue: Math.round(pendingRevenue * 100) / 100,
      totalRevenue: Math.round((deliveredRevenue + pendingRevenue) * 100) / 100,
      doctors: doctorsList.length,
      generatedAt: new Date(),
    };
  } catch (error) {
    console.error('Error in getMonthlyReport:', error);
    return null;
  }
}

/**
 * الحصول على التقرير الشهري لطبيب معين
 */
export async function getDoctorMonthlyReport(doctorId: number, year: number, month: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0, 23, 59, 59);

    // الحصول على الأعمال المسلمة للطبيب في الشهر
    const deliveredWorks = await db
      .select()
      .from(works)
      .where(
        and(
          eq(works.doctorId, doctorId),
          gte(works.createdAt, startDate),
          lte(works.createdAt, endDate),
          eq(works.status, 'delivered')
        )
      );

    // الحصول على الأعمال المعلقة للطبيب في الشهر
    const pendingWorks = await db
      .select()
      .from(works)
      .where(
        and(
          eq(works.doctorId, doctorId),
          gte(works.createdAt, startDate),
          lte(works.createdAt, endDate),
          eq(works.status, 'pending')
        )
      );

    const deliveredRevenue = deliveredWorks.reduce((sum, w) => sum + parseFloat(w.totalPrice || '0'), 0);
    const pendingRevenue = pendingWorks.reduce((sum, w) => sum + parseFloat(w.totalPrice || '0'), 0);

    // الحصول على بيانات الطبيب
    const doctor = await db.select().from(doctors).where(eq(doctors.id, doctorId)).limit(1);

    return {
      doctorId,
      doctorName: doctor[0]?.name || 'غير معروف',
      year,
      month,
      startDate,
      endDate,
      deliveredWorks: deliveredWorks.length,
      pendingWorks: pendingWorks.length,
      totalWorks: deliveredWorks.length + pendingWorks.length,
      deliveredRevenue: Math.round(deliveredRevenue * 100) / 100,
      pendingRevenue: Math.round(pendingRevenue * 100) / 100,
      totalRevenue: Math.round((deliveredRevenue + pendingRevenue) * 100) / 100,
      works: [...deliveredWorks, ...pendingWorks],
      generatedAt: new Date(),
    };
  } catch (error) {
    console.error('Error in getDoctorMonthlyReport:', error);
    return null;
  }
}

/**
 * توليد التقارير الشهرية لجميع الأطباء
 */
export async function generateMonthlyReports(year: number, month: number) {
  const db = await getDb();
  if (!db) return [];

  try {
    // الحصول على جميع الأطباء النشطين
    const allDoctors = await db.select().from(doctors).where(eq(doctors.isActive, true));

    // توليد التقرير لكل طبيب
    const reports = await Promise.all(
      allDoctors.map(doctor => getDoctorMonthlyReport(doctor.id, year, month))
    );

    return reports.filter(r => r !== null);
  } catch (error) {
    console.error('Error in generateMonthlyReports:', error);
    return [];
  }
}


/**
 * إنشاء الفواتير التلقائية من الأعمال المسلمة
 * تجميع الأعمال حسب الطبيب والشهر وإنشاء فاتورة لكل مجموعة
 */
export async function createAutoInvoices() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    // جلب جميع الأعمال المسلمة
    const deliveredWorks = await db
      .select()
      .from(works)
      .where(eq(works.status, "delivered"));

    if (deliveredWorks.length === 0) {
      return { created: 0, skipped: 0, message: "لا توجد أعمال مسلمة" };
    }

    // تجميع الأعمال حسب الطبيب والشهر
    const groupedWorks: Record<string, typeof deliveredWorks> = {};
    for (const work of deliveredWorks) {
      const date = new Date(work.createdAt);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, "0");
      const key = `${work.doctorId}-${year}-${month}`;

      if (!groupedWorks[key]) {
        groupedWorks[key] = [];
      }
      groupedWorks[key].push(work);
    }

    let createdCount = 0;
    let skippedCount = 0;

    // إنشاء فاتورة لكل مجموعة
    for (const [key, groupWorks] of Object.entries(groupedWorks)) {
      const [doctorIdStr, yearStr, monthStr] = key.split("-");
      const doctorId = parseInt(doctorIdStr);
      const year = parseInt(yearStr);
      const month = parseInt(monthStr);

      // التحقق من عدم وجود فاتورة مسبقة
      const existingInvoices = await db
        .select()
        .from(invoices)
        .where(
          and(
            eq(invoices.doctorId, doctorId),
            eq(invoices.status, "draft")
          )
        );

      // التحقق من وجود فاتورة في نفس الشهر والسنة
      const hasSameMonthInvoice = existingInvoices.some(inv => {
        const invDate = new Date(inv.invoiceDate);
        return invDate.getFullYear() === year && (invDate.getMonth() + 1) === month;
      });

      if (hasSameMonthInvoice) {
        skippedCount++;
        continue;
      }

      // حساب المبلغ الإجمالي
      const totalAmount = groupWorks.reduce(
        (sum, w) => sum + parseFloat(w.totalPrice.toString()),
        0
      );

      // إنشاء رقم فاتورة فريد
      const invoiceNumber = `INV-${year}${monthStr}-${doctorId}-${Date.now()}`;
      const invoiceDate = new Date(year, month - 1, 1);
      const dueDate = new Date(year, month, 0);

      // إنشاء الفاتورة
      const result = await db.insert(invoices).values({
        invoiceNumber,
        doctorId,
        subtotal: totalAmount.toString(),
        taxRate: "0",
        taxAmount: "0",
        total: totalAmount.toString(),
        paidAmount: "0",
        remainingAmount: totalAmount.toString(),
        status: "draft",
        invoiceDate,
        dueDate,
        notes: `فاتورة تلقائية لـ ${groupWorks.length} أعمال في ${monthStr}/${year}`,
      });

      // إضافة تفاصيل الفاتورة
      const invoiceId = (result as any)[0].insertId;
      for (const work of groupWorks) {
        await db.insert(invoiceItems).values({
          invoiceId,
          workId: work.id,
          description: work.description || "عمل",
          quantity: work.quantity,
          unitPrice: work.unitPrice.toString(),
          totalPrice: work.totalPrice.toString(),
        });
      }

      createdCount++;
    }

    return {
      created: createdCount,
      skipped: skippedCount,
      message: `تم إنشاء ${createdCount} فاتورة جديدة وتخطي ${skippedCount} فاتورة موجودة`,
    };
  } catch (error) {
    console.error("[createAutoInvoices] Error:", error);
    throw error;
  }
}


// ============ Overdue Works (الأعمال المتأخرة) ============

export async function getOverdueWorks() {
  const db = await getDb();
  if (!db) return [];
  
  try {
    const now = new Date();
    const nowStr = now.toISOString().split('T')[0];
    // استخدام SQL خام للحصول على الأعمال المتأخرة
    const overdueWorks = await db.execute(
      `SELECT 
        w.id,
        w.patientName,
        w.doctorId,
        w.workTypeId,
        w.receptionDate,
        w.dueDate,
        w.status,
        w.description,
        w.totalPrice,
        DATEDIFF('${nowStr}', w.dueDate) as daysOverdue
      FROM works w
      WHERE w.dueDate < '${nowStr}' AND w.status IN ('pending', 'in_progress')
      ORDER BY w.dueDate ASC`
    );
    
    return (overdueWorks as any)[0] || [];
  } catch (error) {
    console.error("[getOverdueWorks] Error:", error);
    return [];
  }
}

export async function getOverdueWorksCount() {
  const overdueWorks = await getOverdueWorks();
  return overdueWorks.length;
}
