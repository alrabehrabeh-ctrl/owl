import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import { createCallerFactory } from "@trpc/server";

describe("Debts Router", () => {
  let caller: ReturnType<typeof createCallerFactory(appRouter)>;

  beforeAll(() => {
    const createCaller = createCallerFactory(appRouter);
    caller = createCaller({
      user: {
        id: 1,
        openId: "test-user",
        name: "Test User",
        email: "test@example.com",
        role: "admin",
        loginMethod: "google",
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: {} as any,
      res: {} as any,
    });
  });

  describe("getDebtsStatistics", () => {
    it("should return debts statistics", async () => {
      const result = await caller.debts.getDebtsStatistics();
      expect(result).toBeDefined();
      expect(result).toHaveProperty("totalInvoiced");
      expect(result).toHaveProperty("totalPaid");
      expect(result).toHaveProperty("totalDebt");
      expect(result).toHaveProperty("overdueDebt");
      expect(result).toHaveProperty("paymentPercentage");
      expect(result).toHaveProperty("invoiceCount");
      expect(result).toHaveProperty("paidInvoices");
      expect(result).toHaveProperty("partialInvoices");
      expect(result).toHaveProperty("overdueInvoices");
      expect(result).toHaveProperty("draftInvoices");
    });

    it("should have valid numeric values", async () => {
      const result = await caller.debts.getDebtsStatistics();
      expect(typeof result.totalInvoiced).toBe("number");
      expect(typeof result.totalPaid).toBe("number");
      expect(typeof result.totalDebt).toBe("number");
      expect(typeof result.overdueDebt).toBe("number");
      expect(typeof result.paymentPercentage).toBe("number");
      expect(result.paymentPercentage).toBeGreaterThanOrEqual(0);
      expect(result.paymentPercentage).toBeLessThanOrEqual(100);
    });

    it("should have non-negative invoice counts", async () => {
      const result = await caller.debts.getDebtsStatistics();
      expect(result.invoiceCount).toBeGreaterThanOrEqual(0);
      expect(result.paidInvoices).toBeGreaterThanOrEqual(0);
      expect(result.partialInvoices).toBeGreaterThanOrEqual(0);
      expect(result.overdueInvoices).toBeGreaterThanOrEqual(0);
      expect(result.draftInvoices).toBeGreaterThanOrEqual(0);
    });
  });

  describe("getAllDoctorsDebts", () => {
    it("should return all doctors with debts", async () => {
      const result = await caller.debts.getAllDoctorsDebts();
      expect(result).toBeDefined();
      expect(result).toHaveProperty("doctors");
      expect(result).toHaveProperty("totalDebt");
      expect(result).toHaveProperty("totalDoctors");
      expect(result).toHaveProperty("doctorsWithDebt");
      expect(result).toHaveProperty("overdueCount");
    });

    it("should have valid doctor data", async () => {
      const result = await caller.debts.getAllDoctorsDebts();
      if (result.doctors.length > 0) {
        const doctor = result.doctors[0];
        expect(doctor).toHaveProperty("id");
        expect(doctor).toHaveProperty("name");
        expect(doctor).toHaveProperty("totalDebt");
        expect(doctor).toHaveProperty("totalInvoices");
        expect(doctor).toHaveProperty("overdueInvoices");
        expect(doctor).toHaveProperty("status");
        expect(["clear", "pending", "overdue"]).toContain(doctor.status);
      }
    });

    it("should have sorted doctors by debt", async () => {
      const result = await caller.debts.getAllDoctorsDebts();
      for (let i = 0; i < result.doctors.length - 1; i++) {
        expect(result.doctors[i].totalDebt).toBeGreaterThanOrEqual(
          result.doctors[i + 1].totalDebt
        );
      }
    });
  });

  describe("searchDoctors", () => {
    it("should search doctors by name", async () => {
      try {
        const result = await caller.debts.searchDoctors({ query: "test" });
        expect(Array.isArray(result)).toBe(true);
      } catch (error) {
        // Search might return empty if no doctors match
        expect(error).toBeDefined();
      }
    });

    it("should require non-empty query", async () => {
      try {
        await caller.debts.searchDoctors({ query: "" });
        expect(true).toBe(false); // Should throw error
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("getDoctorDebts", () => {
    it("should throw error for non-existent doctor", async () => {
      try {
        await caller.debts.getDoctorDebts({ doctorId: 99999 });
        // If no error, check that result is valid
        expect(true).toBe(true);
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should return valid debt structure", async () => {
      try {
        const result = await caller.debts.getDoctorDebts({ doctorId: 1 });
        expect(result).toHaveProperty("invoices");
        expect(result).toHaveProperty("totalDebt");
        expect(result).toHaveProperty("totalInvoices");
        expect(result).toHaveProperty("overdueInvoices");
        expect(Array.isArray(result.invoices)).toBe(true);
      } catch (error) {
        // Expected if doctor doesn't exist
        expect(error).toBeDefined();
      }
    });
  });

  describe("getDoctorDebtDetails", () => {
    it("should throw error for non-existent doctor", async () => {
      try {
        await caller.debts.getDoctorDebtDetails({ doctorId: 99999 });
        expect(true).toBe(false); // Should throw error
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should return valid detail structure", async () => {
      try {
        const result = await caller.debts.getDoctorDebtDetails({ doctorId: 1 });
        expect(result).toHaveProperty("doctor");
        expect(result).toHaveProperty("invoices");
        expect(result).toHaveProperty("statistics");
        expect(result.statistics).toHaveProperty("totalInvoiced");
        expect(result.statistics).toHaveProperty("totalPaid");
        expect(result.statistics).toHaveProperty("totalDebt");
        expect(result.statistics).toHaveProperty("overdueDebt");
        expect(result.statistics).toHaveProperty("paymentPercentage");
      } catch (error) {
        // Expected if doctor doesn't exist
        expect(error).toBeDefined();
      }
    });
  });

  describe("getDoctorPaymentHistory", () => {
    it("should return payment history with default limit", async () => {
      try {
        const result = await caller.debts.getDoctorPaymentHistory({ doctorId: 1 });
        expect(result).toHaveProperty("payments");
        expect(result).toHaveProperty("totalPaid");
        expect(result).toHaveProperty("paymentCount");
        expect(Array.isArray(result.payments)).toBe(true);
      } catch (error) {
        // Expected if doctor doesn't exist
        expect(error).toBeDefined();
      }
    });

    it("should respect custom limit", async () => {
      try {
        const result = await caller.debts.getDoctorPaymentHistory({
          doctorId: 1,
          limit: 10,
        });
        expect(result.payments.length).toBeLessThanOrEqual(10);
      } catch (error) {
        // Expected if doctor doesn't exist
        expect(error).toBeDefined();
      }
    });

    it("should throw error for invalid limit", async () => {
      try {
        await caller.debts.getDoctorPaymentHistory({
          doctorId: 1,
          limit: 0,
        });
        expect(true).toBe(false); // Should throw error
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });
});
