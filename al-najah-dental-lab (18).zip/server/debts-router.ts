import { router, publicProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { doctors, invoices, payments, works } from "../drizzle/schema";
import { eq, and, gte, lte, desc, sum, sql } from "drizzle-orm";

export const debtsRouter = router({
  /**
   * الحصول على المديونيات لطبيب معين
   */
  getDoctorDebts: publicProcedure
    .input(
      z.object({
        doctorId: z.number().int().positive(),
      })
    )
    .query(async ({ input }: { input: { doctorId: number } }) => {
      const db = (await getDb())!;

      // الحصول على الفواتير المستحقة
      const doctorInvoices = await db
        .select({
          id: invoices.id,
          invoiceNumber: invoices.invoiceNumber,
          total: invoices.total,
          paidAmount: invoices.paidAmount,
          remainingAmount: invoices.remainingAmount,
          status: invoices.status,
          invoiceDate: invoices.invoiceDate,
          dueDate: invoices.dueDate,
        })
        .from(invoices)
        .where(eq(invoices.doctorId, input.doctorId));

      return {
        invoices: doctorInvoices,
        totalDebt: doctorInvoices.reduce((sum, inv) => {
          return sum + parseFloat(inv.remainingAmount.toString());
        }, 0),
        totalInvoices: doctorInvoices.length,
        overdueInvoices: doctorInvoices.filter(
          (inv) => inv.dueDate && new Date(inv.dueDate) < new Date()
        ).length,
      };
    }),

  /**
   * الحصول على قائمة جميع الأطباء مع إجمالي المديونيات
   */
  getAllDoctorsDebts: publicProcedure.query(async () => {
    const db = (await getDb())!;

    // الحصول على جميع الأطباء
    const allDoctors = await db.select().from(doctors);

    // حساب المديونيات لكل طبيب
    const doctorsWithDebts = await Promise.all(
      allDoctors.map(async (doctor) => {
        const doctorInvoices = await db
          .select({
            remainingAmount: invoices.remainingAmount,
            status: invoices.status,
            dueDate: invoices.dueDate,
          })
          .from(invoices)
          .where(eq(invoices.doctorId, doctor.id));

        const totalDebt = doctorInvoices.reduce((sum, inv) => {
          return sum + parseFloat(inv.remainingAmount.toString());
        }, 0);

        const overdueInvoices = doctorInvoices.filter(
          (inv) => inv.dueDate && new Date(inv.dueDate) < new Date()
        ).length;

        return {
          id: doctor.id,
          name: doctor.name,
          clinic: doctor.clinic,
          totalDebt,
          totalInvoices: doctorInvoices.length,
          overdueInvoices,
          status:
            totalDebt > 0
              ? overdueInvoices > 0
                ? "overdue"
                : "pending"
              : "clear",
        };
      })
    );

    return {
      doctors: doctorsWithDebts.sort((a, b) => b.totalDebt - a.totalDebt),
      totalDebt: doctorsWithDebts.reduce((sum, doc) => sum + doc.totalDebt, 0),
      totalDoctors: doctorsWithDebts.length,
      doctorsWithDebt: doctorsWithDebts.filter((doc) => doc.totalDebt > 0)
        .length,
      overdueCount: doctorsWithDebts.reduce(
        (sum, doc) => sum + doc.overdueInvoices,
        0
      ),
    };
  }),

  /**
   * الحصول على تفاصيل المديونيات لطبيب معين
   */
  getDoctorDebtDetails: publicProcedure
    .input(
      z.object({
        doctorId: z.number().int().positive(),
      })
    )
    .query(async ({ input }: { input: { doctorId: number } }) => {
      const db = (await getDb())!;

      // الحصول على معلومات الطبيب
      const doctor = await db
        .select()
        .from(doctors)
        .where(eq(doctors.id, input.doctorId))
        .limit(1);

      if (!doctor.length) {
        throw new Error("الطبيب غير موجود");
      }

      // الحصول على الفواتير مع تفاصيل الدفعات
      const doctorInvoices = await db
        .select({
          id: invoices.id,
          invoiceNumber: invoices.invoiceNumber,
          total: invoices.total,
          paidAmount: invoices.paidAmount,
          remainingAmount: invoices.remainingAmount,
          status: invoices.status,
          invoiceDate: invoices.invoiceDate,
          dueDate: invoices.dueDate,
          notes: invoices.notes,
        })
        .from(invoices)
        .where(eq(invoices.doctorId, input.doctorId))
        .orderBy(desc(invoices.invoiceDate));

      // حساب الإحصائيات
      const totalDebt = doctorInvoices.reduce((sum, inv) => {
        return sum + parseFloat(inv.remainingAmount.toString());
      }, 0);

      const totalPaid = doctorInvoices.reduce((sum, inv) => {
        return sum + parseFloat(inv.paidAmount.toString());
      }, 0);

      const totalInvoiced = doctorInvoices.reduce((sum, inv) => {
        return sum + parseFloat(inv.total.toString());
      }, 0);

      const overdueInvoices = doctorInvoices.filter(
        (inv) => inv.dueDate && new Date(inv.dueDate) < new Date()
      );

      const overdueDebt = overdueInvoices.reduce((sum, inv) => {
        return sum + parseFloat(inv.remainingAmount.toString());
      }, 0);

      return {
        doctor: doctor[0],
        invoices: doctorInvoices,
        statistics: {
          totalInvoiced,
          totalPaid,
          totalDebt,
          overdueDebt,
          paymentPercentage:
            totalInvoiced > 0 ? (totalPaid / totalInvoiced) * 100 : 0,
          invoiceCount: doctorInvoices.length,
          paidInvoices: doctorInvoices.filter((inv) => inv.status === "paid")
            .length,
          partialInvoices: doctorInvoices.filter(
            (inv) => inv.status === "partial"
          ).length,
          overdueInvoices: overdueInvoices.length,
        },
      };
    }),

  /**
   * الحصول على سجل الدفعات لطبيب معين
   */
  getDoctorPaymentHistory: publicProcedure
    .input(
      z.object({
        doctorId: z.number().int().positive(),
        limit: z.number().int().positive().default(50),
      })
    )
    .query(async ({ input }: { input: { doctorId: number; limit: number } }) => {
      const db = (await getDb())!;

      const paymentHistory = await db
        .select({
          id: payments.id,
          invoiceId: payments.invoiceId,
          amount: payments.amount,
          paymentMethod: payments.paymentMethod,
          paymentDate: payments.paymentDate,
          referenceNumber: payments.referenceNumber,
          notes: payments.notes,
        })
        .from(payments)
        .where(eq(payments.doctorId, input.doctorId))
        .orderBy(desc(payments.paymentDate))
        .limit(input.limit);

      const totalPaid = paymentHistory.reduce((sum, payment) => {
        return sum + parseFloat(payment.amount.toString());
      }, 0);

      return {
        payments: paymentHistory,
        totalPaid,
        paymentCount: paymentHistory.length,
      };
    }),

  /**
   * البحث عن الأطباء بناءً على اسمهم أو عيادتهم
   */
  searchDoctors: publicProcedure
    .input(
      z.object({
        query: z.string().min(1),
      })
    )
    .query(async ({ input }: { input: { query: string } }) => {
      const db = (await getDb())!;

      const searchResults = await db
        .select()
        .from(doctors)
        .where(
          sql`LOWER(${doctors.name}) LIKE LOWER(${`%${input.query}%`}) OR LOWER(${doctors.clinic}) LIKE LOWER(${`%${input.query}%`})`
        );

      return searchResults;
    }),

  /**
   * الحصول على إحصائيات المديونيات العامة
   */
  getDebtsStatistics: publicProcedure.query(async () => {
    const db = (await getDb())!;

    // الحصول على جميع الفواتير
    const allInvoices = await db.select().from(invoices);

    const totalDebt = allInvoices.reduce((sum, inv) => {
      return sum + parseFloat(inv.remainingAmount.toString());
    }, 0);

    const totalPaid = allInvoices.reduce((sum, inv) => {
      return sum + parseFloat(inv.paidAmount.toString());
    }, 0);

    const totalInvoiced = allInvoices.reduce((sum, inv) => {
      return sum + parseFloat(inv.total.toString());
    }, 0);

    const overdueInvoices = allInvoices.filter(
      (inv) => inv.dueDate && new Date(inv.dueDate) < new Date()
    );

    const overdueDebt = overdueInvoices.reduce((sum, inv) => {
      return sum + parseFloat(inv.remainingAmount.toString());
    }, 0);

    return {
      totalInvoiced,
      totalPaid,
      totalDebt,
      overdueDebt,
      paymentPercentage:
        totalInvoiced > 0 ? (totalPaid / totalInvoiced) * 100 : 0,
      invoiceCount: allInvoices.length,
      paidInvoices: allInvoices.filter((inv) => inv.status === "paid").length,
      partialInvoices: allInvoices.filter((inv) => inv.status === "partial")
        .length,
      overdueInvoices: overdueInvoices.length,
      draftInvoices: allInvoices.filter((inv) => inv.status === "draft").length,
    };
  }),
});
