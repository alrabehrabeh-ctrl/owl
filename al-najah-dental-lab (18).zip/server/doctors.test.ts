import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { doctors } from "../drizzle/schema";
import { eq } from "drizzle-orm";

describe("Doctors Router", () => {
  let testDoctorId: number;
  let db: any;

  beforeAll(async () => {
    db = await getDb();
    if (!db) {
      throw new Error("Database not available");
    }

    // إنشاء طبيب اختبار
    const result = await db
      .insert(doctors)
      .values({
        name: "Test Doctor",
        email: "test@example.com",
        phone: "1234567890",
        specialization: "Test Specialization",
        licenseNumber: "TEST123",
        isActive: true,
      })
      .returning();

    testDoctorId = result[0]?.id;
  });

  afterAll(async () => {
    if (db && testDoctorId) {
      await db.delete(doctors).where(eq(doctors.id, testDoctorId));
    }
  });

  it("should update doctor rating", async () => {
    const newRating = "4.5";
    
    await db
      .update(doctors)
      .set({ rating: newRating })
      .where(eq(doctors.id, testDoctorId));

    const updated = await db
      .select()
      .from(doctors)
      .where(eq(doctors.id, testDoctorId))
      .limit(1);

    expect(updated[0]?.rating).toBe(newRating);
  });

  it("should update doctor internal notes", async () => {
    const newNotes = "Test internal notes";
    
    await db
      .update(doctors)
      .set({ internalNotes: newNotes })
      .where(eq(doctors.id, testDoctorId));

    const updated = await db
      .select()
      .from(doctors)
      .where(eq(doctors.id, testDoctorId))
      .limit(1);

    expect(updated[0]?.internalNotes).toBe(newNotes);
  });

  it("should retrieve doctor with rating", async () => {
    const doctor = await db
      .select()
      .from(doctors)
      .where(eq(doctors.id, testDoctorId))
      .limit(1);

    expect(doctor[0]).toBeDefined();
    expect(doctor[0]?.id).toBe(testDoctorId);
    expect(doctor[0]?.name).toBe("Test Doctor");
  });

  it("should handle profile image field", async () => {
    const imageUrl = "https://example.com/image.jpg";
    
    await db
      .update(doctors)
      .set({ profileImage: imageUrl })
      .where(eq(doctors.id, testDoctorId));

    const updated = await db
      .select()
      .from(doctors)
      .where(eq(doctors.id, testDoctorId))
      .limit(1);

    expect(updated[0]?.profileImage).toBe(imageUrl);
  });
});
