import { describe, it, expect } from "vitest";

describe("Error Handling in Login Page", () => {
  describe("Zod validation errors", () => {
    it("should extract first error message from Zod validation array", () => {
      // Simulate Zod validation error
      const zodErrors = [
        {
          origin: "string",
          code: "too_small",
          minimum: 6,
          inclusive: true,
          path: ["password"],
          message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل",
        },
      ];

      // Extract first error message
      const firstError = zodErrors[0];
      const errorMessage = firstError.message;

      expect(errorMessage).toBe("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
    });

    it("should handle multiple Zod errors by showing first one", () => {
      const zodErrors = [
        {
          origin: "string",
          code: "too_small",
          minimum: 6,
          inclusive: true,
          path: ["password"],
          message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل",
        },
        {
          origin: "string",
          code: "too_long",
          maximum: 100,
          inclusive: true,
          path: ["username"],
          message: "اسم المستخدم طويل جداً",
        },
      ];

      // Show only first error
      const firstError = zodErrors[0];
      expect(firstError.message).toBe("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
    });

    it("should handle empty password error", () => {
      const zodErrors = [
        {
          origin: "string",
          code: "too_small",
          minimum: 6,
          inclusive: true,
          path: ["password"],
          message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل",
        },
      ];

      const errorMessage = zodErrors[0].message;
      expect(errorMessage).toContain("كلمة المرور");
    });

    it("should handle empty username error", () => {
      const zodErrors = [
        {
          origin: "string",
          code: "too_small",
          minimum: 3,
          inclusive: true,
          path: ["username"],
          message: "اسم المستخدم يجب أن يكون 3 أحرف على الأقل",
        },
      ];

      const errorMessage = zodErrors[0].message;
      expect(errorMessage).toContain("اسم المستخدم");
    });
  });

  describe("Error message display", () => {
    it("should display user-friendly error message instead of technical details", () => {
      // Before: Show technical error
      const technicalError = JSON.stringify([
        {
          origin: "string",
          code: "too_small",
          minimum: 6,
          inclusive: true,
          path: ["password"],
          message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل",
        },
      ]);

      // After: Show user-friendly message
      const zodErrors = JSON.parse(technicalError);
      const userFriendlyMessage = zodErrors[0].message;

      expect(userFriendlyMessage).toBe("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
      expect(userFriendlyMessage).not.toContain("origin");
      expect(userFriendlyMessage).not.toContain("code");
    });

    it("should show default message when error has no message", () => {
      const zodErrors = [
        {
          origin: "string",
          code: "invalid",
          path: ["password"],
        } as any,
      ]

      const errorMessage = zodErrors[0].message || "بيانات غير صحيحة";
      expect(errorMessage).toBe("بيانات غير صحيحة");
    });

    it("should handle non-Zod errors gracefully", () => {
      // Non-Zod error
      const error = {
        message: "اسم المستخدم أو كلمة المرور غير صحيحة",
      };

      const errorMessage = error.message || "فشل تسجيل الدخول";
      expect(errorMessage).toBe("اسم المستخدم أو كلمة المرور غير صحيحة");
    });
  });

  describe("Error handling scenarios", () => {
    it("should handle validation error for short password", () => {
      const password = "pass";
      const isValid = password.length >= 6;

      if (!isValid) {
        const errorMessage = "كلمة المرور يجب أن تكون 6 أحرف على الأقل";
        expect(errorMessage).toBeTruthy();
      }
    });

    it("should handle validation error for short username", () => {
      const username = "ab";
      const isValid = username.length >= 3;

      if (!isValid) {
        const errorMessage = "اسم المستخدم يجب أن يكون 3 أحرف على الأقل";
        expect(errorMessage).toBeTruthy();
      }
    });

    it("should accept valid password", () => {
      const password = "ValidPassword123";
      const isValid = password.length >= 6;
      expect(isValid).toBe(true);
    });

    it("should accept valid username", () => {
      const username = "validuser";
      const isValid = username.length >= 3;
      expect(isValid).toBe(true);
    });
  });

  describe("Error extraction logic", () => {
    it("should extract error from zodError array", () => {
      const errorData = {
        zodError: [
          {
            message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل",
            path: ["password"],
          },
        ],
      };

      const hasZodError = errorData?.zodError;
      const isArray = Array.isArray(errorData.zodError);
      const hasElements = errorData.zodError.length > 0;

      expect(hasZodError).toBeTruthy();
      expect(isArray).toBe(true);
      expect(hasElements).toBe(true);

      const firstError = errorData.zodError[0];
      expect(firstError.message).toBe("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
    });

    it("should handle missing zodError gracefully", () => {
      const errorData = {
        message: "اسم المستخدم أو كلمة المرور غير صحيحة",
      };

      const hasZodError = errorData?.zodError;
      expect(hasZodError).toBeFalsy();

      const errorMessage = errorData.message || "فشل تسجيل الدخول";
      expect(errorMessage).toBe("اسم المستخدم أو كلمة المرور غير صحيحة");
    });

    it("should handle empty zodError array", () => {
      const errorData = {
        zodError: [],
      };

      const hasZodError = errorData?.zodError;
      const isArray = Array.isArray(errorData.zodError);
      const hasElements = errorData.zodError.length > 0;

      expect(hasZodError).toBeTruthy();
      expect(isArray).toBe(true);
      expect(hasElements).toBe(false);

      const errorMessage = "بيانات غير صحيحة";
      expect(errorMessage).toBe("بيانات غير صحيحة");
    });
  });

  describe("User experience improvements", () => {
    it("should show clear error message for password validation", () => {
      const zodErrors = [
        {
          message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل",
          path: ["password"],
        },
      ];

      const errorMessage = zodErrors[0].message;
      expect(errorMessage).toContain("كلمة المرور");
      expect(errorMessage).toContain("6");
    });

    it("should show clear error message for username validation", () => {
      const zodErrors = [
        {
          message: "اسم المستخدم يجب أن يكون 3 أحرف على الأقل",
          path: ["username"],
        },
      ];

      const errorMessage = zodErrors[0].message;
      expect(errorMessage).toContain("اسم المستخدم");
      expect(errorMessage).toContain("3");
    });

    it("should not expose technical error details to user", () => {
      const technicalError = {
        origin: "string",
        code: "too_small",
        minimum: 6,
        inclusive: true,
        path: ["password"],
        message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل",
      };

      const userMessage = technicalError.message;

      expect(userMessage).not.toContain("origin");
      expect(userMessage).not.toContain("code");
      expect(userMessage).not.toContain("inclusive");
      expect(userMessage).not.toContain("path");
    });
  });
});
