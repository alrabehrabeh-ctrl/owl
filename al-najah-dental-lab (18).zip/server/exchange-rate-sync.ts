/**
 * خدمة مزامنة أسعار الصرف من API خارجي
 * تحديث أسعار الصرف بشكل يومي من Exchangerate-api
 */

import { getDb, upsertExchangeRate, getAllCurrencies } from "./db";
import { exchangeRates, currencies } from "../drizzle/schema";
import { desc } from "drizzle-orm";

/**
 * قائمة العملات المدعومة
 */
const SUPPORTED_CURRENCIES = ["USD", "SYP", "EUR", "GBP", "AED", "SAR"];

/**
 * مفتاح API لخدمة Exchangerate-api
 * يمكن الحصول عليه من: https://www.exchangerate-api.com
 */
const EXCHANGE_RATE_API_KEY = process.env.EXCHANGE_RATE_API_KEY || "";

/**
 * الحصول على أسعار الصرف من API خارجي
 * @param baseCurrency - العملة الأساسية (مثلاً USD)
 * @returns كائن يحتوي على أسعار الصرف
 */
export async function fetchExchangeRatesFromAPI(
  baseCurrency: string = "USD"
): Promise<Record<string, number> | null> {
  try {
    if (!EXCHANGE_RATE_API_KEY) {
      console.warn(
        "EXCHANGE_RATE_API_KEY is not set. Skipping exchange rate sync."
      );
      return null;
    }

    const url = `https://v6.exchangerate-api.com/v6/${EXCHANGE_RATE_API_KEY}/latest/${baseCurrency}`;
    const response = await fetch(url);

    if (!response.ok) {
      console.error(
        `Failed to fetch exchange rates: ${response.status} ${response.statusText}`
      );
      return null;
    }

    const data = (await response.json()) as {
      result?: string;
      conversion_rates?: Record<string, number>;
      error?: string;
    };

    if (data.result !== "success") {
      console.error(`Exchange rate API error: ${data.error}`);
      return null;
    }

    return data.conversion_rates || null;
  } catch (error) {
    console.error("Error fetching exchange rates:", error);
    return null;
  }
}

/**
 * تحديث أسعار الصرف في قاعدة البيانات
 * @param baseCurrencyId - معرّف العملة الأساسية في قاعدة البيانات
 * @param rates - كائن يحتوي على أسعار الصرف
 */
export async function updateExchangeRatesInDB(
  baseCurrencyId: number,
  rates: Record<string, number>
): Promise<number> {
  let updatedCount = 0;

  try {
    // جلب جميع العملات من قاعدة البيانات
    const allCurrencies = await getAllCurrencies();

    if (!allCurrencies) {
      console.error("Failed to fetch currencies from database");
      return 0;
    }

    for (const currency of allCurrencies) {
      const rate = rates[currency.code];

      if (rate && rate > 0) {
        // تحديث أو إضافة سعر الصرف
        await upsertExchangeRate(
          baseCurrencyId,
          currency.id,
          rate.toString(),
          new Date(),
          "exchangerate-api"
        );
        updatedCount++;
      }
    }

    console.log(`Updated ${updatedCount} exchange rates`);
    return updatedCount;
  } catch (error) {
    console.error("Error updating exchange rates in DB:", error);
    return 0;
  }
}

/**
 * مزامنة أسعار الصرف بشكل كامل
 * تحديث جميع أسعار الصرف من العملة الأساسية (USD) إلى باقي العملات
 */
export async function syncExchangeRates(): Promise<boolean> {
  try {
    console.log("Starting exchange rate sync...");

    // جلب أسعار الصرف من API
    const rates = await fetchExchangeRatesFromAPI("USD");

    if (!rates) {
      console.error("Failed to fetch exchange rates from API");
      return false;
    }

    // تحديث قاعدة البيانات
    // معرّف USD هو عادة 1
    const updatedCount = await updateExchangeRatesInDB(1, rates);

    if (updatedCount > 0) {
      console.log(`Successfully synced ${updatedCount} exchange rates`);
      return true;
    } else {
      console.warn("No exchange rates were updated");
      return false;
    }
  } catch (error) {
    console.error("Error during exchange rate sync:", error);
    return false;
  }
}

/**
 * الحصول على آخر تاريخ تحديث لأسعار الصرف
 */
export async function getLastExchangeRateUpdateTime(): Promise<Date | null> {
  try {
    const db = await getDb();
    if (!db) return null;

    const result = await db
      .select()
      .from(exchangeRates)
      .orderBy(desc(exchangeRates.updatedAt))
      .limit(1);

    if (result && result.length > 0) {
      return result[0].updatedAt;
    }

    return null;
  } catch (error) {
    console.error("Error getting last exchange rate update time:", error);
    return null;
  }
}
