import { describe, expect, it } from "vitest";

/**
 * اختبار تحويل العملات
 * يتحقق من أن الحساب صحيح مع الأسعار المباشرة والعكسية
 */
describe("Exchange rate conversion", () => {
  // دالة محاكاة لحساب التحويل (نفس المنطق في db.ts)
  function convertCurrency(
    amount: number,
    rate: number | null
  ): number | null {
    if (!rate) {
      return null;
    }
    return amount * rate;
  }

  // دالة محاكاة للبحث عن السعر (مع دعم السعر العكسي)
  function getExchangeRate(
    fromCurrencyId: number,
    toCurrencyId: number,
    rates: Record<string, number>
  ): number | null {
    const directKey = `${fromCurrencyId}->${toCurrencyId}`;
    if (rates[directKey]) {
      return rates[directKey];
    }

    const reverseKey = `${toCurrencyId}->${fromCurrencyId}`;
    if (rates[reverseKey]) {
      // حساب المقلوب
      return 1 / rates[reverseKey];
    }

    return null;
  }

  it("should convert with direct exchange rate", () => {
    const rates = {
      "1->2": 1500, // USD -> SYP = 1500
    };

    const rate = getExchangeRate(1, 2, rates);
    expect(rate).toBe(1500);

    const result = convertCurrency(100, rate);
    expect(result).toBe(150000);
  });

  it("should convert with reverse exchange rate", () => {
    const rates = {
      "1->2": 1500, // USD -> SYP = 1500
    };

    // البحث عن SYP -> USD (معكوس)
    const rate = getExchangeRate(2, 1, rates);
    expect(rate).toBeCloseTo(1 / 1500, 6);

    const result = convertCurrency(150000, rate);
    expect(result).toBeCloseTo(100, 2);
  });

  it("should return null when no rate found", () => {
    const rates = {
      "1->2": 1500,
    };

    const rate = getExchangeRate(3, 4, rates);
    expect(rate).toBeNull();

    const result = convertCurrency(100, rate);
    expect(result).toBeNull();
  });

  it("should handle multiple currency pairs", () => {
    const rates = {
      "1->2": 1500, // USD -> SYP
      "1->3": 0.92, // USD -> EUR
      "2->3": 0.000613, // SYP -> EUR
    };

    // USD -> SYP
    const usdToSyp = getExchangeRate(1, 2, rates);
    expect(usdToSyp).toBe(1500);

    // SYP -> USD (معكوس)
    const sypToUsd = getExchangeRate(2, 1, rates);
    expect(sypToUsd).toBeCloseTo(1 / 1500, 6);

    // USD -> EUR
    const usdToEur = getExchangeRate(1, 3, rates);
    expect(usdToEur).toBe(0.92);

    // EUR -> USD (معكوس)
    const eurToUsd = getExchangeRate(3, 1, rates);
    expect(eurToUsd).toBeCloseTo(1 / 0.92, 6);
  });

  it("should handle same currency conversion", () => {
    const rates = {
      "1->2": 1500,
    };

    // USD -> USD
    const rate = getExchangeRate(1, 1, rates);
    expect(rate).toBeNull(); // لا يوجد سعر لنفس العملة

    // لكن يجب أن يكون السعر = 1 في الواقع
    const result = convertCurrency(100, 1);
    expect(result).toBe(100);
  });

  it("should handle decimal rates", () => {
    const rates = {
      "1->2": 0.85, // USD -> EUR
    };

    const rate = getExchangeRate(1, 2, rates);
    expect(rate).toBe(0.85);

    const result = convertCurrency(100, rate);
    expect(result).toBe(85);

    // EUR -> USD (معكوس)
    const reverseRate = getExchangeRate(2, 1, rates);
    expect(reverseRate).toBeCloseTo(1 / 0.85, 6);

    const reverseResult = convertCurrency(85, reverseRate);
    expect(reverseResult).toBeCloseTo(100, 2);
  });

  it("should handle zero amount", () => {
    const rates = {
      "1->2": 1500,
    };

    const rate = getExchangeRate(1, 2, rates);
    const result = convertCurrency(0, rate);
    expect(result).toBe(0);
  });

  it("should handle large amounts", () => {
    const rates = {
      "1->2": 1500,
    };

    const rate = getExchangeRate(1, 2, rates);
    const result = convertCurrency(1000000, rate);
    expect(result).toBe(1500000000);
  });
});
