import { describe, it, expect } from "vitest";

describe("Forecasts Export Functions", () => {

  it("should calculate seasonality correctly", () => {
    const monthlyData = [
      { month: 1, revenue: 1000 },
      { month: 2, revenue: 1500 },
      { month: 3, revenue: 800 },
      { month: 1, revenue: 1200 },
      { month: 2, revenue: 1400 },
      { month: 3, revenue: 900 },
    ];

    const monthlyAvg: Record<number, number[]> = {};
    monthlyData.forEach(d => {
      if (!monthlyAvg[d.month]) monthlyAvg[d.month] = [];
      monthlyAvg[d.month].push(d.revenue);
    });

    const overallAvg = monthlyData.reduce((sum, d) => sum + d.revenue, 0) / monthlyData.length;
    const seasonality: Record<number, number> = {};

    Object.entries(monthlyAvg).forEach(([month, values]) => {
      const monthAvg = values.reduce((a, b) => a + b, 0) / values.length;
      seasonality[parseInt(month)] = Math.round((monthAvg / overallAvg - 1) * 100);
    });

    // شهر 1: متوسط 1100، الإجمالي 1116.67، الموسمية = (1100/1116.67 - 1) * 100 = -1.49%
    expect(seasonality[1]).toBeLessThan(0);
    // شهر 2: متوسط 1450، الموسمية موجبة
    expect(seasonality[2]).toBeGreaterThan(0);
    // شهر 3: متوسط 850، الموسمية سالبة
    expect(seasonality[3]).toBeLessThan(0);
  });

  it("should generate valid CSV export format", () => {
    const data = [
      { month: "يناير", revenue: 1000, forecastedRevenue: 1100, confidence: 0.95 },
      { month: "فبراير", revenue: 1500, forecastedRevenue: 1600, confidence: 0.92 },
    ];

    const csvContent = [
      ["الشهر", "الإيرادات الفعلية", "الإيرادات المتوقعة", "الثقة"],
      ...data.map(d => [
        d.month,
        d.revenue,
        d.forecastedRevenue,
        Math.round(d.confidence * 100) + "%",
      ]),
    ]
      .map(row => row.join(","))
      .join("\n");

    expect(csvContent).toContain("يناير");
    expect(csvContent).toContain("1000");
    expect(csvContent).toContain("95%");
    expect(csvContent.split("\n").length).toBe(3); // رأس + سطرين
  });

  it("should handle empty forecast data gracefully", () => {
    const emptyForecast: any[] = [];
    const monthNames = ["يناير", "فبراير"];

    const totalForecast = emptyForecast.reduce((sum, f) => sum + f.forecastedRevenue, 0);
    const avgForecast = emptyForecast.length > 0 ? totalForecast / emptyForecast.length : 0;

    expect(totalForecast).toBe(0);
    expect(avgForecast).toBe(0);
  });

  it("should calculate growth rate correctly", () => {
    const avgHistorical = 1000;
    const avgForecast = 1200;

    const growthRate = ((avgForecast - avgHistorical) / avgHistorical) * 100;

    expect(growthRate).toBe(20); // نمو 20%
  });

  it("should handle negative growth rate", () => {
    const avgHistorical = 1000;
    const avgForecast = 800;

    const growthRate = ((avgForecast - avgHistorical) / avgHistorical) * 100;

    expect(growthRate).toBe(-20); // انخفاض 20%
  });

  it("should format currency values correctly", () => {
    const values = [1000, 1500.50, 2000.99];

    const formatted = values.map(v => 
      "$" + Math.round(v * 100) / 100
    );

    expect(formatted[0]).toBe("$1000");
    expect(formatted[1]).toBe("$1500.5");
    expect(formatted[2]).toBe("$2000.99");
  });
});
