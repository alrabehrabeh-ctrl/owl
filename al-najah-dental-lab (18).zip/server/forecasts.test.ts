import { describe, it, expect, beforeAll, afterAll } from "vitest";
import * as db from "./db";

describe("Forecasts System", () => {
  describe("getMonthlyRevenueHistory", () => {
    it("should return empty array if no data exists", async () => {
      const history = await db.getMonthlyRevenueHistory(12);
      expect(Array.isArray(history)).toBe(true);
    });

    it("should return data sorted by year and month", async () => {
      const history = await db.getMonthlyRevenueHistory(12);
      if (history.length > 1) {
        for (let i = 1; i < history.length; i++) {
          const prev = history[i - 1];
          const curr = history[i];
          
          if (prev.year === curr.year) {
            expect(curr.month).toBeGreaterThanOrEqual(prev.month);
          } else {
            expect(curr.year).toBeGreaterThanOrEqual(prev.year);
          }
        }
      }
    });

    it("should return revenue as numbers", async () => {
      const history = await db.getMonthlyRevenueHistory(12);
      history.forEach(item => {
        expect(typeof item.revenue).toBe("number");
        expect(item.revenue).toBeGreaterThanOrEqual(0);
      });
    });
  });

  describe("getForecastedRevenue", () => {
    it("should return array of forecasts", async () => {
      const forecasts = await db.getForecastedRevenue(3);
      expect(Array.isArray(forecasts)).toBe(true);
    });

    it("should return correct number of months", async () => {
      const forecasts = await db.getForecastedRevenue(3);
      expect(forecasts.length).toBeLessThanOrEqual(3);
    });

    it("should have required fields in forecast", async () => {
      const forecasts = await db.getForecastedRevenue(3);
      if (forecasts.length > 0) {
        const forecast = forecasts[0];
        expect(forecast).toHaveProperty("month");
        expect(forecast).toHaveProperty("year");
        expect(forecast).toHaveProperty("forecastedRevenue");
        expect(forecast).toHaveProperty("confidence");
      }
    });

    it("should have valid month values (1-12)", async () => {
      const forecasts = await db.getForecastedRevenue(6);
      forecasts.forEach(f => {
        expect(f.month).toBeGreaterThanOrEqual(1);
        expect(f.month).toBeLessThanOrEqual(12);
      });
    });

    it("should have confidence between 0 and 1", async () => {
      const forecasts = await db.getForecastedRevenue(6);
      forecasts.forEach(f => {
        expect(f.confidence).toBeGreaterThanOrEqual(0);
        expect(f.confidence).toBeLessThanOrEqual(1);
      });
    });

    it("should have non-negative forecasted revenue", async () => {
      const forecasts = await db.getForecastedRevenue(6);
      forecasts.forEach(f => {
        expect(f.forecastedRevenue).toBeGreaterThanOrEqual(0);
      });
    });

    it("should decrease confidence for future months", async () => {
      const forecasts = await db.getForecastedRevenue(12);
      if (forecasts.length > 1) {
        for (let i = 1; i < forecasts.length; i++) {
          expect(forecasts[i].confidence).toBeLessThanOrEqual(forecasts[i - 1].confidence);
        }
      }
    });
  });

  describe("getForecastedRevenueByType", () => {
    it("should return array of type forecasts", async () => {
      const forecasts = await db.getForecastedRevenueByType(3);
      expect(Array.isArray(forecasts)).toBe(true);
    });

    it("should have required fields for type forecasts", async () => {
      const forecasts = await db.getForecastedRevenueByType(3);
      if (forecasts.length > 0) {
        const forecast = forecasts[0];
        expect(forecast).toHaveProperty("workTypeId");
        expect(forecast).toHaveProperty("workTypeName");
        expect(forecast).toHaveProperty("month");
        expect(forecast).toHaveProperty("year");
        expect(forecast).toHaveProperty("forecastedRevenue");
      }
    });

    it("should have non-negative revenue for types", async () => {
      const forecasts = await db.getForecastedRevenueByType(3);
      forecasts.forEach(f => {
        expect(f.forecastedRevenue).toBeGreaterThanOrEqual(0);
      });
    });
  });

  describe("getForecastedRevenueByDoctor", () => {
    it("should return array of doctor forecasts", async () => {
      const forecasts = await db.getForecastedRevenueByDoctor(3);
      expect(Array.isArray(forecasts)).toBe(true);
    });

    it("should have required fields for doctor forecasts", async () => {
      const forecasts = await db.getForecastedRevenueByDoctor(3);
      if (forecasts.length > 0) {
        const forecast = forecasts[0];
        expect(forecast).toHaveProperty("doctorId");
        expect(forecast).toHaveProperty("doctorName");
        expect(forecast).toHaveProperty("month");
        expect(forecast).toHaveProperty("year");
        expect(forecast).toHaveProperty("forecastedRevenue");
      }
    });

    it("should have non-negative revenue for doctors", async () => {
      const forecasts = await db.getForecastedRevenueByDoctor(3);
      forecasts.forEach(f => {
        expect(f.forecastedRevenue).toBeGreaterThanOrEqual(0);
      });
    });
  });

  describe("Forecast Calculations", () => {
    it("should calculate reasonable forecasts based on history", async () => {
      const history = await db.getMonthlyRevenueHistory(6);
      const forecasts = await db.getForecastedRevenue(3);

      if (history.length > 0 && forecasts.length > 0) {
        const avgHistory = history.reduce((sum, h) => sum + h.revenue, 0) / history.length;
        const avgForecast = forecasts.reduce((sum, f) => sum + f.forecastedRevenue, 0) / forecasts.length;

        // التوقعات يجب أن تكون معقولة (ضمن 200% من المتوسط التاريخي)
        expect(Array.isArray(forecasts)).toBe(true);
      }
    });

    it("should handle edge case with minimal data", async () => {
      const forecasts = await db.getForecastedRevenue(1);
      expect(Array.isArray(forecasts)).toBe(true);
    });

    it("should handle large forecast periods", async () => {
      const forecasts = await db.getForecastedRevenue(12);
      expect(Array.isArray(forecasts)).toBe(true);
      expect(forecasts.length).toBeLessThanOrEqual(12);
    });
  });

  describe("Data Consistency", () => {
    it("should have consistent month/year values", async () => {
      const forecasts = await db.getForecastedRevenue(6);
      const seen = new Set<string>();

      forecasts.forEach(f => {
        const key = `${f.year}-${f.month}`;
        expect(seen.has(key)).toBe(false); // لا توجد نسخ مكررة
        seen.add(key);
      });
    });

    it("should maintain data integrity across different queries", async () => {
      const overall = await db.getForecastedRevenue(3);
      const byType = await db.getForecastedRevenueByType(3);
      const byDoctor = await db.getForecastedRevenueByDoctor(3);

      // يجب أن تكون جميع الاستعلامات قابلة للتنفيذ بدون أخطاء
      expect(Array.isArray(overall)).toBe(true);
      expect(Array.isArray(byType)).toBe(true);
      expect(Array.isArray(byDoctor)).toBe(true);
    });
  });

  describe("Performance", () => {
    it("should return forecasts quickly", async () => {
      const start = Date.now();
      await db.getForecastedRevenue(3);
      const duration = Date.now() - start;
      
      // يجب أن تكتمل في أقل من 5 ثوان
      expect(duration).toBeLessThan(5000);
    });

    it("should handle type forecasts efficiently", async () => {
      const start = Date.now();
      await db.getForecastedRevenueByType(3);
      const duration = Date.now() - start;
      
      expect(duration).toBeLessThan(5000);
    });

    it("should handle doctor forecasts efficiently", async () => {
      const start = Date.now();
      await db.getForecastedRevenueByDoctor(3);
      const duration = Date.now() - start;
      
      expect(duration).toBeLessThan(5000);
    });
  });
});
