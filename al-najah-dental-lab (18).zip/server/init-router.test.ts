import { describe, expect, it, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { roleSettings } from "../drizzle/role-settings.schema";
import { eq } from "drizzle-orm";

describe("Init Router", () => {
  let db: any;

  beforeAll(async () => {
    db = await getDb();
  });

  afterAll(async () => {
    // Cleanup
    await db.delete(roleSettings);
  });

  describe("Role Settings Table Structure", () => {
    it("should have roleSettings table", async () => {
      expect(db).toBeDefined();
    });

    it("should be able to insert role settings", async () => {
      // Clear existing data
      await db.delete(roleSettings);

      // Insert a role
      await db.insert(roleSettings).values({
        role: "admin",
        passwordHash: "test-hash",
        isActive: "true",
      });

      // Verify insertion
      const result = await db.select().from(roleSettings);
      expect(result.length).toBeGreaterThan(0);
      expect(result[0].role).toBe("admin");
    });

    it("should have correct field types", async () => {
      const result = await db.select().from(roleSettings);
      if (result.length > 0) {
        const row = result[0];
        expect(typeof row.role).toBe("string");
        expect(typeof row.passwordHash).toBe("string");
        expect(typeof row.isActive).toBe("string");
      }
    });

    it("should have timestamps", async () => {
      const result = await db.select().from(roleSettings);
      if (result.length > 0) {
        const row = result[0];
        expect(row.createdAt).toBeDefined();
        expect(row.lastModifiedAt).toBeDefined();
      }
    });
  });

  describe("Role Settings Uniqueness", () => {
    it("should enforce unique role constraint", async () => {
      await db.delete(roleSettings);

      // Insert first role
      await db.insert(roleSettings).values({
        role: "admin",
        passwordHash: "test-hash-1",
        isActive: "true",
      });

      // Try to insert duplicate
      let errorThrown = false;
      try {
        await db.insert(roleSettings).values({
          role: "admin",
          passwordHash: "test-hash-2",
          isActive: "true",
        });
      } catch (error: any) {
        errorThrown = true;
        // Check if error is thrown (could be ER_DUP_ENTRY or similar)
        expect(error).toBeDefined();
      }

      expect(errorThrown).toBe(true);
    });
  });

  describe("Role Settings Operations", () => {
    it("should delete role settings", async () => {
      await db.delete(roleSettings);

      // Insert a role
      await db.insert(roleSettings).values({
        role: "test-role",
        passwordHash: "test-hash",
        isActive: "true",
      });

      // Verify insertion
      let result = await db.select().from(roleSettings);
      expect(result.length).toBeGreaterThan(0);

      // Delete the role
      await db.delete(roleSettings).where(eq(roleSettings.role, "test-role"));

      // Verify deletion
      result = await db.select().from(roleSettings);
      const hasTestRole = result.some((r: any) => r.role === "test-role");
      expect(hasTestRole).toBe(false);
    });

    it("should select all role settings", async () => {
      await db.delete(roleSettings);

      // Insert multiple roles
      const roles = ["admin", "manager", "staff"];
      for (const role of roles) {
        await db.insert(roleSettings).values({
          role,
          passwordHash: `hash-${role}`,
          isActive: "true",
        });
      }

      // Select all
      const result = await db.select().from(roleSettings);
      expect(result.length).toBeGreaterThanOrEqual(3);
    });

    it("should count role settings", async () => {
      await db.delete(roleSettings);

      // Insert roles
      const roles = ["admin", "manager", "staff"];
      for (const role of roles) {
        await db.insert(roleSettings).values({
          role,
          passwordHash: `hash-${role}`,
          isActive: "true",
        });
      }

      // Count
      const result = await db.select().from(roleSettings);
      expect(result.length).toBe(3);
    });
  });

  describe("Default Role Settings", () => {
    it("should support admin role", async () => {
      await db.delete(roleSettings);

      await db.insert(roleSettings).values({
        role: "admin",
        passwordHash: "admin-hash",
        isActive: "true",
      });

      const result = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, "admin"));
      expect(result.length).toBe(1);
      expect(result[0].role).toBe("admin");
    });

    it("should support manager role", async () => {
      await db.delete(roleSettings);

      await db.insert(roleSettings).values({
        role: "manager",
        passwordHash: "manager-hash",
        isActive: "true",
      });

      const result = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, "manager"));
      expect(result.length).toBe(1);
      expect(result[0].role).toBe("manager");
    });

    it("should support staff role", async () => {
      await db.delete(roleSettings);

      await db.insert(roleSettings).values({
        role: "staff",
        passwordHash: "staff-hash",
        isActive: "true",
      });

      const result = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, "staff"));
      expect(result.length).toBe(1);
      expect(result[0].role).toBe("staff");
    });

    it("should support user role", async () => {
      await db.delete(roleSettings);

      await db.insert(roleSettings).values({
        role: "user",
        passwordHash: "user-hash",
        isActive: "true",
      });

      const result = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, "user"));
      expect(result.length).toBe(1);
      expect(result[0].role).toBe("user");
    });
  });
});
