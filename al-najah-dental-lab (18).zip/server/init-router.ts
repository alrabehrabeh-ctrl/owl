import { router, publicProcedure } from "./_core/trpc";
import { getDb } from "./db";
import { roleSettings } from "../drizzle/role-settings.schema";
import { TRPCError } from "@trpc/server";
import { getDefaultRolePasswordHash } from "./password-manager";

export const initRouter = router({
  /**
   * تهيئة جدول roleSettings بالبيانات الافتراضية
   */
  initializeRoleSettings: publicProcedure.mutation(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    try {
      // حذف البيانات القديمة
      await db.delete(roleSettings);

      // إدراج البيانات الافتراضية
      const roles = ["user", "admin", "manager", "staff"] as const;
      for (const role of roles) {
        const passwordHash = getDefaultRolePasswordHash(role);
        await db.insert(roleSettings).values({
          role,
          passwordHash,
          isActive: "true",
        });
      }

      return {
        success: true,
        message: "تم تهيئة جدول roleSettings بنجاح",
        roles: roles.length,
      };
    } catch (error) {
      console.error("Error initializing role settings:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "فشل في تهيئة جدول roleSettings",
      });
    }
  }),

  /**
   * التحقق من حالة جدول roleSettings مع التهيئة التلقائية
   */
  checkRoleSettingsStatus: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    try {
      const settings = await db.select().from(roleSettings);
      
      // إذا كان الجدول فارغاً، قم بالتهيئة التلقائية
      if (settings.length === 0) {
        const roles = ["user", "admin", "manager", "staff"] as const;
        for (const role of roles) {
          const passwordHash = getDefaultRolePasswordHash(role);
          await db.insert(roleSettings).values({
            role,
            passwordHash,
            isActive: "true",
          });
        }
        return {
          initialized: true,
          count: 4,
          roles: ["user", "admin", "manager", "staff"],
          autoInitialized: true,
        };
      }
      
      return {
        initialized: settings.length > 0,
        count: settings.length,
        roles: settings.map((s) => s.role),
        autoInitialized: false,
      };
    } catch (error) {
      console.error("Error checking role settings:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "فشل في التحقق من حالة roleSettings",
      });
    }
  }),
});
