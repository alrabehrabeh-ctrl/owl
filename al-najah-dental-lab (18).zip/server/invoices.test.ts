import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { db } from "./db";
import { getMonthlyInvoicesByDoctorAndDate } from "./db";

describe("Monthly Invoices - Tooth Numbers", () => {
  it("should retrieve tooth numbers from monthly invoices", async () => {
    // اختبار جلب الفواتير الشهرية مع أرقام الأسنان
    try {
      const invoices = await getMonthlyInvoicesByDoctorAndDate(1, "2025-09");
      
      // التحقق من أن البيانات موجودة
      if (invoices && invoices.length > 0) {
        const invoice = invoices[0];
        
        // التحقق من أن حقل toothNumbers موجود
        expect(invoice).toHaveProperty("toothNumbers");
        
        // التحقق من أن toothNumbers ليس فارغاً
        if (invoice.toothNumbers) {
          expect(typeof invoice.toothNumbers).toBe("string");
          console.log("✅ Tooth numbers found:", invoice.toothNumbers);
        }
      }
    } catch (error) {
      console.error("❌ Error retrieving invoices:", error);
      throw error;
    }
  });

  it("should display tooth numbers in invoice HTML", async () => {
    // اختبار أن أرقام الأسنان تظهر في HTML الفاتورة
    try {
      const invoices = await getMonthlyInvoicesByDoctorAndDate(1, "2025-09");
      
      if (invoices && invoices.length > 0) {
        const invoice = invoices[0];
        
        // التحقق من أن البيانات المطلوبة موجودة
        expect(invoice).toHaveProperty("items");
        
        // التحقق من أن كل عنصر يحتوي على toothNumbers
        if (Array.isArray(invoice.items)) {
          invoice.items.forEach((item: any) => {
            if (item.toothNumbers) {
              expect(typeof item.toothNumbers).toBe("string");
              console.log("✅ Item tooth numbers:", item.toothNumbers);
            }
          });
        }
      }
    } catch (error) {
      console.error("❌ Error in invoice HTML test:", error);
      throw error;
    }
  });

  it("should not have empty tooth numbers in invoice items", async () => {
    // اختبار أن أرقام الأسنان ليست فارغة
    try {
      const invoices = await getMonthlyInvoicesByDoctorAndDate(1, "2025-09");
      
      if (invoices && invoices.length > 0) {
        const invoice = invoices[0];
        
        if (Array.isArray(invoice.items)) {
          invoice.items.forEach((item: any) => {
            // إذا كان هناك toothNumbers، يجب أن لا تكون فارغة
            if (item.toothNumbers !== null && item.toothNumbers !== undefined) {
              expect(item.toothNumbers.trim()).not.toBe("");
              console.log("✅ Tooth numbers are not empty:", item.toothNumbers);
            }
          });
        }
      }
    } catch (error) {
      console.error("❌ Error in empty tooth numbers test:", error);
      throw error;
    }
  });
});
