/**
 * وظيفة مجدولة لتحديث أسعار الصرف يومياً
 * تعمل كل يوم في الساعة 12:00 صباحاً (UTC)
 */

import cron from "node-cron";
import { syncExchangeRates } from "../exchange-rate-sync";

/**
 * جدول التشغيل: "0 0 * * *" = كل يوم في الساعة 12:00 صباحاً
 * الصيغة: [ثانية] [دقيقة] [ساعة] [يوم الشهر] [الشهر] [يوم الأسبوع]
 */
const SYNC_SCHEDULE = process.env.EXCHANGE_RATE_SYNC_SCHEDULE || "0 0 * * *";

let syncJob: any = null;

/**
 * بدء وظيفة التحديث المجدولة
 */
export function startExchangeRateSyncJob(): void {
  if (syncJob) {
    console.log("Exchange rate sync job is already running");
    return;
  }

  try {
    syncJob = cron.schedule(SYNC_SCHEDULE, async () => {
      const timestamp = new Date().toISOString();
      console.log(`[${timestamp}] Running scheduled exchange rate sync...`);

      const success = await syncExchangeRates();

      if (success) {
        console.log(
          `[${new Date().toISOString()}] Exchange rate sync completed successfully`
        );
      } else {
        console.error(
          `[${new Date().toISOString()}] Exchange rate sync failed`
        );
      }
    });

    console.log(
      `Exchange rate sync job started with schedule: ${SYNC_SCHEDULE}`
    );
  } catch (error) {
    console.error("Failed to start exchange rate sync job:", error);
  }
}

/**
 * إيقاف وظيفة التحديث المجدولة
 */
export function stopExchangeRateSyncJob(): void {
  if (syncJob) {
    syncJob.stop();
    syncJob = null;
    console.log("Exchange rate sync job stopped");
  }
}

/**
 * تشغيل التحديث يدوياً (للاختبار أو الطلب الفوري)
 */
export async function triggerExchangeRateSyncManually(): Promise<boolean> {
  console.log("Manually triggering exchange rate sync...");
  return await syncExchangeRates();
}
