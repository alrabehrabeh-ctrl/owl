import { router, publicProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getDb } from "./db";
import { otpCodes, twoFactorSettings, otpAttempts } from "../drizzle/schema";
import { eq, and, lt } from "drizzle-orm";

/**
 * توليد رمز OTP عشوائي من 6 أرقام
 */
function generateOTPCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * حساب وقت انتهاء الصلاحية (5 دقائق من الآن)
 */
function getOTPExpireTime(): Date {
  const now = new Date();
  now.setMinutes(now.getMinutes() + 5);
  return now;
}

/**
 * التحقق من قفل الحساب بسبب محاولات فاشلة متكررة
 */
async function isAccountLocked(userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database connection failed" });

  const attempt = await db
    .select()
    .from(otpAttempts)
    .where(eq(otpAttempts.userId, userId))
    .limit(1);

  if (attempt.length === 0) return false;

  const { isLocked, lockedUntil } = attempt[0];
  if (!isLocked) return false;

  // التحقق من انتهاء وقت القفل
  if (lockedUntil && new Date() > lockedUntil) {
    // إزالة القفل
    await db
      .update(otpAttempts)
      .set({ isLocked: false, lockedUntil: null, attemptCount: 0 })
      .where(eq(otpAttempts.userId, userId));
    return false;
  }

  return true;
}

export const otpRouter = router({
  /**
   * توليد وإرسال رمز OTP
   */
  generateOTP: publicProcedure.mutation(async ({ ctx }: { ctx: any }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database connection failed" });

    const userId = ctx.user.id;

    // التحقق من قفل الحساب
    if (await isAccountLocked(userId)) {
      throw new TRPCError({
        code: "TOO_MANY_REQUESTS",
        message: "الحساب مقفول مؤقتاً بسبب محاولات متعددة. يرجى المحاولة لاحقاً.",
      });
    }

    // حذف الرموز القديمة المنتهية الصلاحية
    await db.delete(otpCodes).where(and(eq(otpCodes.userId, userId), lt(otpCodes.expiresAt, new Date())));

    // توليد رمز OTP جديد
    const code = generateOTPCode();
    const expiresAt = getOTPExpireTime();

    // حفظ الرمز في قاعدة البيانات
    await db.insert(otpCodes).values({
      userId,
      code,
      expiresAt,
      isUsed: false,
    });

    // في التطبيق الحقيقي، يتم إرسال الرمز عبر البريد الإلكتروني أو SMS
    // هنا نعيده للاختبار فقط
    return {
      success: true,
      message: "تم توليد رمز OTP بنجاح",
      code, // في الإنتاج، لا نعيد الرمز
      expiresIn: 5 * 60, // 5 دقائق بالثواني
    };
  }),

  /**
   * التحقق من رمز OTP
   */
  verifyOTP: publicProcedure
    .input(z.object({ code: z.string().length(6, "الرمز يجب أن يكون 6 أرقام") }))
    .mutation(async ({ ctx, input }: { ctx: any; input: any }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database connection failed" });

      const userId = ctx.user.id;

      // التحقق من قفل الحساب
      if (await isAccountLocked(userId)) {
        throw new TRPCError({
          code: "TOO_MANY_REQUESTS",
          message: "الحساب مقفول مؤقتاً. يرجى المحاولة لاحقاً.",
        });
      }

      // البحث عن الرمز الصحيح
      const otpRecord = await db
        .select()
        .from(otpCodes)
        .where(and(eq(otpCodes.userId, userId), eq(otpCodes.code, input.code), eq(otpCodes.isUsed, false)))
        .limit(1);

      if (otpRecord.length === 0) {
        // تسجيل محاولة فاشلة
        const attempt = await db
          .select()
          .from(otpAttempts)
          .where(eq(otpAttempts.userId, userId))
          .limit(1);

        let newAttemptCount = 1;
        if (attempt.length > 0) {
          newAttemptCount = (attempt[0].attemptCount || 0) + 1;
        }

        // قفل الحساب بعد 5 محاولات فاشلة
        const isLocked = newAttemptCount >= 5;
        const lockedUntil = isLocked ? new Date(Date.now() + 15 * 60 * 1000) : null; // 15 دقيقة

        if (attempt.length > 0) {
          await db
            .update(otpAttempts)
            .set({
              attemptCount: newAttemptCount,
              lastAttemptAt: new Date(),
              isLocked,
              lockedUntil,
            })
            .where(eq(otpAttempts.userId, userId));
        } else {
          await db.insert(otpAttempts).values({
            userId,
            attemptCount: newAttemptCount,
            lastAttemptAt: new Date(),
            isLocked,
            lockedUntil,
          });
        }

        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: isLocked
            ? "الحساب مقفول بسبب محاولات متعددة خاطئة"
            : `الرمز غير صحيح. محاولات متبقية: ${5 - newAttemptCount}`,
        });
      }

      // التحقق من انتهاء صلاحية الرمز
      if (new Date() > otpRecord[0].expiresAt) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "انتهت صلاحية الرمز" });
      }

      // تحديث الرمز كمستخدم
      await db.update(otpCodes).set({ isUsed: true }).where(eq(otpCodes.id, otpRecord[0].id));

      // إعادة تعيين محاولات الفشل
      await db
        .update(otpAttempts)
        .set({ attemptCount: 0, isLocked: false, lockedUntil: null })
        .where(eq(otpAttempts.userId, userId));

      // تحديث إعدادات 2FA
      const twoFactorSetting = await db
        .select()
        .from(twoFactorSettings)
        .where(eq(twoFactorSettings.userId, userId))
        .limit(1);

      if (twoFactorSetting.length > 0) {
        await db
          .update(twoFactorSettings)
          .set({ lastUsedAt: new Date() })
          .where(eq(twoFactorSettings.userId, userId));
      }

      return {
        success: true,
        message: "تم التحقق من الرمز بنجاح",
      };
    }),

  /**
   * تفعيل 2FA للمستخدم
   */
  enableTwoFactor: publicProcedure.mutation(async ({ ctx }: { ctx: any }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database connection failed" });

    const userId = ctx.user.id;

    // التحقق من وجود إعدادات 2FA
    const existing = await db
      .select()
      .from(twoFactorSettings)
      .where(eq(twoFactorSettings.userId, userId))
      .limit(1);

    if (existing.length > 0) {
      await db
        .update(twoFactorSettings)
        .set({ isEnabled: true })
        .where(eq(twoFactorSettings.userId, userId));
    } else {
      await db.insert(twoFactorSettings).values({
        userId,
        isEnabled: true,
      });
    }

    return {
      success: true,
      message: "تم تفعيل المصادقة الثنائية بنجاح",
    };
  }),

  /**
   * تعطيل 2FA للمستخدم
   */
  disableTwoFactor: publicProcedure.mutation(async ({ ctx }: { ctx: any }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database connection failed" });

    const userId = ctx.user.id;

    await db
      .update(twoFactorSettings)
      .set({ isEnabled: false })
      .where(eq(twoFactorSettings.userId, userId));

    return {
      success: true,
      message: "تم تعطيل المصادقة الثنائية",
    };
  }),

  /**
   * الحصول على حالة 2FA
   */
  getTwoFactorStatus: publicProcedure.query(async ({ ctx }: { ctx: any }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database connection failed" });

    const userId = ctx.user.id;

    const setting = await db
      .select()
      .from(twoFactorSettings)
      .where(eq(twoFactorSettings.userId, userId))
      .limit(1);

    if (setting.length === 0) {
      return {
        isEnabled: false,
        lastUsedAt: null,
      };
    }

    return {
      isEnabled: setting[0].isEnabled,
      lastUsedAt: setting[0].lastUsedAt,
    };
  }),
});
