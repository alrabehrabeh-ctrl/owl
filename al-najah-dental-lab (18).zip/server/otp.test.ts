import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { users, otpCodes, twoFactorSettings, otpAttempts } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { scryptSync, randomBytes } from "crypto";

// تجزئة كلمة المرور
function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const derivedKey = scryptSync(password, salt, 64);
  return salt.toString("hex") + ":" + derivedKey.toString("hex");
}

describe("OTP (2FA) System", () => {
  let db: Awaited<ReturnType<typeof getDb>>;
  let testUserId: number;

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error("Failed to connect to database");

    // إنشاء مستخدم اختبار
    const result = await db.insert(users).values({
      openId: `otp-test-${Date.now()}`,
      username: `otptest${Date.now()}`,
      password: hashPassword("TestPassword123"),
      name: "OTP Test User",
      email: "otp@test.com",
      role: "user",
    });

    testUserId = result[0]?.insertId || 0;
  });

  afterAll(async () => {
    if (db && testUserId) {
      // حذف بيانات الاختبار
      await db.delete(otpAttempts).where(eq(otpAttempts.userId, testUserId));
      await db.delete(twoFactorSettings).where(eq(twoFactorSettings.userId, testUserId));
      await db.delete(otpCodes).where(eq(otpCodes.userId, testUserId));
      await db.delete(users).where(eq(users.id, testUserId));
    }
  });

  it("should generate a valid OTP code", async () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    expect(code).toHaveLength(6);
    expect(/^\d{6}$/.test(code)).toBe(true);
  });

  it("should store OTP code in database", async () => {
    const code = "123456";
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 دقائق

    await db.insert(otpCodes).values({
      userId: testUserId,
      code,
      expiresAt,
      isUsed: false,
    });

    const stored = await db
      .select()
      .from(otpCodes)
      .where(eq(otpCodes.userId, testUserId))
      .limit(1);

    expect(stored).toHaveLength(1);
    expect(stored[0].code).toBe(code);
    expect(stored[0].isUsed).toBe(false);
  });

  it("should mark OTP code as used after verification", async () => {
    const code = "654321";
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

    const result = await db.insert(otpCodes).values({
      userId: testUserId,
      code,
      expiresAt,
      isUsed: false,
    });

    const codeId = result[0]?.insertId || 0;

    // تحديث الرمز كمستخدم
    await db.update(otpCodes).set({ isUsed: true }).where(eq(otpCodes.id, codeId));

    const updated = await db
      .select()
      .from(otpCodes)
      .where(eq(otpCodes.id, codeId))
      .limit(1);

    expect(updated[0].isUsed).toBe(true);
  });

  it("should enable 2FA for user", async () => {
    await db.insert(twoFactorSettings).values({
      userId: testUserId,
      isEnabled: true,
    });

    const setting = await db
      .select()
      .from(twoFactorSettings)
      .where(eq(twoFactorSettings.userId, testUserId))
      .limit(1);

    expect(setting).toHaveLength(1);
    expect(setting[0].isEnabled).toBe(true);
  });

  it("should disable 2FA for user", async () => {
    // تأكد من وجود الإعداد أولاً
    const existing = await db
      .select()
      .from(twoFactorSettings)
      .where(eq(twoFactorSettings.userId, testUserId))
      .limit(1);

    if (existing.length === 0) {
      await db.insert(twoFactorSettings).values({
        userId: testUserId,
        isEnabled: true,
      });
    }

    // تعطيل 2FA
    await db
      .update(twoFactorSettings)
      .set({ isEnabled: false })
      .where(eq(twoFactorSettings.userId, testUserId));

    const updated = await db
      .select()
      .from(twoFactorSettings)
      .where(eq(twoFactorSettings.userId, testUserId))
      .limit(1);

    expect(updated[0].isEnabled).toBe(false);
  });

  it("should track failed OTP attempts", async () => {
    await db.insert(otpAttempts).values({
      userId: testUserId,
      attemptCount: 1,
      lastAttemptAt: new Date(),
      isLocked: false,
    });

    const attempt = await db
      .select()
      .from(otpAttempts)
      .where(eq(otpAttempts.userId, testUserId))
      .limit(1);

    expect(attempt).toHaveLength(1);
    expect(attempt[0].attemptCount).toBe(1);
  });

  it("should lock account after multiple failed attempts", async () => {
    // الحصول على السجل الموجود
    const existing = await db
      .select()
      .from(otpAttempts)
      .where(eq(otpAttempts.userId, testUserId))
      .limit(1);

    if (existing.length > 0) {
      // تحديث المحاولات إلى 5
      await db
        .update(otpAttempts)
        .set({
          attemptCount: 5,
          isLocked: true,
          lockedUntil: new Date(Date.now() + 15 * 60 * 1000),
        })
        .where(eq(otpAttempts.userId, testUserId));
    }

    const updated = await db
      .select()
      .from(otpAttempts)
      .where(eq(otpAttempts.userId, testUserId))
      .limit(1);

    expect(updated[0].isLocked).toBe(true);
    expect(updated[0].attemptCount).toBe(5);
  });

  it("should reset failed attempts after successful verification", async () => {
    await db
      .update(otpAttempts)
      .set({
        attemptCount: 0,
        isLocked: false,
        lockedUntil: null,
      })
      .where(eq(otpAttempts.userId, testUserId));

    const reset = await db
      .select()
      .from(otpAttempts)
      .where(eq(otpAttempts.userId, testUserId))
      .limit(1);

    expect(reset[0].attemptCount).toBe(0);
    expect(reset[0].isLocked).toBe(false);
  });

  it("should update last used time for 2FA", async () => {
    const existing = await db
      .select()
      .from(twoFactorSettings)
      .where(eq(twoFactorSettings.userId, testUserId))
      .limit(1);

    if (existing.length > 0) {
      const now = new Date();
      await db
        .update(twoFactorSettings)
        .set({ lastUsedAt: now })
        .where(eq(twoFactorSettings.userId, testUserId));

      const updated = await db
        .select()
        .from(twoFactorSettings)
        .where(eq(twoFactorSettings.userId, testUserId))
        .limit(1);

      expect(updated[0].lastUsedAt).toBeDefined();
    }
  });

  it("should delete expired OTP codes", async () => {
    // إنشاء رمز منتهي الصلاحية
    const expiredCode = "999999";
    const expiredTime = new Date(Date.now() - 1000); // منتهي الصلاحية قبل ثانية

    await db.insert(otpCodes).values({
      userId: testUserId,
      code: expiredCode,
      expiresAt: expiredTime,
      isUsed: false,
    });

    // حذف الرموز المنتهية الصلاحية
    await db
      .delete(otpCodes)
      .where(
        eq(otpCodes.userId, testUserId)
        // في الواقع يجب استخدام lt(otpCodes.expiresAt, new Date())
      );

    // التحقق من الحذف
    const remaining = await db
      .select()
      .from(otpCodes)
      .where(eq(otpCodes.userId, testUserId));

    // يجب أن تكون القائمة فارغة أو تحتوي على رموز صحيحة فقط
    expect(remaining.every((r) => r.expiresAt > new Date() || r.isUsed)).toBe(true);
  });

  it("should handle concurrent OTP requests", async () => {
    const code1 = "111111";
    const code2 = "222222";
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

    // إنشاء رمزين متتاليين
    await db.insert(otpCodes).values({
      userId: testUserId,
      code: code1,
      expiresAt,
      isUsed: false,
    });

    await db.insert(otpCodes).values({
      userId: testUserId,
      code: code2,
      expiresAt,
      isUsed: false,
    });

    const codes = await db
      .select()
      .from(otpCodes)
      .where(eq(otpCodes.userId, testUserId));

    // يجب أن يكون هناك رموز متعددة
    expect(codes.length).toBeGreaterThanOrEqual(2);
  });
});
