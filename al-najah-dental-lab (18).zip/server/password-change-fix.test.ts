import { describe, it, expect } from "vitest";
import { hashPassword, verifyPassword } from "./password-manager";

describe("Password Change Fix Tests", () => {
  describe("Password Update Verification", () => {
    it("should verify that password hash changes after update", () => {
      const oldPassword = "oldPassword123";
      const newPassword = "newPassword456";

      const oldHash = hashPassword(oldPassword);
      const newHash = hashPassword(newPassword);

      // التحقق من أن الـ hashes مختلفة
      expect(oldHash).not.toBe(newHash);

      // التحقق من أن كل hash يتطابق مع كلمة المرور الخاصة به
      expect(verifyPassword(oldPassword, oldHash)).toBe(true);
      expect(verifyPassword(newPassword, newHash)).toBe(true);

      // التحقق من أن كلمة المرور القديمة لا تتطابق مع الـ hash الجديد
      expect(verifyPassword(oldPassword, newHash)).toBe(false);
      expect(verifyPassword(newPassword, oldHash)).toBe(false);
    });

    it("should handle password change for all roles", () => {
      const roles = ["admin", "manager", "staff", "user"];
      const passwords = {
        admin: "newAdminPass",
        manager: "newManagerPass",
        staff: "newStaffPass",
        user: "newUserPass",
      };

      for (const role of roles) {
        const newPassword = passwords[role as keyof typeof passwords];
        const hash = hashPassword(newPassword);

        expect(verifyPassword(newPassword, hash)).toBe(true);
        expect(hash.length).toBeGreaterThan(0);
      }
    });

    it("should ensure password change is not reversible", () => {
      const password1 = "password1";
      const password2 = "password2";

      const hash1 = hashPassword(password1);
      const hash2 = hashPassword(password2);

      // لا يمكن استخراج كلمة المرور من الـ hash
      expect(hash1).not.toContain(password1);
      expect(hash2).not.toContain(password2);
    });

    it("should handle special characters in passwords", () => {
      const specialPasswords = [
        "P@ssw0rd!",
        "مرحبا123",
        "!@#$%^&*()",
        "password with spaces",
        "123456",
      ];

      for (const password of specialPasswords) {
        const hash = hashPassword(password);
        expect(verifyPassword(password, hash)).toBe(true);
      }
    });

    it("should ensure consistent hashing", () => {
      const password = "testPassword";
      const hash1 = hashPassword(password);
      const hash2 = hashPassword(password);
      const hash3 = hashPassword(password);

      // جميع الـ hashes يجب أن تكون متطابقة
      expect(hash1).toBe(hash2);
      expect(hash2).toBe(hash3);
    });

    it("should handle empty password edge case", () => {
      const emptyPassword = "";
      const hash = hashPassword(emptyPassword);

      // حتى كلمة المرور الفارغة يجب أن تُشفر
      expect(hash).toBeDefined();
      expect(hash.length).toBeGreaterThan(0);
      expect(verifyPassword(emptyPassword, hash)).toBe(true);
    });

    it("should verify password change sequence", () => {
      // محاكاة تسلسل تغيير كلمات المرور
      const passwords = ["initial", "changed1", "changed2", "changed3"];
      const hashes = passwords.map((p) => hashPassword(p));

      // التحقق من أن كل hash فريد
      const uniqueHashes = new Set(hashes);
      expect(uniqueHashes.size).toBe(passwords.length);

      // التحقق من أن كل كلمة مرور تتطابق مع hash الخاص بها
      for (let i = 0; i < passwords.length; i++) {
        expect(verifyPassword(passwords[i], hashes[i])).toBe(true);
      }
    });

    it("should handle case sensitivity in passwords", () => {
      const password1 = "Password";
      const password2 = "password";

      const hash1 = hashPassword(password1);
      const hash2 = hashPassword(password2);

      // يجب أن تكون الـ hashes مختلفة
      expect(hash1).not.toBe(hash2);

      // التحقق من الحساسية
      expect(verifyPassword(password1, hash1)).toBe(true);
      expect(verifyPassword(password2, hash1)).toBe(false);
      expect(verifyPassword(password1, hash2)).toBe(false);
      expect(verifyPassword(password2, hash2)).toBe(true);
    });

    it("should ensure password change is atomic", () => {
      const oldPassword = "oldPassword";
      const newPassword = "newPassword";

      const oldHash = hashPassword(oldPassword);
      const newHash = hashPassword(newPassword);

      // بعد التغيير، يجب أن تكون كلمة المرور القديمة غير صالحة
      expect(verifyPassword(oldPassword, newHash)).toBe(false);

      // وكلمة المرور الجديدة يجب أن تكون صالحة
      expect(verifyPassword(newPassword, newHash)).toBe(true);
    });
  });

  describe("Password Change Logs", () => {
    it("should track password changes with different hashes", () => {
      const changes = [
        { old: "pass1", new: "pass2" },
        { old: "pass2", new: "pass3" },
        { old: "pass3", new: "pass4" },
      ];

      const logs = changes.map((change) => ({
        oldHash: hashPassword(change.old),
        newHash: hashPassword(change.new),
      }));

      // التحقق من أن كل تغيير مسجل بشكل صحيح
      for (let i = 0; i < logs.length; i++) {
        const log = logs[i];
        const change = changes[i];

        expect(verifyPassword(change.old, log.oldHash)).toBe(true);
        expect(verifyPassword(change.new, log.newHash)).toBe(true);
        expect(log.oldHash).not.toBe(log.newHash);
      }
    });

    it("should maintain log integrity", () => {
      const passwords = ["initial", "changed1", "changed2"];
      const logs = [];

      for (let i = 0; i < passwords.length - 1; i++) {
        logs.push({
          oldPassword: passwords[i],
          newPassword: passwords[i + 1],
          oldHash: hashPassword(passwords[i]),
          newHash: hashPassword(passwords[i + 1]),
        });
      }

      // التحقق من أن السجلات متسلسلة بشكل صحيح
      for (let i = 0; i < logs.length - 1; i++) {
        const currentLog = logs[i];
        const nextLog = logs[i + 1];

        // الـ hash الجديد للسجل الحالي يجب أن يكون الـ hash القديم للسجل التالي
        expect(currentLog.newHash).toBe(nextLog.oldHash);
      }
    });
  });
});
