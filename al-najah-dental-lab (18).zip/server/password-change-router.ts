import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { roleSettings, passwordChangeLogs } from "../drizzle/role-settings.schema";
import { eq, desc } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { verifyPassword, hashPassword, getDefaultRolePasswordHash } from "./password-manager";

export const passwordChangeRouter = router({
  /**
   * تعديل كلمة مرور الدور
   */
  changeRolePassword: publicProcedure
    .input(
      z.object({
        role: z.enum(["user", "admin", "manager", "staff"]),
        newPassword: z.string().min(1, "كلمة المرور لا يمكن أن تكون فارغة"),
        reason: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // الحصول على إعدادات الدور الحالية
      const settings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, input.role))
        .limit(1);

      if (settings.length === 0) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "إعدادات الدور غير موجودة",
        });
      }

      const oldPasswordHash = settings[0].passwordHash;
      const newPasswordHash = hashPassword(input.newPassword);

      // التحقق من عدم استخدام نفس كلمة المرور
      if (oldPasswordHash === newPasswordHash) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "كلمة المرور الجديدة يجب أن تكون مختلفة عن الحالية",
        });
      }

      // تحديث كلمة المرور
      await db
        .update(roleSettings)
        .set({ passwordHash: newPasswordHash })
        .where(eq(roleSettings.role, input.role));

      // تسجيل التغيير
      await db.insert(passwordChangeLogs).values({
        role: input.role,
        changedBy: ctx.user.id,
        oldPasswordHash,
        newPasswordHash,
        reason: input.reason,
      });

      return { success: true };
    }),

  /**
   * إعادة تعيين كلمة مرور الدور إلى الافتراضية
   */
  resetRolePasswordToDefault: publicProcedure
    .input(z.object({ role: z.enum(["user", "admin", "manager", "staff"]) }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // الحصول على إعدادات الدور الحالية
      const settings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, input.role))
        .limit(1);

      if (settings.length === 0) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "إعدادات الدور غير موجودة",
        });
      }

      const oldPasswordHash = settings[0].passwordHash;
      const newPasswordHash = getDefaultRolePasswordHash(input.role);

      // التحقق من عدم استخدام نفس كلمة المرور
      if (oldPasswordHash === newPasswordHash) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "كلمة المرور الافتراضية هي نفس الحالية",
        });
      }

      // تحديث كلمة المرور
      await db
        .update(roleSettings)
        .set({ passwordHash: newPasswordHash })
        .where(eq(roleSettings.role, input.role));

      // تسجيل التغيير
      await db.insert(passwordChangeLogs).values({
        role: input.role,
        changedBy: ctx.user.id,
        oldPasswordHash,
        newPasswordHash,
        reason: "إعادة تعيين إلى الافتراضية",
      });

      return { success: true };
    }),

  /**
   * الحصول على سجل تغييرات كلمات المرور
   */
  getPasswordChangeLogs: publicProcedure
    .input(
      z.object({
        role: z.enum(["user", "admin", "manager", "staff"]).optional(),
        limit: z.number().default(50),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      let query: any = db.select().from(passwordChangeLogs);

      if (input.role) {
        query = query.where(eq(passwordChangeLogs.role, input.role));
      }

      const logs = await query.orderBy(desc(passwordChangeLogs.createdAt)).limit(input.limit);

      return logs;
    }),
});
