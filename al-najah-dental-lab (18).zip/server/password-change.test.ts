import { describe, expect, it } from "vitest";
import {
  hashPassword,
  verifyPassword,
  getDefaultRolePasswordHash,
} from "./password-manager";

describe("Password Change System", () => {
  describe("Password Hashing and Verification", () => {
    it("should hash password correctly", () => {
      const password = "newPassword123";
      const hash = hashPassword(password);
      expect(hash).toBeDefined();
      expect(hash.length).toBeGreaterThan(0);
    });

    it("should verify correct password", () => {
      const password = "testPassword";
      const hash = hashPassword(password);
      expect(verifyPassword(password, hash)).toBe(true);
    });

    it("should reject incorrect password", () => {
      const password = "testPassword";
      const hash = hashPassword(password);
      expect(verifyPassword("wrongPassword", hash)).toBe(false);
    });

    it("should produce consistent hashes", () => {
      const password = "test";
      const hash1 = hashPassword(password);
      const hash2 = hashPassword(password);
      expect(hash1).toBe(hash2);
    });
  });

  describe("Default Role Passwords", () => {
    it("should get default hash for admin role", () => {
      const hash = getDefaultRolePasswordHash("admin");
      expect(verifyPassword("admin", hash)).toBe(true);
    });

    it("should get default hash for manager role", () => {
      const hash = getDefaultRolePasswordHash("manager");
      expect(verifyPassword("1985", hash)).toBe(true);
    });

    it("should get default hash for staff role", () => {
      const hash = getDefaultRolePasswordHash("staff");
      expect(verifyPassword("0000", hash)).toBe(true);
    });

    it("should get default hash for user role", () => {
      const hash = getDefaultRolePasswordHash("user");
      expect(verifyPassword("0000", hash)).toBe(true);
    });

    it("should throw error for invalid role", () => {
      expect(() => getDefaultRolePasswordHash("invalid" as any)).toThrow();
    });
  });

  describe("Password Change Validation", () => {
    it("should reject empty password", () => {
      expect(() => {
        const hash = hashPassword("");
        if (!hash) throw new Error("Empty password not allowed");
      }).not.toThrow();
    });

    it("should allow any non-empty password", () => {
      const passwords = ["a", "123", "password with spaces", "!@#$%^&*()"];
      for (const password of passwords) {
        const hash = hashPassword(password);
        expect(verifyPassword(password, hash)).toBe(true);
      }
    });

    it("should produce different hashes for different passwords", () => {
      const hash1 = hashPassword("password1");
      const hash2 = hashPassword("password2");
      expect(hash1).not.toBe(hash2);
    });
  });

  describe("Security Features", () => {
    it("should not store plain text passwords", () => {
      const password = "mySecretPassword";
      const hash = hashPassword(password);
      expect(hash).not.toBe(password);
    });

    it("should produce long hash values", () => {
      const hash = hashPassword("test");
      expect(hash.length).toBeGreaterThan(20);
    });

    it("should be case sensitive", () => {
      const password = "MyPassword";
      const hash = hashPassword(password);
      expect(verifyPassword("mypassword", hash)).toBe(false);
      expect(verifyPassword("MyPassword", hash)).toBe(true);
    });

    it("should handle special characters", () => {
      const password = "P@ssw0rd!#$%";
      const hash = hashPassword(password);
      expect(verifyPassword(password, hash)).toBe(true);
      expect(verifyPassword("P@ssw0rd!#$", hash)).toBe(false);
    });

    it("should handle unicode characters", () => {
      const password = "كلمة المرور";
      const hash = hashPassword(password);
      expect(verifyPassword(password, hash)).toBe(true);
      expect(verifyPassword("كلمة المرور ", hash)).toBe(false);
    });
  });

  describe("Password Reset", () => {
    it("should reset to correct default password for admin", () => {
      const defaultHash = getDefaultRolePasswordHash("admin");
      expect(verifyPassword("admin", defaultHash)).toBe(true);
    });

    it("should reset to correct default password for manager", () => {
      const defaultHash = getDefaultRolePasswordHash("manager");
      expect(verifyPassword("1985", defaultHash)).toBe(true);
    });

    it("should reset to correct default password for staff", () => {
      const defaultHash = getDefaultRolePasswordHash("staff");
      expect(verifyPassword("0000", defaultHash)).toBe(true);
    });

    it("should reset to correct default password for user", () => {
      const defaultHash = getDefaultRolePasswordHash("user");
      expect(verifyPassword("0000", defaultHash)).toBe(true);
    });
  });

  describe("Password Change Scenarios", () => {
    it("should handle changing from default to custom password", () => {
      const defaultHash = getDefaultRolePasswordHash("admin");
      const customPassword = "newCustomPassword";
      const customHash = hashPassword(customPassword);

      expect(verifyPassword("admin", defaultHash)).toBe(true);
      expect(verifyPassword(customPassword, customHash)).toBe(true);
      expect(defaultHash).not.toBe(customHash);
    });

    it("should handle changing from custom to another custom password", () => {
      const password1 = "firstPassword";
      const password2 = "secondPassword";
      const hash1 = hashPassword(password1);
      const hash2 = hashPassword(password2);

      expect(verifyPassword(password1, hash1)).toBe(true);
      expect(verifyPassword(password2, hash2)).toBe(true);
      expect(hash1).not.toBe(hash2);
    });

    it("should prevent using same password twice", () => {
      const password = "samePassword";
      const hash1 = hashPassword(password);
      const hash2 = hashPassword(password);

      expect(hash1).toBe(hash2);
    });
  });
});
