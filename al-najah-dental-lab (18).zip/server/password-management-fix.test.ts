import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { roleSettings, passwordChangeLogs } from "../drizzle/role-settings.schema";
import { eq } from "drizzle-orm";

describe("Password Management Page Fix", () => {
  let db: any;

  beforeAll(async () => {
    db = await getDb();
  });

  it("should initialize role settings if empty", async () => {
    // حذف جميع البيانات
    await db.delete(roleSettings);

    // التحقق من أن الجدول فارغ
    const emptySettings = await db.select().from(roleSettings);
    expect(emptySettings.length).toBe(0);

    // إدراج البيانات الافتراضية
    const roles = ["user", "admin", "manager", "staff"] as const;
    for (const role of roles) {
      await db.insert(roleSettings).values({
        role,
        passwordHash: "default_hash_" + role,
        isActive: "true",
      });
    }

    // التحقق من أن البيانات تم إدراجها
    const settings = await db.select().from(roleSettings);
    expect(settings.length).toBe(4);
    expect(settings.map((s: any) => s.role).sort()).toEqual(["admin", "manager", "staff", "user"]);
  });

  it("should have role settings for all roles", async () => {
    const settings = await db.select().from(roleSettings);
    const roles = settings.map((s: any) => s.role).sort();
    expect(roles).toEqual(["admin", "manager", "staff", "user"]);
  });

  it("should have password hash for each role", async () => {
    const settings = await db.select().from(roleSettings);
    for (const setting of settings) {
      expect(setting.passwordHash).toBeDefined();
      expect(setting.passwordHash.length).toBeGreaterThan(0);
    }
  });

  it("should have isActive flag for each role", async () => {
    const settings = await db.select().from(roleSettings);
    for (const setting of settings) {
      expect(setting.isActive).toBe("true");
    }
  });

  it("should be able to query role settings by role", async () => {
    const userSettings = await db
      .select()
      .from(roleSettings)
      .where(eq(roleSettings.role, "user"))
      .limit(1);

    expect(userSettings.length).toBe(1);
    expect(userSettings[0].role).toBe("user");
  });

  it("should handle password change logs", async () => {
    // حذف السجلات القديمة
    await db.delete(passwordChangeLogs);

    // إدراج سجل جديد
    await db.insert(passwordChangeLogs).values({
      role: "user",
      changedBy: 1,
      oldPasswordHash: "old_hash",
      newPasswordHash: "new_hash",
      reason: "Test password change",
    });

    // التحقق من أن السجل تم إدراجه
    const logs = await db.select().from(passwordChangeLogs);
    expect(logs.length).toBeGreaterThan(0);
  });

  it("should retrieve password change logs by role", async () => {
    const userLogs = await db
      .select()
      .from(passwordChangeLogs)
      .where(eq(passwordChangeLogs.role, "user"));

    expect(userLogs.length).toBeGreaterThan(0);
    for (const log of userLogs) {
      expect(log.role).toBe("user");
    }
  });

  it("should have all required fields in role settings", async () => {
    const settings = await db.select().from(roleSettings).limit(1);
    expect(settings.length).toBe(1);

    const setting = settings[0];
    expect(setting).toHaveProperty("id");
    expect(setting).toHaveProperty("role");
    expect(setting).toHaveProperty("passwordHash");
    expect(setting).toHaveProperty("isActive");
    expect(setting).toHaveProperty("createdAt");
  });

  it("should have all required fields in password change logs", async () => {
    const logs = await db.select().from(passwordChangeLogs).limit(1);
    if (logs.length > 0) {
      const log = logs[0];
      expect(log).toHaveProperty("id");
      expect(log).toHaveProperty("role");
      expect(log).toHaveProperty("changedBy");
      expect(log).toHaveProperty("oldPasswordHash");
      expect(log).toHaveProperty("newPasswordHash");
      expect(log).toHaveProperty("createdAt");
    }
  });

  it("should prevent duplicate roles in role settings", async () => {
    const settings = await db.select().from(roleSettings);
    const roles = settings.map((s: any) => s.role);
    const uniqueRoles = new Set(roles);
    expect(roles.length).toBe(uniqueRoles.size);
  });

  it("should auto-initialize on first access", async () => {
    // هذا الاختبار يتحقق من أن الجدول يحتوي على البيانات الافتراضية
    const settings = await db.select().from(roleSettings);
    expect(settings.length).toBeGreaterThan(0);
  });
});
