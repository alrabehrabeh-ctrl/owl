import crypto from "crypto";

/**
 * كلمات المرور الافتراضية لكل دور
 * تم تعيين كلمات مرور قوية وعشوائية لكل دور لضمان الأمان
 * يجب تغيير هذه الكلمات فوراً بعد التثبيت الأول
 */
export const DEFAULT_ROLE_PASSWORDS: Record<string, string> = {
  admin: "SecureAdmin@2024#Lab",
  manager: "ManagerPass$2024#Secure",
  staff: "StaffAccess@2024#Lab",
  user: "UserPass$2024#Secure",
};

/**
 * تشفير كلمة المرور باستخدام SHA-256
 */
export function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex");
}

/**
 * التحقق من كلمة المرور
 */
export function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

/**
 * الحصول على hash كلمة المرور الافتراضية للدور
 */
export function getDefaultRolePasswordHash(role: string): string {
  const password = DEFAULT_ROLE_PASSWORDS[role];
  if (!password) {
    throw new Error(`No default password defined for role: ${role}`);
  }
  return hashPassword(password);
}

/**
 * التحقق من كلمة مرور الدور
 */
export function verifyRolePassword(role: string, password: string, storedHash: string): boolean {
  return verifyPassword(password, storedHash);
}

/**
 * إعادة تعيين كلمة مرور الدور إلى الافتراضية
 */
export function resetRolePasswordToDefault(role: string): string {
  return getDefaultRolePasswordHash(role);
}

/**
 * تغيير كلمة مرور الدور
 */
export function changeRolePassword(newPassword: string): string {
  if (!newPassword || newPassword.length < 1) {
    throw new Error("Password must not be empty");
  }
  return hashPassword(newPassword);
}
