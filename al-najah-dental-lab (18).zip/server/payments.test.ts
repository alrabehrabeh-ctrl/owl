import { describe, it, expect, beforeEach, vi } from "vitest";
import * as db from "./db";

// Mock the database functions
vi.mock("./db", async () => {
  const actual = await vi.importActual<typeof db>("./db");
  return {
    ...actual,
  };
});

describe("Payment and Invoice Updates", () => {
  describe("createPayment", () => {
    it("should update invoice with correct paid and remaining amounts", async () => {
      // Test data
      const invoiceId = 1;
      const doctorId = 1;
      const paymentAmount = "100.00";
      const invoiceTotal = "500.00";

      // Mock invoice data
      const mockInvoice = {
        id: invoiceId,
        doctorId,
        total: invoiceTotal,
        paidAmount: "0.00",
        remainingAmount: invoiceTotal,
        status: "sent",
      };

      // Mock payment data
      const paymentData = {
        invoiceId,
        doctorId,
        amount: paymentAmount,
        paymentMethod: "cash" as const,
        paymentDate: new Date(),
      };

      // Calculate expected values
      const totalPaid = parseFloat(paymentAmount);
      const expectedRemaining = parseFloat(invoiceTotal) - totalPaid;

      // Verify calculations
      expect(totalPaid).toBe(100);
      expect(expectedRemaining).toBe(400);
    });

    it("should mark invoice as partial when partial payment is made", async () => {
      const invoiceTotal = "1000.00";
      const paymentAmount = "300.00";

      const totalPaid = parseFloat(paymentAmount);
      const invoiceTotalNum = parseFloat(invoiceTotal);

      let status = "sent";
      if (totalPaid >= invoiceTotalNum) {
        status = "paid";
      } else if (totalPaid > 0) {
        status = "partial";
      }

      expect(status).toBe("partial");
    });

    it("should mark invoice as paid when full payment is made", async () => {
      const invoiceTotal = "1000.00";
      const paymentAmount = "1000.00";

      const totalPaid = parseFloat(paymentAmount);
      const invoiceTotalNum = parseFloat(invoiceTotal);

      let status = "sent";
      if (totalPaid >= invoiceTotalNum) {
        status = "paid";
      } else if (totalPaid > 0) {
        status = "partial";
      }

      expect(status).toBe("paid");
    });

    it("should keep status as sent when no payment is made", async () => {
      const paymentAmount = "0.00";

      const totalPaid = parseFloat(paymentAmount);

      let status = "sent";
      if (totalPaid > 0) {
        status = "partial";
      }

      expect(status).toBe("sent");
    });
  });

  describe("deletePayment", () => {
    it("should recalculate invoice amounts when payment is deleted", async () => {
      // Initial state: invoice with one payment
      const invoiceTotal = "1000.00";
      const payment1Amount = "300.00";
      const payment2Amount = "200.00";

      // After deleting payment1, only payment2 remains
      const remainingPayment = parseFloat(payment2Amount);
      const expectedRemaining = parseFloat(invoiceTotal) - remainingPayment;

      expect(remainingPayment).toBe(200);
      expect(expectedRemaining).toBe(800);
    });

    it("should reset invoice status when all payments are deleted", async () => {
      const invoiceTotal = "1000.00";
      const totalPaid = 0; // All payments deleted

      let status = "sent";
      if (totalPaid >= parseFloat(invoiceTotal)) {
        status = "paid";
      } else if (totalPaid > 0) {
        status = "partial";
      }

      expect(status).toBe("sent");
    });
  });

  describe("Invoice Payment Calculations", () => {
    it("should correctly calculate remaining amount with multiple payments", async () => {
      const invoiceTotal = 1000;
      const payments = [100, 200, 150]; // Three payments
      const totalPaid = payments.reduce((sum, p) => sum + p, 0);
      const remaining = invoiceTotal - totalPaid;

      expect(totalPaid).toBe(450);
      expect(remaining).toBe(550);
    });

    it("should handle decimal amounts correctly", async () => {
      const invoiceTotal = 1234.56;
      const payment1 = 500.25;
      const payment2 = 234.31;
      const totalPaid = payment1 + payment2;
      const remaining = invoiceTotal - totalPaid;

      expect(totalPaid).toBeCloseTo(734.56, 2);
      expect(remaining).toBeCloseTo(500, 2);
    });

    it("should prevent overpayment", async () => {
      const invoiceTotal = 1000;
      const currentPayments = 800;
      const newPayment = 300;
      const totalPaid = currentPayments + newPayment;

      // Validation: new payment should not exceed remaining amount
      const remainingAmount = invoiceTotal - currentPayments;
      const isValid = newPayment <= remainingAmount;

      expect(isValid).toBe(false);
      expect(totalPaid).toBe(1100); // Would exceed invoice total
    });
  });
});
