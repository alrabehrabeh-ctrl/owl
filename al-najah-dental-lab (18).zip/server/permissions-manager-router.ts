import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { roleSettings, permissionChangeLogs } from "../drizzle/role-settings.schema";
import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import {
  verifyRolePassword,
  changeRolePassword,
  resetRolePasswordToDefault,
  getDefaultRolePasswordHash,
  DEFAULT_ROLE_PASSWORDS,
} from "./password-manager";
import { getRolePermissions, type Permission, rolePermissions } from "./permissions";

export const permissionsManagerRouter = router({
  /**
   * التحقق من كلمة مرور الدور
   */
  verifyRolePassword: publicProcedure
    .input(z.object({ role: z.enum(["user", "admin", "manager", "staff"]), password: z.string() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const settings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, input.role))
        .limit(1);

      if (settings.length === 0) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "إعدادات الدور غير موجودة",
        });
      }

      const isValid = verifyRolePassword(input.role, input.password, settings[0].passwordHash);

      return { isValid };
    }),

  /**
   * الحصول على الصلاحيات الحالية للدور
   */
  getRoleCurrentPermissions: publicProcedure
    .input(z.object({ role: z.enum(["user", "admin", "manager", "staff"]) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const settings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, input.role))
        .limit(1);

      // إذا لم توجد إعدادات مخصصة، استخدم الافتراضية
      if (settings.length === 0 || !settings[0].customPermissions) {
        return getRolePermissions(input.role as any);
      }

      return settings[0].customPermissions || [];
    }),

  /**
   * تعديل الصلاحيات للدور
   */
  updateRolePermissions: protectedProcedure
    .input(
      z.object({
        role: z.enum(["user", "admin", "manager", "staff"]),
        permissions: z.array(z.string()),
        reason: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // الحصول على الصلاحيات القديمة
      const settings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, input.role))
        .limit(1);

      const oldPermissions = settings.length > 0 ? settings[0].customPermissions || getRolePermissions(input.role as any) : getRolePermissions(input.role as any);

      // تحديث الصلاحيات
      if (settings.length > 0) {
        await db
          .update(roleSettings)
          .set({ customPermissions: input.permissions })
          .where(eq(roleSettings.role, input.role));
      } else {
        await db.insert(roleSettings).values({
          role: input.role,
          passwordHash: getDefaultRolePasswordHash(input.role),
          customPermissions: input.permissions,
        });
      }

      // تسجيل التغيير
      await db.insert(permissionChangeLogs).values({
        role: input.role,
        changedBy: ctx.user.id,
        changeType: "update",
        oldPermissions: oldPermissions as any,
        newPermissions: input.permissions as any,
        reason: input.reason,
      });

      return { success: true };
    }),

  /**
   * إضافة صلاحية للدور
   */
  addPermissionToRole: protectedProcedure
    .input(
      z.object({
        role: z.enum(["user", "admin", "manager", "staff"]),
        permission: z.string(),
        reason: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const settings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, input.role))
        .limit(1);

      const currentPermissions = settings.length > 0 ? settings[0].customPermissions || getRolePermissions(input.role as any) : getRolePermissions(input.role as any);

      // التحقق من عدم وجود الصلاحية بالفعل
      if (currentPermissions.includes(input.permission)) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "الصلاحية موجودة بالفعل",
        });
      }

      const newPermissions = [...currentPermissions, input.permission];

      if (settings.length > 0) {
        await db
          .update(roleSettings)
          .set({ customPermissions: newPermissions })
          .where(eq(roleSettings.role, input.role));
      } else {
        await db.insert(roleSettings).values({
          role: input.role,
          passwordHash: getDefaultRolePasswordHash(input.role),
          customPermissions: newPermissions,
        });
      }

      // تسجيل التغيير
      await db.insert(permissionChangeLogs).values({
        role: input.role,
        changedBy: ctx.user.id,
        changeType: "add",
        permission: input.permission,
        oldPermissions: currentPermissions as any,
        newPermissions: newPermissions as any,
        reason: input.reason,
      });

      return { success: true };
    }),

  /**
   * إزالة صلاحية من الدور
   */
  removePermissionFromRole: protectedProcedure
    .input(
      z.object({
        role: z.enum(["user", "admin", "manager", "staff"]),
        permission: z.string(),
        reason: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const settings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, input.role))
        .limit(1);

      const currentPermissions = settings.length > 0 ? settings[0].customPermissions || getRolePermissions(input.role as any) : getRolePermissions(input.role as any);

      // التحقق من وجود الصلاحية
      if (!currentPermissions.includes(input.permission)) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "الصلاحية غير موجودة",
        });
      }

      const newPermissions = currentPermissions.filter((p) => p !== input.permission);

      if (settings.length > 0) {
        await db
          .update(roleSettings)
          .set({ customPermissions: newPermissions })
          .where(eq(roleSettings.role, input.role));
      }

      // تسجيل التغيير
      await db.insert(permissionChangeLogs).values({
        role: input.role,
        changedBy: ctx.user.id,
        changeType: "remove",
        permission: input.permission,
        oldPermissions: currentPermissions as any,
        newPermissions: newPermissions as any,
        reason: input.reason,
      });

      return { success: true };
    }),

  /**
   * إعادة تعيين الصلاحيات إلى الافتراضية
   */
  resetRolePermissionsToDefault: protectedProcedure
    .input(z.object({ role: z.enum(["user", "admin", "manager", "staff"]) }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const settings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, input.role))
        .limit(1);

      const oldPermissions = settings.length > 0 ? settings[0].customPermissions || getRolePermissions(input.role as any) : getRolePermissions(input.role as any);
      const defaultPermissions = getRolePermissions(input.role as any);

      if (settings.length > 0) {
        await db
          .update(roleSettings)
          .set({ customPermissions: null })
          .where(eq(roleSettings.role, input.role));
      }

      // تسجيل التغيير
      await db.insert(permissionChangeLogs).values({
        role: input.role,
        changedBy: ctx.user.id,
        changeType: "reset",
        oldPermissions: oldPermissions as any,
        newPermissions: defaultPermissions as any,
        reason: "إعادة تعيين إلى الافتراضية",
      });

      return { success: true };
    }),

  /**
   * الحصول على سجل التغييرات
   */
  getPermissionChangeLogs: publicProcedure
    .input(
      z.object({
        role: z.enum(["user", "admin", "manager", "staff"]).optional(),
        limit: z.number().default(50),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      let query: any = db.select().from(permissionChangeLogs);

      if (input.role) {
        query = query.where(eq(permissionChangeLogs.role, input.role));
      }

      const logs = await query.orderBy(permissionChangeLogs.createdAt).limit(input.limit);

      return logs;
    }),
});
