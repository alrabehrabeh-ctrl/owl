import { describe, expect, it, beforeAll } from "vitest";
import {
  hashPassword,
  verifyPassword,
  getDefaultRolePasswordHash,
  verifyRolePassword,
  resetRolePasswordToDefault,
  changeRolePassword,
  DEFAULT_ROLE_PASSWORDS,
} from "./password-manager";

describe("Password Manager", () => {
  describe("Password Hashing", () => {
    it("should hash password correctly", () => {
      const password = "test123";
      const hash = hashPassword(password);
      expect(hash).toBeDefined();
      expect(hash.length).toBeGreaterThan(0);
      expect(typeof hash).toBe("string");
    });

    it("should produce same hash for same password", () => {
      const password = "test123";
      const hash1 = hashPassword(password);
      const hash2 = hashPassword(password);
      expect(hash1).toBe(hash2);
    });

    it("should produce different hash for different passwords", () => {
      const hash1 = hashPassword("password1");
      const hash2 = hashPassword("password2");
      expect(hash1).not.toBe(hash2);
    });
  });

  describe("Password Verification", () => {
    it("should verify correct password", () => {
      const password = "myPassword123";
      const hash = hashPassword(password);
      expect(verifyPassword(password, hash)).toBe(true);
    });

    it("should reject incorrect password", () => {
      const password = "myPassword123";
      const hash = hashPassword(password);
      expect(verifyPassword("wrongPassword", hash)).toBe(false);
    });

    it("should be case sensitive", () => {
      const password = "MyPassword";
      const hash = hashPassword(password);
      expect(verifyPassword("mypassword", hash)).toBe(false);
    });
  });

  describe("Default Role Passwords", () => {
    it("should have default passwords for all roles", () => {
      const roles = ["user", "admin", "manager", "staff"];
      for (const role of roles) {
        expect(DEFAULT_ROLE_PASSWORDS[role]).toBeDefined();
        expect(DEFAULT_ROLE_PASSWORDS[role].length).toBeGreaterThan(0);
      }
    });

    it("should have correct default passwords", () => {
      expect(DEFAULT_ROLE_PASSWORDS.admin).toBe("admin");
      expect(DEFAULT_ROLE_PASSWORDS.manager).toBe("1985");
      expect(DEFAULT_ROLE_PASSWORDS.staff).toBe("0000");
      expect(DEFAULT_ROLE_PASSWORDS.user).toBe("0000");
    });

    it("should get correct hash for default role password", () => {
      const roles = ["user", "admin", "manager", "staff"];
      for (const role of roles) {
        const hash = getDefaultRolePasswordHash(role);
        const expectedHash = hashPassword(DEFAULT_ROLE_PASSWORDS[role]);
        expect(hash).toBe(expectedHash);
      }
    });

    it("should throw error for invalid role", () => {
      expect(() => getDefaultRolePasswordHash("invalid")).toThrow();
    });
  });

  describe("Role Password Verification", () => {
    it("should verify correct role password", () => {
      const role = "admin";
      const password = DEFAULT_ROLE_PASSWORDS[role];
      const hash = getDefaultRolePasswordHash(role);
      expect(verifyRolePassword(role, password, hash)).toBe(true);
    });

    it("should reject incorrect role password", () => {
      const role = "admin";
      const hash = getDefaultRolePasswordHash(role);
      expect(verifyRolePassword(role, "wrongPassword", hash)).toBe(false);
    });

    it("should verify all default role passwords", () => {
      const roles = ["user", "admin", "manager", "staff"];
      for (const role of roles) {
        const password = DEFAULT_ROLE_PASSWORDS[role];
        const hash = getDefaultRolePasswordHash(role);
        expect(verifyRolePassword(role, password, hash)).toBe(true);
      }
    });
  });

  describe("Password Reset", () => {
    it("should reset password to default", () => {
      const role = "admin";
      const newHash = resetRolePasswordToDefault(role);
      const defaultHash = getDefaultRolePasswordHash(role);
      expect(newHash).toBe(defaultHash);
    });

    it("should reset all roles to default", () => {
      const roles = ["user", "admin", "manager", "staff"];
      for (const role of roles) {
        const resetHash = resetRolePasswordToDefault(role);
        const defaultHash = getDefaultRolePasswordHash(role);
        expect(resetHash).toBe(defaultHash);
      }
    });
  });

  describe("Password Change", () => {
    it("should change password to new value", () => {
      const newPassword = "newPassword123";
      const hash = changeRolePassword(newPassword);
      expect(verifyPassword(newPassword, hash)).toBe(true);
    });

    it("should reject empty password", () => {
      expect(() => changeRolePassword("")).toThrow();
    });

    it("should produce different hash for different passwords", () => {
      const hash1 = changeRolePassword("password1");
      const hash2 = changeRolePassword("password2");
      expect(hash1).not.toBe(hash2);
    });

    it("should allow any non-empty password", () => {
      const passwords = ["a", "123", "password with spaces", "!@#$%^&*()"];
      for (const password of passwords) {
        const hash = changeRolePassword(password);
        expect(verifyPassword(password, hash)).toBe(true);
      }
    });
  });

  describe("Security", () => {
    it("should not store plain text passwords", () => {
      const password = "myPassword123";
      const hash = hashPassword(password);
      expect(hash).not.toBe(password);
    });

    it("should produce consistent hashes", () => {
      const password = "test";
      const hashes = [
        hashPassword(password),
        hashPassword(password),
        hashPassword(password),
      ];
      expect(hashes[0]).toBe(hashes[1]);
      expect(hashes[1]).toBe(hashes[2]);
    });

    it("should have long hash values", () => {
      const hash = hashPassword("test");
      expect(hash.length).toBeGreaterThan(20);
    });
  });
});
