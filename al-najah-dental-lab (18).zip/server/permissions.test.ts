import { describe, expect, it } from "vitest";
import {
  hasPermission,
  getRolePermissions,
  rolePermissions,
  roleDescriptions,
  permissionDescriptions,
  type Role,
  type Permission,
} from "./permissions";

describe("Permissions System", () => {
  describe("Role Permissions", () => {
    it("should have permissions defined for all roles", () => {
      const roles: Role[] = ["user", "admin", "manager", "staff"];
      
      for (const role of roles) {
        expect(rolePermissions[role]).toBeDefined();
        expect(Array.isArray(rolePermissions[role])).toBe(true);
        expect(rolePermissions[role].length).toBeGreaterThan(0);
      }
    });

    it("should have role descriptions for all roles", () => {
      const roles: Role[] = ["user", "admin", "manager", "staff"];
      
      for (const role of roles) {
        expect(roleDescriptions[role]).toBeDefined();
        expect(roleDescriptions[role].length).toBeGreaterThan(0);
      }
    });

    it("should have correct role hierarchy (permissions increase)", () => {
      const userPerms = rolePermissions.user.length;
      const staffPerms = rolePermissions.staff.length;
      const managerPerms = rolePermissions.manager.length;
      const adminPerms = rolePermissions.admin.length;

      expect(userPerms).toBeLessThanOrEqual(staffPerms);
      expect(staffPerms).toBeLessThanOrEqual(managerPerms);
      expect(managerPerms).toBeLessThanOrEqual(adminPerms);
    });

    it("admin should have all permissions", () => {
      const adminPerms = rolePermissions.admin;
      const allPerms = new Set<Permission>();
      
      for (const perms of Object.values(rolePermissions)) {
        perms.forEach((p) => allPerms.add(p));
      }

      for (const perm of allPerms) {
        expect(adminPerms).toContain(perm);
      }
    });
  });

  describe("hasPermission Function", () => {
    it("should return true for admin with any permission", () => {
      const testPermissions: Permission[] = [
        "users.view",
        "users.create",
        "users.delete",
        "doctors.view",
        "invoices.create",
        "settings.update",
      ];

      for (const permission of testPermissions) {
        expect(hasPermission("admin", permission)).toBe(true);
      }
    });

    it("should return false for user with admin-only permissions", () => {
      const adminOnlyPermissions: Permission[] = [
        "users.manage_roles",
        "settings.update",
        "salaries.delete",
      ];

      for (const permission of adminOnlyPermissions) {
        expect(hasPermission("user", permission)).toBe(false);
      }
    });

    it("should return true for user with allowed permissions", () => {
      const userPermissions: Permission[] = [
        "doctors.view",
        "works.view",
        "invoices.view",
        "reports.view",
      ];

      for (const permission of userPermissions) {
        expect(hasPermission("user", permission)).toBe(true);
      }
    });

    it("should return true for staff with staff permissions", () => {
      const staffPermissions: Permission[] = [
        "doctors.create",
        "works.update",
        "invoices.create",
        "expenses.view",
      ];

      for (const permission of staffPermissions) {
        expect(hasPermission("staff", permission)).toBe(true);
      }
    });

    it("should return true for manager with manager permissions", () => {
      const managerPermissions: Permission[] = [
        "doctors.delete",
        "works.delete",
        "invoices.delete",
        "audit_log.view",
      ];

      for (const permission of managerPermissions) {
        expect(hasPermission("manager", permission)).toBe(true);
      }
    });

    it("should return false for invalid permission", () => {
      expect(hasPermission("user", "invalid.permission" as Permission)).toBe(false);
      expect(hasPermission("admin", "invalid.permission" as Permission)).toBe(false);
    });
  });

  describe("getRolePermissions Function", () => {
    it("should return array of permissions for each role", () => {
      const roles: Role[] = ["user", "admin", "manager", "staff"];
      
      for (const role of roles) {
        const perms = getRolePermissions(role);
        expect(Array.isArray(perms)).toBe(true);
        expect(perms.length).toBeGreaterThan(0);
        expect(perms).toEqual(rolePermissions[role]);
      }
    });

    it("should return empty array for invalid role", () => {
      const perms = getRolePermissions("invalid" as Role);
      expect(Array.isArray(perms)).toBe(true);
      expect(perms.length).toBe(0);
    });
  });

  describe("Permission Categories", () => {
    it("should have descriptions for all permissions", () => {
      const allPerms = new Set<Permission>();
      
      for (const perms of Object.values(rolePermissions)) {
        perms.forEach((p) => allPerms.add(p));
      }

      for (const perm of allPerms) {
        expect(permissionDescriptions[perm]).toBeDefined();
        expect(permissionDescriptions[perm].length).toBeGreaterThan(0);
      }
    });

    it("should have permissions grouped by category", () => {
      const categories = {
        "users.": ["users.view", "users.create", "users.update", "users.delete", "users.manage_roles"],
        "doctors.": ["doctors.view", "doctors.create", "doctors.update", "doctors.delete"],
        "works.": ["works.view", "works.create", "works.update", "works.delete"],
        "invoices.": ["invoices.view", "invoices.create", "invoices.update", "invoices.delete", "invoices.export"],
      };

      for (const [prefix, expectedPerms] of Object.entries(categories)) {
        for (const perm of expectedPerms) {
          expect(perm.startsWith(prefix)).toBe(true);
        }
      }
    });
  });

  describe("Role Specific Permissions", () => {
    it("user role should only have view permissions", () => {
      const userPerms = rolePermissions.user;
      
      for (const perm of userPerms) {
        expect(perm).toMatch(/\.view$/);
      }
    });

    it("staff role should not have delete permissions", () => {
      const staffPerms = rolePermissions.staff;
      
      for (const perm of staffPerms) {
        expect(perm).not.toMatch(/\.delete$/);
      }
    });

    it("manager role should have delete permissions", () => {
      const managerPerms = rolePermissions.manager;
      const deletePerms = managerPerms.filter((p) => p.includes(".delete"));
      
      expect(deletePerms.length).toBeGreaterThan(0);
    });

    it("admin role should have all types of permissions", () => {
      const adminPerms = rolePermissions.admin;
      const hasView = adminPerms.some((p) => p.includes(".view"));
      const hasCreate = adminPerms.some((p) => p.includes(".create"));
      const hasUpdate = adminPerms.some((p) => p.includes(".update"));
      const hasDelete = adminPerms.some((p) => p.includes(".delete"));
      const hasManage = adminPerms.some((p) => p.includes(".manage"));

      expect(hasView).toBe(true);
      expect(hasCreate).toBe(true);
      expect(hasUpdate).toBe(true);
      expect(hasDelete).toBe(true);
      expect(hasManage).toBe(true);
    });
  });

  describe("Permission Inheritance", () => {
    it("staff should have all user permissions", () => {
      const userPerms = rolePermissions.user;
      const staffPerms = rolePermissions.staff;

      for (const perm of userPerms) {
        expect(staffPerms).toContain(perm);
      }
    });

    it("manager should have all staff permissions", () => {
      const staffPerms = rolePermissions.staff;
      const managerPerms = rolePermissions.manager;

      for (const perm of staffPerms) {
        expect(managerPerms).toContain(perm);
      }
    });

    it("admin should have all manager permissions", () => {
      const managerPerms = rolePermissions.manager;
      const adminPerms = rolePermissions.admin;

      for (const perm of managerPerms) {
        expect(adminPerms).toContain(perm);
      }
    });
  });

  describe("Permission Consistency", () => {
    it("should not have duplicate permissions in any role", () => {
      const roles: Role[] = ["user", "admin", "manager", "staff"];
      
      for (const role of roles) {
        const perms = rolePermissions[role];
        const uniquePerms = new Set(perms);
        expect(perms.length).toBe(uniquePerms.size);
      }
    });

    it("should have valid permission format", () => {
      const roles: Role[] = ["user", "admin", "manager", "staff"];
      const validFormat = /^[a-z_]+\.[a-z_]+$/;

      for (const role of roles) {
        const perms = rolePermissions[role];
        for (const perm of perms) {
          expect(perm).toMatch(validFormat);
        }
      }
    });
  });
});
