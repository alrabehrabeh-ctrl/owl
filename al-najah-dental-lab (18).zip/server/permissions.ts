/**
 * نظام الصلاحيات والأدوار
 * يحدد الصلاحيات المتاحة لكل دور
 */

export type Role = "user" | "admin" | "manager" | "staff";

export type Permission =
  // إدارة المستخدمين
  | "users.view"
  | "users.create"
  | "users.update"
  | "users.delete"
  | "users.manage_roles"
  // إدارة الأطباء
  | "doctors.view"
  | "doctors.create"
  | "doctors.update"
  | "doctors.delete"
  // إدارة الأعمال
  | "works.view"
  | "works.create"
  | "works.update"
  | "works.delete"
  // إدارة الفواتير
  | "invoices.view"
  | "invoices.create"
  | "invoices.update"
  | "invoices.delete"
  | "invoices.export"
  // إدارة المصروفات
  | "expenses.view"
  | "expenses.create"
  | "expenses.update"
  | "expenses.delete"
  // إدارة الدفعات
  | "payments.view"
  | "payments.create"
  | "payments.update"
  | "payments.delete"
  // إدارة الرواتب
  | "salaries.view"
  | "salaries.create"
  | "salaries.update"
  | "salaries.delete"
  // التقارير
  | "reports.view"
  | "reports.create"
  | "reports.export"
  // سجل التدقيق
  | "audit_log.view"
  // الإعدادات
  | "settings.view"
  | "settings.update";

/**
 * تعريف الصلاحيات لكل دور
 */
export const rolePermissions: Record<Role, Permission[]> = {
  // المستخدم العادي - صلاحيات محدودة جداً
  user: [
    "doctors.view",
    "works.view",
    "invoices.view",
    "reports.view",
  ],

  // الموظف - صلاحيات أكثر من المستخدم العادي
  staff: [
    // الأطباء
    "doctors.view",
    "doctors.create",
    "doctors.update",
    // الأعمال
    "works.view",
    "works.create",
    "works.update",
    // الفواتير
    "invoices.view",
    "invoices.create",
    "invoices.update",
    "invoices.export",
    // المصروفات
    "expenses.view",
    "expenses.create",
    "expenses.update",
    // الدفعات
    "payments.view",
    "payments.create",
    "payments.update",
    // التقارير
    "reports.view",
    "reports.export",
  ],

  // المدير - صلاحيات واسعة
  manager: [
    // إدارة المستخدمين (عرض فقط)
    "users.view",
    // الأطباء
    "doctors.view",
    "doctors.create",
    "doctors.update",
    "doctors.delete",
    // الأعمال
    "works.view",
    "works.create",
    "works.update",
    "works.delete",
    // الفواتير
    "invoices.view",
    "invoices.create",
    "invoices.update",
    "invoices.delete",
    "invoices.export",
    // المصروفات
    "expenses.view",
    "expenses.create",
    "expenses.update",
    "expenses.delete",
    // الدفعات
    "payments.view",
    "payments.create",
    "payments.update",
    "payments.delete",
    // الرواتب
    "salaries.view",
    "salaries.create",
    "salaries.update",
    // التقارير
    "reports.view",
    "reports.create",
    "reports.export",
    // سجل التدقيق
    "audit_log.view",
  ],

  // المسؤول - صلاحيات كاملة
  admin: [
    // إدارة المستخدمين
    "users.view",
    "users.create",
    "users.update",
    "users.delete",
    "users.manage_roles",
    // الأطباء
    "doctors.view",
    "doctors.create",
    "doctors.update",
    "doctors.delete",
    // الأعمال
    "works.view",
    "works.create",
    "works.update",
    "works.delete",
    // الفواتير
    "invoices.view",
    "invoices.create",
    "invoices.update",
    "invoices.delete",
    "invoices.export",
    // المصروفات
    "expenses.view",
    "expenses.create",
    "expenses.update",
    "expenses.delete",
    // الدفعات
    "payments.view",
    "payments.create",
    "payments.update",
    "payments.delete",
    // الرواتب
    "salaries.view",
    "salaries.create",
    "salaries.update",
    "salaries.delete",
    // التقارير
    "reports.view",
    "reports.create",
    "reports.export",
    // سجل التدقيق
    "audit_log.view",
    // الإعدادات
    "settings.view",
    "settings.update",
  ],
};

/**
 * التحقق من وجود صلاحية معينة لدور معين
 */
export function hasPermission(role: Role, permission: Permission): boolean {
  return rolePermissions[role]?.includes(permission) ?? false;
}

/**
 * الحصول على جميع الصلاحيات لدور معين
 */
export function getRolePermissions(role: Role): Permission[] {
  return rolePermissions[role] ?? [];
}

/**
 * وصف الأدوار باللغة العربية
 */
export const roleDescriptions: Record<Role, string> = {
  user: "مستخدم عادي - صلاحيات محدودة للعرض فقط",
  staff: "موظف - صلاحيات لإدارة الأعمال والفواتير",
  manager: "مدير - صلاحيات واسعة لإدارة جميع العمليات",
  admin: "مسؤول - صلاحيات كاملة على جميع النظام",
};

/**
 * وصف الصلاحيات باللغة العربية
 */
export const permissionDescriptions: Record<Permission, string> = {
  // إدارة المستخدمين
  "users.view": "عرض المستخدمين",
  "users.create": "إنشاء مستخدم جديد",
  "users.update": "تحديث بيانات المستخدم",
  "users.delete": "حذف المستخدم",
  "users.manage_roles": "إدارة أدوار المستخدمين",
  // إدارة الأطباء
  "doctors.view": "عرض الأطباء",
  "doctors.create": "إضافة طبيب جديد",
  "doctors.update": "تحديث بيانات الطبيب",
  "doctors.delete": "حذف الطبيب",
  // إدارة الأعمال
  "works.view": "عرض الأعمال",
  "works.create": "إضافة عمل جديد",
  "works.update": "تحديث بيانات العمل",
  "works.delete": "حذف العمل",
  // إدارة الفواتير
  "invoices.view": "عرض الفواتير",
  "invoices.create": "إنشاء فاتورة جديدة",
  "invoices.update": "تحديث الفاتورة",
  "invoices.delete": "حذف الفاتورة",
  "invoices.export": "تصدير الفواتير",
  // إدارة المصروفات
  "expenses.view": "عرض المصروفات",
  "expenses.create": "إضافة مصروف جديد",
  "expenses.update": "تحديث المصروف",
  "expenses.delete": "حذف المصروف",
  // إدارة الدفعات
  "payments.view": "عرض الدفعات",
  "payments.create": "تسجيل دفعة جديدة",
  "payments.update": "تحديث الدفعة",
  "payments.delete": "حذف الدفعة",
  // إدارة الرواتب
  "salaries.view": "عرض الرواتب",
  "salaries.create": "إضافة راتب جديد",
  "salaries.update": "تحديث الراتب",
  "salaries.delete": "حذف الراتب",
  // التقارير
  "reports.view": "عرض التقارير",
  "reports.create": "إنشاء تقرير جديد",
  "reports.export": "تصدير التقارير",
  // سجل التدقيق
  "audit_log.view": "عرض سجل التدقيق",
  // الإعدادات
  "settings.view": "عرض الإعدادات",
  "settings.update": "تحديث الإعدادات",
};
