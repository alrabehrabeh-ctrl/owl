import { describe, it, expect } from "vitest";

describe("Profit Distribution Calculations", () => {
  describe("Revenue Calculation", () => {
    it("should calculate total revenue from delivered works", () => {
      const works = [
        { id: 1, status: "delivered", totalPrice: "100.00" },
        { id: 2, status: "delivered", totalPrice: "200.00" },
        { id: 3, status: "pending", totalPrice: "150.00" },
      ];

      const revenue = works
        .filter((w) => w.status === "delivered")
        .reduce((sum, w) => sum + parseFloat(w.totalPrice), 0);

      expect(revenue).toBe(300);
    });

    it("should exclude non-delivered works from revenue", () => {
      const works = [
        { id: 1, status: "delivered", totalPrice: "100.00" },
        { id: 2, status: "pending", totalPrice: "200.00" },
        { id: 3, status: "cancelled", totalPrice: "150.00" },
      ];

      const revenue = works
        .filter((w) => w.status === "delivered")
        .reduce((sum, w) => sum + parseFloat(w.totalPrice), 0);

      expect(revenue).toBe(100);
    });

    it("should handle empty work list", () => {
      const works: any[] = [];

      const revenue = works
        .filter((w) => w.status === "delivered")
        .reduce((sum, w) => sum + parseFloat(w.totalPrice), 0);

      expect(revenue).toBe(0);
    });
  });

  describe("Expense Calculation", () => {
    it("should calculate total expenses", () => {
      const expenses = [
        { id: 1, amount: "50.00" },
        { id: 2, amount: "75.00" },
        { id: 3, amount: "25.00" },
      ];

      const totalExpenses = expenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);

      expect(totalExpenses).toBe(150);
    });

    it("should handle empty expense list", () => {
      const expenses: any[] = [];

      const totalExpenses = expenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);

      expect(totalExpenses).toBe(0);
    });
  });

  describe("Net Profit Calculation", () => {
    it("should calculate net profit correctly", () => {
      const revenue = 1000;
      const expenses = 300;
      const netProfit = revenue - expenses;

      expect(netProfit).toBe(700);
    });

    it("should handle negative net profit", () => {
      const revenue = 200;
      const expenses = 500;
      const netProfit = revenue - expenses;

      expect(netProfit).toBe(-300);
    });

    it("should handle zero net profit", () => {
      const revenue = 500;
      const expenses = 500;
      const netProfit = revenue - expenses;

      expect(netProfit).toBe(0);
    });
  });

  describe("Profit Distribution", () => {
    it("should distribute profit correctly (40-40-20)", () => {
      const netProfit = 1000;

      const distribution = {
        person1: netProfit * 0.4, // 400
        person2: netProfit * 0.4, // 400
        person3: netProfit * 0.2, // 200
      };

      expect(distribution.person1).toBe(400);
      expect(distribution.person2).toBe(400);
      expect(distribution.person3).toBe(200);
      expect(distribution.person1 + distribution.person2 + distribution.person3).toBe(1000);
    });

    it("should distribute zero profit", () => {
      const netProfit = 0;

      const distribution = {
        person1: netProfit * 0.4,
        person2: netProfit * 0.4,
        person3: netProfit * 0.2,
      };

      expect(distribution.person1).toBe(0);
      expect(distribution.person2).toBe(0);
      expect(distribution.person3).toBe(0);
    });

    it("should distribute negative profit", () => {
      const netProfit = -500;

      const distribution = {
        person1: netProfit * 0.4, // -200
        person2: netProfit * 0.4, // -200
        person3: netProfit * 0.2, // -100
      };

      expect(distribution.person1).toBe(-200);
      expect(distribution.person2).toBe(-200);
      expect(distribution.person3).toBe(-100);
    });

    it("should distribute decimal profit correctly", () => {
      const netProfit = 1234.56;

      const distribution = {
        person1: netProfit * 0.4,
        person2: netProfit * 0.4,
        person3: netProfit * 0.2,
      };

      expect(distribution.person1).toBeCloseTo(493.824, 2);
      expect(distribution.person2).toBeCloseTo(493.824, 2);
      expect(distribution.person3).toBeCloseTo(246.912, 2);
    });
  });

  describe("Profit Margin Calculation", () => {
    it("should calculate profit margin correctly", () => {
      const revenue = 1000;
      const netProfit = 250;
      const profitMargin = (netProfit / revenue) * 100;

      expect(profitMargin).toBe(25);
    });

    it("should handle zero revenue", () => {
      const revenue = 0;
      const netProfit = 100;
      const profitMargin = revenue > 0 ? (netProfit / revenue) * 100 : 0;

      expect(profitMargin).toBe(0);
    });

    it("should calculate high profit margin", () => {
      const revenue = 100;
      const netProfit = 90;
      const profitMargin = (netProfit / revenue) * 100;

      expect(profitMargin).toBe(90);
    });

    it("should calculate negative profit margin", () => {
      const revenue = 1000;
      const netProfit = -200;
      const profitMargin = (netProfit / revenue) * 100;

      expect(profitMargin).toBe(-20);
    });
  });

  describe("Date Range Filtering", () => {
    it("should filter works by date range", () => {
      const works = [
        { id: 1, status: "delivered", totalPrice: "100.00", receivedDate: "2026-01-15" },
        { id: 2, status: "delivered", totalPrice: "200.00", receivedDate: "2026-02-10" },
        { id: 3, status: "delivered", totalPrice: "150.00", receivedDate: "2026-03-05" },
      ];

      const startDate = new Date("2026-02-01");
      const endDate = new Date("2026-02-28");

      const filtered = works.filter((w) => {
        const workDate = new Date(w.receivedDate);
        return workDate >= startDate && workDate <= endDate && w.status === "delivered";
      });

      expect(filtered.length).toBe(1);
      expect(filtered[0].totalPrice).toBe("200.00");
    });

    it("should filter expenses by date range", () => {
      const expenses = [
        { id: 1, amount: "50.00", expenseDate: "2026-01-15" },
        { id: 2, amount: "75.00", expenseDate: "2026-02-10" },
        { id: 3, amount: "25.00", expenseDate: "2026-03-05" },
      ];

      const startDate = new Date("2026-02-01");
      const endDate = new Date("2026-02-28");

      const filtered = expenses.filter((e) => {
        const expenseDate = new Date(e.expenseDate);
        return expenseDate >= startDate && expenseDate <= endDate;
      });

      expect(filtered.length).toBe(1);
      expect(filtered[0].amount).toBe("75.00");
    });
  });
});
