import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import * as db from "./db";

describe("RBAC - Default Role Assignment", () => {
  let database: any;

  beforeAll(async () => {
    database = await getDb();
    if (!database) {
      throw new Error("Database connection failed");
    }
  });

  afterAll(async () => {
    // Cleanup test data
    if (database) {
      await database
        .delete(users)
        .where(eq(users.openId, "test-user-default-role"));
    }
  });

  it("should assign default role 'user' when no role is provided", async () => {
    // Test upsertUser with no role
    await db.upsertUser({
      openId: "test-user-default-role",
      name: "Test User",
      email: "test@example.com",
    });

    // Verify the user has role 'user'
    const user = await db.getUserByOpenId("test-user-default-role");
    expect(user).toBeDefined();
    expect(user?.role).toBe("user");
  });

  it("should preserve explicit role when provided", async () => {
    // Test upsertUser with explicit role
    await db.upsertUser({
      openId: "test-user-explicit-role",
      name: "Test Manager",
      email: "manager@example.com",
      role: "manager",
    });

    // Verify the user has role 'manager'
    const user = await db.getUserByOpenId("test-user-explicit-role");
    expect(user).toBeDefined();
    expect(user?.role).toBe("manager");
  });

  it("should assign 'admin' role to owner", async () => {
    // Get owner openId from environment
    const ownerOpenId = process.env.OWNER_OPEN_ID || "owner-test-id";

    // Test upsertUser for owner
    await db.upsertUser({
      openId: ownerOpenId,
      name: "Owner User",
      email: "owner@example.com",
    });

    // Verify the owner has role 'admin'
    const user = await db.getUserByOpenId(ownerOpenId);
    expect(user).toBeDefined();
    expect(user?.role).toBe("admin");
  });

  it("should not override existing role on update", async () => {
    // First insert with default role
    await db.upsertUser({
      openId: "test-user-role-update",
      name: "Test User",
      email: "test@example.com",
    });

    // Verify initial role
    let user = await db.getUserByOpenId("test-user-role-update");
    expect(user?.role).toBe("user");

    // Update with explicit role
    await db.upsertUser({
      openId: "test-user-role-update",
      name: "Test User Updated",
      role: "manager",
    });

    // Verify role was updated
    user = await db.getUserByOpenId("test-user-role-update");
    expect(user?.role).toBe("manager");

    // Cleanup
    if (database) {
      await database
        .delete(users)
        .where(eq(users.openId, "test-user-role-update"));
    }
  });

  it("should handle all valid roles", async () => {
    const testRoles = ["user", "admin", "manager", "staff"];
    const testUsers = [];

    for (const role of testRoles) {
      const openId = `test-user-role-${role}`;
      testUsers.push(openId);

      await db.upsertUser({
        openId,
        name: `Test ${role}`,
        email: `${role}@example.com`,
        role: role as any,
      });

      const user = await db.getUserByOpenId(openId);
      expect(user?.role).toBe(role);
    }

    // Cleanup
    if (database) {
      for (const openId of testUsers) {
        await database.delete(users).where(eq(users.openId, openId));
      }
    }
  });
});
