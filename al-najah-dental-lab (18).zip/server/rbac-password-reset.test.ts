import { describe, it, expect, beforeAll } from "vitest";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { scryptSync } from "crypto";

describe("RBAC and Password Reset", () => {
  let db: any;

  beforeAll(async () => {
    db = await getDb();
  });

  describe("User Roles", () => {
    it("should have users with admin role", async () => {
      const adminUsers = await db
        .select()
        .from(users)
        .where(eq(users.role, "admin"));

      expect(adminUsers.length).toBeGreaterThan(0);
    });

    it("should have users with different roles", async () => {
      const allUsers = await db.select().from(users);

      const roles = new Set(allUsers.map((u: any) => u.role));
      expect(roles.size).toBeGreaterThan(0);
    });

    it("should have user, admin, manager, or staff roles only", async () => {
      const allUsers = await db.select().from(users);
      const validRoles = ["user", "admin", "manager", "staff"];

      allUsers.forEach((user: any) => {
        expect(validRoles).toContain(user.role);
      });
    });
  });

  describe("Password Hashing", () => {
    it("should have hashed passwords for users", async () => {
      const usersWithPassword = await db
        .select()
        .from(users)
        .where(eq(users.password, null));

      // Some users may not have passwords set yet
      expect(usersWithPassword).toBeDefined();
    });

    it("should have passwords in correct format (salt:hash)", async () => {
      const allUsers = await db.select().from(users);

      allUsers.forEach((user: any) => {
        if (user.password) {
          const parts = user.password.split(":");
          expect(parts.length).toBe(2);
          expect(parts[0].length).toBeGreaterThan(0); // salt
          expect(parts[1].length).toBeGreaterThan(0); // hash
        }
      });
    });
  });

  describe("User Data Integrity", () => {
    it("should have required fields for all users", async () => {
      const allUsers = await db.select().from(users);

      allUsers.forEach((user: any) => {
        expect(user.id).toBeDefined();
        expect(user.openId).toBeDefined();
        expect(user.role).toBeDefined();
        expect(user.createdAt).toBeDefined();
        expect(user.updatedAt).toBeDefined();
      });
    });

    it("should have unique openId for all users", async () => {
      const allUsers = await db.select().from(users);
      const openIds = allUsers.map((u: any) => u.openId);
      const uniqueOpenIds = new Set(openIds);

      expect(uniqueOpenIds.size).toBe(openIds.length);
    });

    it("should have username and email for users with loginMethod", async () => {
      const usersWithLoginMethod = await db.select().from(users);

      usersWithLoginMethod.forEach((user: any) => {
        if (user.loginMethod === "manual") {
          expect(user.username).toBeDefined();
        }
      });
    });
  });

  describe("Admin Users", () => {
    it("should have at least one admin user", async () => {
      const adminUsers = await db
        .select()
        .from(users)
        .where(eq(users.role, "admin"));

      expect(adminUsers.length).toBeGreaterThanOrEqual(1);
    });

    it("admin users should have names", async () => {
      const adminUsers = await db
        .select()
        .from(users)
        .where(eq(users.role, "admin"));

      adminUsers.forEach((admin: any) => {
        expect(admin.name).toBeDefined();
      });
    });
  });
});
