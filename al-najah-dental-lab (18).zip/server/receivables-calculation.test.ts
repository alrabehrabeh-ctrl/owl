import { describe, expect, it } from "vitest";

/**
 * اختبار حساب المديونية
 * يتحقق من أن الحساب صحيح: remainingAmount = totalAmount - paidAmount
 */
describe("Receivables calculation", () => {
  // دالة محاكاة لحساب المديونية (نفس المنطق في ReceivablesPage)
  function calculateReceivables(
    works: Array<{ totalPrice: string | number }>,
    payments: Array<{ amount: string | number }>
  ) {
    const totalAmount = works.reduce(
      (sum: number, work: any) => sum + parseFloat(work.totalPrice || 0),
      0
    );
    const paidAmount = payments.reduce(
      (sum: number, payment: any) => sum + parseFloat(payment.amount || 0),
      0
    );
    const remainingAmount = Math.max(0, totalAmount - paidAmount);

    return {
      totalAmount,
      paidAmount,
      remainingAmount,
    };
  }

  it("should calculate remaining amount correctly when no payments", () => {
    const works = [
      { totalPrice: "100" },
      { totalPrice: "200" },
      { totalPrice: "300" },
    ];
    const payments: any[] = [];

    const result = calculateReceivables(works, payments);

    expect(result.totalAmount).toBe(600);
    expect(result.paidAmount).toBe(0);
    expect(result.remainingAmount).toBe(600);
  });

  it("should calculate remaining amount correctly with partial payment", () => {
    const works = [
      { totalPrice: "100" },
      { totalPrice: "200" },
      { totalPrice: "300" },
    ];
    const payments = [{ amount: "250" }];

    const result = calculateReceivables(works, payments);

    expect(result.totalAmount).toBe(600);
    expect(result.paidAmount).toBe(250);
    expect(result.remainingAmount).toBe(350);
  });

  it("should calculate remaining amount correctly with full payment", () => {
    const works = [
      { totalPrice: "100" },
      { totalPrice: "200" },
      { totalPrice: "300" },
    ];
    const payments = [{ amount: "600" }];

    const result = calculateReceivables(works, payments);

    expect(result.totalAmount).toBe(600);
    expect(result.paidAmount).toBe(600);
    expect(result.remainingAmount).toBe(0);
  });

  it("should not allow negative remaining amount", () => {
    const works = [{ totalPrice: "100" }];
    const payments = [{ amount: "200" }]; // أكثر من المبلغ الكلي

    const result = calculateReceivables(works, payments);

    expect(result.totalAmount).toBe(100);
    expect(result.paidAmount).toBe(200);
    expect(result.remainingAmount).toBe(0); // يجب أن يكون 0 وليس سالب
  });

  it("should handle multiple payments", () => {
    const works = [
      { totalPrice: "500" },
      { totalPrice: "500" },
    ];
    const payments = [
      { amount: "200" },
      { amount: "300" },
      { amount: "150" },
    ];

    const result = calculateReceivables(works, payments);

    expect(result.totalAmount).toBe(1000);
    expect(result.paidAmount).toBe(650);
    expect(result.remainingAmount).toBe(350);
  });

  it("should handle string and number amounts", () => {
    const works = [
      { totalPrice: "100" },
      { totalPrice: 200 },
      { totalPrice: "300" },
    ];
    const payments = [
      { amount: "150" },
      { amount: 100 },
    ];

    const result = calculateReceivables(works, payments);

    expect(result.totalAmount).toBe(600);
    expect(result.paidAmount).toBe(250);
    expect(result.remainingAmount).toBe(350);
  });

  it("should handle empty works array", () => {
    const works: any[] = [];
    const payments = [{ amount: "100" }];

    const result = calculateReceivables(works, payments);

    expect(result.totalAmount).toBe(0);
    expect(result.paidAmount).toBe(100);
    expect(result.remainingAmount).toBe(0); // لا يمكن أن يكون سالب
  });

  it("should handle decimal amounts", () => {
    const works = [
      { totalPrice: "100.50" },
      { totalPrice: "200.75" },
    ];
    const payments = [{ amount: "150.25" }];

    const result = calculateReceivables(works, payments);

    expect(result.totalAmount).toBeCloseTo(301.25, 2);
    expect(result.paidAmount).toBe(150.25);
    expect(result.remainingAmount).toBeCloseTo(151, 2);
  });
});
