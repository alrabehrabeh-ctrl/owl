import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { rolePermissions, getRolePermissions, hasPermission, roleDescriptions, permissionDescriptions, type Role, type Permission } from "./permissions";

export const rolesRouter = router({
  /**
   * الحصول على جميع الأدوار المتاحة
   */
  getAllRoles: publicProcedure.query(async () => {
    const roles: Array<{
      id: Role;
      name: string;
      description: string;
      permissionCount: number;
    }> = [];

    for (const role of Object.keys(rolePermissions) as Role[]) {
      roles.push({
        id: role,
        name: role,
        description: roleDescriptions[role],
        permissionCount: rolePermissions[role].length,
      });
    }

    return roles;
  }),

  /**
   * الحصول على الصلاحيات لدور معين
   */
  getRolePermissions: publicProcedure
    .input(z.object({ role: z.enum(["user", "admin", "manager", "staff"]) }))
    .query(async ({ input }) => {
      const permissions = getRolePermissions(input.role);
      return permissions.map((permission) => ({
        id: permission,
        name: permission,
        description: permissionDescriptions[permission],
      }));
    }),

  /**
   * التحقق من وجود صلاحية معينة للمستخدم الحالي
   */
  hasPermission: protectedProcedure
    .input(z.object({ permission: z.string() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "يجب تسجيل الدخول أولاً",
        });
      }
      return hasPermission(ctx.user.role as Role, input.permission as Permission);
    }),

  /**
   * الحصول على جميع الصلاحيات المتاحة للمستخدم الحالي
   */
  getCurrentUserPermissions: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "يجب تسجيل الدخول أولاً",
      });
    }
    const permissions = getRolePermissions(ctx.user.role as Role);
    return permissions.map((permission) => ({
      id: permission,
      name: permission,
      description: permissionDescriptions[permission],
    }));
  }),

  /**
   * الحصول على معلومات الدور الحالي للمستخدم
   */
  getCurrentUserRole: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "يجب تسجيل الدخول أولاً",
      });
    }
    const role = ctx.user.role as Role;
    return {
      id: role,
      name: role,
      description: roleDescriptions[role],
      permissions: getRolePermissions(role),
      permissionCount: rolePermissions[role].length,
    };
  }),

  /**
   * الحصول على ملخص الأدوار والصلاحيات (للمسؤولين فقط)
   */
  getRolesSummary: publicProcedure.query(async () => {
    const summary = [];

    for (const role of Object.keys(rolePermissions) as Role[]) {
      summary.push({
        role,
        description: roleDescriptions[role],
        permissionCount: rolePermissions[role].length,
        permissions: rolePermissions[role],
      });
    }

    return summary;
  }),

  /**
   * الحصول على جميع الصلاحيات المتاحة
   */
  getAllPermissions: publicProcedure.query(async () => {
    const permissions: Array<{
      id: Permission;
      name: string;
      description: string;
      roles: Role[];
    }> = [];

    const allPermissions = new Set<Permission>();
    for (const perms of Object.values(rolePermissions)) {
      perms.forEach((p) => allPermissions.add(p));
    }

    for (const permission of Array.from(allPermissions)) {
      const rolesWithPermission: Role[] = [];
      for (const [role, perms] of Object.entries(rolePermissions)) {
        if (perms.includes(permission)) {
          rolesWithPermission.push(role as Role);
        }
      }

      permissions.push({
        id: permission,
        name: permission,
        description: permissionDescriptions[permission],
        roles: rolesWithPermission,
      });
    }

    return permissions;
  }),

  /**
   * التحقق من صلاحيات مستخدم معين (للمسؤولين فقط)
   */
  checkUserPermissions: publicProcedure
    .input(z.object({ userId: z.number(), permission: z.string() }))
    .query(async ({ input }) => {
      // هذا مثال - في الواقع ستحتاج إلى جلب بيانات المستخدم من قاعدة البيانات
      return {
        userId: input.userId,
        permission: input.permission,
        hasPermission: false, // سيتم تحديثه بناءً على دور المستخدم
      };
    }),

  /**
   * الحصول على قائمة بالصلاحيات التي يمتلكها دور معين
   */
  getPermissionsByRole: publicProcedure
    .input(z.object({ role: z.enum(["user", "admin", "manager", "staff"]) }))
    .query(async ({ input }) => {
      return {
        role: input.role,
        description: roleDescriptions[input.role],
        permissions: rolePermissions[input.role].map((p) => ({
          id: p,
          name: p,
          description: permissionDescriptions[p],
        })),
      };
    }),
});
