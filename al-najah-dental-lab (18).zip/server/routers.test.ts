import { describe, it, expect, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("Routers", () => {
  let ctx: TrpcContext;

  beforeEach(() => {
    ctx = createAuthContext();
  });

  describe("doctors", () => {
    it("should list doctors", async () => {
      const caller = appRouter.createCaller(ctx);
      const doctors = await caller.doctors.list();
      expect(Array.isArray(doctors)).toBe(true);
    });
  });

  describe("works", () => {
    it("should list works", async () => {
      const caller = appRouter.createCaller(ctx);
      const works = await caller.works.list();
      expect(Array.isArray(works)).toBe(true);
    });
  });

  describe("invoices", () => {
    it("should list invoices", async () => {
      const caller = appRouter.createCaller(ctx);
      const invoices = await caller.invoices.list();
      expect(Array.isArray(invoices)).toBe(true);
    });
  });

  describe("payments", () => {
    it("should list payments", async () => {
      const caller = appRouter.createCaller(ctx);
      const payments = await caller.payments.list();
      expect(Array.isArray(payments)).toBe(true);
    });
  });

  describe("expenses", () => {
    it("should list expenses", async () => {
      const caller = appRouter.createCaller(ctx);
      const expenses = await caller.expenses.list();
      expect(Array.isArray(expenses)).toBe(true);
    });
  });

  describe("employees", () => {
    it("should list employees", async () => {
      const caller = appRouter.createCaller(ctx);
      const employees = await caller.employees.list();
      expect(Array.isArray(employees)).toBe(true);
    });
  });

  describe("auth", () => {
    it("should get current user", async () => {
      const caller = appRouter.createCaller(ctx);
      const user = await caller.auth.me();
      expect(user).toBeDefined();
      expect(user?.id).toBe(1);
    });
  });

  describe("reports", () => {
    it("should get overdue invoices", async () => {
      const caller = appRouter.createCaller(ctx);
      const invoices = await caller.reports.getOverdueInvoices();
      expect(Array.isArray(invoices)).toBe(true);
    });

    it("should get pending works", async () => {
      const caller = appRouter.createCaller(ctx);
      const works = await caller.reports.getPendingWorks();
      expect(Array.isArray(works)).toBe(true);
    });
  });
});
