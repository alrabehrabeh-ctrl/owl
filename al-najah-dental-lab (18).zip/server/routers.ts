import { getSessionCookieOptions } from "./_core/cookies";
import { COOKIE_NAME } from "@shared/const";
import { systemRouter } from "./_core/systemRouter";
import { router, publicProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { getDb } from "./db";
import { works, doctors, workTypes, users } from "../drizzle/schema";
import { eq, desc } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { usersRouter } from "./users-router";
import { rolesRouter } from "./roles-router";
import { permissionsManagerRouter } from "./permissions-manager-router";
import { passwordChangeRouter } from "./password-change-router";
import { initRouter } from "./init-router";
import { backupRouter } from "./backup-router";
import { debtsRouter } from "./debts-router";
import { auditLogRouter } from "./audit-log-router";
import { authUsernameRouter } from "./auth-username-router";
import { activityLogRouter } from "./activity-log-router";
import { otpRouter } from "./otp-router";

export const appRouter = router({
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      console.log('[Logout] Logout mutation called');
      const cookieOptions = getSessionCookieOptions(ctx.req);
      // Clear the session cookie by setting expires to past date
      ctx.res.cookie(COOKIE_NAME, '', {
        ...cookieOptions,
        expires: new Date(0),
        maxAge: 0,
      });
      console.log('[Logout] Session cookie cleared');
      return {
        success: true,
      } as const;
    }),
    directLogin: publicProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const database = await getDb();
        if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

        // جلب المستخدم
        const targetUser = await database
          .select()
          .from(users)
          .where(eq(users.id, input.userId))
          .limit(1);

        if (targetUser.length === 0) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "المستخدم غير موجود",
          });
        }

        try {
          // استيراد SDK
          const { sdk } = await import("./_core/sdk");
          const { ONE_YEAR_MS } = await import("../shared/const");

          // إنشاء جلسة جديدة
          const sessionToken = await sdk.createSessionToken(targetUser[0].openId, {
            name: targetUser[0].name || "",
            expiresInMs: ONE_YEAR_MS,
          });

          // تعيين ملف الجلسة
          const cookieOptions = getSessionCookieOptions(ctx.req);
          ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

          return { success: true, user: targetUser[0] };
        } catch (error) {
          console.error("[DirectLogin] Failed to create session", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "فشل تسجيل الدخول",
          });
        }
      }),
  }),

  // ============ Doctors Router ============
  doctors: router({
    list: publicProcedure.query(async () => {
      return db.getAllDoctors();
    }),

    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getDoctorById(input.id);
    }),

    create: publicProcedure
      .input(
        z.object({
          name: z.string().min(1),
          email: z.string().email().or(z.literal("")).optional(),
          phone: z.string().optional(),
          specialization: z.string().optional(),
          clinic: z.string().optional(),
          address: z.string().optional(),
          taxId: z.string().optional(),
          bankAccount: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.createDoctor(input);
      }),

    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          email: z.string().email().or(z.literal("")).optional(),
          phone: z.string().optional(),
          specialization: z.string().optional(),
          clinic: z.string().optional(),
          address: z.string().optional(),
          taxId: z.string().optional(),
          bankAccount: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return db.updateDoctor(id, data);
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const database = await getDb();
        if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        return database.delete(doctors).where(eq(doctors.id, input.id));
      }),


  }),

  // ============ Works Router ============
  works: router({
    list: publicProcedure
      .query(async () => {
        return db.getAllWorks();
      }),

    listWithTypes: publicProcedure.query(async () => {
      return db.getAllWorksWithTypes();
    }),

    listWithDoctorAndTypes: publicProcedure.query(async () => {
      return db.getAllWorksWithDoctorAndTypes();
    }),

    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getWorkById(input.id);
    }),

    getByDoctor: publicProcedure.input(z.object({ doctorId: z.number() })).query(async ({ input }) => {
      return db.getWorksByDoctor(input.doctorId);
    }),

    getByDoctorWithDetails: publicProcedure.input(z.object({ doctorId: z.number() })).query(async ({ input }) => {
      const db_instance = await getDb();
      if (!db_instance) return [];
      
      const result = await db_instance
        .select({
          id: works.id,
          doctorId: works.doctorId,
          doctorName: doctors.name,
          workTypeId: works.workTypeId,
          workTypeName: workTypes.name,
          quantity: works.quantity,
          unitPrice: works.unitPrice,
          totalPrice: works.totalPrice,
          status: works.status,
          dueDate: works.dueDate,
          receptionDate: works.receptionDate,
          patientName: works.patientName,
          description: works.description,
          notes: works.notes,
          createdAt: works.createdAt,
          updatedAt: works.updatedAt,
        })
        .from(works)
        .leftJoin(doctors, eq(works.doctorId, doctors.id))
        .leftJoin(workTypes, eq(works.workTypeId, workTypes.id))
        .where(eq(works.doctorId, input.doctorId))
        .orderBy(desc(works.createdAt));
      
      return result;
    }),

    create: publicProcedure
      .input(
        z.object({
          doctorId: z.number(),
          workTypeId: z.number(),
          patientName: z.string().optional(),
          description: z.string().optional(),
          quantity: z.number().default(1),
          unitPrice: z.string(),
          totalPrice: z.string(),
          dueDate: z.date().optional(),
          receptionDate: z.date().optional(),
          status: z.enum(["pending", "in_progress", "completed", "delivered"]).optional(),
          notes: z.string().optional(),
          toothNumbers: z.union([z.array(z.string()), z.string()]).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const processedInput = {
          ...input,
          toothNumbers: Array.isArray(input.toothNumbers) 
            ? JSON.stringify(input.toothNumbers)
            : input.toothNumbers
        };
        return db.createWork(processedInput);
      }),

    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          patientName: z.string().optional(),
          status: z.enum(["pending", "in_progress", "completed", "delivered"]).optional(),
          completedDate: z.date().optional(),
          dueDate: z.date().optional(),
          receptionDate: z.date().optional(),
          description: z.string().optional(),
          quantity: z.number().optional(),
          unitPrice: z.string().optional(),
          totalPrice: z.string().optional(),
          notes: z.string().optional(),
          toothNumbers: z.string().optional(),
          workTypeId: z.number().optional(),
          doctorId: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return db.updateWork(id, data);
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deleteWork(input.id);
      })
  }),

  // ============ Invoices Router ============
  invoices: router({
    list: publicProcedure.query(async () => {
      return db.getAllInvoices();
    }),

    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getInvoiceById(input.id);
    }),

    getByDoctor: publicProcedure.input(z.object({ doctorId: z.number() })).query(async ({ input }) => {
      return db.getInvoicesByDoctor(input.doctorId);
    }),

    getItems: publicProcedure.input(z.object({ invoiceId: z.number() })).query(async ({ input }) => {
      return db.getInvoiceItems(input.invoiceId);
    }),

    create: publicProcedure
      .input(
        z.object({
          invoiceNumber: z.string(),
          doctorId: z.number(),
          subtotal: z.string(),
          taxRate: z.string().optional(),
          taxAmount: z.string().optional(),
          total: z.string(),
          invoiceDate: z.date(),
          dueDate: z.date(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.createInvoice({
          ...input,
          paidAmount: "0",
          remainingAmount: input.total,
          status: "sent",
        });
      }),

    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.enum(["sent", "paid", "partial", "overdue", "cancelled"]).optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return db.updateInvoice(id, data);
      }),

    createAutoInvoices: publicProcedure.mutation(async () => {
      return db.createAutoInvoices();
    }),
  }),

  // ============ Payments Router ============
  payments: router({
    list: publicProcedure.query(async () => {
      return db.getAllPayments();
    }),

    getByInvoice: publicProcedure.input(z.object({ invoiceId: z.number() })).query(async ({ input }) => {
      return db.getPaymentsByInvoice(input.invoiceId);
    }),

    create: publicProcedure
      .input(
        z.object({
          invoiceId: z.number(),
          doctorId: z.number(),
          amount: z.string(),
          paymentMethod: z.enum(["cash", "check", "bank_transfer", "credit_card", "other"]),
          paymentDate: z.date(),
          referenceNumber: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.createPayment(input);
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deletePayment(input.id);
      }),

    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          amount: z.string(),
          paymentMethod: z.enum(["cash", "check", "bank_transfer", "credit_card", "other"]),
          referenceNumber: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.updatePayment(input.id, {
          amount: input.amount,
          paymentMethod: input.paymentMethod,
          referenceNumber: input.referenceNumber,
        });
      }),
  }),

  // ============ Import Router ============
  import: router({
    importWorks: publicProcedure
      .input(
        z.object({
          works: z.array(
            z.object({
              doctorName: z.string(),
              patientName: z.string().optional(),
              description: z.string().optional(),
              quantity: z.number().default(1),
              unitPrice: z.number().default(0),
              totalPrice: z.number(),
              status: z.enum(["pending", "in_progress", "completed", "delivered"]).default("pending"),
              receptionDate: z.date(),
              dueDate: z.date(),
              toothNumbers: z.string().optional(),
              notes: z.string().optional(),
            })
          ),
          deleteExisting: z.boolean().default(false),
        })
      )
      .mutation(async ({ input }) => {
        const db_instance = await getDb();
        if (!db_instance) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        
        const results = {
          imported: 0,
          failed: 0,
          errors: [] as string[],
          createdDoctors: 0,
          createdWorkTypes: 0,
        };
        
        // خريطة لتخزين الأطباء المُنشأة
        const doctorMap = new Map<string, number>();
        // خريطة لتخزين أنواع العمل المُنشأة
        const workTypeMap = new Map<string, number>();
        
        // معالجة كل عمل
        for (let i = 0; i < input.works.length; i++) {
          const work = input.works[i];
          
          try {
            // ============ معالجة الطبيب ============
            const doctorNameTrimmed = work.doctorName.trim();
            let doctorId: number;
            
            // البحث عن الطبيب في الخريطة أولاً
            if (doctorMap.has(doctorNameTrimmed)) {
              doctorId = doctorMap.get(doctorNameTrimmed)!;
            } else {
              // البحث عن الطبيب في قاعدة البيانات
              const existingDoctor = await db_instance
                .select()
                .from(doctors)
                .where(eq(doctors.name, doctorNameTrimmed))
                .limit(1);
              
              if (existingDoctor.length > 0) {
                doctorId = existingDoctor[0].id;
                doctorMap.set(doctorNameTrimmed, doctorId);
              } else {
                // إنشاء طبيب جديد
                const result = await db_instance.insert(doctors).values({
                  name: doctorNameTrimmed,
                });
                
                // الحصول على ID من النتيجة
                const insertedDoctor = await db_instance
                  .select()
                  .from(doctors)
                  .where(eq(doctors.name, doctorNameTrimmed))
                  .limit(1);
                
                if (insertedDoctor.length === 0) {
                  throw new Error("فشل إنشاء الطبيب");
                }
                
                doctorId = insertedDoctor[0].id;
                doctorMap.set(doctorNameTrimmed, doctorId);
                results.createdDoctors++;
              }
            }
            
            // ============ معالجة نوع العمل ============
            const workTypeName = work.description?.trim() || "عام";
            let workTypeId: number;
            
            // البحث عن نوع العمل في الخريطة أولاً
            if (workTypeMap.has(workTypeName)) {
              workTypeId = workTypeMap.get(workTypeName)!;
            } else {
              // البحث عن نوع العمل في قاعدة البيانات
              const existingWorkType = await db_instance
                .select()
                .from(workTypes)
                .where(eq(workTypes.name, workTypeName))
                .limit(1);
              
              if (existingWorkType.length > 0) {
                workTypeId = existingWorkType[0].id;
                workTypeMap.set(workTypeName, workTypeId);
              } else {
                // إنشاء نوع عمل جديد
                const result = await db_instance.insert(workTypes).values({
                  name: workTypeName,
                });
                
                // الحصول على ID من النتيجة
                const insertedWorkType = await db_instance
                  .select()
                  .from(workTypes)
                  .where(eq(workTypes.name, workTypeName))
                  .limit(1);
                
                if (insertedWorkType.length === 0) {
                  throw new Error("فشل إنشاء نوع العمل");
                }
                
                workTypeId = insertedWorkType[0].id;
                workTypeMap.set(workTypeName, workTypeId);
                results.createdWorkTypes++;
              }
            }
            
            // إدراج العمل
            await db_instance.insert(works).values({
              doctorId,
              workTypeId,
              description: work.description || "عام",
              quantity: work.quantity,
              unitPrice: String(work.unitPrice),
              totalPrice: String(work.totalPrice),
              status: work.status,
              dueDate: work.dueDate,
              receptionDate: work.receptionDate,
              patientName: work.patientName || "-",
              toothNumbers: work.toothNumbers || "-",
              notes: work.notes || "",
            });
            
            results.imported++;
          } catch (err) {
            results.failed++;
            results.errors.push(`الصف ${i + 2}: ${err instanceof Error ? err.message : "خطأ غير معروف"}`);
          }
        }
        
        return results;
      }),
  }),

  // ============ Expenses Router ============
  expenses: router({
    list: publicProcedure.query(async () => {
      return db.getAllExpenses();
    }),

    getByCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        return db.getExpensesByCategory(input.category);
      }),

    create: publicProcedure
      .input(
        z.object({
          category: z.enum(["salary", "rent", "materials", "utilities", "maintenance", "other"]),
          description: z.string(),
          amount: z.string(),
          vendor: z.string().optional(),
          expenseDate: z.date(),
          paymentMethod: z.enum(["cash", "check", "bank_transfer", "credit_card", "other"]),
          referenceNumber: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.createExpense(input);
      }),

    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          category: z.enum(["salary", "rent", "materials", "utilities", "maintenance", "other"]),
          description: z.string(),
          amount: z.string(),
          vendor: z.string().optional(),
          expenseDate: z.date(),
          paymentMethod: z.enum(["cash", "check", "bank_transfer", "credit_card", "other"]),
          referenceNumber: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return db.updateExpense(id, data);
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deleteExpense(input.id);
      }),
  }),

  // ============ Employees Router ============
  employees: router({
    list: publicProcedure.query(async () => {
      return db.getAllEmployees();
    }),

    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getEmployeeById(input.id);
    }),

    create: publicProcedure
      .input(
        z.object({
          name: z.string().min(1),
          email: z.string().email().optional(),
          phone: z.string().optional(),
          position: z.string(),
          salary: z.string(),
          hireDate: z.date(),
          bankAccount: z.string().optional(),
          taxId: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.createEmployee(input);
      }),

    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          email: z.string().email().optional(),
          phone: z.string().optional(),
          position: z.string().optional(),
          salary: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return db.updateEmployee(id, data);
      }),
  }),

  // ============ Salaries Router ============
  salaries: router({
    getByEmployee: publicProcedure
      .input(z.object({ employeeId: z.number() }))
      .query(async ({ input }) => {
        return db.getSalariesByEmployee(input.employeeId);
      }),

    getByMonth: publicProcedure.input(z.object({ month: z.string() })).query(async ({ input }) => {
      return db.getSalariesByMonth(input.month);
    }),

    create: publicProcedure
      .input(
        z.object({
          employeeId: z.number(),
          month: z.string(),
          baseSalary: z.string(),
          deductions: z.string().optional(),
          bonuses: z.string().optional(),
          netSalary: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        return db.createSalary({
          ...input,
          status: "pending",
        });
      }),

    markAsPaid: publicProcedure
      .input(
        z.object({
          id: z.number(),
          paymentDate: z.date(),
          paymentMethod: z.enum(["cash", "check", "bank_transfer", "credit_card", "other"]),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return db.updateSalary(id, {
          ...data,
          status: "paid",
        });
      }),
  }),

  // ============ Alerts Router ============
  alerts: router({
    getUnread: publicProcedure.query(async () => {
      return db.getUnreadAlerts();
    }),

    markAsRead: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.markAlertAsRead(input.id);
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deleteAlert(input.id);
      }),
  }),

  // ============ Documents Router ============
  documents: router({
    getByRelated: publicProcedure
      .input(
        z.object({
          relatedType: z.string(),
          relatedId: z.number(),
        })
      )
      .query(async ({ input }) => {
        return db.getDocumentsByRelated(input.relatedType, input.relatedId);
      }),

    create: publicProcedure
      .input(
        z.object({
          fileName: z.string(),
          fileUrl: z.string(),
          fileSize: z.number().optional(),
          mimeType: z.string().optional(),
          documentType: z.enum(["work_image", "invoice", "contract", "payment_receipt", "other"]),
          relatedType: z.enum(["work", "invoice", "doctor", "employee"]).optional(),
          relatedId: z.number().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.createDocument({
          ...input,
          uploadedBy: ctx.user?.id,
        });
      }),
  }),

  // ============ Payment Works Router ============
  paymentWorks: router({
    getByPayment: publicProcedure
      .input(z.object({ paymentId: z.number() }))
      .query(async ({ input }) => {
        return db.getPaymentWorksByPayment(input.paymentId);
      }),

    getByWork: publicProcedure
      .input(z.object({ workId: z.number() }))
      .query(async ({ input }) => {
        return db.getPaymentWorksByWork(input.workId);
      }),

    create: publicProcedure
      .input(
        z.object({
          paymentId: z.number(),
          workId: z.number(),
          amount: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        return db.createPaymentWork(input);
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deletePaymentWork(input.id);
      }),
  }),

  // ============ Financial Reports Router ============
  reports: router({
    getTotalRevenue: publicProcedure
      .input(
        z.object({
          startDate: z.date(),
          endDate: z.date(),
        })
      )
      .query(async ({ input }) => {
        return db.getTotalRevenue(input.startDate, input.endDate);
      }),

    getTotalReceivables: publicProcedure
      .query(async () => {
        return db.getTotalReceivables();
      }),

    getTotalExpenses: publicProcedure
      .input(
        z.object({
          startDate: z.date(),
          endDate: z.date(),
        })
      )
      .query(async ({ input }) => {
        return db.getTotalExpenses(input.startDate, input.endDate);
      }),

    getOverdueInvoices: publicProcedure.query(async () => {
      return db.getOverdueInvoices();
    }),

    getPendingWorks: publicProcedure.query(async () => {
      return db.getPendingWorks();
    }),

    getOverdueWorks: publicProcedure.query(async () => {
      return db.getOverdueWorks();
    }),

    getOverdueWorksCount: publicProcedure.query(async () => {
      return db.getOverdueWorksCount();
    }),

    getMonthlyRevenue: publicProcedure
      .input(z.object({ year: z.number() }))
      .query(async ({ input }) => {
        return db.getMonthlyRevenue(input.year);
      }),

    getMonthlyExpenses: publicProcedure
      .input(z.object({ year: z.number() }))
      .query(async ({ input }) => {
        return db.getMonthlyExpenses(input.year);
      }),
  }),

  // ============ Monthly Invoices Router ============
  monthlyInvoices: router({
    getByDoctorAndDate: publicProcedure
      .input(
        z.object({
          doctorId: z.number(),
          year: z.number(),
          month: z.number(),
        })
      )
      .query(async ({ input }) => {
        return db.getMonthlyInvoicesByDoctorAndDate(input.doctorId, input.year, input.month);
      }),

    getSummary: publicProcedure
      .input(
        z.object({
          doctorId: z.number(),
          year: z.number(),
          month: z.number(),
        })
      )
      .query(async ({ input }) => {
        return db.getMonthlyInvoiceSummary(input.doctorId, input.year, input.month);
      }),
  }),

  invoicePayments: router({
    getPaymentDetails: publicProcedure
      .input(z.object({ invoiceId: z.number() }))
      .query(async ({ input }) => {
        return db.getInvoicePaymentDetails(input.invoiceId);
      }),

    getDoctorMonthlySummary: publicProcedure
      .input(
        z.object({
          doctorId: z.number(),
          year: z.number(),
          month: z.number(),
        })
      )
      .query(async ({ input }) => {
        return db.getDoctorMonthlyPaymentSummary(input.doctorId, input.year, input.month);
      }),

    getMonthlyPaymentsSummary: publicProcedure
      .input(
        z.object({
          year: z.number(),
          month: z.number(),
        })
      )
      .query(async ({ input }) => {
        return db.getMonthlyPaymentsSummary(input.year, input.month);
       }),
  }),

  // ============ Work Types Router ============
  workTypes: router({
    list: publicProcedure.query(async () => {
      return db.getAllWorkTypes();
    }),
  }),

  // ============ Forecasts Router ============
  forecasts: router({
    getHistoricalData: publicProcedure
      .input(
        z.object({
          monthsBack: z.number().default(12).optional(),
        })
      )
      .query(async ({ input }) => {
        return db.getMonthlyRevenueHistory(input.monthsBack || 12);
      }),

    getOverallForecast: publicProcedure
      .input(
        z.object({
          monthsAhead: z.number().default(3).optional(),
        })
      )
      .query(async ({ input }) => {
        return db.getForecastedRevenue(input.monthsAhead || 3);
      }),

    getByType: publicProcedure
      .input(
        z.object({
          monthsAhead: z.number().default(3).optional(),
        })
      )
      .query(async ({ input }) => {
        return db.getForecastedRevenueByType(input.monthsAhead || 3);
      }),

    getByDoctor: publicProcedure
      .input(
        z.object({
          monthsAhead: z.number().default(3).optional(),
        })
      )
      .query(async ({ input }) => {
        return db.getForecastedRevenueByDoctor(input.monthsAhead || 3);
      }),

  }),

  // ============ Monthly Reports Router ============
  monthlyReports: router({
    getMonthlyReport: publicProcedure
      .input(
        z.object({
          year: z.number(),
          month: z.number(),
        })
      )
      .query(async ({ input }) => {
        return db.getMonthlyReport(input.year, input.month);
      }),

    getDoctorMonthlyReport: publicProcedure
      .input(
        z.object({
          doctorId: z.number(),
          year: z.number(),
          month: z.number(),
        })
      )
      .query(async ({ input }) => {
        return db.getDoctorMonthlyReport(input.doctorId, input.year, input.month);
      }),

    generateMonthlyReports: publicProcedure
      .input(
        z.object({
          year: z.number(),
          month: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        return db.generateMonthlyReports(input.year, input.month);
      }),
  }),

  // ============ Currencies Router ============
  currencies: router({
    getAll: publicProcedure.query(async () => {
      return db.getAllCurrencies();
    }),

    getDefault: publicProcedure.query(async () => {
      return db.getDefaultCurrency();
    }),

    getExchangeRate: publicProcedure
      .input(
        z.object({
          fromCurrencyId: z.number(),
          toCurrencyId: z.number(),
        })
      )
      .query(async ({ input }) => {
        return db.getExchangeRate(input.fromCurrencyId, input.toCurrencyId);
      }),

    convertAmount: publicProcedure
      .input(
        z.object({
          amount: z.number(),
          fromCurrencyId: z.number(),
          toCurrencyId: z.number(),
        })
      )
      .query(async ({ input }) => {
        const converted = await db.convertCurrency(
          input.amount,
          input.fromCurrencyId,
          input.toCurrencyId
        );
        return {
          originalAmount: input.amount,
          convertedAmount: converted,
        };
      }),

    add: publicProcedure
      .input(
        z.object({
          code: z.string().min(1),
          name: z.string().min(1),
          symbol: z.string().min(1),
          isDefault: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.addCurrency(input.code, input.name, input.symbol, input.isDefault);
      }),

    update: publicProcedure
      .input(
        z.object({
          currencyId: z.number(),
          name: z.string().optional(),
          symbol: z.string().optional(),
          isDefault: z.boolean().optional(),
          isActive: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { currencyId, ...updates } = input;
        return db.updateCurrency(currencyId, updates);
      }),

    setExchangeRate: publicProcedure
      .input(
        z.object({
          fromCurrencyId: z.number(),
          toCurrencyId: z.number(),
          rate: z.string(),
          date: z.date().optional(),
          source: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.upsertExchangeRate(
          input.fromCurrencyId,
          input.toCurrencyId,
          input.rate,
          input.date || new Date(),
          input.source
        );
      }),

    calculateConversion: publicProcedure
      .input(
        z.object({
          amount: z.number(),
          fromCurrencyId: z.number(),
          toCurrencyId: z.number(),
        })
      )
      .query(async ({ input }) => {
        return db.calculatePriceInSecondCurrency(
          input.amount,
          input.fromCurrencyId,
          input.toCurrencyId
        );
      }),

    syncExchangeRates: publicProcedure.mutation(async () => {
      const { syncExchangeRates } = await import("./exchange-rate-sync");
      const success = await syncExchangeRates();
      return {
        success,
        message: success ? "Exchange rates synced successfully" : "Failed to sync exchange rates",
      };
    }),

    getLastUpdateTime: publicProcedure.query(async () => {
      const { getLastExchangeRateUpdateTime } = await import("./exchange-rate-sync");
      const lastUpdate = await getLastExchangeRateUpdateTime();
      return {
        lastUpdate,
        status: lastUpdate ? "synced" : "not_synced",
      };
    }),
  }),

  // ============ Works Currency Router ============
  worksCurrency: router({
    updateWithConversion: publicProcedure
      .input(
        z.object({
          workId: z.number(),
          currencyId: z.number(),
          totalPrice: z.number(),
          secondCurrencyId: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.updateWorkWithCurrencyConversion(
          input.workId,
          input.currencyId,
          input.totalPrice,
          input.secondCurrencyId || 2
        );
      }),

    getWithBothCurrencies: publicProcedure
      .input(z.object({ workId: z.number() }))
      .query(async ({ input }) => {
        return db.getWorkWithBothCurrencies(input.workId);
      }),
  }),

  // ============ Invoices Currency Router ============
  invoicesCurrency: router({
    updateWithConversion: publicProcedure
      .input(
        z.object({
          invoiceId: z.number(),
          currencyId: z.number(),
          totalPrice: z.number(),
          secondCurrencyId: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.updateInvoiceWithCurrencyConversion(
          input.invoiceId,
          input.currencyId,
          input.totalPrice,
          input.secondCurrencyId || 2
        );
      }),

    getWithBothCurrencies: publicProcedure
      .input(z.object({ invoiceId: z.number() }))
      .query(async ({ input }) => {
        return db.getInvoiceWithBothCurrencies(input.invoiceId);
      }),
  }),
  
  // ============ System Router ============
  system: systemRouter,

  // ============ Users Router ============
  users: usersRouter,


  // ============ Audit Log Router ============
  auditLog: auditLogRouter,

  // ============ Auth Username Router ============
  authUsername: authUsernameRouter,

  // ============ Activity Log Router ============
  activityLog: activityLogRouter,

  // ============ Roles Router ============
  roles: rolesRouter,

  // ============ Permissions Manager Router ============
  permissionsManager: permissionsManagerRouter,

  // ============ Password Change Router ============
  passwordChange: passwordChangeRouter,

  // ============ Init Router ============
  init: initRouter,

  // ============ Backup Router ============
  backup: backupRouter,

  // ============ Debts Router ============
  debts: debtsRouter,

  // ============ OTP Router (2FA) ============
  otp: otpRouter,
});
export type AppRouter = typeof appRouter;
