import { describe, expect, it } from "vitest";

// نسخة من الدالة للاختبار
function safeJsonParse(jsonString: string | null | undefined, defaultValue: any = []) {
  if (!jsonString) return defaultValue;
  try {
    const parsed = JSON.parse(jsonString);
    return Array.isArray(parsed) ? parsed : defaultValue;
  } catch (error) {
    console.warn("Failed to parse JSON:", jsonString, error);
    return defaultValue;
  }
}

describe("safeJsonParse utility function", () => {
  it("should parse valid JSON array", () => {
    const result = safeJsonParse('["T1", "T2", "T3"]');
    expect(result).toEqual(["T1", "T2", "T3"]);
  });

  it("should return default value for null", () => {
    const result = safeJsonParse(null);
    expect(result).toEqual([]);
  });

  it("should return default value for undefined", () => {
    const result = safeJsonParse(undefined);
    expect(result).toEqual([]);
  });

  it("should return default value for empty string", () => {
    const result = safeJsonParse("");
    expect(result).toEqual([]);
  });

  it("should handle invalid JSON gracefully", () => {
    const result = safeJsonParse("-");
    expect(result).toEqual([]);
  });

  it("should handle malformed JSON", () => {
    const result = safeJsonParse("{ invalid json }");
    expect(result).toEqual([]);
  });

  it("should return default value if parsed result is not an array", () => {
    const result = safeJsonParse('{"key": "value"}');
    expect(result).toEqual([]);
  });

  it("should use custom default value", () => {
    const customDefault = ["custom"];
    const result = safeJsonParse("-", customDefault);
    expect(result).toEqual(customDefault);
  });

  it("should handle empty array", () => {
    const result = safeJsonParse("[]");
    expect(result).toEqual([]);
  });

  it("should handle array with various tooth numbers", () => {
    const result = safeJsonParse('["T1R", "T2R", "T3R", "T4R", "T5R", "T6R", "T7R"]');
    expect(result).toHaveLength(7);
    expect(result[0]).toBe("T1R");
  });
});
