import { describe, it, expect } from "vitest";
import { DEFAULT_ROLE_PASSWORDS, hashPassword, verifyPassword } from "./password-manager";

describe("Security Fixes - Strong Default Passwords", () => {
  it("should have strong default passwords for all roles", () => {
    const roles = ["admin", "manager", "staff", "user"];
    for (const role of roles) {
      const password = DEFAULT_ROLE_PASSWORDS[role];
      expect(password).toBeDefined();
      expect(password.length).toBeGreaterThanOrEqual(16);
      // Check for complexity: uppercase, lowercase, numbers, special chars
      expect(/[A-Z]/.test(password)).toBe(true); // Uppercase
      expect(/[a-z]/.test(password)).toBe(true); // Lowercase
      expect(/[0-9]/.test(password)).toBe(true); // Numbers
      expect(/[@$#&!]/.test(password)).toBe(true); // Special characters
    }
  });

  it("should not have weak passwords like 'admin', '1985', '0000'", () => {
    const weakPasswords = ["admin", "1985", "0000"];
    const allPasswords = Object.values(DEFAULT_ROLE_PASSWORDS);
    for (const weak of weakPasswords) {
      expect(allPasswords).not.toContain(weak);
    }
  });

  it("should have unique passwords for each role", () => {
    const passwords = Object.values(DEFAULT_ROLE_PASSWORDS);
    const uniquePasswords = new Set(passwords);
    expect(passwords.length).toBe(uniquePasswords.size);
  });

  it("should hash passwords correctly", () => {
    const password = "TestPassword@2024#Secure";
    const hash = hashPassword(password);
    expect(hash).toBeDefined();
    expect(hash.length).toBeGreaterThan(0);
    expect(hash).not.toBe(password); // Hash should not equal original
  });

  it("should verify correct passwords", () => {
    const password = "TestPassword@2024#Secure";
    const hash = hashPassword(password);
    expect(verifyPassword(password, hash)).toBe(true);
  });

  it("should reject incorrect passwords", () => {
    const password = "TestPassword@2024#Secure";
    const hash = hashPassword(password);
    expect(verifyPassword("WrongPassword", hash)).toBe(false);
  });

  it("should be case-sensitive for passwords", () => {
    const password = "TestPassword@2024#Secure";
    const hash = hashPassword(password);
    expect(verifyPassword("testpassword@2024#secure", hash)).toBe(false);
    expect(verifyPassword("TESTPASSWORD@2024#SECURE", hash)).toBe(false);
  });

  it("should have different hashes for different passwords", () => {
    const password1 = "Password@2024#One";
    const password2 = "Password@2024#Two";
    const hash1 = hashPassword(password1);
    const hash2 = hashPassword(password2);
    expect(hash1).not.toBe(hash2);
  });

  it("should generate consistent hashes for same password", () => {
    const password = "ConsistentPassword@2024#Test";
    const hash1 = hashPassword(password);
    const hash2 = hashPassword(password);
    expect(hash1).toBe(hash2);
  });

  it("should have minimum 16 characters for all default passwords", () => {
    const roles = ["admin", "manager", "staff", "user"];
    for (const role of roles) {
      const password = DEFAULT_ROLE_PASSWORDS[role];
      expect(password.length).toBeGreaterThanOrEqual(16);
    }
  });

  it("should not contain common weak patterns", () => {
    const weakPatterns = [
      /^admin/i,
      /^password/i,
      /^123456/,
      /^000000/,
      /^111111/,
      /^qwerty/i,
      /^abc123/i,
    ];
    
    const allPasswords = Object.values(DEFAULT_ROLE_PASSWORDS);
    for (const password of allPasswords) {
      for (const pattern of weakPatterns) {
        expect(pattern.test(password)).toBe(false);
      }
    }
  });
});
