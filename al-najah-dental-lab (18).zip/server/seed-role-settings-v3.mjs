import crypto from "crypto";
import mysql from "mysql2/promise";

// دالة تشفير كلمات المرور
function hashPassword(password) {
  return crypto.createHash("sha256").update(password).digest("hex");
}

// البيانات الافتراضية
const DEFAULT_ROLE_PASSWORDS = {
  user: "0000",
  admin: "admin",
  manager: "1985",
  staff: "0000",
};

async function seedRoleSettings() {
  let connection;
  try {
    // الاتصال بقاعدة البيانات من DATABASE_URL
    const dbUrl = process.env.DATABASE_URL;
    if (!dbUrl) {
      throw new Error("DATABASE_URL غير معرّف");
    }

    // تحليل DATABASE_URL
    const url = new URL(dbUrl);
    const config = {
      host: url.hostname,
      user: url.username,
      password: url.password,
      database: url.pathname.slice(1),
      port: url.port || 4000,
      ssl: "Amazon RDS",
      enableKeepAlive: true,
    };

    console.log(`الاتصال بـ: ${config.host}:${config.port}/${config.database}`);

    // الاتصال بقاعدة البيانات
    connection = await mysql.createConnection(config);
    console.log("✓ تم الاتصال بقاعدة البيانات");

    // حذف البيانات القديمة
    await connection.execute("DELETE FROM roleSettings");
    console.log("✓ تم حذف البيانات القديمة");

    // إدراج البيانات الافتراضية
    for (const [role, password] of Object.entries(DEFAULT_ROLE_PASSWORDS)) {
      const passwordHash = hashPassword(password);
      await connection.execute(
        "INSERT INTO roleSettings (role, passwordHash, isActive, createdAt, lastModifiedAt) VALUES (?, ?, ?, NOW(), NOW())",
        [role, passwordHash, "true"]
      );
      console.log(`✓ تم إضافة إعدادات الدور: ${role}`);
    }

    console.log("\n✅ تم تهيئة جدول roleSettings بنجاح!");
    console.log("\nالأدوار والكلمات المرور الافتراضية:");
    for (const [role, password] of Object.entries(DEFAULT_ROLE_PASSWORDS)) {
      console.log(`  - ${role}: ${password}`);
    }
  } catch (error) {
    console.error("❌ حدث خطأ:", error.message);
    console.error(error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

// تشغيل السكريبت
seedRoleSettings();
