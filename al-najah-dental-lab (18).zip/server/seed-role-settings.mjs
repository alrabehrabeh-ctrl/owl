import { createConnection } from "mysql2/promise";
import crypto from "crypto";

// دالة تشفير كلمات المرور
function hashPassword(password) {
  return crypto.createHash("sha256").update(password).digest("hex");
}

// البيانات الافتراضية
const DEFAULT_ROLE_PASSWORDS = {
  user: "0000",
  admin: "admin",
  manager: "1985",
  staff: "0000",
};

async function seedRoleSettings() {
  let connection;
  try {
    // الاتصال بقاعدة البيانات
    connection = await createConnection({
      host: process.env.DB_HOST || "localhost",
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "",
      database: process.env.DB_NAME || "al_najah_dental",
    });

    console.log("✓ تم الاتصال بقاعدة البيانات");

    // حذف البيانات القديمة (اختياري)
    await connection.execute("DELETE FROM roleSettings");
    console.log("✓ تم حذف البيانات القديمة");

    // إدراج البيانات الافتراضية
    for (const [role, password] of Object.entries(DEFAULT_ROLE_PASSWORDS)) {
      const passwordHash = hashPassword(password);
      await connection.execute(
        "INSERT INTO roleSettings (role, passwordHash, isActive, createdAt, lastModifiedAt) VALUES (?, ?, ?, NOW(), NOW())",
        [role, passwordHash, "true"]
      );
      console.log(`✓ تم إضافة إعدادات الدور: ${role}`);
    }

    console.log("\n✅ تم تهيئة جدول roleSettings بنجاح!");
    console.log("\nالأدوار والكلمات المرور الافتراضية:");
    for (const [role, password] of Object.entries(DEFAULT_ROLE_PASSWORDS)) {
      console.log(`  - ${role}: ${password}`);
    }
  } catch (error) {
    console.error("❌ حدث خطأ:", error.message);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

// تشغيل السكريبت
seedRoleSettings();
