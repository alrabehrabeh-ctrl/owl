import { describe, expect, it } from "vitest";
import { getAllWorksWithDoctorAndTypes, getAllWorksWithTypes } from "./db";

describe("toothNumbers in work retrieval", () => {
  it("should include toothNumbers in getAllWorksWithDoctorAndTypes", async () => {
    const works = await getAllWorksWithDoctorAndTypes(1);
    
    if (works.length > 0) {
      const work = works[0];
      expect(work).toHaveProperty("toothNumbers");
      // toothNumbers يمكن أن يكون null أو JSON string
      if (work.toothNumbers) {
        expect(typeof work.toothNumbers).toBe("string");
      }
    }
  });

  it("should include toothNumbers in getAllWorksWithTypes", async () => {
    const works = await getAllWorksWithTypes(1);
    
    if (works.length > 0) {
      const work = works[0];
      expect(work).toHaveProperty("toothNumbers");
      // toothNumbers يمكن أن يكون null أو JSON string
      if (work.toothNumbers) {
        expect(typeof work.toothNumbers).toBe("string");
      }
    }
  });

  it("should parse toothNumbers correctly", async () => {
    const works = await getAllWorksWithDoctorAndTypes(1);
    
    if (works.length > 0) {
      const work = works[0];
      if (work.toothNumbers && work.toothNumbers !== "[]") {
        const parsed = JSON.parse(work.toothNumbers);
        expect(Array.isArray(parsed)).toBe(true);
      }
    }
  });
});
