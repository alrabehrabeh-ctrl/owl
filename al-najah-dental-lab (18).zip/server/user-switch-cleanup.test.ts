import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import type { Database } from "drizzle-orm/mysql-core";

describe("User Switch Data Cleanup - Frontend Fix", () => {
  let db: Database | null = null;
  let testUserIds: number[] = [];

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // إنشاء مستخدمي اختبار
    const user1 = await db
      .insert(users)
      .values({
        openId: `test-cleanup-user-1-${Date.now()}`,
        name: "مستخدم الاختبار 1",
        email: `test-cleanup-1-${Date.now()}@test.com`,
        loginMethod: "test",
        role: "user",
      })
      .returning({ id: users.id });

    const user2 = await db
      .insert(users)
      .values({
        openId: `test-cleanup-user-2-${Date.now()}`,
        name: "مستخدم الاختبار 2",
        email: `test-cleanup-2-${Date.now()}@test.com`,
        loginMethod: "test",
        role: "user",
      })
      .returning({ id: users.id });

    const admin = await db
      .insert(users)
      .values({
        openId: `test-cleanup-admin-${Date.now()}`,
        name: "مسؤول الاختبار",
        email: `test-cleanup-admin-${Date.now()}@test.com`,
        loginMethod: "test",
        role: "admin",
      })
      .returning({ id: users.id });

    testUserIds = [(user1 as any)[0].id, (user2 as any)[0].id, (admin as any)[0].id];
  });

  afterAll(async () => {
    if (!db) return;
    for (const userId of testUserIds) {
      await db.delete(users).where(eq(users.id, userId));
    }
  });

  describe("localStorage Cleanup Simulation", () => {
    it("should verify user data exists before switch", async () => {
      if (!db) throw new Error("Database not initialized");

      const user1 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      expect(user1.length).toBe(1);
      expect(user1[0].name).toBe("مستخدم الاختبار 1");
      expect(user1[0].role).toBe("user");
    });

    it("should verify second user data exists", async () => {
      if (!db) throw new Error("Database not initialized");

      const user2 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[1]))
        .limit(1);

      expect(user2.length).toBe(1);
      expect(user2[0].name).toBe("مستخدم الاختبار 2");
      expect(user2[0].role).toBe("user");
    });

    it("should verify admin user has correct role", async () => {
      if (!db) throw new Error("Database not initialized");

      const admin = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[2]))
        .limit(1);

      expect(admin.length).toBe(1);
      expect(admin[0].role).toBe("admin");
    });

    it("should preserve user data integrity after simulated switch", async () => {
      if (!db) throw new Error("Database not initialized");

      const user1Before = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      // محاكاة تبديل المستخدم (بدون تعديل البيانات)
      const user1After = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      expect(user1Before[0].name).toBe(user1After[0].name);
      expect(user1Before[0].email).toBe(user1After[0].email);
      expect(user1Before[0].role).toBe(user1After[0].role);
      expect(user1Before[0].openId).toBe(user1After[0].openId);
    });

    it("should ensure openId uniqueness for all users", async () => {
      if (!db) throw new Error("Database not initialized");

      const allUsers = await db.select().from(users);
      const openIds = allUsers.map((u) => u.openId);
      const uniqueOpenIds = new Set(openIds);

      expect(uniqueOpenIds.size).toBe(openIds.length);
    });

    it("should verify user data structure is complete", async () => {
      if (!db) throw new Error("Database not initialized");

      const user = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      expect(user[0]).toHaveProperty("id");
      expect(user[0]).toHaveProperty("openId");
      expect(user[0]).toHaveProperty("name");
      expect(user[0]).toHaveProperty("email");
      expect(user[0]).toHaveProperty("role");
      expect(user[0]).toHaveProperty("loginMethod");
      expect(user[0]).toHaveProperty("createdAt");
      expect(user[0]).toHaveProperty("updatedAt");
    });

    it("should verify all role values are valid", async () => {
      if (!db) throw new Error("Database not initialized");

      const validRoles = ["user", "admin", "manager", "staff"];

      for (const userId of testUserIds) {
        const user = await db
          .select()
          .from(users)
          .where(eq(users.id, userId))
          .limit(1);

        expect(validRoles).toContain(user[0].role);
      }
    });

    it("should verify timestamps are properly set", async () => {
      if (!db) throw new Error("Database not initialized");

      const user = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      expect(user[0].createdAt).toBeDefined();
      expect(user[0].updatedAt).toBeDefined();
      expect(user[0].createdAt).toBeInstanceOf(Date);
      expect(user[0].updatedAt).toBeInstanceOf(Date);
    });

    it("should verify different users have different data", async () => {
      if (!db) throw new Error("Database not initialized");

      const user1 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      const user2 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[1]))
        .limit(1);

      expect(user1[0].openId).not.toBe(user2[0].openId);
      expect(user1[0].name).not.toBe(user2[0].name);
      expect(user1[0].email).not.toBe(user2[0].email);
    });

    it("should verify admin can switch to regular user", async () => {
      if (!db) throw new Error("Database not initialized");

      const admin = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[2]))
        .limit(1);

      const regularUser = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      expect(admin[0].role).toBe("admin");
      expect(regularUser[0].role).toBe("user");
      expect(admin[0].id).not.toBe(regularUser[0].id);
    });

    it("should verify user data persists across multiple queries", async () => {
      if (!db) throw new Error("Database not initialized");

      const query1 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      const query2 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      expect(query1[0]).toEqual(query2[0]);
    });

    it("should verify email uniqueness", async () => {
      if (!db) throw new Error("Database not initialized");

      const user1 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      const user2 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[1]))
        .limit(1);

      const admin = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[2]))
        .limit(1);

      const emails = [user1[0].email, user2[0].email, admin[0].email];
      const uniqueEmails = new Set(emails);

      expect(uniqueEmails.size).toBe(3);
    });
  });

  describe("Frontend Data Cleanup Verification", () => {
    it("should simulate localStorage cleanup for user 1", () => {
      // محاكاة localStorage
      const mockLocalStorage: Record<string, string> = {
        "manus-runtime-user-info": JSON.stringify({
          id: testUserIds[0],
          name: "مستخدم الاختبار 1",
        }),
        "loginUsername": "user1",
        "loginRememberMe": "true",
      };

      // محاكاة المسح
      delete mockLocalStorage["manus-runtime-user-info"];
      delete mockLocalStorage["loginUsername"];
      delete mockLocalStorage["loginRememberMe"];

      expect(Object.keys(mockLocalStorage).length).toBe(0);
    });

    it("should simulate tRPC cache invalidation", () => {
      // محاكاة tRPC cache
      const mockCache: Record<string, any> = {
        "auth.me": {
          id: testUserIds[0],
          name: "مستخدم الاختبار 1",
        },
      };

      // محاكاة المسح
      mockCache["auth.me"] = null;

      expect(mockCache["auth.me"]).toBeNull();
    });

    it("should verify cleanup doesn't affect database", async () => {
      if (!db) throw new Error("Database not initialized");

      // محاكاة localStorage cleanup
      const mockLocalStorage: Record<string, string> = {
        "manus-runtime-user-info": JSON.stringify({
          id: testUserIds[0],
          name: "مستخدم الاختبار 1",
        }),
      };
      delete mockLocalStorage["manus-runtime-user-info"];

      // التحقق من أن البيانات في قاعدة البيانات لم تتأثر
      const user = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      expect(user.length).toBe(1);
      expect(user[0].name).toBe("مستخدم الاختبار 1");
    });
  });
});
