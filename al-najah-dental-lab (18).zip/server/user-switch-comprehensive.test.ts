import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { users, roleSettings } from "../drizzle/schema";
import { userSwitchAuditLog } from "../drizzle/audit-log.schema";
import { eq } from "drizzle-orm";
import { hashPassword, verifyPassword } from "./password-manager";

describe("User Switch Comprehensive Tests", () => {
  let db: any;
  let testUserIds: number[] = [];
  let adminId: number;

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // جلب المسؤول الحالي
    const adminUsers = await db
      .select()
      .from(users)
      .where(eq(users.role, "admin"))
      .limit(1);

    if (adminUsers.length > 0) {
      adminId = adminUsers[0].id;
    }

    // جلب أو إنشاء 3 مستخدمين اختبار
    const testEmails = ["user1@test.com", "user2@test.com", "user3@test.com"];

    for (const email of testEmails) {
      const existing = await db
        .select()
        .from(users)
        .where(eq(users.email, email))
        .limit(1);

      if (existing.length > 0) {
        testUserIds.push(existing[0].id);
      }
    }

    expect(testUserIds.length).toBe(3);
  });

  afterAll(async () => {
    if (db) {
      // تنظيف سجلات التدقيق
      await db.delete(userSwitchAuditLog);
    }
  });

  describe("User Switch Functionality", () => {
    it("should have 3 test users available", () => {
      expect(testUserIds.length).toBe(3);
      expect(testUserIds[0]).toBeGreaterThan(0);
      expect(testUserIds[1]).toBeGreaterThan(0);
      expect(testUserIds[2]).toBeGreaterThan(0);
    });

    it("should verify admin password is correct", async () => {
      const adminSettings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, "admin"))
        .limit(1);

      expect(adminSettings.length).toBeGreaterThan(0);
      const isValid = verifyPassword("admin1985", adminSettings[0].passwordHash);
      expect(isValid).toBe(true);
    });

    it("should log successful user switch from admin to user1", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: adminId,
        switchedTo: testUserIds[0],
        status: "success",
        ipAddress: "192.168.1.1",
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.switchedTo, testUserIds[0]));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[logs.length - 1].status).toBe("success");
    });

    it("should log successful user switch from admin to user2", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: adminId,
        switchedTo: testUserIds[1],
        status: "success",
        ipAddress: "192.168.1.2",
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.switchedTo, testUserIds[1]));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[logs.length - 1].status).toBe("success");
    });

    it("should log successful user switch from admin to user3", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: adminId,
        switchedTo: testUserIds[2],
        status: "success",
        ipAddress: "192.168.1.3",
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.switchedTo, testUserIds[2]));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[logs.length - 1].status).toBe("success");
    });

    it("should log failed switch with wrong password", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: adminId,
        switchedTo: testUserIds[0],
        status: "failed",
        failureReason: "كلمة السر غير صحيحة",
        ipAddress: "192.168.1.100",
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.status, "failed"));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[logs.length - 1].failureReason).toBe("كلمة السر غير صحيحة");
    });

    it("should log failed switch with non-existent user", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: adminId,
        switchedTo: 999999,
        status: "failed",
        failureReason: "المستخدم غير موجود",
        ipAddress: "192.168.1.101",
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.status, "failed"));

      expect(logs.length).toBeGreaterThan(0);
      const failedLog = logs.find((log: any) => log.failureReason === "المستخدم غير موجود");
      expect(failedLog).toBeDefined();
    });

    it("should track multiple switches in audit log", async () => {
      const allLogs = await db.select().from(userSwitchAuditLog);
      expect(allLogs.length).toBeGreaterThanOrEqual(5);
    });

    it("should have correct user data for each test user", async () => {
      const user1 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      const user2 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[1]))
        .limit(1);

      const user3 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[2]))
        .limit(1);

      expect(user1[0].email).toBe("user1@test.com");
      expect(user2[0].email).toBe("user2@test.com");
      expect(user3[0].email).toBe("user3@test.com");

      expect(user1[0].name).toBe("المستخدم الأول");
      expect(user2[0].name).toBe("المستخدم الثاني");
      expect(user3[0].name).toBe("المستخدم الثالث");
    });

    it("should verify different roles for test users", async () => {
      const user1 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      const user2 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[1]))
        .limit(1);

      const user3 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[2]))
        .limit(1);

      expect(user1[0].role).toBe("user");
      expect(user2[0].role).toBe("manager");
      expect(user3[0].role).toBe("staff");
    });

    it("should record IP addresses for each switch attempt", async () => {
      const logs = await db.select().from(userSwitchAuditLog);
      const ips = logs.map((log: any) => log.ipAddress).filter((ip: string) => ip);

      expect(ips.length).toBeGreaterThan(0);
      expect(ips).toContain("192.168.1.1");
      expect(ips).toContain("192.168.1.2");
      expect(ips).toContain("192.168.1.3");
    });

    it("should maintain chronological order of audit logs", async () => {
      const logs = await db.select().from(userSwitchAuditLog);
      const timestamps = logs.map((log: any) => new Date(log.createdAt).getTime());

      for (let i = 1; i < timestamps.length; i++) {
        expect(timestamps[i]).toBeGreaterThanOrEqual(timestamps[i - 1]);
      }
    });

    it("should count successful and failed attempts", async () => {
      const logs = await db.select().from(userSwitchAuditLog);
      const successful = logs.filter((log: any) => log.status === "success").length;
      const failed = logs.filter((log: any) => log.status === "failed").length;

      expect(successful).toBeGreaterThanOrEqual(3);
      expect(failed).toBeGreaterThanOrEqual(2);
    });
  });

  describe("User Switch Edge Cases", () => {
    it("should handle switching to same user multiple times", async () => {
      for (let i = 0; i < 3; i++) {
        await db.insert(userSwitchAuditLog).values({
          switchedBy: adminId,
          switchedTo: testUserIds[0],
          status: "success",
        });
      }

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.switchedTo, testUserIds[0]));

      expect(logs.length).toBeGreaterThanOrEqual(4);
    });

    it("should handle rapid consecutive switches", async () => {
      const timestamps = [];

      for (const userId of testUserIds) {
        await db.insert(userSwitchAuditLog).values({
          switchedBy: adminId,
          switchedTo: userId,
          status: "success",
        });

        const logs = await db
          .select()
          .from(userSwitchAuditLog)
          .where(eq(userSwitchAuditLog.switchedTo, userId));

        timestamps.push(new Date(logs[logs.length - 1].createdAt).getTime());
      }

      // تحقق من أن الطوابع الزمنية بترتيب تصاعدي
      for (let i = 1; i < timestamps.length; i++) {
        expect(timestamps[i]).toBeGreaterThanOrEqual(timestamps[i - 1]);
      }
    });

    it("should store additional metadata correctly", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: adminId,
        switchedTo: testUserIds[0],
        status: "success",
        ipAddress: "10.0.0.1",
        userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.ipAddress, "10.0.0.1"));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[logs.length - 1].userAgent).toContain("Mozilla");
    });
  });
});
