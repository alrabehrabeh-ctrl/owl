import { describe, it, expect } from "vitest";
import { hashPassword, verifyPassword } from "./password-manager";

describe("User Switch Fix Tests", () => {
  describe("Admin Password Verification", () => {
    it("should verify admin password correctly", () => {
      const adminPassword = "admin";
      const hash = hashPassword(adminPassword);

      expect(verifyPassword(adminPassword, hash)).toBe(true);
    });

    it("should reject incorrect password", () => {
      const correctPassword = "admin";
      const wrongPassword = "wrongPassword";
      const hash = hashPassword(correctPassword);

      expect(verifyPassword(wrongPassword, hash)).toBe(false);
    });

    it("should handle password verification for different roles", () => {
      const passwords = {
        admin: "admin",
        manager: "1985",
        staff: "0000",
        user: "0000",
      };

      for (const [role, password] of Object.entries(passwords)) {
        const hash = hashPassword(password);
        expect(verifyPassword(password, hash)).toBe(true);
        expect(verifyPassword("wrongPassword", hash)).toBe(false);
      }
    });

    it("should ensure password hashes are different for different passwords", () => {
      const password1 = "admin";
      const password2 = "1985";

      const hash1 = hashPassword(password1);
      const hash2 = hashPassword(password2);

      expect(hash1).not.toBe(hash2);
      expect(verifyPassword(password1, hash1)).toBe(true);
      expect(verifyPassword(password2, hash2)).toBe(true);
      expect(verifyPassword(password1, hash2)).toBe(false);
      expect(verifyPassword(password2, hash1)).toBe(false);
    });

    it("should handle empty password edge case", () => {
      const emptyPassword = "";
      const hash = hashPassword(emptyPassword);

      expect(verifyPassword(emptyPassword, hash)).toBe(true);
      expect(verifyPassword("anyPassword", hash)).toBe(false);
    });

    it("should be case sensitive", () => {
      const password = "Admin";
      const wrongCase = "admin";
      const hash = hashPassword(password);

      expect(verifyPassword(password, hash)).toBe(true);
      expect(verifyPassword(wrongCase, hash)).toBe(false);
    });

    it("should handle special characters in password", () => {
      const specialPasswords = [
        "admin@123",
        "P@ssw0rd!",
        "مرحبا123",
        "!@#$%^&*()",
      ];

      for (const password of specialPasswords) {
        const hash = hashPassword(password);
        expect(verifyPassword(password, hash)).toBe(true);
      }
    });

    it("should ensure consistent verification", () => {
      const password = "testPassword";
      const hash = hashPassword(password);

      // التحقق المتكرر يجب أن يعطي نفس النتيجة
      expect(verifyPassword(password, hash)).toBe(true);
      expect(verifyPassword(password, hash)).toBe(true);
      expect(verifyPassword(password, hash)).toBe(true);
    });

    it("should prevent password bypass attempts", () => {
      const correctPassword = "admin";
      const hash = hashPassword(correctPassword);

      const bypassAttempts = [
        "admin ",
        " admin",
        "Admin",
        "ADMIN",
        "adm in",
        "admin\n",
        "admin\t",
      ];

      for (const attempt of bypassAttempts) {
        expect(verifyPassword(attempt, hash)).toBe(false);
      }
    });
  });

  describe("User Switch Security", () => {
    it("should verify that password is required for admin switch", () => {
      const adminPassword = "admin";
      const hash = hashPassword(adminPassword);

      // بدون كلمة مرور، يجب أن تفشل
      expect(verifyPassword("", hash)).toBe(false);

      // مع كلمة المرور الصحيحة، يجب أن تنجح
      expect(verifyPassword(adminPassword, hash)).toBe(true);
    });

    it("should ensure password is not stored in plain text", () => {
      const password = "admin";
      const hash = hashPassword(password);

      expect(hash).not.toBe(password);
      expect(hash).not.toContain(password);
    });

    it("should verify password change sequence for user switch", () => {
      // محاكاة تسلسل تغيير كلمات المرور
      const oldPassword = "oldAdmin";
      const newPassword = "newAdmin";

      const oldHash = hashPassword(oldPassword);
      const newHash = hashPassword(newPassword);

      // بعد التغيير، كلمة المرور القديمة يجب أن لا تعمل
      expect(verifyPassword(oldPassword, newHash)).toBe(false);
      expect(verifyPassword(newPassword, newHash)).toBe(true);
    });
  });
});
