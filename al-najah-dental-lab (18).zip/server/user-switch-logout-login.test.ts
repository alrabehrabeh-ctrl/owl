import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { userSwitchAuditLog } from "../drizzle/audit-log.schema";
import { eq } from "drizzle-orm";

describe("User Switch with Logout/Login System", () => {
  let db: any;
  let testUserIds: number[] = [];
  let adminId: number;

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // جلب المسؤول
    const adminUsers = await db
      .select()
      .from(users)
      .where(eq(users.role, "admin"))
      .limit(1);

    if (adminUsers.length > 0) {
      adminId = adminUsers[0].id;
    }

    // جلب 3 مستخدمي اختبار
    const testEmails = ["user1@test.com", "user2@test.com", "user3@test.com"];

    for (const email of testEmails) {
      const existing = await db
        .select()
        .from(users)
        .where(eq(users.email, email))
        .limit(1);

      if (existing.length > 0) {
        testUserIds.push(existing[0].id);
      }
    }

    expect(testUserIds.length).toBe(3);
  });

  afterAll(async () => {
    if (db) {
      // تنظيف سجلات التدقيق
      await db.delete(userSwitchAuditLog);
    }
  });

  describe("Logout/Login Flow", () => {
    it("should have admin user available", () => {
      expect(adminId).toBeGreaterThan(0);
    });

    it("should have 3 test users available", () => {
      expect(testUserIds.length).toBe(3);
      testUserIds.forEach((id) => {
        expect(id).toBeGreaterThan(0);
      });
    });

    it("should verify test user roles", async () => {
      const user1 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      const user2 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[1]))
        .limit(1);

      const user3 = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[2]))
        .limit(1);

      expect(user1[0].role).toBe("user");
      expect(user2[0].role).toBe("manager");
      expect(user3[0].role).toBe("staff");
    });

    it("should log logout from admin", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: adminId,
        switchedTo: testUserIds[0],
        status: "success",
        ipAddress: "192.168.1.1",
      });

      const logs = await db.select().from(userSwitchAuditLog);
      expect(logs.length).toBeGreaterThan(0);
    });

    it("should log successful login to user1", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: adminId,
        switchedTo: testUserIds[0],
        status: "success",
        ipAddress: "192.168.1.1",
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.switchedTo, testUserIds[0]));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[logs.length - 1].status).toBe("success");
    });

    it("should log successful login to user2", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: adminId,
        switchedTo: testUserIds[1],
        status: "success",
        ipAddress: "192.168.1.2",
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.switchedTo, testUserIds[1]));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[logs.length - 1].status).toBe("success");
    });

    it("should log successful login to user3", async () => {
      await db.insert(userSwitchAuditLog).values({
        switchedBy: adminId,
        switchedTo: testUserIds[2],
        status: "success",
        ipAddress: "192.168.1.3",
      });

      const logs = await db
        .select()
        .from(userSwitchAuditLog)
        .where(eq(userSwitchAuditLog.switchedTo, testUserIds[2]));

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[logs.length - 1].status).toBe("success");
    });

    it("should handle rapid logout/login cycles", async () => {
      for (let i = 0; i < 3; i++) {
        await db.insert(userSwitchAuditLog).values({
          switchedBy: adminId,
          switchedTo: testUserIds[i],
          status: "success",
          ipAddress: `192.168.1.${100 + i}`,
        });
      }

      const logs = await db.select().from(userSwitchAuditLog);
      expect(logs.length).toBeGreaterThanOrEqual(6);
    });

    it("should track IP addresses for security", async () => {
      const logs = await db.select().from(userSwitchAuditLog);
      const ips = logs.map((log: any) => log.ipAddress).filter((ip: string) => ip);

      expect(ips.length).toBeGreaterThan(0);
      expect(ips).toContain("192.168.1.1");
      expect(ips).toContain("192.168.1.2");
      expect(ips).toContain("192.168.1.3");
    });

    it("should maintain chronological order of logs", async () => {
      const logs = await db.select().from(userSwitchAuditLog);
      const timestamps = logs.map((log: any) => new Date(log.createdAt).getTime());

      for (let i = 1; i < timestamps.length; i++) {
        expect(timestamps[i]).toBeGreaterThanOrEqual(timestamps[i - 1]);
      }
    });

    it("should handle switching between all users", async () => {
      const allLogs = await db.select().from(userSwitchAuditLog);
      const successfulSwitches = allLogs.filter((log: any) => log.status === "success");

      expect(successfulSwitches.length).toBeGreaterThanOrEqual(6);
    });

    it("should verify user data is preserved after logout/login", async () => {
      const user1Before = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      // محاكاة تسجيل خروج وتسجيل دخول
      await db.insert(userSwitchAuditLog).values({
        switchedBy: adminId,
        switchedTo: testUserIds[0],
        status: "success",
      });

      const user1After = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserIds[0]))
        .limit(1);

      expect(user1Before[0].id).toBe(user1After[0].id);
      expect(user1Before[0].email).toBe(user1After[0].email);
      expect(user1Before[0].name).toBe(user1After[0].name);
    });

    it("should count total logout/login operations", async () => {
      const logs = await db.select().from(userSwitchAuditLog);
      const totalOperations = logs.length;

      expect(totalOperations).toBeGreaterThanOrEqual(8);
    });
  });

  describe("Security Considerations", () => {
    it("should track who initiated the switch", async () => {
      const logs = await db.select().from(userSwitchAuditLog);

      logs.forEach((log: any) => {
        expect(log.switchedBy).toBe(adminId);
      });
    });

    it("should track which user was switched to", async () => {
      const logs = await db.select().from(userSwitchAuditLog);

      const switchedToIds = new Set(logs.map((log: any) => log.switchedTo));
      expect(switchedToIds.has(testUserIds[0])).toBe(true);
      expect(switchedToIds.has(testUserIds[1])).toBe(true);
      expect(switchedToIds.has(testUserIds[2])).toBe(true);
    });

    it("should have timestamps for all operations", async () => {
      const logs = await db.select().from(userSwitchAuditLog);

      logs.forEach((log: any) => {
        expect(log.createdAt).toBeDefined();
        expect(log.createdAt instanceof Date || typeof log.createdAt === "string").toBe(true);
      });
    });
  });
});
