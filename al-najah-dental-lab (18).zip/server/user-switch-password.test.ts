import { describe, it, expect, beforeAll, afterAll, vi } from "vitest";
import { getDb } from "./db";
import { users, roleSettings } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "./password-manager";

describe("User Switch and Password Change", () => {
  let db: any;

  beforeAll(async () => {
    db = await getDb();
  });

  describe("تبديل المستخدمين", () => {
    it("يجب أن يتمكن من الحصول على قائمة المستخدمين المتاحين للتبديل", async () => {
      const allUsers = await db
        .select({
          id: users.id,
          name: users.name,
          email: users.email,
          role: users.role,
        })
        .from(users);

      expect(allUsers).toBeDefined();
      expect(Array.isArray(allUsers)).toBe(true);
    });

    it("يجب أن يتمكن من التحقق من وجود المستخدم المراد التبديل إليه", async () => {
      const testUser = await db
        .select()
        .from(users)
        .limit(1);

      if (testUser.length > 0) {
        expect(testUser[0].id).toBeDefined();
        expect(testUser[0].openId).toBeDefined();
      }
    });

    it("يجب أن يرفع خطأ عند محاولة التبديل إلى مستخدم غير موجود", async () => {
      const nonExistentUserId = 999999;
      const user = await db
        .select()
        .from(users)
        .where(eq(users.id, nonExistentUserId))
        .limit(1);

      expect(user.length).toBe(0);
    });
  });

  describe("تغيير كلمة المرور", () => {
    it("يجب أن يتمكن من تحديث كلمة مرور الدور", async () => {
      const role = "staff";
      const newPassword = "newPassword123";
      const newPasswordHash = hashPassword(newPassword);

      const settings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, role))
        .limit(1);

      if (settings.length > 0) {
        const oldHash = settings[0].passwordHash;
        expect(oldHash).toBeDefined();
        expect(newPasswordHash).not.toBe(oldHash);
      }
    });

    it("يجب أن يتمكن من الحصول على سجل تغييرات كلمات المرور", async () => {
      const logs = await db
        .select()
        .from(roleSettings);

      expect(logs).toBeDefined();
      expect(Array.isArray(logs)).toBe(true);
    });

    it("يجب أن يرفع خطأ عند محاولة استخدام نفس كلمة المرور", async () => {
      const role = "staff";
      const settings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, role))
        .limit(1);

      if (settings.length > 0) {
        const currentHash = settings[0].passwordHash;
        const sameHash = hashPassword(settings[0].password || "");
        
        // إذا كانت كلمة المرور الجديدة نفس الحالية، يجب أن يرفع خطأ
        if (currentHash === sameHash) {
          expect(currentHash).toBe(sameHash);
        }
      }
    });

    it("يجب أن يتمكن من إعادة تعيين كلمة المرور إلى الافتراضية", async () => {
      const role = "staff";
      const settings = await db
        .select()
        .from(roleSettings)
        .where(eq(roleSettings.role, role))
        .limit(1);

      if (settings.length > 0) {
        expect(settings[0].passwordHash).toBeDefined();
      }
    });
  });

  describe("التكامل بين التبديل وتغيير كلمة المرور", () => {
    it("يجب أن يتمكن من تبديل المستخدم وتغيير كلمة المرور بشكل مستقل", async () => {
      const user = await db
        .select()
        .from(users)
        .limit(1);

      const settings = await db
        .select()
        .from(roleSettings)
        .limit(1);

      expect(user.length).toBeGreaterThanOrEqual(0);
      expect(settings.length).toBeGreaterThanOrEqual(0);
    });

    it("يجب أن يتمكن من الحصول على معلومات المستخدم بعد التبديل", async () => {
      const users_list = await db
        .select({
          id: users.id,
          name: users.name,
          email: users.email,
          role: users.role,
        })
        .from(users)
        .limit(1);

      if (users_list.length > 0) {
        const user = users_list[0];
        expect(user.id).toBeDefined();
        expect(user.name).toBeDefined();
        expect(user.role).toBeDefined();
      }
    });
  });
});
