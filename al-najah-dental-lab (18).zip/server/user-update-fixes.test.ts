import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";

describe("User Update Fixes", () => {
  let db: any;
  let testUserId: number;

  beforeEach(async () => {
    db = await getDb();
    if (!db) throw new Error("Database not available");

    // Create a test user
    const result = await db.insert(users).values({
      email: "test-update@example.com",
      name: "Test User",
      username: "testuser",
      role: "user",
      openId: "test-openid-" + Date.now(),
      loginMethod: "manual",
    });

    const inserted = await db
      .select()
      .from(users)
      .where(eq(users.email, "test-update@example.com"))
      .limit(1);

    testUserId = inserted[0].id;
  });

  afterEach(async () => {
    if (db && testUserId) {
      await db.delete(users).where(eq(users.id, testUserId));
    }
  });

  it("should update user name correctly", async () => {
    const newName = "Updated Name";
    await db
      .update(users)
      .set({ name: newName })
      .where(eq(users.id, testUserId));

    const updated = await db
      .select()
      .from(users)
      .where(eq(users.id, testUserId))
      .limit(1);

    expect(updated[0].name).toBe(newName);
  });

  it("should update user email correctly", async () => {
    const newEmail = "new-email@example.com";
    await db
      .update(users)
      .set({ email: newEmail })
      .where(eq(users.id, testUserId));

    const updated = await db
      .select()
      .from(users)
      .where(eq(users.id, testUserId))
      .limit(1);

    expect(updated[0].email).toBe(newEmail);
  });

  it("should update user role correctly", async () => {
    const newRole = "admin";
    await db
      .update(users)
      .set({ role: newRole })
      .where(eq(users.id, testUserId));

    const updated = await db
      .select()
      .from(users)
      .where(eq(users.id, testUserId))
      .limit(1);

    expect(updated[0].role).toBe(newRole);
  });

  it("should update multiple fields at once", async () => {
    const newName = "Multi Update";
    const newRole = "manager";

    await db
      .update(users)
      .set({ name: newName, role: newRole })
      .where(eq(users.id, testUserId));

    const updated = await db
      .select()
      .from(users)
      .where(eq(users.id, testUserId))
      .limit(1);

    expect(updated[0].name).toBe(newName);
    expect(updated[0].role).toBe(newRole);
  });

  it("should not create duplicate users with same email", async () => {
    try {
      await db.insert(users).values({
        email: "test-update@example.com",
        name: "Duplicate User",
        username: "duplicate",
        role: "user",
        openId: "duplicate-openid",
        loginMethod: "manual",
      });
      expect.fail("Should have thrown an error for duplicate email");
    } catch (error: any) {
      expect(error.message).toContain("Duplicate");
    }
  });

  it("should preserve existing data when updating only one field", async () => {
    const originalEmail = "test-update@example.com";
    const originalUsername = "testuser";
    const newName = "Only Name Updated";

    await db
      .update(users)
      .set({ name: newName })
      .where(eq(users.id, testUserId));

    const updated = await db
      .select()
      .from(users)
      .where(eq(users.id, testUserId))
      .limit(1);

    expect(updated[0].name).toBe(newName);
    expect(updated[0].email).toBe(originalEmail);
    expect(updated[0].username).toBe(originalUsername);
  });
});
