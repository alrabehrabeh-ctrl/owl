import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { users, activityLogs } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { scryptSync, randomBytes } from "crypto";

// تجزئة كلمة المرور
function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const derivedKey = scryptSync(password, salt, 64);
  return salt.toString("hex") + ":" + derivedKey.toString("hex");
}

// التحقق من كلمة المرور
function verifyPassword(password: string, hash: string): boolean {
  const [saltHex, keyHex] = hash.split(":");
  const salt = Buffer.from(saltHex, "hex");
  const derivedKey = scryptSync(password, salt, 64);
  return derivedKey.toString("hex") === keyHex;
}

describe("Username and Activity Logging System", () => {
  let db: Awaited<ReturnType<typeof getDb>>;
  let testUserId: number;

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error("Failed to connect to database");

    // إنشاء مستخدم اختبار
    const result = await db.insert(users).values({
      openId: `test-user-${Date.now()}`,
      username: `testuser${Date.now()}`,
      password: hashPassword("TestPassword123"),
      name: "Test User",
      email: "test@example.com",
      role: "user",
    });

    testUserId = result[0]?.insertId || 0;
  });

  afterAll(async () => {
    if (db && testUserId) {
      // حذف بيانات الاختبار
      await db.delete(activityLogs).where(eq(activityLogs.userId, testUserId));
      await db.delete(users).where(eq(users.id, testUserId));
    }
  });

  it("should hash and verify passwords correctly", () => {
    const password = "MySecurePassword123";
    const hash = hashPassword(password);

    expect(verifyPassword(password, hash)).toBe(true);
    expect(verifyPassword("WrongPassword", hash)).toBe(false);
  });

  it("should create user with username and password", async () => {
    const newUser = await db
      .select()
      .from(users)
      .where(eq(users.id, testUserId))
      .limit(1);

    expect(newUser).toHaveLength(1);
    expect(newUser[0].username).toBeDefined();
    expect(newUser[0].username).toMatch(/^testuser\d+$/);
    expect(newUser[0].password).toBeDefined();
  });

  it("should log activity with all required fields", async () => {
    const activity = await db.insert(activityLogs).values({
      userId: testUserId,
      action: "create",
      entityType: "doctor",
      entityId: 1,
      entityName: "Dr. Ahmed",
      description: "تم إضافة طبيب جديد",
      ipAddress: "192.168.1.1",
      userAgent: "Mozilla/5.0",
      status: "pending",
    });

    expect(activity[0]?.insertId).toBeDefined();

    const logged = await db
      .select()
      .from(activityLogs)
      .where(eq(activityLogs.id, activity[0]?.insertId || 0))
      .limit(1);

    expect(logged).toHaveLength(1);
    expect(logged[0].action).toBe("create");
    expect(logged[0].entityType).toBe("doctor");
    expect(logged[0].status).toBe("pending");
  });

  it("should track multiple activities for same user", async () => {
    // إضافة نشاط أول
    const activity1 = await db.insert(activityLogs).values({
      userId: testUserId,
      action: "create",
      entityType: "work",
      entityId: 1,
      description: "إضافة عمل جديد",
      status: "pending",
    });

    // إضافة نشاط ثاني
    const activity2 = await db.insert(activityLogs).values({
      userId: testUserId,
      action: "update",
      entityType: "work",
      entityId: 1,
      description: "تحديث حالة العمل",
      status: "pending",
    });

    const userActivities = await db
      .select()
      .from(activityLogs)
      .where(eq(activityLogs.userId, testUserId));

    expect(userActivities.length).toBeGreaterThanOrEqual(2);
  });

  it("should store old and new values as JSON", async () => {
    const oldValues = { status: "pending", price: 100 };
    const newValues = { status: "completed", price: 120 };

    const activity = await db.insert(activityLogs).values({
      userId: testUserId,
      action: "update",
      entityType: "work",
      entityId: 1,
      oldValues: JSON.stringify(oldValues),
      newValues: JSON.stringify(newValues),
      status: "pending",
    });

    const logged = await db
      .select()
      .from(activityLogs)
      .where(eq(activityLogs.id, activity[0]?.insertId || 0))
      .limit(1);

    expect(logged[0].oldValues).toBeDefined();
    expect(logged[0].newValues).toBeDefined();
  });

  it("should update activity status to approved", async () => {
    const activity = await db.insert(activityLogs).values({
      userId: testUserId,
      action: "create",
      entityType: "doctor",
      description: "إضافة طبيب",
      status: "pending",
    });

    const activityId = activity[0]?.insertId || 0;

    await db
      .update(activityLogs)
      .set({
        status: "approved",
        reviewedBy: testUserId,
        reviewedAt: new Date(),
        reviewNotes: "تم المراجعة والموافقة",
      })
      .where(eq(activityLogs.id, activityId));

    const updated = await db
      .select()
      .from(activityLogs)
      .where(eq(activityLogs.id, activityId))
      .limit(1);

    expect(updated[0].status).toBe("approved");
    expect(updated[0].reviewedBy).toBe(testUserId);
    expect(updated[0].reviewNotes).toBe("تم المراجعة والموافقة");
  });

  it("should update activity status to rejected", async () => {
    const activity = await db.insert(activityLogs).values({
      userId: testUserId,
      action: "create",
      entityType: "payment",
      description: "إضافة دفعة",
      status: "pending",
    });

    const activityId = activity[0]?.insertId || 0;

    await db
      .update(activityLogs)
      .set({
        status: "rejected",
        reviewedBy: testUserId,
        reviewedAt: new Date(),
        reviewNotes: "بيانات غير صحيحة",
      })
      .where(eq(activityLogs.id, activityId));

    const updated = await db
      .select()
      .from(activityLogs)
      .where(eq(activityLogs.id, activityId))
      .limit(1);

    expect(updated[0].status).toBe("rejected");
    expect(updated[0].reviewNotes).toBe("بيانات غير صحيحة");
  });

  it("should track IP address and user agent", async () => {
    const ipAddress = "203.0.113.42";
    const userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)";

    const activity = await db.insert(activityLogs).values({
      userId: testUserId,
      action: "create",
      entityType: "doctor",
      ipAddress,
      userAgent,
      status: "pending",
    });

    const logged = await db
      .select()
      .from(activityLogs)
      .where(eq(activityLogs.id, activity[0]?.insertId || 0))
      .limit(1);

    expect(logged[0].ipAddress).toBe(ipAddress);
    expect(logged[0].userAgent).toBe(userAgent);
  });

  it("should handle activity with all optional fields", async () => {
    const activity = await db.insert(activityLogs).values({
      userId: testUserId,
      action: "delete",
      entityType: "work",
      entityId: 99,
      entityName: "Work #99",
      description: "حذف عمل قديم",
      oldValues: JSON.stringify({ status: "pending" }),
      ipAddress: "192.168.1.100",
      userAgent: "Chrome/91.0",
      status: "pending",
    });

    const logged = await db
      .select()
      .from(activityLogs)
      .where(eq(activityLogs.id, activity[0]?.insertId || 0))
      .limit(1);

    expect(logged[0]).toBeDefined();
    expect(logged[0].entityId).toBe(99);
    expect(logged[0].entityName).toBe("Work #99");
  });

  it("should verify password hashing is secure", () => {
    const password = "SecurePassword123";
    const hash1 = hashPassword(password);
    const hash2 = hashPassword(password);

    // يجب أن تكون الـ hashes مختلفة (لأن كل واحد له salt مختلف)
    expect(hash1).not.toBe(hash2);

    // لكن كلاهما يجب أن يتحقق من نفس كلمة المرور
    expect(verifyPassword(password, hash1)).toBe(true);
    expect(verifyPassword(password, hash2)).toBe(true);
  });
});
