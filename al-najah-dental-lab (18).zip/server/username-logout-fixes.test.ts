import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { createHash } from "crypto";

describe("Username and Logout Fixes", () => {
  let db: any;
  let testUserId: number;

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error("Failed to get database");
  });

  afterAll(async () => {
    // Cleanup test data
    if (db && testUserId) {
      await db.delete(users).where(eq(users.id, testUserId));
    }
  });

  describe("Username Field Handling", () => {
    it("should save username when creating a new user", async () => {
      const testUsername = `testuser_${Date.now()}`;
      const testEmail = `test_${Date.now()}@example.com`;

      const result = await db.insert(users).values({
        email: testEmail,
        name: "Test User",
        username: testUsername,
        role: "user",
        openId: `temp-${Date.now()}`,
        loginMethod: "manual",
      });

      const createdUser = await db
        .select()
        .from(users)
        .where(eq(users.email, testEmail))
        .limit(1);

      expect(createdUser).toHaveLength(1);
      expect(createdUser[0].username).toBe(testUsername);
      testUserId = createdUser[0].id;
    });

    it("should update username when modifying a user", async () => {
      if (!testUserId) {
        throw new Error("No test user created");
      }

      const newUsername = `updated_${Date.now()}`;

      await db
        .update(users)
        .set({ username: newUsername })
        .where(eq(users.id, testUserId));

      const updatedUser = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserId))
        .limit(1);

      expect(updatedUser).toHaveLength(1);
      expect(updatedUser[0].username).toBe(newUsername);
    });

    it("should preserve username when updating other fields", async () => {
      if (!testUserId) {
        throw new Error("No test user created");
      }

      const originalUsername = `preserve_${Date.now()}`;

      // First set the username
      await db
        .update(users)
        .set({ username: originalUsername })
        .where(eq(users.id, testUserId));

      // Then update another field
      await db
        .update(users)
        .set({ name: "Updated Name" })
        .where(eq(users.id, testUserId));

      const user = await db
        .select()
        .from(users)
        .where(eq(users.id, testUserId))
        .limit(1);

      expect(user[0].username).toBe(originalUsername);
      expect(user[0].name).toBe("Updated Name");
    });

    it("should handle special characters in username", async () => {
      const specialUsername = `user_${Date.now()}_-._~`;
      const testEmail = `special_${Date.now()}@example.com`;

      const result = await db.insert(users).values({
        email: testEmail,
        name: "Special User",
        username: specialUsername,
        role: "user",
        openId: `temp-${Date.now()}`,
        loginMethod: "manual",
      });

      const createdUser = await db
        .select()
        .from(users)
        .where(eq(users.email, testEmail))
        .limit(1);

      expect(createdUser[0].username).toBe(specialUsername);

      // Cleanup
      if (createdUser[0].id) {
        await db.delete(users).where(eq(users.id, createdUser[0].id));
      }
    });

    it("should handle empty username gracefully", async () => {
      const testEmail = `empty_${Date.now()}@example.com`;

      // Empty username should still be saved
      const result = await db.insert(users).values({
        email: testEmail,
        name: "Empty Username User",
        username: "",
        role: "user",
        openId: `temp-${Date.now()}`,
        loginMethod: "manual",
      });

      const createdUser = await db
        .select()
        .from(users)
        .where(eq(users.email, testEmail))
        .limit(1);

      expect(createdUser).toHaveLength(1);
      expect(createdUser[0].username).toBe("");

      // Cleanup
      if (createdUser[0].id) {
        await db.delete(users).where(eq(users.id, createdUser[0].id));
      }
    });

    it("should handle long usernames", async () => {
      const longUsername = "a".repeat(100);
      const testEmail = `long_${Date.now()}@example.com`;

      const result = await db.insert(users).values({
        email: testEmail,
        name: "Long Username User",
        username: longUsername,
        role: "user",
        openId: `temp-${Date.now()}`,
        loginMethod: "manual",
      });

      const createdUser = await db
        .select()
        .from(users)
        .where(eq(users.email, testEmail))
        .limit(1);

      expect(createdUser[0].username).toBe(longUsername);
      expect(createdUser[0].username.length).toBe(100);

      // Cleanup
      if (createdUser[0].id) {
        await db.delete(users).where(eq(users.id, createdUser[0].id));
      }
    });
  });

  describe("Logout Redirect Behavior", () => {
    it("should verify logout clears session cookie", async () => {
      // This test verifies the logout procedure clears the session
      // The actual redirect happens on the client side in useAuth hook
      const testEmail = `logout_${Date.now()}@example.com`;

      const result = await db.insert(users).values({
        email: testEmail,
        name: "Logout Test User",
        username: `logouttest_${Date.now()}`,
        role: "user",
        openId: `temp-${Date.now()}`,
        loginMethod: "manual",
      });

      const createdUser = await db
        .select()
        .from(users)
        .where(eq(users.email, testEmail))
        .limit(1);

      expect(createdUser).toHaveLength(1);

      // Cleanup
      if (createdUser[0].id) {
        await db.delete(users).where(eq(users.id, createdUser[0].id));
      }
    });

    it("should verify logout invalidates auth state", async () => {
      // The logout mutation should invalidate the auth.me query
      // This is handled by the useAuth hook in the frontend
      const testEmail = `invalidate_${Date.now()}@example.com`;

      const result = await db.insert(users).values({
        email: testEmail,
        name: "Invalidate Test User",
        username: `invalidatetest_${Date.now()}`,
        role: "user",
        openId: `temp-${Date.now()}`,
        loginMethod: "manual",
      });

      const createdUser = await db
        .select()
        .from(users)
        .where(eq(users.email, testEmail))
        .limit(1);

      expect(createdUser).toHaveLength(1);
      expect(createdUser[0].username).toBeDefined();

      // Cleanup
      if (createdUser[0].id) {
        await db.delete(users).where(eq(users.id, createdUser[0].id));
      }
    });
  });

  describe("Integration Tests", () => {
    it("should handle complete user creation and update flow with username", async () => {
      const testUsername = `integration_${Date.now()}`;
      const testEmail = `integration_${Date.now()}@example.com`;

      // Create user
      await db.insert(users).values({
        email: testEmail,
        name: "Integration Test User",
        username: testUsername,
        role: "user",
        openId: `temp-${Date.now()}`,
        loginMethod: "manual",
      });

      const createdUser = await db
        .select()
        .from(users)
        .where(eq(users.email, testEmail))
        .limit(1);

      expect(createdUser[0].username).toBe(testUsername);

      // Update user
      const newUsername = `updated_integration_${Date.now()}`;
      await db
        .update(users)
        .set({
          username: newUsername,
          name: "Updated Integration User",
          role: "manager",
        })
        .where(eq(users.id, createdUser[0].id));

      const updatedUser = await db
        .select()
        .from(users)
        .where(eq(users.id, createdUser[0].id))
        .limit(1);

      expect(updatedUser[0].username).toBe(newUsername);
      expect(updatedUser[0].name).toBe("Updated Integration User");
      expect(updatedUser[0].role).toBe("manager");

      // Cleanup
      await db.delete(users).where(eq(users.id, createdUser[0].id));
    });

    it("should maintain data integrity across multiple operations", async () => {
      const testEmail = `integrity_${Date.now()}@example.com`;
      const usernames = [
        `user1_${Date.now()}`,
        `user2_${Date.now()}`,
        `user3_${Date.now()}`,
      ];

      // Create user with first username
      await db.insert(users).values({
        email: testEmail,
        name: "Integrity Test User",
        username: usernames[0],
        role: "user",
        openId: `temp-${Date.now()}`,
        loginMethod: "manual",
      });

      let user = await db
        .select()
        .from(users)
        .where(eq(users.email, testEmail))
        .limit(1);

      expect(user[0].username).toBe(usernames[0]);

      // Update to second username
      await db
        .update(users)
        .set({ username: usernames[1] })
        .where(eq(users.id, user[0].id));

      user = await db
        .select()
        .from(users)
        .where(eq(users.id, user[0].id))
        .limit(1);

      expect(user[0].username).toBe(usernames[1]);

      // Update to third username
      await db
        .update(users)
        .set({ username: usernames[2] })
        .where(eq(users.id, user[0].id));

      user = await db
        .select()
        .from(users)
        .where(eq(users.id, user[0].id))
        .limit(1);

      expect(user[0].username).toBe(usernames[2]);

      // Cleanup
      await db.delete(users).where(eq(users.id, user[0].id));
    });
  });
});
