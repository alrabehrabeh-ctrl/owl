import { z } from "zod";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { roleSettings } from "../drizzle/role-settings.schema";
import { TRPCError } from "@trpc/server";
import { router, adminProcedure, protectedProcedure, publicProcedure } from "./_core/trpc";
import { sdk } from "./_core/sdk";
import { getSessionCookieOptions } from "./_core/cookies";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

export const usersRouter = router({
  // جلب جميع المستخدمين
  // ملاحظة: تم إيقاف نظام الصلاحيات مؤقتاً
  getAll: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    return await db.select().from(users).orderBy(users.createdAt);
  }),

  // جلب مستخدم واحد
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const user = await db
        .select()
        .from(users)
        .where(eq(users.id, input.id))
        .limit(1);

      if (user.length === 0) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "المستخدم غير موجود",
        });
      }

      return user[0];
    }),

  // تحديث مستخدم
  update: adminProcedure
    .input(
      z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          email: z.string().optional(),
          role: z.enum(["admin", "user"]).optional(),
        }),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // حماية حساب admin من التعديل
      const targetUser = await db
        .select()
        .from(users)
        .where(eq(users.id, input.id))
        .limit(1);

      if (targetUser.length > 0 && targetUser[0].username === 'admin') {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "لا يمكن تعديل حساب المسؤول الرئيسي",
        });
      }

      console.log(`[update] Updating user ${input.id} with data:`, input.data);

      const result = await db
        .update(users)
        .set(input.data)
        .where(eq(users.id, input.id));

      return result;
    }),

  // حذف مستخدم
  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // حماية حساب admin من الحذف
      const targetUser = await db
        .select()
        .from(users)
        .where(eq(users.id, input.id))
        .limit(1);

      if (targetUser.length > 0 && targetUser[0].username === 'admin') {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "لا يمكن حذف حساب المسؤول الرئيسي",
        });
      }

      const result = await db.delete(users).where(eq(users.id, input.id));

      return result;
    }),

  // إنشاء مستخدم
  create: adminProcedure
    .input(
      z.object({
        name: z.string(),
        email: z.string(),
        role: z.enum(["admin", "user"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const result = await db.insert(users).values({
        name: input.name,
        email: input.email,
        role: input.role,
        openId: `user-${Date.now()}`,
      });

      return result;
    }),

  // تبديل المستخدم
  // ملاحظة: استخدام adminProcedure للتأكد من أن المستخدم مسؤول
  switchUser: adminProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // التحقق من أن المستخدم الحالي هو مسؤول
      if (!ctx.user || ctx.user.role !== "admin") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "ليس لديك صلاحية لتبديل المستخدمين",
        });
      }

      const targetUser = await db
        .select()
        .from(users)
        .where(eq(users.id, input.userId))
        .limit(1);

      if (targetUser.length === 0) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "المستخدم غير موجود",
        });
      }

      try {
        console.log(`[switchUser] ===== STARTING USER SWITCH =====`);
        console.log(`[switchUser] Current user: ${ctx.user.id} (${ctx.user.name})`);
        console.log(`[switchUser] Target user: ${input.userId} (${targetUser[0].name})`);
        console.log(`[switchUser] Target user openId: ${targetUser[0].openId}`);
        
        const cookieOptions = getSessionCookieOptions(ctx.req);
        console.log(`[switchUser] Cookie options:`, cookieOptions);
        
        // Step 1: Delete old cookie using maxAge: 0
        ctx.res.cookie(COOKIE_NAME, '', { ...cookieOptions, maxAge: 0 });
        console.log(`[switchUser] Step 1: Old cookie deleted with maxAge: 0`);
        
        // Step 2: Create new session token for target user
        const sessionToken = await sdk.createSessionToken(targetUser[0].openId, {
          name: targetUser[0].name || "",
          expiresInMs: ONE_YEAR_MS,
        });
        console.log(`[switchUser] Step 2: Created new session token for target user`);
        console.log(`[switchUser] New token (first 50 chars): ${sessionToken.substring(0, 50)}...`);
        
        // Step 3: Set new cookie
        ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
        console.log(`[switchUser] Step 3: New cookie set with maxAge: ${ONE_YEAR_MS}`);
        console.log(`[switchUser] ===== USER SWITCH COMPLETED =====`);
        
        // Log successful switch
        try {
          if (ctx.user) {
            // Import userSwitchAuditLog if it exists
            // await db.insert(userSwitchAuditLog).values({
            //   switchedBy: ctx.user.id,
            //   switchedTo: input.userId,
            //   status: "success",
            //   ipAddress: ctx.req.ip || "unknown",
            // });
          }
        } catch (e) {
          console.error("Failed to log audit", e);
        }
        
        return targetUser[0];
      } catch (error) {
        console.error("[switchUser] Failed to create session token", error);
        
        // Log failed switch
        try {
          if (ctx.user && db) {
            // await db.insert(userSwitchAuditLog).values({
            //   switchedBy: ctx.user.id,
            //   switchedTo: input.userId,
            //   status: "failed",
            //   failureReason: error instanceof Error ? error.message : "Unknown error",
            //   ipAddress: ctx.req.ip || "unknown",
            // });
          }
        } catch (e) {
          console.error("Failed to log audit", e);
        }
        
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to switch user",
        });
      }
    }),

  // ملاحظة: تم إيقاف نظام الصلاحيات مؤقتاً
  getAvailableForSwitch: publicProcedure.query(async ({ ctx }: any) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    const allUsers = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        role: users.role,
      })
      .from(users)
      .orderBy(users.createdAt);

    return allUsers;
  }),
});
