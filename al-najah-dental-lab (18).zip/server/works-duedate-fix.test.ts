import { describe, it, expect } from "vitest";

/**
 * اختبار إصلاح مشكلة dueDate في صفحة الأعمال
 * 
 * المشكلة الأصلية:
 * - عند إنشاء عمل جديد، إذا لم يتم إدخال تاريخ التسليم (deliveryDate)
 * - يتم محاولة new Date("") مما ينتج عن Invalid Date
 * - يتم إرسال null للخادم مما يسبب خطأ Zod validation
 * 
 * الحل:
 * - إضافة تحقق من formData.deliveryDate قبل الإرسال
 * - إذا كانت فارغة، استخدام التاريخ الافتراضي (5 أيام من تاريخ الاستقبال)
 * - إذا فشل الحساب الافتراضي، استخدام تاريخ الاستقبال نفسه
 */

describe("Works Page - dueDate Fix", () => {
  /**
   * دالة محاكاة لحساب تاريخ التسليم الافتراضي
   * (نفس الدالة المستخدمة في صفحة الأعمال)
   */
  const calculateDefaultDeliveryDate = (receptionDate: string) => {
    const date = new Date(receptionDate);
    date.setDate(date.getDate() + 5);
    return date.toISOString().split("T")[0];
  };

  /**
   * دالة محاكاة لمعالجة dueDate عند الإرسال
   * (نفس المنطق المستخدم في handleSubmit)
   */
  const processDueDate = (
    deliveryDate: string,
    receptionDate: string
  ): Date => {
    const dueDate = deliveryDate
      ? new Date(deliveryDate)
      : calculateDefaultDeliveryDate(receptionDate)
        ? new Date(calculateDefaultDeliveryDate(receptionDate))
        : new Date(receptionDate);
    return dueDate;
  };

  it("should use provided deliveryDate when it is not empty", () => {
    const receptionDate = "2026-02-24";
    const deliveryDate = "2026-03-05";

    const result = processDueDate(deliveryDate, receptionDate);

    expect(result).toBeInstanceOf(Date);
    expect(result.toISOString().split("T")[0]).toBe("2026-03-05");
  });

  it("should calculate default deliveryDate when it is empty", () => {
    const receptionDate = "2026-02-24";
    const deliveryDate = ""; // فارغ

    const result = processDueDate(deliveryDate, receptionDate);

    expect(result).toBeInstanceOf(Date);
    // التاريخ الافتراضي هو 5 أيام لاحقة
    expect(result.toISOString().split("T")[0]).toBe("2026-03-01");
  });

  it("should fallback to receptionDate if calculation fails", () => {
    const receptionDate = "2026-02-24";
    const deliveryDate = "";

    const result = processDueDate(deliveryDate, receptionDate);

    expect(result).toBeInstanceOf(Date);
    expect(result.getTime()).toBeGreaterThanOrEqual(
      new Date(receptionDate).getTime()
    );
  });

  it("should never return null or Invalid Date", () => {
    const testCases = [
      { receptionDate: "2026-02-24", deliveryDate: "" },
      { receptionDate: "2026-02-24", deliveryDate: "2026-03-05" },
      { receptionDate: "2026-01-01", deliveryDate: "" },
    ];

    testCases.forEach(({ receptionDate, deliveryDate }) => {
      const result = processDueDate(deliveryDate, receptionDate);

      expect(result).toBeInstanceOf(Date);
      expect(isNaN(result.getTime())).toBe(false);
      expect(result).not.toBeNull();
    });
  });

  it("should handle edge cases correctly", () => {
    // حالة: تاريخ استقبال في نهاية الشهر
    const receptionDate = "2026-02-28";
    const deliveryDate = "";

    const result = processDueDate(deliveryDate, receptionDate);

    expect(result).toBeInstanceOf(Date);
    expect(isNaN(result.getTime())).toBe(false);
    // يجب أن يكون التاريخ الافتراضي 5 أيام لاحقة
    const expectedDate = new Date(receptionDate);
    expectedDate.setDate(expectedDate.getDate() + 5);
    expect(result.toISOString().split("T")[0]).toBe(
      expectedDate.toISOString().split("T")[0]
    );
  });

  it("should validate that dueDate is always a valid Date object", () => {
    const receptionDate = "2026-02-24";
    const deliveryDates = ["", "2026-03-05", "2026-02-25"];

    deliveryDates.forEach((deliveryDate) => {
      const result = processDueDate(deliveryDate, receptionDate);

      // التحقق من أن النتيجة هي Date صحيحة
      expect(result).toBeInstanceOf(Date);
      expect(result.toString()).not.toBe("Invalid Date");
      expect(typeof result.getTime()).toBe("number");
      expect(result.getTime()).toBeGreaterThan(0);
    });
  });
});
