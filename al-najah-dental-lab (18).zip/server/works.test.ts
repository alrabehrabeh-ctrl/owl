import { describe, it, expect, beforeAll, afterAll } from "vitest";
import * as db from "./db";

describe("Works Database Functions", () => {
  describe("getAllWorks", () => {
    it("should return works with doctor names", async () => {
      const works = await db.getAllWorks();
      
      // التحقق من أن النتيجة مصفوفة
      expect(Array.isArray(works)).toBe(true);
      
      // إذا كانت هناك أعمال، تحقق من أن كل عمل يحتوي على doctorName
      if (works.length > 0) {
        works.forEach((work: any) => {
          expect(work).toHaveProperty("id");
          expect(work).toHaveProperty("doctorId");
          expect(work).toHaveProperty("doctorName");
          expect(work).toHaveProperty("workTypeName");
          expect(work).toHaveProperty("receptionDate");
          expect(work).toHaveProperty("patientName");
        });
      }
    });

    it("should include doctor name instead of just doctorId", async () => {
      const works = await db.getAllWorks();
      
      if (works.length > 0) {
        const firstWork = works[0];
        // التحقق من أن doctorName موجود وليس undefined
        if (firstWork.doctorId) {
          expect(firstWork.doctorName).toBeDefined();
          expect(typeof firstWork.doctorName).toBe("string");
        }
      }
    });

    it("should include work type name", async () => {
      const works = await db.getAllWorks();
      
      if (works.length > 0) {
        const firstWork = works[0];
        // إذا كان هناك workTypeId، يجب أن يكون هناك workTypeName
        if (firstWork.workTypeId) {
          expect(firstWork.workTypeName).toBeDefined();
        }
      }
    });

    it("should respect limit parameter", async () => {
      const allWorks = await db.getAllWorks();
      const limitedWorks = await db.getAllWorks(5);
      
      if (allWorks.length > 5) {
        expect(limitedWorks.length).toBeLessThanOrEqual(5);
      }
    });
  });
});
